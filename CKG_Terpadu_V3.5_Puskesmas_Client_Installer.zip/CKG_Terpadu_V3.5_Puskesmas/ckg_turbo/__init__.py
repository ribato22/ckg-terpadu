"""Sehat Indonesiaku - CKG Sekolah Turbo Engine (Cross-Platform Background RPA)."""

__version__ = "3.0.0"

