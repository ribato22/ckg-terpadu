from __future__ import annotations

import contextlib
import datetime as dt
import json
import sqlite3
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional

from .models import StudentRecord


class StateDB:
    """Thread-safe SQLite checkpoint store for CKG Sekolah batch jobs."""

    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._init_schema()

    @contextlib.contextmanager
    def _connect(self):
        conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        conn.row_factory = sqlite3.Row
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _init_schema(self) -> None:
        with self._lock, self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS student_checkpoints (
                    file_key TEXT NOT NULL,
                    row_index INTEGER NOT NULL,
                    nik TEXT,
                    nama TEXT,
                    status_sistem TEXT,
                    status_rapor TEXT,
                    tatalaksana TEXT,
                    no_tiket TEXT,
                    state TEXT,
                    last_step TEXT,
                    updated_at TEXT,
                    PRIMARY KEY (file_key, row_index)
                );

                CREATE TABLE IF NOT EXISTS app_settings (
                    key TEXT PRIMARY KEY,
                    value_json TEXT NOT NULL
                );
                """
            )

    def save_student_checkpoint(self, file_key: str, student: StudentRecord) -> None:
        now_str = dt.datetime.now().strftime("%H:%M:%S")
        student.updated_at = now_str
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                INSERT INTO student_checkpoints (
                    file_key, row_index, nik, nama,
                    status_sistem, status_rapor, tatalaksana, no_tiket,
                    state, last_step, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(file_key, row_index) DO UPDATE SET
                    nik=excluded.nik,
                    nama=excluded.nama,
                    status_sistem=excluded.status_sistem,
                    status_rapor=excluded.status_rapor,
                    tatalaksana=excluded.tatalaksana,
                    no_tiket=excluded.no_tiket,
                    state=excluded.state,
                    last_step=excluded.last_step,
                    updated_at=excluded.updated_at
                """,
                (
                    file_key,
                    student.row_index,
                    student.nik,
                    student.nama,
                    student.status_sistem,
                    student.status_rapor,
                    student.tatalaksana,
                    student.no_tiket,
                    student.state,
                    student.last_step,
                    now_str,
                ),
            )

    def restore_checkpoints(self, file_key: str, students: List[StudentRecord]) -> int:
        """Restore saved checkpoints for a given Excel file key. Returns count of restored rows."""
        with self._lock, self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM student_checkpoints WHERE file_key = ?",
                (file_key,),
            ).fetchall()

        by_idx = {r["row_index"]: r for r in rows}
        restored = 0
        for s in students:
            saved = by_idx.get(s.row_index)
            if saved and saved["nik"] == s.nik:
                s.status_sistem = saved["status_sistem"] or "-"
                s.status_rapor = saved["status_rapor"] or "-"
                s.tatalaksana = saved["tatalaksana"] or "-"
                if saved["no_tiket"] and saved["no_tiket"] != "-":
                    s.no_tiket = saved["no_tiket"]
                s.state = saved["state"] or "pending"
                if s.state == "running":
                    s.state = "pending"
                # Auto-heal false-positive 'SUKSES (Draft ...)' where Selesaikan Layanan was not completed
                if s.status_sistem.startswith("SUKSES (Draft"):
                    s.state = "failed"
                    s.status_sistem = "Belum Selesai: Masih di Sedang Pemeriksaan (Klik Mulai / Ulangi)"
                s.last_step = saved["last_step"] or ""
                s.updated_at = saved["updated_at"] or ""
                if s.state in ("success", "failed", "skipped", "warning"):
                    restored += 1
        return restored

    def clear_checkpoints(self, file_key: str, preserve_tickets: bool = True) -> None:
        with self._lock, self._connect() as conn:
            if preserve_tickets:
                conn.execute(
                    """
                    UPDATE student_checkpoints
                    SET state = 'pending',
                        status_sistem = '-',
                        status_rapor = '-',
                        tatalaksana = '-',
                        last_step = ''
                    WHERE file_key = ?
                    """,
                    (file_key,),
                )
            else:
                conn.execute("DELETE FROM student_checkpoints WHERE file_key = ?", (file_key,))

    def save_setting(self, key: str, value: Any) -> None:
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                INSERT INTO app_settings (key, value_json) VALUES (?, ?)
                ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json
                """,
                (key, json.dumps(value)),
            )

    def get_setting(self, key: str, default: Any = None) -> Any:
        with self._lock, self._connect() as conn:
            row = conn.execute(
                "SELECT value_json FROM app_settings WHERE key = ?",
                (key,),
            ).fetchone()
        if not row:
            return default
        try:
            return json.loads(row["value_json"])
        except Exception:
            return default
