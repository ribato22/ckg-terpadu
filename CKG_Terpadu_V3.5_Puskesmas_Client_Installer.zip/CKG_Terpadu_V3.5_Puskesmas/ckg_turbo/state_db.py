from __future__ import annotations

import contextlib
import datetime as dt
import json
import sqlite3
import tempfile
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional

from .models import StudentRecord


def is_temp_runtime_path(path: Path) -> bool:
    """Return True if path resides inside an OS temporary directory (e.g. unit test sandboxes)."""
    s = str(path.resolve()).lower().replace("\\", "/")
    tmp_root = str(Path(tempfile.gettempdir()).resolve()).lower().replace("\\", "/")
    if s.startswith(tmp_root):
        return True
    return any(
         s.startswith(prefix)
        for prefix in ("/tmp/", "/private/tmp/", "/var/folders/", "/private/var/folders/")
    ) or "/temp/" in s


class StateDB:
    """Thread-safe SQLite checkpoint store for CKG Sekolah & Umum batch jobs with cross-update vault sync."""

    def __init__(self, db_path: str | Path, vault_dir: Optional[str | Path] = None) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        if vault_dir is not None:
            self.vault_dir: Optional[Path] = Path(vault_dir)
        elif is_temp_runtime_path(self.db_path):
            self.vault_dir = None
        else:
            self.vault_dir = Path.home() / ".ckg_terpadu_vault"

        self._mirror_db_path: Optional[Path] = None
        if self.vault_dir is not None:
            try:
                self.vault_dir.mkdir(parents=True, exist_ok=True)
                cand = (self.vault_dir / "checkpoints_mirror.db").resolve()
                if cand != self.db_path.resolve():
                    self._mirror_db_path = cand
            except Exception:
                self._mirror_db_path = None

        self._init_schema()
        self._sync_from_vault_mirror()

    @contextlib.contextmanager
    def _connect(self):
        conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        conn.row_factory = sqlite3.Row
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _init_schema(self) -> None:
        with self._lock, self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS student_checkpoints (
                    file_key TEXT NOT NULL,
                    row_index INTEGER NOT NULL,
                    nik TEXT,
                    nama TEXT,
                    status_sistem TEXT,
                    status_rapor TEXT,
                    tatalaksana TEXT,
                    no_tiket TEXT,
                    state TEXT,
                    last_step TEXT,
                    updated_at TEXT,
                    PRIMARY KEY (file_key, row_index)
                );

                CREATE TABLE IF NOT EXISTS app_settings (
                    key TEXT PRIMARY KEY,
                    value_json TEXT NOT NULL
                );
                """
            )
        if self._mirror_db_path is not None:
            try:
                with contextlib.closing(
                    sqlite3.connect(str(self._mirror_db_path), check_same_thread=False)
                ) as mconn:
                    mconn.executescript(
                        """
                        CREATE TABLE IF NOT EXISTS student_checkpoints (
                            file_key TEXT NOT NULL,
                            row_index INTEGER NOT NULL,
                            nik TEXT,
                            nama TEXT,
                            status_sistem TEXT,
                            status_rapor TEXT,
                            tatalaksana TEXT,
                            no_tiket TEXT,
                            state TEXT,
                            last_step TEXT,
                            updated_at TEXT,
                            PRIMARY KEY (file_key, row_index)
                        );
                        """
                    )
                    mconn.commit()
            except Exception:
                pass

    def _sync_from_vault_mirror(self) -> None:
        """Restore student checkpoints from the OS-level vault when opening a newly extracted app update folder."""
        if self._mirror_db_path is None or not self._mirror_db_path.exists():
            return
        try:
            with self._lock, self._connect() as conn, contextlib.closing(
                sqlite3.connect(str(self._mirror_db_path), check_same_thread=False)
            ) as mconn:
                mconn.row_factory = sqlite3.Row
                mirror_rows = mconn.execute("SELECT * FROM student_checkpoints").fetchall()
                for r in mirror_rows:
                    conn.execute(
                        """
                        INSERT OR IGNORE INTO student_checkpoints (
                            file_key, row_index, nik, nama,
                            status_sistem, status_rapor, tatalaksana, no_tiket,
                            state, last_step, updated_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            r["file_key"],
                            r["row_index"],
                            r["nik"],
                            r["nama"],
                            r["status_sistem"],
                            r["status_rapor"],
                            r["tatalaksana"],
                            r["no_tiket"],
                            r["state"],
                            r["last_step"],
                            r["updated_at"],
                        ),
                    )
                local_rows = conn.execute("SELECT * FROM student_checkpoints").fetchall()
                for r in local_rows:
                    mconn.execute(
                        """
                        INSERT OR IGNORE INTO student_checkpoints (
                            file_key, row_index, nik, nama,
                            status_sistem, status_rapor, tatalaksana, no_tiket,
                            state, last_step, updated_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            r["file_key"],
                            r["row_index"],
                            r["nik"],
                            r["nama"],
                            r["status_sistem"],
                            r["status_rapor"],
                            r["tatalaksana"],
                            r["no_tiket"],
                            r["state"],
                            r["last_step"],
                            r["updated_at"],
                        ),
                    )
                mconn.commit()
        except Exception:
            pass

    def save_student_checkpoint(self, file_key: str, student: StudentRecord) -> None:
        now_str = dt.datetime.now().strftime("%H:%M:%S")
        student.updated_at = now_str
        params = (
            file_key,
            student.row_index,
            student.nik,
            student.nama,
            student.status_sistem,
            student.status_rapor,
            student.tatalaksana,
            student.no_tiket,
            student.state,
            student.last_step,
            now_str,
        )
        upsert_sql = """
            INSERT INTO student_checkpoints (
                file_key, row_index, nik, nama,
                status_sistem, status_rapor, tatalaksana, no_tiket,
                state, last_step, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(file_key, row_index) DO UPDATE SET
                nik=excluded.nik,
                nama=excluded.nama,
                status_sistem=excluded.status_sistem,
                status_rapor=excluded.status_rapor,
                tatalaksana=excluded.tatalaksana,
                no_tiket=excluded.no_tiket,
                state=excluded.state,
                last_step=excluded.last_step,
                updated_at=excluded.updated_at
        """
        with self._lock, self._connect() as conn:
            conn.execute(upsert_sql, params)
        if self._mirror_db_path is not None:
            try:
                with contextlib.closing(
                    sqlite3.connect(str(self._mirror_db_path), check_same_thread=False)
                ) as mconn:
                    mconn.execute(upsert_sql, params)
                    mconn.commit()
            except Exception:
                pass

    def restore_checkpoints(self, file_key: str, students: List[StudentRecord]) -> int:
        """Restore saved checkpoints for a given Excel file key. Returns count of restored rows."""
        with self._lock, self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM student_checkpoints WHERE file_key = ?",
                (file_key,),
            ).fetchall()

        by_idx = {r["row_index"]: r for r in rows}
        restored = 0
        for s in students:
            saved = by_idx.get(s.row_index)
            if saved and saved["nik"] == s.nik:
                s.status_sistem = saved["status_sistem"] or "-"
                s.status_rapor = saved["status_rapor"] or "-"
                s.tatalaksana = saved["tatalaksana"] or "-"
                if saved["no_tiket"] and saved["no_tiket"] != "-":
                    s.no_tiket = saved["no_tiket"]
                s.state = saved["state"] or "pending"
                if s.state == "running":
                    s.state = "pending"
                # Auto-heal false-positive 'SUKSES (Draft ...)' where Selesaikan Layanan was not completed
                if s.status_sistem.startswith("SUKSES (Draft"):
                    s.state = "failed"
                    s.status_sistem = "Belum Selesai: Masih di Sedang Pemeriksaan (Klik Mulai / Ulangi)"
                s.last_step = saved["last_step"] or ""
                s.updated_at = saved["updated_at"] or ""
                if s.state in ("success", "failed", "skipped", "warning"):
                    restored += 1
        return restored

    def clear_checkpoints(self, file_key: str, preserve_tickets: bool = True) -> None:
        with self._lock, self._connect() as conn:
            if preserve_tickets:
                conn.execute(
                    """
                    UPDATE student_checkpoints
                    SET state = 'pending',
                        status_sistem = '-',
                        status_rapor = '-',
                        tatalaksana = '-',
                        last_step = ''
                    WHERE file_key = ?
                    """,
                    (file_key,),
                )
            else:
                conn.execute("DELETE FROM student_checkpoints WHERE file_key = ?", (file_key,))
        if self._mirror_db_path is not None and self._mirror_db_path.exists():
            try:
                with contextlib.closing(
                    sqlite3.connect(str(self._mirror_db_path), check_same_thread=False)
                ) as mconn:
                    if preserve_tickets:
                        mconn.execute(
                            """
                            UPDATE student_checkpoints
                            SET state = 'pending',
                                status_sistem = '-',
                                status_rapor = '-',
                                tatalaksana = '-',
                                last_step = ''
                            WHERE file_key = ?
                            """,
                            (file_key,),
                        )
                    else:
                        mconn.execute("DELETE FROM student_checkpoints WHERE file_key = ?", (file_key,))
                    mconn.commit()
            except Exception:
                pass

    def save_setting(self, key: str, value: Any) -> None:
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                INSERT INTO app_settings (key, value_json) VALUES (?, ?)
                ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json
                """,
                (key, json.dumps(value)),
            )

    def get_setting(self, key: str, default: Any = None) -> Any:
        with self._lock, self._connect() as conn:
            row = conn.execute(
                "SELECT value_json FROM app_settings WHERE key = ?",
                (key,),
            ).fetchone()
        if not row:
            return default
        try:
            return json.loads(row["value_json"])
        except Exception:
            return default
