from __future__ import annotations

import base64
import datetime as dt
import hashlib
import hmac
import json
import os
import platform
import re
import shutil
import subprocess
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .state_db import StateDB

# Master HMAC secret for local hardware ledger & Starter Trial (capped at <=30 quota, <=14 days)
_SAAS_MASTER_SECRET = b"CKG-CLINICAL-PRO-V3-HYBRID-SAAS-2026-MASTER-KEY"
# NIST SP 800-132 PBKDF2-HMAC-SHA256 (100,000 iterations) digest of Owner PIN (plaintext PIN is never stored in code)
_OWNER_PIN_PBKDF2_DIGEST = "3D853ECA91830A591ABC6EAE7ABC063C6D14016DD42A995D466C9E8EF50BF1EC"
_OWNER_PIN_PBKDF2_ITERATIONS = 100_000
_PIN_MAX_FAILED_ATTEMPTS = 5
_PIN_LOCKOUT_SECONDS = 300
_CACHED_MACHINE_FINGERPRINT: Optional[str] = None

# NIST P-256 (secp256r1 / FIPS 186-5) Asymmetric Public-Key Cryptography for Paid Licenses
# Private signing scalar NEVER exists in source code or Client ZIP; only the Public Key Point Q=(Qx, Qy) is embedded.
_P256_P = 0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF
_P256_N = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551
_P256_A = _P256_P - 3
_P256_G = (
    0x6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296,
    0x4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5,
)
_P256_PUB_Q = (
    0x551F38537AFAB262BCF9C8701B98D60590B4F69E22E8A8B2C77DA1FFBABB46F7,
    0x74BE99494900BCB484CF7C2CD599B9A75D234BCAC822CFAF5F4FC28688DE9574,
)
_CACHED_OWNER_PRIV_SCALAR: Optional[int] = None
_P256_VERIFY_CACHE: Dict[str, bool] = {}


def _p256_pt_add(
    p1: Optional[Tuple[int, int]], p2: Optional[Tuple[int, int]]
) -> Optional[Tuple[int, int]]:
    if p1 is None:
        return p2
    if p2 is None:
        return p1
    x1, y1 = p1
    x2, y2 = p2
    if x1 == x2:
        if (y1 + y2) % _P256_P == 0:
            return None
        lam = (3 * x1 * x1 + _P256_A) * pow(2 * y1, _P256_P - 2, _P256_P) % _P256_P
    else:
        lam = (y2 - y1) * pow(x2 - x1, _P256_P - 2, _P256_P) % _P256_P
    x3 = (lam * lam - x1 - x2) % _P256_P
    y3 = (lam * (x1 - x3) - y1) % _P256_P
    return (x3, y3)


def _p256_pt_mul(k: int, pt: Tuple[int, int]) -> Optional[Tuple[int, int]]:
    res: Optional[Tuple[int, int]] = None
    addend: Optional[Tuple[int, int]] = pt
    scalar = int(k)
    while scalar > 0:
        if scalar & 1:
            res = _p256_pt_add(res, addend)
        addend = _p256_pt_add(addend, addend)
        scalar >>= 1
    return res


def _resolve_owner_p256_priv_scalar(owner_pin: str = "") -> Optional[int]:
    """Derive or load the Owner's NIST P-256 private signing scalar (never present in Client ZIP)."""
    global _CACHED_OWNER_PRIV_SCALAR
    if _CACHED_OWNER_PRIV_SCALAR is not None:
        return _CACHED_OWNER_PRIV_SCALAR

    pin_clean = (owner_pin or os.environ.get("CKG_OWNER_PIN") or "").strip()
    if pin_clean:
        cand = (
            int.from_bytes(
                hashlib.pbkdf2_hmac(
                    "sha256",
                    pin_clean.encode("utf-8"),
                    b"CKG-P256-OWNER-SIGNING-KEY-V3.5",
                    _OWNER_PIN_PBKDF2_ITERATIONS,
                ),
                "big",
            )
            % (_P256_N - 1)
            + 1
        )
        if _p256_pt_mul(cand, _P256_G) == _P256_PUB_Q:
            _CACHED_OWNER_PRIV_SCALAR = cand
            return cand

    key_file = Path(__file__).resolve().parent.parent / ".owner_studio.key"
    if key_file.is_file():
        try:
            raw_txt = key_file.read_text(encoding="utf-8", errors="ignore").strip()
            if ":" in raw_txt:
                hex_part = raw_txt.split(":", 1)[1].strip()
                cand_file = int(hex_part, 16)
                if 1 <= cand_file < _P256_N and _p256_pt_mul(cand_file, _P256_G) == _P256_PUB_Q:
                    _CACHED_OWNER_PRIV_SCALAR = cand_file
                    return cand_file
        except Exception:
            pass
    return None


def _p256_schnorr_sign(msg: bytes, priv_x: int) -> str:
    """Create a deterministic 48-byte (64-char base64url) Schnorr signature over NIST P-256."""
    k = (
        int.from_bytes(hmac.new(priv_x.to_bytes(32, "big"), msg, hashlib.sha256).digest(), "big")
        % (_P256_N - 1)
        + 1
    )
    r_pt = _p256_pt_mul(k, _P256_G)
    assert r_pt is not None
    e = int.from_bytes(
        hashlib.sha256(r_pt[0].to_bytes(32, "big") + r_pt[1].to_bytes(32, "big") + msg).digest()[:16],
        "big",
    )
    s = (k - e * priv_x) % _P256_N
    sig_bytes = e.to_bytes(16, "big") + s.to_bytes(32, "big")
    return _b64url_encode(sig_bytes)


def _p256_schnorr_verify(msg: bytes, sig_b64: str) -> bool:
    """Verify a 48-byte Schnorr signature over NIST P-256 using ONLY Public Key _P256_PUB_Q."""
    cache_key = f"{msg.decode('ascii', errors='ignore')}.{sig_b64}"
    if cache_key in _P256_VERIFY_CACHE:
        return _P256_VERIFY_CACHE[cache_key]
    try:
        raw = _b64url_decode(sig_b64)
        if len(raw) != 48:
            return False
        e = int.from_bytes(raw[:16], "big")
        s = int.from_bytes(raw[16:], "big")
        if not (1 <= s < _P256_N and e > 0):
            return False
        r_v = _p256_pt_add(_p256_pt_mul(s, _P256_G), _p256_pt_mul(e, _P256_PUB_Q))
        if r_v is None:
            return False
        e_v = int.from_bytes(
            hashlib.sha256(r_v[0].to_bytes(32, "big") + r_v[1].to_bytes(32, "big") + msg).digest()[:16],
            "big",
        )
        ok = hmac.compare_digest(e.to_bytes(16, "big"), e_v.to_bytes(16, "big"))
        if len(_P256_VERIFY_CACHE) > 512:
            _P256_VERIFY_CACHE.clear()
        _P256_VERIFY_CACHE[cache_key] = ok
        return ok
    except Exception:
        return False

PLAN_DEFINITIONS: Dict[str, Dict[str, Any]] = {
    "TRIAL": {
        "code": "TRIAL",
        "name": "Starter Trial (Uji Coba Gratis)",
        "badge": "TRIAL 30 PESERTA",
        "max_workers": 1,
        "default_quota": 30,
        "default_days": 14,
        "allowed_services": ["sekolah", "umum"],
    },
    "PAKET_BULANAN": {
        "code": "PAKET_BULANAN",
        "name": "Paket Hemat Bulanan (Sekolah & Umum)",
        "badge": "PRO 300 PESERTA",
        "max_workers": 2,
        "default_quota": 300,
        "default_days": 30,
        "allowed_services": ["sekolah", "umum"],
    },
    "PRO_SEKOLAH": {
        "code": "PRO_SEKOLAH",
        "name": "Paket CKG Sekolah (Khusus Anak Sekolah)",
        "badge": "PRO SEKOLAH",
        "max_workers": 3,
        "default_quota": 3000,
        "default_days": 180,
        "allowed_services": ["sekolah"],
    },
    "PRO_UMUM": {
        "code": "PRO_UMUM",
        "name": "Paket CKG Umum (Khusus Dewasa & Lansia)",
        "badge": "PRO UMUM",
        "max_workers": 3,
        "default_quota": 3000,
        "default_days": 180,
        "allowed_services": ["umum"],
    },
    "PRO_PUSKESMAS": {
        "code": "PRO_PUSKESMAS",
        "name": "Clinical Pro Puskesmas (Sekolah + Umum)",
        "badge": "PRO PUSKESMAS",
        "max_workers": 4,
        "default_quota": 50000,
        "default_days": 365,
        "allowed_services": ["sekolah", "umum"],
    },
    "ENTERPRISE_DINKES": {
        "code": "ENTERPRISE_DINKES",
        "name": "Enterprise Dinkes & Owner Studio (Multi-Faskes)",
        "badge": "ENTERPRISE SAAS",
        "max_workers": 4,
        "default_quota": 999999,
        "default_days": 3650,
        "allowed_services": ["sekolah", "umum"],
    },
}


def _get_os_immutable_hardware_uuid() -> str:
    """Query immutable motherboard/OS hardware UUID so changing hostname or Wi-Fi MAC cannot alter machine_id."""
    sys_name = platform.system().lower()
    try:
        if sys_name == "darwin":
            out = subprocess.check_output(
                ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                text=True,
                stderr=subprocess.DEVNULL,
                timeout=2.0,
            )
            m = re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', out)
            if m and m.group(1).strip():
                return m.group(1).strip().upper()
        elif sys_name == "windows":
            import winreg  # type: ignore[import-not-found]

            with winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"SOFTWARE\Microsoft\Cryptography",
                0,
                winreg.KEY_READ | getattr(winreg, "KEY_WOW64_64KEY", 0),
            ) as key:
                val, _ = winreg.QueryValueEx(key, "MachineGuid")
                if val and str(val).strip():
                    return str(val).strip().upper()
        else:
            for mid_path in (Path("/etc/machine-id"), Path("/var/lib/dbus/machine-id")):
                if mid_path.is_file():
                    mid = mid_path.read_text(encoding="utf-8", errors="ignore").strip()
                    if mid:
                        return mid.upper()
    except Exception:
        pass
    return f"{platform.node()}-{uuid.getnode()}"


def _get_legacy_machine_fingerprint() -> str:
    """Legacy hardware fingerprint (pre-IOPlatformUUID) for seamless ledger migration on existing installs."""
    raw = f"{platform.system()}-{platform.machine()}-{platform.node()}-{uuid.getnode()}"
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest().upper()
    return f"CKG-{digest[:4]}-{digest[4:8]}-{digest[8:12]}"


def get_machine_fingerprint() -> str:
    """Generate a deterministic, immutable hardware fingerprint for SaaS node binding."""
    global _CACHED_MACHINE_FINGERPRINT
    if _CACHED_MACHINE_FINGERPRINT:
        return _CACHED_MACHINE_FINGERPRINT
    hw_uuid = _get_os_immutable_hardware_uuid()
    raw = f"{platform.system()}-{platform.machine()}-{hw_uuid}"
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest().upper()
    _CACHED_MACHINE_FINGERPRINT = f"CKG-{digest[:4]}-{digest[4:8]}-{digest[8:12]}"
    return _CACHED_MACHINE_FINGERPRINT


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _b64url_decode(s: str) -> bytes:
    pad = "=" * ((4 - len(s) % 4) % 4)
    return base64.urlsafe_b64decode(s + pad)


def _decode_jwt_exp(token_str: str) -> Optional[int]:
    """Extract 'exp' timestamp from a JWT string without external dependencies."""
    if not token_str or token_str.count(".") != 2:
        return None
    try:
        payload_b64 = token_str.split(".")[1]
        payload = json.loads(_b64url_decode(payload_b64).decode("utf-8"))
        exp = payload.get("exp")
        return int(exp) if exp else None
    except Exception:
        return None


class SessionVault:
    """
    Enterprise Multi-Account Session Vault for CKG Sekolah V3.3 SaaS.
    Manages up to 4 independent Kemenkes Nakes account slots (slot_1 .. slot_4),
    enabling true multi-worker parallel execution without Kemenkes single-device collisions.
    """

    MAX_SLOTS = 4

    def __init__(self, data_dir: Path, state_db: StateDB) -> None:
        self.data_dir = Path(data_dir)
        self.state_db = state_db
        self.sessions_dir = self.data_dir / "sessions"
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.legacy_storage_path = self.data_dir / "storage_state.json"

        # Runtime health overrides (slot_id -> {"expired": bool, "reason": str, "verified_at": str})
        self._runtime_state: Dict[int, Dict[str, Any]] = {}
        self._migrate_legacy_session()

    def _migrate_legacy_session(self) -> None:
        """Ensure existing data/storage_state.json is mirrored into Slot #1."""
        slot1_path = self.get_slot_path(1)
        if self.legacy_storage_path.exists() and self.legacy_storage_path.stat().st_size > 50:
            if (
                not slot1_path.exists()
                or self.legacy_storage_path.stat().st_mtime > slot1_path.stat().st_mtime
            ):
                try:
                    shutil.copy2(self.legacy_storage_path, slot1_path)
                except Exception:
                    pass
        elif slot1_path.exists() and slot1_path.stat().st_size > 50:
            try:
                shutil.copy2(slot1_path, self.legacy_storage_path)
            except Exception:
                pass

    def get_slot_path(self, slot_id: int) -> Path:
        slot_id = max(1, min(self.MAX_SLOTS, int(slot_id)))
        return self.sessions_dir / f"slot_{slot_id}.json"

    def sync_slot_to_legacy(self, slot_id: int = 1) -> None:
        """Keep data/storage_state.json synced with Slot #1 (or first active slot)."""
        src = self.get_slot_path(slot_id)
        if src.exists() and src.stat().st_size > 50:
            try:
                shutil.copy2(src, self.legacy_storage_path)
            except Exception:
                pass

    def mark_slot_expired(self, slot_id: int, reason: str = "Sesi berakhir") -> None:
        self._runtime_state[slot_id] = {
            "expired": True,
            "reason": reason,
            "updated_at": dt.datetime.now().strftime("%H:%M:%S"),
        }

    def mark_slot_healthy(self, slot_id: int) -> None:
        self._runtime_state[slot_id] = {
            "expired": False,
            "reason": "",
            "verified_at": dt.datetime.now().strftime("%H:%M:%S"),
        }
        if slot_id == 1 or not self.legacy_storage_path.exists():
            self.sync_slot_to_legacy(slot_id)

    def delete_slot(self, slot_id: int) -> None:
        path = self.get_slot_path(slot_id)
        if path.exists():
            try:
                path.unlink()
            except Exception:
                pass
        if slot_id == 1 and self.legacy_storage_path.exists():
            try:
                self.legacy_storage_path.unlink()
            except Exception:
                pass
        self._runtime_state.pop(slot_id, None)

    def inspect_slot(self, slot_id: int) -> Dict[str, Any]:
        """Parse storage_state JSON for a slot and extract officer, Faskes, and token health."""
        slot_id = max(1, min(self.MAX_SLOTS, int(slot_id)))
        path = self.get_slot_path(slot_id)
        if slot_id == 1 and not path.exists() and self.legacy_storage_path.exists():
            self._migrate_legacy_session()

        info: Dict[str, Any] = {
            "slot_id": slot_id,
            "label": f"Akun Nakes #{slot_id}",
            "has_file": False,
            "status": "empty",  # empty | active | expiring_soon | expired
            "status_label": "Slot Kosong",
            "officer_name": "",
            "faskes_name": "",
            "jabatan": "",
            "email": "",
            "nik": "",
            "region": "",
            "saved_at": "-",
            "age_minutes": 0,
            "jwt_remaining_minutes": None,
            "stk_remaining_minutes": None,
            "refresh_remaining_minutes": None,
            "keepalive_enabled": True,
            "verified_at": self._runtime_state.get(slot_id, {}).get("verified_at", ""),
            "error_reason": self._runtime_state.get(slot_id, {}).get("reason", ""),
        }

        if not path.exists() or path.stat().st_size <= 50:
            return info

        try:
            stat = path.stat()
            mtime_dt = dt.datetime.fromtimestamp(stat.st_mtime)
            age_sec = max(0.0, time.time() - stat.st_mtime)
            info["has_file"] = True
            info["saved_at"] = mtime_dt.strftime("%d %b %H:%M")
            info["age_minutes"] = int(age_sec // 60)

            raw = json.loads(path.read_text(encoding="utf-8"))
            origins = raw.get("origins", [])
            cookies = raw.get("cookies", [])

            jwt_exp: Optional[int] = None
            stk_exp: Optional[int] = None
            refresh_exp: Optional[int] = None
            has_auth_entry = False

            for origin in origins:
                for item in origin.get("localStorage", []):
                    k = (item.get("name") or "").strip()
                    v = item.get("value") or ""
                    if k == "user_eksternal" and v:
                        has_auth_entry = True
                        try:
                            u = json.loads(v)
                            info["faskes_name"] = (
                                u.get("faskes_name")
                                or u.get("health_centre_name")
                                or u.get("sarana_binaan_name")
                                or u.get("nama_faskes")
                                or u.get("namaFaskes")
                                or u.get("instansi")
                                or ""
                            ).strip()
                            info["officer_name"] = (
                                u.get("name")
                                or u.get("nama")
                                or u.get("full_name")
                                or ""
                            ).strip()
                            info["jabatan"] = (
                                u.get("job_position_name")
                                or u.get("instance_position")
                                or u.get("jabatan")
                                or u.get("role_name")
                                or ""
                            ).strip()
                            info["email"] = (u.get("email") or "").strip()
                            info["nik"] = (u.get("nik") or u.get("identity_number") or "").strip()
                            prov = (u.get("provinsi_name") or u.get("namaProvinsi") or "").strip()
                            kab = (u.get("kabkota_name") or u.get("namaKabKota") or "").strip()
                            info["region"] = " • ".join(p for p in (kab, prov) if p)
                            for tk_field in ("token", "access_token", "jwt"):
                                if isinstance(u.get(tk_field), str):
                                    exp_cand = _decode_jwt_exp(u[tk_field])
                                    if exp_cand:
                                        jwt_exp = exp_cand
                        except Exception:
                            pass
                    elif k.lower() in ("token", "access_token", "auth_token", "jwt") and v:
                        has_auth_entry = True
                        exp_cand = _decode_jwt_exp(v.strip('"'))
                        if exp_cand:
                            jwt_exp = exp_cand

            for c in cookies:
                c_name = (c.get("name") or "").strip().lower()
                c_val = c.get("value") or ""
                c_exp = c.get("expires")
                c_exp_int = int(c_exp) if isinstance(c_exp, (int, float)) and c_exp > 0 else None
                if c_name in ("asik_web_stk", "asik_web_ctk") and c_exp_int:
                    stk_exp = c_exp_int if stk_exp is None else min(stk_exp, c_exp_int)
                    has_auth_entry = True
                elif c_name == "refresh_token" and c_exp_int:
                    refresh_exp = c_exp_int
                    has_auth_entry = True
                elif c_name in ("token_eksternal", "access_menu") and c_exp_int:
                    jwt_exp = c_exp_int
                    has_auth_entry = True
                if c_val.count(".") == 2:
                    exp_cand = _decode_jwt_exp(c_val)
                    if exp_cand:
                        jwt_exp = exp_cand
                        has_auth_entry = True

            if len(cookies) > 0:
                has_auth_entry = True

            now_ts = int(time.time())
            if stk_exp:
                info["stk_remaining_minutes"] = int((stk_exp - now_ts) // 60)
            if refresh_exp:
                info["refresh_remaining_minutes"] = int((refresh_exp - now_ts) // 60)

            rt = self._runtime_state.get(slot_id, {})
            if rt.get("expired"):
                info["status"] = "expired"
                info["status_label"] = "Sesi Berakhir (Perlu Login)"
                return info

            if jwt_exp:
                rem_sec = jwt_exp - now_ts
                info["jwt_remaining_minutes"] = int(rem_sec // 60)
                if rem_sec <= 0 and (not refresh_exp or refresh_exp <= now_ts):
                    info["status"] = "expired"
                    info["status_label"] = "Token Kedaluwarsa"
                    return info
                if 0 < rem_sec < 1800:
                    info["status"] = "expiring_soon"
                    info["status_label"] = f"Aktif • Auto-KeepAlive ({max(1, int(rem_sec // 60))} mnt)"
                    return info

            if has_auth_entry:
                info["status"] = "active"
                info["status_label"] = "Aktif • Auto-KeepAlive"
            else:
                info["status"] = "expired"
                info["status_label"] = "Belum Terautentikasi"

        except Exception as exc:
            info["status"] = "expired"
            info["status_label"] = f"File Sesi Rusak ({exc})"

        return info

    def get_all_slots(self) -> List[Dict[str, Any]]:
        return [self.inspect_slot(i) for i in range(1, self.MAX_SLOTS + 1)]

    def get_healthy_slots(self) -> List[Dict[str, Any]]:
        return [
            s
            for s in self.get_all_slots()
            if s["status"] in ("active", "expiring_soon") and s["has_file"]
        ]

    def get_primary_faskes_info(self) -> Dict[str, str]:
        """Return Faskes & Officer metadata from the first populated slot."""
        for s in self.get_all_slots():
            if s["faskes_name"] or s["officer_name"]:
                return {
                    "faskes_name": s["faskes_name"] or "Akun Kemenkes Aktif",
                    "officer_name": s["officer_name"],
                    "jabatan": s["jabatan"],
                    "region": s["region"],
                }
        return {
            "faskes_name": self.state_db.get_setting("active_faskes", "Belum Terdeteksi"),
            "officer_name": "",
            "jabatan": "",
            "region": "",
        }


class LicenseManager:
    """
    Hybrid Cloud SaaS License & Faskes-Lock Controller (Opsi A).
    Provides cryptographic HMAC-SHA256 license verification, Faskes binding,
    tamper-proof monotonic quota tracking, program-scope locking (Sekolah vs Umum),
    and Owner Studio vs Client Mode isolation.
    """

    def __init__(
        self,
        state_db: StateDB,
        ledger_path: Optional[Path] = None,
        owner_mode: Optional[bool] = None,
        base_dir: Optional[Path] = None,
        shadow_paths: Optional[List[Path]] = None,
    ) -> None:
        self.state_db = state_db
        self.machine_id = get_machine_fingerprint()
        db_parent = self.state_db.db_path.resolve().parent
        self.base_dir = (
            Path(base_dir)
            if base_dir
            else (db_parent.parent if db_parent.name == "data" else db_parent)
        )
        owner_marker = self.base_dir / ".owner_studio.key"
        expected_unlock_tok = self._compute_owner_unlock_token()
        stored_unlock_tok = (self.state_db.get_setting("owner_studio_unlocked", "") or "").strip()

        if owner_mode is not None:
            self.is_owner_mode = bool(owner_mode)
        else:
            self.is_owner_mode = owner_marker.exists() or (
                bool(stored_unlock_tok)
                and hmac.compare_digest(stored_unlock_tok.upper(), expected_unlock_tok)
            )

        is_tmp_env = str(self.base_dir).startswith(("/tmp", "/private/var/folders", "/var/folders"))
        if ledger_path is not None:
            self.ledger_path = Path(ledger_path)
        elif is_tmp_env:
            self.ledger_path = self.base_dir / ".ckg_terpadu_ledger.json"
        else:
            self.ledger_path = Path.home() / ".ckg_terpadu_ledger.json"

        if shadow_paths is not None:
            self._shadow_paths = [Path(p) for p in shadow_paths]
        elif ledger_path is not None or is_tmp_env:
            self._shadow_paths = []
        else:
            self._shadow_paths = self._default_os_shadow_paths()

        self._all_ledger_paths: List[Path] = [self.ledger_path] + [
            p for p in self._shadow_paths if p != self.ledger_path
        ]
        self._inflight_reserved: int = 0
        self._ledger_tampered = False
        self._clock_rollback = False
        self._pin_failed_attempts: int = int(self.state_db.get_setting("saas_pin_failed_attempts", 0) or 0)
        self._pin_lockout_until: int = int(self.state_db.get_setting("saas_pin_lockout_until", 0) or 0)
        self._ledger_data: Dict[str, Any] = {}
        self._sync_tamper_proof_ledger()
        self._ensure_default_license()

    def _default_os_shadow_paths(self) -> List[Path]:
        """Return hidden OS-specific secondary anchor paths so deleting ~/.ckg_terpadu_ledger.json cannot reset Trial."""
        paths: List[Path] = []
        sys_name = platform.system().lower()
        if sys_name == "darwin":
            paths.append(Path.home() / "Library" / "Application Support" / ".ckg_sys_telemetry.dat")
        elif sys_name == "windows":
            local_app = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
            paths.append(Path(local_app) / ".ckg_sys_telemetry.dat")
        else:
            paths.append(Path.home() / ".config" / ".ckg_sys_telemetry.dat")
        paths.append(self.base_dir / "data" / ".sys_quota_anchor.dat")
        return paths

    def _compute_owner_unlock_token(self) -> str:
        msg = f"OWNER_STUDIO_UNLOCK|{self.machine_id}".encode("utf-8")
        return hmac.new(_SAAS_MASTER_SECRET, msg, hashlib.sha256).hexdigest().upper()

    @staticmethod
    def _key_id(key_str: str) -> str:
        clean = (key_str or "").strip()
        if not clean:
            return "NONE"
        if clean.startswith("CKG-V3.") and clean.count(".") == 2:
            try:
                _, payload_b64, _ = clean.split(".", 2)
                payload = json.loads(_b64url_decode(payload_b64).decode("utf-8"))
                if isinstance(payload, dict) and payload.get("plan"):
                    canonical = (
                        f"V3|{str(payload.get('client', '')).strip()}|"
                        f"{str(payload.get('plan', '')).strip().upper()}|"
                        f"{str(payload.get('faskes', '*')).strip().upper()}|"
                        f"{str(payload.get('hw', '*')).strip().upper()}|"
                        f"{int(payload.get('quota', 0))}|"
                        f"{str(payload.get('iat', '')).strip()}|"
                        f"{str(payload.get('exp', '')).strip()}"
                    )
                    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:16].upper()
            except Exception:
                pass
        return hashlib.sha256(clean.encode("utf-8")).hexdigest()[:16].upper()

    def _compute_ledger_sig(
        self,
        hw: str,
        first_seen: str,
        used: int,
        trial_key: str,
        last_seen_date: str = "",
        key_usage: Optional[Dict[str, int]] = None,
        last_seen_ts: int = 0,
    ) -> str:
        ku_str = ""
        if key_usage:
            ku_str = json.dumps(key_usage, separators=(",", ":"), sort_keys=True)
        if last_seen_ts > 0:
            msg = (
                f"{hw}|{first_seen}|{int(used)}|{trial_key}|{last_seen_date}|{ku_str}|{int(last_seen_ts)}"
            ).encode("utf-8")
        elif last_seen_date or ku_str:
            msg = f"{hw}|{first_seen}|{int(used)}|{trial_key}|{last_seen_date}|{ku_str}".encode("utf-8")
        else:
            msg = f"{hw}|{first_seen}|{int(used)}|{trial_key}".encode("utf-8")
        return hmac.new(_SAAS_MASTER_SECRET, msg, hashlib.sha256).hexdigest().upper()

    def _sync_tamper_proof_ledger(self) -> None:
        """
        Load, cross-verify, and merge all hardware usage anchors + SQLite state_db.
        - Detects HMAC tampering or hardware-mismatch on any anchor.
        - Detects system clock rollback (date, Unix epoch timestamp, and file mtime).
        - Restores & auto-heals any deleted anchor from surviving anchors.
        """
        today_str = dt.date.today().isoformat()
        now_ts = int(time.time())
        db_used = int(self.state_db.get_setting("saas_processed_count", 0) or 0)
        db_last_ts = int(self.state_db.get_setting("saas_last_seen_ts", 0) or 0)
        raw_db_ku = self.state_db.get_setting("saas_key_usage_json", "{}") or "{}"
        try:
            db_key_usage = {str(k): int(v) for k, v in json.loads(raw_db_ku).items()}
        except Exception:
            db_key_usage = {}

        max_fs_mtime = 0
        try:
            if self.state_db.db_path.exists():
                max_fs_mtime = max(max_fs_mtime, int(self.state_db.db_path.stat().st_mtime))
        except Exception:
            pass

        merged_used = max(0, db_used)
        merged_first_seen = today_str
        merged_last_seen = today_str
        merged_last_ts = max(0, db_last_ts)
        merged_trial_key = ""
        merged_key_usage: Dict[str, int] = dict(db_key_usage)
        found_any_anchor = False
        needs_heal = False

        for path in self._all_ledger_paths:
            if not path.exists():
                needs_heal = True
                continue
            found_any_anchor = True
            try:
                max_fs_mtime = max(max_fs_mtime, int(path.stat().st_mtime))
                raw = json.loads(path.read_text(encoding="utf-8"))
                hw = str(raw.get("hw", self.machine_id))
                first_seen = str(raw.get("first_seen", today_str))
                ledger_used = int(raw.get("used", 0))
                trial_key = str(raw.get("trial_key", ""))
                last_seen_date = str(raw.get("last_seen_date", ""))
                last_seen_ts = int(raw.get("last_seen_ts", 0) or 0)
                raw_ku = raw.get("key_usage")
                ku_dict: Optional[Dict[str, int]] = None
                if isinstance(raw_ku, dict):
                    ku_dict = {str(k): int(v) for k, v in raw_ku.items()}
                sig = str(raw.get("sig", ""))

                expected_v3 = self._compute_ledger_sig(
                    hw, first_seen, ledger_used, trial_key, last_seen_date, ku_dict, last_seen_ts
                )
                expected_v2 = self._compute_ledger_sig(
                    hw, first_seen, ledger_used, trial_key, last_seen_date, ku_dict, 0
                )
                expected_v1 = self._compute_ledger_sig(hw, first_seen, ledger_used, trial_key)
                if not sig or (
                    not hmac.compare_digest(sig.upper(), expected_v3)
                    and not hmac.compare_digest(sig.upper(), expected_v2)
                    and not hmac.compare_digest(sig.upper(), expected_v1)
                ):
                    self._ledger_tampered = True
                    return
                valid_hws = {self.machine_id.upper(), _get_legacy_machine_fingerprint().upper()}
                if hw.upper() not in valid_hws:
                    self._ledger_tampered = True
                    return
                if hw.upper() != self.machine_id.upper():
                    needs_heal = True

                merged_used = max(merged_used, ledger_used)
                if first_seen and first_seen < merged_first_seen:
                    merged_first_seen = first_seen
                if last_seen_date:
                    if last_seen_date > today_str:
                        self._clock_rollback = True
                    if last_seen_date > merged_last_seen:
                        merged_last_seen = last_seen_date
                if last_seen_ts > 0:
                    if last_seen_ts > now_ts + 300:
                        self._clock_rollback = True
                    if last_seen_ts > merged_last_ts:
                        merged_last_ts = last_seen_ts
                if trial_key and not merged_trial_key:
                    merged_trial_key = trial_key
                if ku_dict:
                    for k_id, k_val in ku_dict.items():
                        merged_key_usage[k_id] = max(merged_key_usage.get(k_id, 0), int(k_val))
            except Exception:
                self._ledger_tampered = True
                return

        if max_fs_mtime > now_ts + 300 or merged_last_ts > now_ts + 300:
            self._clock_rollback = True
        if not self._clock_rollback:
            merged_last_ts = max(merged_last_ts, now_ts)

        self._ledger_data = {
            "hw": self.machine_id,
            "first_seen": merged_first_seen,
            "last_seen_date": merged_last_seen,
            "last_seen_ts": merged_last_ts,
            "used": merged_used,
            "trial_key": merged_trial_key,
            "key_usage": merged_key_usage,
        }

        if merged_used != db_used:
            self.state_db.save_setting("saas_processed_count", merged_used)
        if merged_last_ts != db_last_ts:
            self.state_db.save_setting("saas_last_seen_ts", merged_last_ts)
        if merged_key_usage != db_key_usage:
            self.state_db.save_setting("saas_key_usage_json", json.dumps(merged_key_usage, sort_keys=True))
        if not found_any_anchor or needs_heal or merged_used != db_used:
            self._save_ledger()

    def _save_ledger(self) -> None:
        if self._ledger_tampered:
            return
        hw = self._ledger_data.get("hw", self.machine_id)
        first_seen = self._ledger_data.get("first_seen", dt.date.today().isoformat())
        last_seen_date = self._ledger_data.get("last_seen_date", dt.date.today().isoformat())
        last_seen_ts = int(self._ledger_data.get("last_seen_ts", int(time.time())) or int(time.time()))
        used = int(self._ledger_data.get("used", 0))
        trial_key = str(self._ledger_data.get("trial_key", ""))
        key_usage: Dict[str, int] = {
            str(k): int(v) for k, v in (self._ledger_data.get("key_usage") or {}).items()
        }
        sig = self._compute_ledger_sig(
            hw, first_seen, used, trial_key, last_seen_date, key_usage, last_seen_ts
        )
        payload = {
            "hw": hw,
            "first_seen": first_seen,
            "last_seen_date": last_seen_date,
            "last_seen_ts": last_seen_ts,
            "used": used,
            "trial_key": trial_key,
            "key_usage": key_usage,
            "sig": sig,
        }
        serialized = json.dumps(payload, indent=2)
        for path in self._all_ledger_paths:
            try:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(serialized, encoding="utf-8")
            except Exception:
                pass

    def _ensure_default_license(self) -> None:
        """
        In Owner Mode: ensure an active ENTERPRISE_DINKES license is present.
        In Client Mode: start with a hardware-bound Starter Trial (30 quota, 14 days)
        persisted in the tamper-proof hardware ledger so wiping state.db cannot reset Trial.
        """
        saved_key = self.state_db.get_setting("saas_license_key", "")
        if saved_key:
            return

        if self.is_owner_mode:
            default_key = self.generate_license_key(
                client_name="Owner Master Studio (All Faskes)",
                plan="ENTERPRISE_DINKES",
                faskes_lock="*",
                days_valid=3650,
                quota_limit=999999,
            )
            self.state_db.save_setting("saas_license_key", default_key)
            return

        ledger_trial = self._ledger_data.get("trial_key", "")
        if not ledger_trial:
            ledger_trial = self.generate_license_key(
                client_name="Uji Coba Puskesmas (Starter Trial)",
                plan="TRIAL",
                faskes_lock="*",
                days_valid=14,
                quota_limit=30,
                machine_lock=self.machine_id,
            )
            self._ledger_data["trial_key"] = ledger_trial
            self._save_ledger()
        self.state_db.save_setting("saas_license_key", ledger_trial)

    def is_pin_locked_out(self) -> Tuple[bool, int]:
        now_ts = int(time.time())
        lock_until = max(
            self._pin_lockout_until,
            int(self.state_db.get_setting("saas_pin_lockout_until", 0) or 0),
        )
        self._pin_lockout_until = lock_until
        if lock_until > now_ts:
            return True, lock_until - now_ts
        return False, 0

    def _record_pin_attempt(self, success: bool) -> None:
        if success:
            self._pin_failed_attempts = 0
            self._pin_lockout_until = 0
            self.state_db.save_setting("saas_pin_failed_attempts", 0)
            self.state_db.save_setting("saas_pin_lockout_until", 0)
            return
        self._pin_failed_attempts = (
            max(
                self._pin_failed_attempts,
                int(self.state_db.get_setting("saas_pin_failed_attempts", 0) or 0),
            )
            + 1
        )
        self.state_db.save_setting("saas_pin_failed_attempts", self._pin_failed_attempts)
        if self._pin_failed_attempts >= _PIN_MAX_FAILED_ATTEMPTS:
            self._pin_lockout_until = int(time.time()) + _PIN_LOCKOUT_SECONDS
            self.state_db.save_setting("saas_pin_lockout_until", self._pin_lockout_until)

    def verify_owner_pin(self, pin: str) -> bool:
        if self.is_owner_mode:
            return True
        locked, _ = self.is_pin_locked_out()
        if locked:
            return False
        given = (pin or "").strip()
        if not given:
            self._record_pin_attempt(False)
            return False
        env_pin = (os.environ.get("CKG_OWNER_PIN") or "").strip()
        if env_pin and hmac.compare_digest(given, env_pin):
            self._record_pin_attempt(True)
            return True
        given_pbkdf2 = (
            hashlib.pbkdf2_hmac(
                "sha256",
                given.encode("utf-8"),
                _SAAS_MASTER_SECRET,
                _OWNER_PIN_PBKDF2_ITERATIONS,
            )
            .hex()
            .upper()
        )
        matched = hmac.compare_digest(given_pbkdf2, _OWNER_PIN_PBKDF2_DIGEST)
        self._record_pin_attempt(matched)
        if matched:
            _resolve_owner_p256_priv_scalar(given)
        return matched

    def unlock_owner_studio(self, pin: str) -> Tuple[bool, str]:
        locked, rem_sec = self.is_pin_locked_out()
        if locked:
            return (
                False,
                f"Terlalu banyak percobaan PIN gagal. Akses dikunci sementara ({rem_sec} detik).",
            )
        if not self.verify_owner_pin(pin):
            locked_after, rem_after = self.is_pin_locked_out()
            if locked_after:
                return (
                    False,
                    f"Terlalu banyak percobaan PIN gagal ({_PIN_MAX_FAILED_ATTEMPTS}x). "
                    f"Akses dikunci sementara selama 5 menit ({rem_after} detik).",
                )
            return False, "PIN Pengelola (Owner) tidak sesuai."
        self.is_owner_mode = True
        self.state_db.save_setting("owner_studio_unlocked", self._compute_owner_unlock_token())
        return True, "Mode Pengelola (Owner Studio) berhasil dibuka."

    @staticmethod
    def clean_faskes_lock(raw_faskes: str) -> str:
        """Strip officer name suffix (e.g. 'SEI PANAS • NADYA AGITHA') so lock binds to the Puskesmas."""
        val = (raw_faskes or "*").strip()
        if "•" in val:
            val = val.split("•", 1)[0].strip()
        return (val or "*").upper()

    @staticmethod
    def generate_license_key(
        client_name: str,
        plan: str = "PRO_PUSKESMAS",
        faskes_lock: str = "*",
        days_valid: int = 365,
        quota_limit: int = 50000,
        machine_lock: str = "*",
        owner_pin: str = "",
    ) -> str:
        """
        Generate a signed cryptographic license key: CKG-V3.<payload_b64>.<sig>.
        - Paid licenses (plan != 'TRIAL') are signed with NIST P-256 Asymmetric Private Scalar.
        - Starter Trial ('TRIAL') is signed with local Trial HMAC (strictly capped at <=30 quota, <=14 days).
        """
        plan_code = plan if plan in PLAN_DEFINITIONS else "PRO_PUSKESMAS"
        plan_meta = PLAN_DEFINITIONS[plan_code]
        now = dt.date.today()
        exp_date = now + dt.timedelta(days=max(1, int(days_valid)))
        cleaned_faskes = LicenseManager.clean_faskes_lock(faskes_lock)

        payload = {
            "v": 3,
            "client": (client_name or "Puskesmas Mitra").strip(),
            "plan": plan_code,
            "faskes": cleaned_faskes,
            "hw": (machine_lock or "*").strip().upper(),
            "workers": plan_meta["max_workers"],
            "quota": int(quota_limit or plan_meta["default_quota"]),
            "iat": now.isoformat(),
            "exp": exp_date.isoformat(),
        }
        payload_bytes = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
        payload_b64 = _b64url_encode(payload_bytes)
        if plan_code != "TRIAL":
            priv_x = _resolve_owner_p256_priv_scalar(owner_pin)
            if priv_x is not None:
                sig_p256 = _p256_schnorr_sign(payload_b64.encode("ascii"), priv_x)
                return f"CKG-V3.{payload_b64}.{sig_p256}"
        sig = hmac.new(_SAAS_MASTER_SECRET, payload_b64.encode("ascii"), hashlib.sha256).hexdigest()[:16].upper()
        return f"CKG-V3.{payload_b64}.{sig}"

    def get_issued_licenses(self) -> List[Dict[str, Any]]:
        """Return all client licenses issued by the Owner Studio, enriched with live days_left & status."""
        raw_str = self.state_db.get_setting("saas_issued_licenses_json", "[]") or "[]"
        try:
            items = json.loads(raw_str)
            if not isinstance(items, list):
                items = []
        except Exception:
            items = []

        today = dt.date.today()
        enriched: List[Dict[str, Any]] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            rec = dict(item)
            exp_str = str(rec.get("expires_at", ""))
            try:
                exp_date = dt.date.fromisoformat(exp_str)
                days_left = (exp_date - today).days
            except Exception:
                days_left = int(rec.get("days_valid", 365))
            rec["days_left"] = days_left
            if days_left < 0:
                rec["status"] = "expired"
                rec["status_label"] = "Kedaluwarsa"
            elif days_left <= 14:
                rec["status"] = "expiring_soon"
                rec["status_label"] = f"Segera Habis ({days_left} hr)"
            else:
                rec["status"] = "active"
                rec["status_label"] = f"Aktif ({days_left} hr)"
            enriched.append(rec)
        return enriched

    def record_issued_license(
        self,
        client_name: str,
        plan: str,
        faskes_lock: str,
        days_valid: int,
        quota_limit: int,
        machine_lock: str,
        license_key: str,
        wa_template: str,
        notes: str = "",
    ) -> List[Dict[str, Any]]:
        """Save or update an issued client license in the Owner CRM Registry."""
        raw_str = self.state_db.get_setting("saas_issued_licenses_json", "[]") or "[]"
        try:
            items = json.loads(raw_str)
            if not isinstance(items, list):
                items = []
        except Exception:
            items = []

        plan_code = plan if plan in PLAN_DEFINITIONS else "PRO_PUSKESMAS"
        plan_meta = PLAN_DEFINITIONS[plan_code]
        now = dt.date.today()
        exp_date = now + dt.timedelta(days=max(1, int(days_valid)))
        clean_faskes = self.clean_faskes_lock(faskes_lock)

        new_rec = {
            "id": f"LIC-{int(time.time() * 1000)}-{uuid.uuid4().hex[:4].upper()}",
            "client_name": (client_name or "Puskesmas Mitra").strip(),
            "plan": plan_code,
            "plan_name": plan_meta["name"],
            "plan_badge": plan_meta["badge"],
            "faskes_lock": clean_faskes,
            "machine_lock": (machine_lock or "*").strip().upper(),
            "days_valid": int(days_valid),
            "quota_limit": int(quota_limit),
            "created_at": now.isoformat(),
            "expires_at": exp_date.isoformat(),
            "license_key": license_key,
            "wa_template": wa_template,
            "notes": (notes or "").strip(),
        }
        items.insert(0, new_rec)
        self.state_db.save_setting("saas_issued_licenses_json", json.dumps(items, ensure_ascii=False))
        return self.get_issued_licenses()

    def delete_issued_license(self, rec_id: str) -> List[Dict[str, Any]]:
        """Remove a client license record from the Owner CRM Registry by ID."""
        raw_str = self.state_db.get_setting("saas_issued_licenses_json", "[]") or "[]"
        try:
            items = json.loads(raw_str)
            if not isinstance(items, list):
                items = []
        except Exception:
            items = []
        filtered = [it for it in items if isinstance(it, dict) and it.get("id") != rec_id]
        self.state_db.save_setting("saas_issued_licenses_json", json.dumps(filtered, ensure_ascii=False))
        return self.get_issued_licenses()

    def verify_license_key(
        self, key_str: str, ignore_hw_lock: bool = False
    ) -> Tuple[bool, str, Dict[str, Any]]:
        """Verify cryptographic signature, expiration date, and hardware binding."""
        clean = (key_str or "").strip()
        if not clean.startswith("CKG-V3.") or clean.count(".") != 2:
            return False, "Format kode lisensi tidak valid (harus diawali CKG-V3.).", {}

        _, payload_b64, sig_given = clean.split(".", 2)
        try:
            payload = json.loads(_b64url_decode(payload_b64).decode("utf-8"))
        except Exception:
            return False, "Payload lisensi rusak.", {}

        if not isinstance(payload, dict) or payload.get("v") != 3:
            return False, "Versi skema payload lisensi tidak didukung.", {}

        plan_code = str(payload.get("plan", "")).strip()
        if plan_code not in PLAN_DEFINITIONS:
            return False, "Kode paket lisensi tidak dikenali.", payload

        if plan_code != "TRIAL":
            if not _p256_schnorr_verify(payload_b64.encode("ascii"), sig_given):
                return (
                    False,
                    "Tanda tangan kriptografi asimetris (NIST P-256 Public-Key) tidak sah.",
                    {},
                )
        else:
            expected_hmac = (
                hmac.new(_SAAS_MASTER_SECRET, payload_b64.encode("ascii"), hashlib.sha256)
                .hexdigest()[:16]
                .upper()
            )
            is_valid_trial_sig = hmac.compare_digest(
                sig_given.upper(), expected_hmac
            ) or _p256_schnorr_verify(payload_b64.encode("ascii"), sig_given)
            if not is_valid_trial_sig:
                return False, "Tanda tangan kriptografi lisensi tidak sah (Signature Mismatch).", {}

        quota_val = payload.get("quota")
        workers_val = payload.get("workers", 1)
        if (
            not isinstance(quota_val, int)
            or isinstance(quota_val, bool)
            or quota_val < 1
            or quota_val > 1_000_000
        ):
            return False, "Nilai kuota lisensi di luar batas standar keamanan.", payload
        if (
            not isinstance(workers_val, int)
            or isinstance(workers_val, bool)
            or workers_val < 1
            or workers_val > 4
        ):
            return False, "Konfigurasi worker lisensi tidak valid.", payload

        exp_str = str(payload.get("exp", "")).strip()
        iat_str = str(payload.get("iat", "")).strip()
        today = dt.date.today()
        try:
            iat_date = dt.date.fromisoformat(iat_str)
            exp_date = dt.date.fromisoformat(exp_str)
        except Exception:
            return False, "Format tanggal penerbitan/kedaluwarsa lisensi tidak valid.", payload

        if exp_date < iat_date or (exp_date - iat_date).days > 3660:
            return False, "Rentang masa aktif lisensi tidak valid.", payload
        if today < iat_date:
            self._clock_rollback = True

        hw_lock = str(payload.get("hw", "*")).strip()
        if plan_code == "TRIAL":
            if (
                quota_val > 30
                or (exp_date - iat_date).days > 14
                or workers_val > 1
                or not hw_lock
                or hw_lock == "*"
            ):
                return (
                    False,
                    "Lisensi TRIAL melanggar batas keamanan (Maks 30 peserta, 14 hari, wajib terkunci perangkat).",
                    payload,
                )

        days_left = (exp_date - today).days
        if days_left < 0:
            return False, f"Lisensi telah kedaluwarsa pada {exp_str}.", payload
        payload["days_left"] = days_left

        if (
            not ignore_hw_lock
            and hw_lock
            and hw_lock != "*"
            and hw_lock.upper() != self.machine_id.upper()
        ):
            return (
                False,
                f"Lisensi ini dikunci untuk perangkat {hw_lock} (Perangkat Anda: {self.machine_id}).",
                payload,
            )

        return True, "Lisensi Aktif & Terverifikasi", payload

    def activate_license(self, key_str: str) -> Dict[str, Any]:
        clean = (key_str or "").strip()
        ok, msg, payload = self.verify_license_key(clean)
        if not ok:
            return {"ok": False, "message": msg}
        self._sync_tamper_proof_ledger()
        kid = self._key_id(clean)
        ku = self._ledger_data.setdefault("key_usage", {})
        if kid not in ku:
            ku[kid] = 0
        self.state_db.save_setting("saas_license_key", clean)
        self.state_db.save_setting("saas_key_usage_json", json.dumps(ku, sort_keys=True))
        self._save_ledger()
        return {
            "ok": True,
            "message": f"Lisensi {payload.get('plan')} untuk '{payload.get('client')}' berhasil diaktifkan!",
            "status": self.get_status(),
        }

    def get_usage_count(self) -> int:
        self._sync_tamper_proof_ledger()
        key_str = (self.state_db.get_setting("saas_license_key", "") or "").strip()
        ok, _, payload = self.verify_license_key(key_str)
        total_used = max(
            int(self.state_db.get_setting("saas_processed_count", 0) or 0),
            int(self._ledger_data.get("used", 0) or 0),
        )
        if not ok or payload.get("plan", "TRIAL") == "TRIAL":
            return total_used
        kid = self._key_id(key_str)
        ku = self._ledger_data.get("key_usage") or {}
        if kid in ku:
            return int(ku.get(kid, 0))
        return total_used

    def increment_usage(self, count: int = 1) -> int:
        delta = max(0, int(count))
        self._sync_tamper_proof_ledger()
        total_cur = (
            max(
                int(self.state_db.get_setting("saas_processed_count", 0) or 0),
                int(self._ledger_data.get("used", 0) or 0),
            )
            + delta
        )
        self.state_db.save_setting("saas_processed_count", total_cur)
        self._ledger_data["used"] = total_cur

        key_str = (self.state_db.get_setting("saas_license_key", "") or "").strip()
        if key_str:
            kid = self._key_id(key_str)
            ku = self._ledger_data.setdefault("key_usage", {})
            ku[kid] = int(ku.get(kid, 0)) + delta
            self.state_db.save_setting("saas_key_usage_json", json.dumps(ku, sort_keys=True))

        today_str = dt.date.today().isoformat()
        if today_str > str(self._ledger_data.get("last_seen_date", "")):
            self._ledger_data["last_seen_date"] = today_str
        now_ts = int(time.time())
        if not self._clock_rollback and now_ts > int(self._ledger_data.get("last_seen_ts", 0) or 0):
            self._ledger_data["last_seen_ts"] = now_ts
            self.state_db.save_setting("saas_last_seen_ts", now_ts)
        self._save_ledger()
        return self.get_usage_count()

    def try_reserve_quota(
        self, detected_faskes: str, service_type: str = "sekolah"
    ) -> Tuple[bool, str]:
        """Atomically verify license/scope/faskes and reserve 1 in-flight quota slot for a worker."""
        ok, msg = self.verify_faskes_and_quota(detected_faskes, service_type=service_type)
        if not ok:
            return False, msg
        status = self.get_status()
        used = status["quota_used"]
        limit = status["quota_limit"]
        if used + self._inflight_reserved >= limit:
            return (
                False,
                f"Kuota paket {status['plan_name']} telah mencapai batas ({used + self._inflight_reserved}/{limit} peserta). "
                f"Silakan upgrade atau perbarui lisensi Anda.",
            )
        self._inflight_reserved += 1
        return True, "OK"

    def commit_reserved_quota(self, count: int = 1) -> int:
        """Commit an in-flight reserved quota slot into permanent monotonic ledger usage."""
        n = max(1, int(count))
        self._inflight_reserved = max(0, self._inflight_reserved - n)
        return self.increment_usage(n)

    def release_reserved_quota(self, count: int = 1) -> None:
        """Release an in-flight reserved quota slot when a student fails before completion."""
        n = max(1, int(count))
        self._inflight_reserved = max(0, self._inflight_reserved - n)

    def verify_faskes_and_quota(
        self, detected_faskes: str, service_type: str = "sekolah"
    ) -> Tuple[bool, str]:
        """Check whether the current Faskes, program scope, system clock, & participant quota are permitted."""
        self._sync_tamper_proof_ledger()
        if self._ledger_tampered:
            return (
                False,
                "Sistem mendeteksi manipulasi pada file proteksi kuota perangkat. Silakan hubungi pengelola lisensi resmi.",
            )
        if self._clock_rollback:
            return (
                False,
                "Sistem mendeteksi tanggal komputer dimundurkan (Clock Rollback). "
                "Harap kembalikan jam & tanggal komputer Anda ke waktu sebenarnya.",
            )

        status = self.get_status()
        if not status["is_valid"]:
            return False, status["message"]

        allowed_services = status.get("allowed_services", ["sekolah", "umum"])
        norm_srv = "umum" if str(service_type).lower().strip() == "umum" else "sekolah"
        if norm_srv not in allowed_services:
            only_label = "CKG Sekolah" if "sekolah" in allowed_services else "CKG Umum"
            return (
                False,
                f"Paket lisensi Anda ({status['plan_name']}) hanya berlaku untuk program {only_label}. "
                f"Silakan upgrade ke Paket Clinical Pro Puskesmas (Sekolah + Umum).",
            )

        used = status["quota_used"]
        limit = status["quota_limit"]
        if used >= limit:
            return (
                False,
                f"Kuota paket {status['plan_name']} telah habis ({used}/{limit} peserta). Silakan aktifkan lisensi Pro Puskesmas.",
            )

        faskes_lock = (status["faskes_lock"] or "*").strip().upper()
        if faskes_lock != "*":
            det_upper = (detected_faskes or "").strip().upper()
            if det_upper and det_upper not in ("BELUM TERDETEKSI", "AKUN KEMENKES AKTIF"):
                if faskes_lock not in det_upper and det_upper not in faskes_lock:
                    return (
                        False,
                        f"Faskes-Lock Mismatch! Lisensi ini hanya berlaku untuk '{faskes_lock}', "
                        f"sedangkan akun Kemenkes yang login adalah '{detected_faskes}'.",
                    )

        return True, "OK"

    def get_status(self) -> Dict[str, Any]:
        key_str = self.state_db.get_setting("saas_license_key", "")
        ok, msg, payload = self.verify_license_key(key_str)
        if self._ledger_tampered:
            ok = False
            msg = "File proteksi kuota perangkat rusak atau dimodifikasi."
        elif self._clock_rollback:
            ok = False
            msg = "Tanggal komputer terdeteksi dimundurkan (Clock Rollback)."
        plan_code = payload.get("plan", "TRIAL") if ok else "UNLICENSED"
        plan_meta = PLAN_DEFINITIONS.get(plan_code, PLAN_DEFINITIONS["PRO_PUSKESMAS"])
        used = self.get_usage_count()
        quota_limit = int(payload.get("quota", plan_meta["default_quota"])) if ok else 0

        return {
            "is_valid": ok,
            "is_owner_mode": self.is_owner_mode,
            "message": msg,
            "machine_id": self.machine_id,
            "license_key": key_str,
            "client_name": payload.get("client", "Belum Terdaftar"),
            "plan_code": plan_code,
            "plan_name": plan_meta["name"] if ok else "Lisensi Tidak Valid",
            "plan_badge": plan_meta["badge"] if ok else "UNLICENSED",
            "allowed_services": plan_meta.get("allowed_services", ["sekolah", "umum"]),
            "faskes_lock": payload.get("faskes", "*"),
            "max_workers": int(payload.get("workers", plan_meta["max_workers"])) if ok else 1,
            "quota_used": used,
            "quota_limit": quota_limit,
            "expires_at": payload.get("exp", "-"),
            "days_left": payload.get("days_left", 0),
            "issued_licenses": self.get_issued_licenses() if self.is_owner_mode else [],
        }
