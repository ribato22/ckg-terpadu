from __future__ import annotations

import base64
import datetime as dt
import hashlib
import hmac
import json
import os
import platform
import shutil
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .state_db import StateDB

# Master HMAC secret for signing & verifying Hybrid SaaS License Keys (Opsi A)
_SAAS_MASTER_SECRET = b"CKG-CLINICAL-PRO-V3-HYBRID-SAAS-2026-MASTER-KEY"
_OWNER_MASTER_PIN = os.environ.get("CKG_OWNER_PIN", "CKG-OWNER-2026")

PLAN_DEFINITIONS: Dict[str, Dict[str, Any]] = {
    "TRIAL": {
        "code": "TRIAL",
        "name": "Starter Trial (Uji Coba Gratis)",
        "badge": "TRIAL 30 PESERTA",
        "max_workers": 1,
        "default_quota": 30,
        "default_days": 14,
        "allowed_services": ["sekolah", "umum"],
    },
    "PAKET_BULANAN": {
        "code": "PAKET_BULANAN",
        "name": "Paket Hemat Bulanan (Sekolah & Umum)",
        "badge": "PRO 300 PESERTA",
        "max_workers": 2,
        "default_quota": 300,
        "default_days": 30,
        "allowed_services": ["sekolah", "umum"],
    },
    "PRO_SEKOLAH": {
        "code": "PRO_SEKOLAH",
        "name": "Paket CKG Sekolah (Khusus Anak Sekolah)",
        "badge": "PRO SEKOLAH",
        "max_workers": 2,
        "default_quota": 3000,
        "default_days": 180,
        "allowed_services": ["sekolah"],
    },
    "PRO_UMUM": {
        "code": "PRO_UMUM",
        "name": "Paket CKG Umum (Khusus Dewasa & Lansia)",
        "badge": "PRO UMUM",
        "max_workers": 2,
        "default_quota": 3000,
        "default_days": 180,
        "allowed_services": ["umum"],
    },
    "PRO_PUSKESMAS": {
        "code": "PRO_PUSKESMAS",
        "name": "Clinical Pro Puskesmas (Sekolah + Umum)",
        "badge": "PRO PUSKESMAS",
        "max_workers": 4,
        "default_quota": 50000,
        "default_days": 365,
        "allowed_services": ["sekolah", "umum"],
    },
    "ENTERPRISE_DINKES": {
        "code": "ENTERPRISE_DINKES",
        "name": "Enterprise Dinkes & Owner Studio (Multi-Faskes)",
        "badge": "ENTERPRISE SAAS",
        "max_workers": 4,
        "default_quota": 999999,
        "default_days": 3650,
        "allowed_services": ["sekolah", "umum"],
    },
}


def get_machine_fingerprint() -> str:
    """Generate a deterministic, readable hardware fingerprint for SaaS node binding."""
    raw = f"{platform.system()}-{platform.machine()}-{platform.node()}-{uuid.getnode()}"
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest().upper()
    return f"CKG-{digest[:4]}-{digest[4:8]}-{digest[8:12]}"


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _b64url_decode(s: str) -> bytes:
    pad = "=" * ((4 - len(s) % 4) % 4)
    return base64.urlsafe_b64decode(s + pad)


def _decode_jwt_exp(token_str: str) -> Optional[int]:
    """Extract 'exp' timestamp from a JWT string without external dependencies."""
    if not token_str or token_str.count(".") != 2:
        return None
    try:
        payload_b64 = token_str.split(".")[1]
        payload = json.loads(_b64url_decode(payload_b64).decode("utf-8"))
        exp = payload.get("exp")
        return int(exp) if exp else None
    except Exception:
        return None


class SessionVault:
    """
    Enterprise Multi-Account Session Vault for CKG Sekolah V3.3 SaaS.
    Manages up to 4 independent Kemenkes Nakes account slots (slot_1 .. slot_4),
    enabling true multi-worker parallel execution without Kemenkes single-device collisions.
    """

    MAX_SLOTS = 4

    def __init__(self, data_dir: Path, state_db: StateDB) -> None:
        self.data_dir = Path(data_dir)
        self.state_db = state_db
        self.sessions_dir = self.data_dir / "sessions"
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.legacy_storage_path = self.data_dir / "storage_state.json"

        # Runtime health overrides (slot_id -> {"expired": bool, "reason": str, "verified_at": str})
        self._runtime_state: Dict[int, Dict[str, Any]] = {}
        self._migrate_legacy_session()

    def _migrate_legacy_session(self) -> None:
        """Ensure existing data/storage_state.json is mirrored into Slot #1."""
        slot1_path = self.get_slot_path(1)
        if self.legacy_storage_path.exists() and self.legacy_storage_path.stat().st_size > 50:
            if (
                not slot1_path.exists()
                or self.legacy_storage_path.stat().st_mtime > slot1_path.stat().st_mtime
            ):
                try:
                    shutil.copy2(self.legacy_storage_path, slot1_path)
                except Exception:
                    pass
        elif slot1_path.exists() and slot1_path.stat().st_size > 50:
            try:
                shutil.copy2(slot1_path, self.legacy_storage_path)
            except Exception:
                pass

    def get_slot_path(self, slot_id: int) -> Path:
        slot_id = max(1, min(self.MAX_SLOTS, int(slot_id)))
        return self.sessions_dir / f"slot_{slot_id}.json"

    def sync_slot_to_legacy(self, slot_id: int = 1) -> None:
        """Keep data/storage_state.json synced with Slot #1 (or first active slot)."""
        src = self.get_slot_path(slot_id)
        if src.exists() and src.stat().st_size > 50:
            try:
                shutil.copy2(src, self.legacy_storage_path)
            except Exception:
                pass

    def mark_slot_expired(self, slot_id: int, reason: str = "Sesi berakhir") -> None:
        self._runtime_state[slot_id] = {
            "expired": True,
            "reason": reason,
            "updated_at": dt.datetime.now().strftime("%H:%M:%S"),
        }

    def mark_slot_healthy(self, slot_id: int) -> None:
        self._runtime_state[slot_id] = {
            "expired": False,
            "reason": "",
            "verified_at": dt.datetime.now().strftime("%H:%M:%S"),
        }
        if slot_id == 1 or not self.legacy_storage_path.exists():
            self.sync_slot_to_legacy(slot_id)

    def delete_slot(self, slot_id: int) -> None:
        path = self.get_slot_path(slot_id)
        if path.exists():
            try:
                path.unlink()
            except Exception:
                pass
        if slot_id == 1 and self.legacy_storage_path.exists():
            try:
                self.legacy_storage_path.unlink()
            except Exception:
                pass
        self._runtime_state.pop(slot_id, None)

    def inspect_slot(self, slot_id: int) -> Dict[str, Any]:
        """Parse storage_state JSON for a slot and extract officer, Faskes, and token health."""
        slot_id = max(1, min(self.MAX_SLOTS, int(slot_id)))
        path = self.get_slot_path(slot_id)
        if slot_id == 1 and not path.exists() and self.legacy_storage_path.exists():
            self._migrate_legacy_session()

        info: Dict[str, Any] = {
            "slot_id": slot_id,
            "label": f"Akun Nakes #{slot_id}",
            "has_file": False,
            "status": "empty",  # empty | active | expiring_soon | expired
            "status_label": "Slot Kosong",
            "officer_name": "",
            "faskes_name": "",
            "jabatan": "",
            "email": "",
            "nik": "",
            "region": "",
            "saved_at": "-",
            "age_minutes": 0,
            "jwt_remaining_minutes": None,
            "stk_remaining_minutes": None,
            "refresh_remaining_minutes": None,
            "keepalive_enabled": True,
            "verified_at": self._runtime_state.get(slot_id, {}).get("verified_at", ""),
            "error_reason": self._runtime_state.get(slot_id, {}).get("reason", ""),
        }

        if not path.exists() or path.stat().st_size <= 50:
            return info

        try:
            stat = path.stat()
            mtime_dt = dt.datetime.fromtimestamp(stat.st_mtime)
            age_sec = max(0.0, time.time() - stat.st_mtime)
            info["has_file"] = True
            info["saved_at"] = mtime_dt.strftime("%d %b %H:%M")
            info["age_minutes"] = int(age_sec // 60)

            raw = json.loads(path.read_text(encoding="utf-8"))
            origins = raw.get("origins", [])
            cookies = raw.get("cookies", [])

            jwt_exp: Optional[int] = None
            stk_exp: Optional[int] = None
            refresh_exp: Optional[int] = None
            has_auth_entry = False

            for origin in origins:
                for item in origin.get("localStorage", []):
                    k = (item.get("name") or "").strip()
                    v = item.get("value") or ""
                    if k == "user_eksternal" and v:
                        has_auth_entry = True
                        try:
                            u = json.loads(v)
                            info["faskes_name"] = (
                                u.get("faskes_name")
                                or u.get("health_centre_name")
                                or u.get("sarana_binaan_name")
                                or u.get("nama_faskes")
                                or u.get("namaFaskes")
                                or u.get("instansi")
                                or ""
                            ).strip()
                            info["officer_name"] = (
                                u.get("name")
                                or u.get("nama")
                                or u.get("full_name")
                                or ""
                            ).strip()
                            info["jabatan"] = (
                                u.get("job_position_name")
                                or u.get("instance_position")
                                or u.get("jabatan")
                                or u.get("role_name")
                                or ""
                            ).strip()
                            info["email"] = (u.get("email") or "").strip()
                            info["nik"] = (u.get("nik") or u.get("identity_number") or "").strip()
                            prov = (u.get("provinsi_name") or u.get("namaProvinsi") or "").strip()
                            kab = (u.get("kabkota_name") or u.get("namaKabKota") or "").strip()
                            info["region"] = " • ".join(p for p in (kab, prov) if p)
                            for tk_field in ("token", "access_token", "jwt"):
                                if isinstance(u.get(tk_field), str):
                                    exp_cand = _decode_jwt_exp(u[tk_field])
                                    if exp_cand:
                                        jwt_exp = exp_cand
                        except Exception:
                            pass
                    elif k.lower() in ("token", "access_token", "auth_token", "jwt") and v:
                        has_auth_entry = True
                        exp_cand = _decode_jwt_exp(v.strip('"'))
                        if exp_cand:
                            jwt_exp = exp_cand

            for c in cookies:
                c_name = (c.get("name") or "").strip().lower()
                c_val = c.get("value") or ""
                c_exp = c.get("expires")
                c_exp_int = int(c_exp) if isinstance(c_exp, (int, float)) and c_exp > 0 else None
                if c_name in ("asik_web_stk", "asik_web_ctk") and c_exp_int:
                    stk_exp = c_exp_int if stk_exp is None else min(stk_exp, c_exp_int)
                    has_auth_entry = True
                elif c_name == "refresh_token" and c_exp_int:
                    refresh_exp = c_exp_int
                    has_auth_entry = True
                elif c_name in ("token_eksternal", "access_menu") and c_exp_int:
                    jwt_exp = c_exp_int
                    has_auth_entry = True
                if c_val.count(".") == 2:
                    exp_cand = _decode_jwt_exp(c_val)
                    if exp_cand:
                        jwt_exp = exp_cand
                        has_auth_entry = True

            if len(cookies) > 0:
                has_auth_entry = True

            now_ts = int(time.time())
            if stk_exp:
                info["stk_remaining_minutes"] = int((stk_exp - now_ts) // 60)
            if refresh_exp:
                info["refresh_remaining_minutes"] = int((refresh_exp - now_ts) // 60)

            rt = self._runtime_state.get(slot_id, {})
            if rt.get("expired"):
                info["status"] = "expired"
                info["status_label"] = "Sesi Berakhir (Perlu Login)"
                return info

            if jwt_exp:
                rem_sec = jwt_exp - now_ts
                info["jwt_remaining_minutes"] = int(rem_sec // 60)
                if rem_sec <= 0 and (not refresh_exp or refresh_exp <= now_ts):
                    info["status"] = "expired"
                    info["status_label"] = "Token Kedaluwarsa"
                    return info
                if 0 < rem_sec < 1800:
                    info["status"] = "expiring_soon"
                    info["status_label"] = f"Aktif • Auto-KeepAlive ({max(1, int(rem_sec // 60))} mnt)"
                    return info

            if has_auth_entry:
                info["status"] = "active"
                info["status_label"] = "Aktif • Auto-KeepAlive"
            else:
                info["status"] = "expired"
                info["status_label"] = "Belum Terautentikasi"

        except Exception as exc:
            info["status"] = "expired"
            info["status_label"] = f"File Sesi Rusak ({exc})"

        return info

    def get_all_slots(self) -> List[Dict[str, Any]]:
        return [self.inspect_slot(i) for i in range(1, self.MAX_SLOTS + 1)]

    def get_healthy_slots(self) -> List[Dict[str, Any]]:
        return [
            s
            for s in self.get_all_slots()
            if s["status"] in ("active", "expiring_soon") and s["has_file"]
        ]

    def get_primary_faskes_info(self) -> Dict[str, str]:
        """Return Faskes & Officer metadata from the first populated slot."""
        for s in self.get_all_slots():
            if s["faskes_name"] or s["officer_name"]:
                return {
                    "faskes_name": s["faskes_name"] or "Akun Kemenkes Aktif",
                    "officer_name": s["officer_name"],
                    "jabatan": s["jabatan"],
                    "region": s["region"],
                }
        return {
            "faskes_name": self.state_db.get_setting("active_faskes", "Belum Terdeteksi"),
            "officer_name": "",
            "jabatan": "",
            "region": "",
        }


class LicenseManager:
    """
    Hybrid Cloud SaaS License & Faskes-Lock Controller (Opsi A).
    Provides cryptographic HMAC-SHA256 license verification, Faskes binding,
    tamper-proof monotonic quota tracking, program-scope locking (Sekolah vs Umum),
    and Owner Studio vs Client Mode isolation.
    """

    def __init__(
        self,
        state_db: StateDB,
        ledger_path: Optional[Path] = None,
        owner_mode: Optional[bool] = None,
        base_dir: Optional[Path] = None,
    ) -> None:
        self.state_db = state_db
        self.machine_id = get_machine_fingerprint()
        self.base_dir = Path(base_dir) if base_dir else self.state_db.db_path.resolve().parent.parent
        owner_marker = self.base_dir / ".owner_studio.key"

        if owner_mode is not None:
            self.is_owner_mode = bool(owner_mode)
        else:
            self.is_owner_mode = (
                owner_marker.exists()
                or self.state_db.get_setting("owner_studio_unlocked", "") == "1"
            )

        if ledger_path is not None:
            self.ledger_path = Path(ledger_path)
        elif str(self.base_dir).startswith(("/tmp", "/private/var/folders", "/var/folders")):
            self.ledger_path = self.base_dir / ".ckg_terpadu_ledger.json"
        else:
            self.ledger_path = Path.home() / ".ckg_terpadu_ledger.json"

        self._ledger_tampered = False
        self._ledger_data: Dict[str, Any] = {}
        self._sync_tamper_proof_ledger()
        self._ensure_default_license()

    def _compute_ledger_sig(self, hw: str, first_seen: str, used: int, trial_key: str) -> str:
        msg = f"{hw}|{first_seen}|{int(used)}|{trial_key}".encode("utf-8")
        return hmac.new(_SAAS_MASTER_SECRET, msg, hashlib.sha256).hexdigest().upper()

    def _sync_tamper_proof_ledger(self) -> None:
        """Load or initialize the signed hardware usage ledger to prevent SQLite deletion resets."""
        db_used = int(self.state_db.get_setting("saas_processed_count", 0) or 0)
        if self.ledger_path.exists():
            try:
                raw = json.loads(self.ledger_path.read_text(encoding="utf-8"))
                hw = str(raw.get("hw", self.machine_id))
                first_seen = str(raw.get("first_seen", dt.date.today().isoformat()))
                ledger_used = int(raw.get("used", 0))
                trial_key = str(raw.get("trial_key", ""))
                sig = str(raw.get("sig", ""))
                expected = self._compute_ledger_sig(hw, first_seen, ledger_used, trial_key)
                if not sig or not hmac.compare_digest(sig.upper(), expected):
                    self._ledger_tampered = True
                    return
                merged_used = max(db_used, ledger_used)
                self._ledger_data = {
                    "hw": hw,
                    "first_seen": first_seen,
                    "used": merged_used,
                    "trial_key": trial_key,
                }
                if merged_used != db_used:
                    self.state_db.save_setting("saas_processed_count", merged_used)
                if merged_used != ledger_used:
                    self._save_ledger()
                return
            except Exception:
                self._ledger_tampered = True
                return

        self._ledger_data = {
            "hw": self.machine_id,
            "first_seen": dt.date.today().isoformat(),
            "used": db_used,
            "trial_key": "",
        }
        self._save_ledger()

    def _save_ledger(self) -> None:
        if self._ledger_tampered:
            return
        hw = self._ledger_data.get("hw", self.machine_id)
        first_seen = self._ledger_data.get("first_seen", dt.date.today().isoformat())
        used = int(self._ledger_data.get("used", 0))
        trial_key = str(self._ledger_data.get("trial_key", ""))
        sig = self._compute_ledger_sig(hw, first_seen, used, trial_key)
        payload = {
            "hw": hw,
            "first_seen": first_seen,
            "used": used,
            "trial_key": trial_key,
            "sig": sig,
        }
        try:
            self.ledger_path.parent.mkdir(parents=True, exist_ok=True)
            self.ledger_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        except Exception:
            pass

    def _ensure_default_license(self) -> None:
        """
        In Owner Mode: ensure an active ENTERPRISE_DINKES license is present.
        In Client Mode: start with a hardware-bound Starter Trial (30 quota, 14 days)
        persisted in the tamper-proof hardware ledger so wiping state.db cannot reset Trial.
        """
        saved_key = self.state_db.get_setting("saas_license_key", "")
        if saved_key:
            return

        if self.is_owner_mode:
            default_key = self.generate_license_key(
                client_name="Owner Master Studio (All Faskes)",
                plan="ENTERPRISE_DINKES",
                faskes_lock="*",
                days_valid=3650,
                quota_limit=999999,
            )
            self.state_db.save_setting("saas_license_key", default_key)
            return

        ledger_trial = self._ledger_data.get("trial_key", "")
        if not ledger_trial:
            ledger_trial = self.generate_license_key(
                client_name="Uji Coba Puskesmas (Starter Trial)",
                plan="TRIAL",
                faskes_lock="*",
                days_valid=14,
                quota_limit=30,
                machine_lock=self.machine_id,
            )
            self._ledger_data["trial_key"] = ledger_trial
            self._save_ledger()
        self.state_db.save_setting("saas_license_key", ledger_trial)

    def verify_owner_pin(self, pin: str) -> bool:
        if self.is_owner_mode:
            return True
        given = (pin or "").strip()
        if not given:
            return False
        return hmac.compare_digest(given, _OWNER_MASTER_PIN)

    def unlock_owner_studio(self, pin: str) -> Tuple[bool, str]:
        if not self.verify_owner_pin(pin):
            return False, "PIN Pengelola (Owner) tidak sesuai."
        self.is_owner_mode = True
        self.state_db.save_setting("owner_studio_unlocked", "1")
        return True, "Mode Pengelola (Owner Studio) berhasil dibuka."

    @staticmethod
    def clean_faskes_lock(raw_faskes: str) -> str:
        """Strip officer name suffix (e.g. 'SEI PANAS • NADYA AGITHA') so lock binds to the Puskesmas."""
        val = (raw_faskes or "*").strip()
        if "•" in val:
            val = val.split("•", 1)[0].strip()
        return (val or "*").upper()

    @staticmethod
    def generate_license_key(
        client_name: str,
        plan: str = "PRO_PUSKESMAS",
        faskes_lock: str = "*",
        days_valid: int = 365,
        quota_limit: int = 50000,
        machine_lock: str = "*",
    ) -> str:
        """Generate a signed cryptographic license key: CKG-V3.<payload_b64>.<sig_hex>."""
        plan_code = plan if plan in PLAN_DEFINITIONS else "PRO_PUSKESMAS"
        plan_meta = PLAN_DEFINITIONS[plan_code]
        now = dt.date.today()
        exp_date = now + dt.timedelta(days=max(1, int(days_valid)))
        cleaned_faskes = LicenseManager.clean_faskes_lock(faskes_lock)

        payload = {
            "v": 3,
            "client": (client_name or "Puskesmas Mitra").strip(),
            "plan": plan_code,
            "faskes": cleaned_faskes,
            "hw": (machine_lock or "*").strip().upper(),
            "workers": plan_meta["max_workers"],
            "quota": int(quota_limit or plan_meta["default_quota"]),
            "iat": now.isoformat(),
            "exp": exp_date.isoformat(),
        }
        payload_bytes = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
        payload_b64 = _b64url_encode(payload_bytes)
        sig = hmac.new(_SAAS_MASTER_SECRET, payload_b64.encode("ascii"), hashlib.sha256).hexdigest()[:16].upper()
        return f"CKG-V3.{payload_b64}.{sig}"

    def get_issued_licenses(self) -> List[Dict[str, Any]]:
        """Return all client licenses issued by the Owner Studio, enriched with live days_left & status."""
        raw_str = self.state_db.get_setting("saas_issued_licenses_json", "[]") or "[]"
        try:
            items = json.loads(raw_str)
            if not isinstance(items, list):
                items = []
        except Exception:
            items = []

        today = dt.date.today()
        enriched: List[Dict[str, Any]] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            rec = dict(item)
            exp_str = str(rec.get("expires_at", ""))
            try:
                exp_date = dt.date.fromisoformat(exp_str)
                days_left = (exp_date - today).days
            except Exception:
                days_left = int(rec.get("days_valid", 365))
            rec["days_left"] = days_left
            if days_left < 0:
                rec["status"] = "expired"
                rec["status_label"] = "Kedaluwarsa"
            elif days_left <= 14:
                rec["status"] = "expiring_soon"
                rec["status_label"] = f"Segera Habis ({days_left} hr)"
            else:
                rec["status"] = "active"
                rec["status_label"] = f"Aktif ({days_left} hr)"
            enriched.append(rec)
        return enriched

    def record_issued_license(
        self,
        client_name: str,
        plan: str,
        faskes_lock: str,
        days_valid: int,
        quota_limit: int,
        machine_lock: str,
        license_key: str,
        wa_template: str,
        notes: str = "",
    ) -> List[Dict[str, Any]]:
        """Save or update an issued client license in the Owner CRM Registry."""
        raw_str = self.state_db.get_setting("saas_issued_licenses_json", "[]") or "[]"
        try:
            items = json.loads(raw_str)
            if not isinstance(items, list):
                items = []
        except Exception:
            items = []

        plan_code = plan if plan in PLAN_DEFINITIONS else "PRO_PUSKESMAS"
        plan_meta = PLAN_DEFINITIONS[plan_code]
        now = dt.date.today()
        exp_date = now + dt.timedelta(days=max(1, int(days_valid)))
        clean_faskes = self.clean_faskes_lock(faskes_lock)

        new_rec = {
            "id": f"LIC-{int(time.time() * 1000)}-{uuid.uuid4().hex[:4].upper()}",
            "client_name": (client_name or "Puskesmas Mitra").strip(),
            "plan": plan_code,
            "plan_name": plan_meta["name"],
            "plan_badge": plan_meta["badge"],
            "faskes_lock": clean_faskes,
            "machine_lock": (machine_lock or "*").strip().upper(),
            "days_valid": int(days_valid),
            "quota_limit": int(quota_limit),
            "created_at": now.isoformat(),
            "expires_at": exp_date.isoformat(),
            "license_key": license_key,
            "wa_template": wa_template,
            "notes": (notes or "").strip(),
        }
        items.insert(0, new_rec)
        self.state_db.save_setting("saas_issued_licenses_json", json.dumps(items, ensure_ascii=False))
        return self.get_issued_licenses()

    def delete_issued_license(self, rec_id: str) -> List[Dict[str, Any]]:
        """Remove a client license record from the Owner CRM Registry by ID."""
        raw_str = self.state_db.get_setting("saas_issued_licenses_json", "[]") or "[]"
        try:
            items = json.loads(raw_str)
            if not isinstance(items, list):
                items = []
        except Exception:
            items = []
        filtered = [it for it in items if isinstance(it, dict) and it.get("id") != rec_id]
        self.state_db.save_setting("saas_issued_licenses_json", json.dumps(filtered, ensure_ascii=False))
        return self.get_issued_licenses()

    def verify_license_key(
        self, key_str: str, ignore_hw_lock: bool = False
    ) -> Tuple[bool, str, Dict[str, Any]]:
        """Verify cryptographic signature, expiration date, and hardware binding."""
        clean = (key_str or "").strip()
        if not clean.startswith("CKG-V3.") or clean.count(".") != 2:
            return False, "Format kode lisensi tidak valid (harus diawali CKG-V3.).", {}

        _, payload_b64, sig_given = clean.split(".", 2)
        expected_sig = (
            hmac.new(_SAAS_MASTER_SECRET, payload_b64.encode("ascii"), hashlib.sha256)
            .hexdigest()[:16]
            .upper()
        )
        if not hmac.compare_digest(sig_given.upper(), expected_sig):
            return False, "Tanda tangan kriptografi lisensi tidak sah (Signature Mismatch).", {}

        try:
            payload = json.loads(_b64url_decode(payload_b64).decode("utf-8"))
        except Exception:
            return False, "Payload lisensi rusak.", {}

        exp_str = payload.get("exp", "")
        try:
            exp_date = dt.date.fromisoformat(exp_str)
            days_left = (exp_date - dt.date.today()).days
            if days_left < 0:
                return False, f"Lisensi telah kedaluwarsa pada {exp_str}.", payload
            payload["days_left"] = days_left
        except Exception:
            payload["days_left"] = 365

        hw_lock = payload.get("hw", "*")
        if (
            not ignore_hw_lock
            and hw_lock
            and hw_lock != "*"
            and hw_lock.upper() != self.machine_id.upper()
        ):
            return (
                False,
                f"Lisensi ini dikunci untuk perangkat {hw_lock} (Perangkat Anda: {self.machine_id}).",
                payload,
            )

        return True, "Lisensi Aktif & Terverifikasi", payload

    def activate_license(self, key_str: str) -> Dict[str, Any]:
        ok, msg, payload = self.verify_license_key(key_str)
        if not ok:
            return {"ok": False, "message": msg}
        self.state_db.save_setting("saas_license_key", key_str.strip())
        return {
            "ok": True,
            "message": f"Lisensi {payload.get('plan')} untuk '{payload.get('client')}' berhasil diaktifkan!",
            "status": self.get_status(),
        }

    def get_usage_count(self) -> int:
        db_used = int(self.state_db.get_setting("saas_processed_count", 0) or 0)
        ledger_used = int(self._ledger_data.get("used", 0) or 0)
        return max(db_used, ledger_used)

    def increment_usage(self, count: int = 1) -> int:
        cur = self.get_usage_count() + max(0, count)
        self.state_db.save_setting("saas_processed_count", cur)
        self._ledger_data["used"] = cur
        self._save_ledger()
        return cur

    def verify_faskes_and_quota(
        self, detected_faskes: str, service_type: str = "sekolah"
    ) -> Tuple[bool, str]:
        """Check whether the current Faskes, program scope, & participant quota are permitted."""
        if self._ledger_tampered:
            return (
                False,
                "Sistem mendeteksi manipulasi pada file proteksi kuota perangkat. Silakan hubungi pengelola lisensi resmi.",
            )

        status = self.get_status()
        if not status["is_valid"]:
            return False, status["message"]

        allowed_services = status.get("allowed_services", ["sekolah", "umum"])
        norm_srv = "umum" if str(service_type).lower().strip() == "umum" else "sekolah"
        if norm_srv not in allowed_services:
            only_label = "CKG Sekolah" if "sekolah" in allowed_services else "CKG Umum"
            return (
                False,
                f"Paket lisensi Anda ({status['plan_name']}) hanya berlaku untuk program {only_label}. "
                f"Silakan upgrade ke Paket Clinical Pro Puskesmas (Sekolah + Umum).",
            )

        used = status["quota_used"]
        limit = status["quota_limit"]
        if used >= limit:
            return (
                False,
                f"Kuota paket {status['plan_name']} telah habis ({used}/{limit} peserta). Silakan aktifkan lisensi Pro Puskesmas.",
            )

        faskes_lock = (status["faskes_lock"] or "*").strip().upper()
        if faskes_lock != "*":
            det_upper = (detected_faskes or "").strip().upper()
            if det_upper and det_upper not in ("BELUM TERDETEKSI", "AKUN KEMENKES AKTIF"):
                if faskes_lock not in det_upper and det_upper not in faskes_lock:
                    return (
                        False,
                        f"Faskes-Lock Mismatch! Lisensi ini hanya berlaku untuk '{faskes_lock}', "
                        f"sedangkan akun Kemenkes yang login adalah '{detected_faskes}'.",
                    )

        return True, "OK"

    def get_status(self) -> Dict[str, Any]:
        key_str = self.state_db.get_setting("saas_license_key", "")
        ok, msg, payload = self.verify_license_key(key_str)
        if self._ledger_tampered:
            ok = False
            msg = "File proteksi kuota perangkat rusak atau dimodifikasi."
        plan_code = payload.get("plan", "TRIAL") if ok else "UNLICENSED"
        plan_meta = PLAN_DEFINITIONS.get(plan_code, PLAN_DEFINITIONS["PRO_PUSKESMAS"])
        used = self.get_usage_count()
        quota_limit = int(payload.get("quota", plan_meta["default_quota"])) if ok else 0

        return {
            "is_valid": ok,
            "is_owner_mode": self.is_owner_mode,
            "message": msg,
            "machine_id": self.machine_id,
            "license_key": key_str,
            "client_name": payload.get("client", "Belum Terdaftar"),
            "plan_code": plan_code,
            "plan_name": plan_meta["name"] if ok else "Lisensi Tidak Valid",
            "plan_badge": plan_meta["badge"] if ok else "UNLICENSED",
            "allowed_services": plan_meta.get("allowed_services", ["sekolah", "umum"]),
            "faskes_lock": payload.get("faskes", "*"),
            "max_workers": int(payload.get("workers", plan_meta["max_workers"])) if ok else 1,
            "quota_used": used,
            "quota_limit": quota_limit,
            "expires_at": payload.get("exp", "-"),
            "days_left": payload.get("days_left", 0),
            "issued_licenses": self.get_issued_licenses() if self.is_owner_mode else [],
        }
