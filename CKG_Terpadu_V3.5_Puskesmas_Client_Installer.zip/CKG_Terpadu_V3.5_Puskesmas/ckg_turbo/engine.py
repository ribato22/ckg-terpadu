from __future__ import annotations

import asyncio
import datetime as dt
import importlib
import json
import os
import platform
import re
import sys
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple


def _detach_dead_tty_stdio(data_dir: Optional[Path] = None) -> None:
    """
    Prevent Node.js (Playwright driver) libuv uv_tty_init() from blocking in kernel open()
    if the Python server was started in a macOS/POSIX pseudo-terminal (ttysXXX) that was later closed.
    """
    if "unittest" in sys.modules:
        return
    try:
        if os.isatty(0):
            devnull_fd = os.open(os.devnull, os.O_RDONLY)
            os.dup2(devnull_fd, 0)
            os.close(devnull_fd)
    except Exception:
        pass
    try:
        if os.isatty(2):
            log_target = str(data_dir / "playwright_driver.log") if data_dir else os.devnull
            err_fd = os.open(log_target, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)
            os.dup2(err_fd, 2)
            os.close(err_fd)
    except Exception:
        pass


_detach_dead_tty_stdio(Path(__file__).resolve().parent.parent / "data")

from . import models as _models_mod

if not hasattr(_models_mod.JobConfig, "auto_retry_failed"):
    importlib.reload(_models_mod)
    _srv_mod = sys.modules.get("ckg_turbo.server")
    if _srv_mod is not None:
        setattr(_srv_mod, "JobConfig", _models_mod.JobConfig)

from .excel_io import export_report_excel, swap_day_month_if_possible
from .models import DataQualitySummary, JobConfig, StudentRecord
from .saas import LicenseManager, SessionVault
from .selectors import (
    DISABLE_ANIMATIONS_INIT_SCRIPT,
    JS_CHECK_STEP1_STATUS,
    JS_CLICK_KIRIM,
    JS_FILL_FAKTOR_TB,
    JS_FILL_IMUNISASI,
    JS_FILL_REPRODUKSI_PUTRA,
    JS_FILL_REPRODUKSI_PUTRI,
    JS_FILL_TELINGA_MATA,
    JS_GET_MANDIRI_PROGRESS,
    JS_IS_LOADING_ACTIVE,
    JS_IS_OUTSIDE_EXAM_PAGE,
    JS_KLIK_OPSI,
    JS_RADAR_ERROR_CHECK,
    JS_READ_FORM_ERRORS,
    JS_TAG_MANDIRI_BUTTONS,
    JS_TAG_NAKES_BUTTONS,
    SAFE_DEFAULT_ANSWERS,
    URL_BASE,
    URL_LOGIN,
    URL_PELAYANAN,
    URL_PELAYANAN_UMUM,
    URL_PENDAFTARAN,
    URL_PENDAFTARAN_UMUM,
)
from .state_db import StateDB


class BomAutoRetryUniversal(Exception):
    """Raised when Kemenkes returns a transient error or session reset requiring retry."""


def get_cross_platform_user_agent() -> str:
    sys_name = platform.system().lower()
    if sys_name == "darwin":
        return (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
        )
    if sys_name == "linux":
        return (
            "Mozilla/5.0 (X11; Linux x86_64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
        )
    return (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    )


class CKGTurboEngine:
    """
    Ultra-Robust, High-Speed, Cross-Platform Async Playwright Engine for CKG Sekolah.
    Matches 100% of V2.6's exact DOM sequences while supporting live session hot-reload.
    """

    def __init__(
        self,
        data_dir: str | Path,
        state_db: StateDB,
        log_callback: Optional[Callable[[str, str, Optional[int]], None]] = None,
    ) -> None:
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.storage_state_path = self.data_dir / "storage_state.json"
        self.reports_dir = self.data_dir / "reports"
        self.reports_dir.mkdir(parents=True, exist_ok=True)

        self.state_db = state_db
        self._log_callback = log_callback

        # Enterprise SaaS License Manager & Multi-Account Session Vault (Opsi A)
        self.license_mgr = LicenseManager(state_db)
        self.session_vault = SessionVault(self.data_dir, state_db)

        self.is_running: bool = False
        self.is_paused: bool = False
        self.stop_requested: bool = False
        self.session_expired: bool = False

        # Session hot-reload tracking so paused workers immediately pick up new logins
        self._session_reload_seq: int = 0
        self._worker_session_seq: Dict[int, int] = {}
        self._worker_slot_map: Dict[int, int] = {}
        self._active_context: Optional[Any] = None
        self._slot_contexts: Dict[int, Any] = {}
        self._active_pages: Dict[int, Any] = {}
        self._filter_lock = asyncio.Lock()
        self._slot_locks: Dict[int, asyncio.Lock] = {
            i: asyncio.Lock() for i in range(1, SessionVault.MAX_SLOTS + 1)
        }
        self._verified_school_cache: Dict[str, str] = {}

        self.active_faskes: str = self.state_db.get_setting("active_faskes", "Belum Terdeteksi")
        self.officer_name: str = ""
        self.faskes_region: str = ""
        self._load_session_metadata()

        self.current_file_key: str = ""
        self.current_excel_path: Optional[Path] = None
        self.latest_report_path: Optional[Path] = None
        self.students: List[StudentRecord] = []
        self.data_quality: DataQualitySummary = DataQualitySummary()
        self.config: JobConfig = JobConfig()

        # Latest JPEG screenshot bytes per worker_id for Live Background Peek
        self.worker_screenshots: Dict[int, bytes] = {}
        self.worker_status: Dict[int, str] = {}
        self._report_lock = asyncio.Lock()

    def _load_session_metadata(self) -> None:
        """Read Faskes name, Officer name, and Region from SessionVault or storage_state.json."""
        self.session_vault._migrate_legacy_session()
        primary = self.session_vault.get_primary_faskes_info()
        faskes = primary.get("faskes_name", "")
        officer = primary.get("officer_name", "")
        region = primary.get("region", "")
        if faskes and faskes not in ("Belum Terdeteksi", "Akun Kemenkes Aktif"):
            self.active_faskes = f"{faskes} • {officer}" if officer else faskes
            self.officer_name = officer
            self.faskes_region = region
            self.state_db.save_setting("active_faskes", self.active_faskes)
            return

        if not self.has_saved_session():
            return
        try:
            raw = json.loads(self.storage_state_path.read_text(encoding="utf-8"))
            for origin in raw.get("origins", []):
                for item in origin.get("localStorage", []):
                    if item.get("name") == "user_eksternal":
                        user_obj = json.loads(item.get("value", "{}"))
                        faskes = (user_obj.get("faskes_name") or "").strip()
                        officer = (user_obj.get("name") or "").strip()
                        kab = (user_obj.get("kabkota_name") or "").strip()
                        prov = (user_obj.get("provinsi_name") or "").strip()
                        if faskes and officer:
                            self.active_faskes = f"{faskes} • {officer}"
                        elif faskes:
                            self.active_faskes = faskes
                        self.officer_name = officer
                        self.faskes_region = f"{kab}, {prov}".strip(", ")
                        self.state_db.save_setting("active_faskes", self.active_faskes)
                        return
        except Exception:
            pass

    def log(self, message: str, level: str = "info", worker_id: Optional[int] = None) -> None:
        prefix = f"[W{worker_id}] " if worker_id is not None else ""
        full_msg = f"{prefix}{message}"
        if self._log_callback:
            self._log_callback(full_msg, level, worker_id)

    def _ensure_keepalive_daemon_running(self) -> None:
        """Lazily start the background session keep-alive loop inside the active asyncio event loop."""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        task = getattr(self, "_keepalive_task", None)
        if task is None or task.done():
            self._keepalive_task = loop.create_task(self._session_keepalive_loop())

    async def _session_keepalive_loop(self) -> None:
        """
        Background Session Keep-Alive Daemon:
        Every 45 seconds, checks all authenticated Account Slots (1..4).
        Because Kemenkes 'asik_web_stk' & 'asik_web_ctk' cookies expire after 60 minutes of inactivity
        (while 'token_eksternal' lasts 24h and 'refresh_token' lasts 7d), this daemon automatically
        refreshes the session cookies in headless mode whenever remaining STK cookie time <= 38 minutes
        or file age >= 22 minutes (while the robot is idle), keeping the session alive continuously!
        """
        while True:
            await asyncio.sleep(45)
            try:
                if getattr(self, "is_running", False):
                    continue
                for slot in self.session_vault.get_all_slots():
                    if not slot.get("has_file") or slot.get("status") not in ("active", "expiring_soon"):
                        continue
                    stk_rem = slot.get("stk_remaining_minutes")
                    age_min = slot.get("age_minutes", 0)
                    needs_refresh = (
                        (stk_rem is not None and stk_rem <= 38 and age_min >= 15)
                        or age_min >= 22
                    )
                    if needs_refresh and not getattr(self, "is_running", False):
                        slot_id = int(slot.get("slot_id", 1))
                        await self.verify_session_slot(slot_id=slot_id, quiet=True)
            except asyncio.CancelledError:
                break
            except Exception:
                pass

    def _get_faskes_fallback_wa(self) -> str:
        """Return 085117622524 specifically when active faskes is Puskesmas Sei Panas, else generic fallback."""
        if "sei panas" in (getattr(self, "active_faskes", "") or "").lower():
            return "085117622524"
        return "081234567890"

    def has_saved_session(self) -> bool:
        try:
            self.session_vault.__class__ = SessionVault
        except Exception:
            pass
        if not getattr(self, "_cleared_zombie_run_v37", False):
            self._cleared_zombie_run_v37 = True
            if getattr(self, "is_running", False) and not getattr(self, "_slot_contexts", None):
                self.is_running = False
        self._ensure_keepalive_daemon_running()
        file_key = getattr(self, "current_file_key", None)
        students = getattr(self, "students", None)
        if (
            students
            and "sei panas" in (getattr(self, "active_faskes", "") or "").lower()
            and not getattr(self, "_updated_default_wa_v38", False)
        ):
            self._updated_default_wa_v38 = True
            for s in students:
                if not s.wa_pasien or s.wa_pasien == "081234567890":
                    s.wa_pasien = "085117622524"
                    s.healed_notes = [
                        n.replace("081234567890", "085117622524") for n in (s.healed_notes or [])
                    ]
        if not getattr(self, "is_running", False) and file_key and students and not getattr(self, "_synced_db_v36", False):
            try:
                self.state_db.restore_checkpoints(file_key, students)
                self._synced_db_v36 = True
            except Exception:
                pass
        healthy = self.session_vault.get_healthy_slots()
        if healthy:
            return True
        all_slots = self.session_vault.get_all_slots()
        if any(s.get("status") == "expired" for s in all_slots):
            return False
        return self.storage_state_path.exists() and self.storage_state_path.stat().st_size > 50

    async def _launch_browser(self, p: Any, headless: bool) -> Any:
        _detach_dead_tty_stdio(getattr(self, "data_dir", None))
        launch_args = [
            "--disable-blink-features=AutomationControlled",
            "--force-device-scale-factor=1",
            "--disable-background-timer-throttling",
            "--disable-backgrounding-occluded-windows",
            "--disable-renderer-backgrounding",
        ]
        if not headless:
            launch_args.append("--start-maximized")

        channels = ("chrome", None, "msedge")
        for channel in channels:
            try:
                kwargs: Dict[str, Any] = {
                    "headless": headless,
                    "args": launch_args,
                    "timeout": 15000,
                }
                if channel:
                    kwargs["channel"] = channel
                return await p.chromium.launch(**kwargs)
            except Exception:
                continue
        raise RuntimeError(
            "Browser Chromium/Chrome tidak ditemukan. Pastikan Google Chrome terinstal "
            "atau jalankan: playwright install chromium"
        )

    def _get_worker_filter_lock(self, worker_id: int) -> asyncio.Lock:
        slot_id = self._worker_slot_map.get(worker_id, 1)
        return self._slot_locks.get(slot_id, self._filter_lock)

    async def _verify_or_refresh_context_session(self, context: Any) -> Dict[str, Any]:
        """
        Authoritative fast session check & token refresh against Kemenkes API
        (/api/user-management/refresh-token).
        Completes in ~0.3s instead of hanging 30-45s on Nuxt SSR HTTP 503 when token_eksternal expires.
        """
        try:
            cookies = await context.cookies()
            key_token = ""
            has_auth_cookie = False
            for c in cookies:
                name = c.get("name") or ""
                if name == "key_token":
                    key_token = c.get("value") or ""
                if name in ("token_eksternal", "refresh_token", "asik_token"):
                    has_auth_cookie = True
            if not has_auth_cookie:
                return {
                    "alive": False,
                    "expired": True,
                    "status": 401,
                    "message": "Cookie autentikasi tidak ditemukan.",
                }

            headers: Dict[str, str] = {
                "Accept": "application/json",
                "Content-Type": "application/json",
            }
            if key_token:
                headers["x-csrf-token"] = key_token

            resp = await context.request.post(
                f"{URL_BASE}/api/user-management/refresh-token",
                headers=headers,
                data="{}",
                timeout=10000,
            )
            status = resp.status
            body_text = ""
            try:
                body_text = await resp.text()
            except Exception:
                pass

            if status == 200:
                return {
                    "alive": True,
                    "expired": False,
                    "status": 200,
                    "message": "Sesi aktif dan token diperbarui.",
                }

            body_upper = (body_text or "").upper()
            if (
                status == 401
                or "ERROR_SESSION_EXPIRED" in body_upper
                or "ERROR_TOKEN_REVOKED" in body_upper
                or "SESI ANDA TELAH BERAKHIR" in body_upper
                or "SILAKAN LOGIN KEMBALI" in body_upper
            ):
                return {
                    "alive": False,
                    "expired": True,
                    "status": status,
                    "message": "Sesi Anda telah berakhir di server Kemenkes, silakan login kembali.",
                }

            return {
                "alive": False,
                "expired": False,
                "status": status,
                "message": f"Respons server Kemenkes HTTP {status}",
            }
        except Exception as exc:
            return {
                "alive": False,
                "expired": False,
                "status": 0,
                "message": str(exc),
            }

    async def verify_session_slot(self, slot_id: int = 1, quiet: bool = False) -> Dict[str, Any]:
        """
        Proactively verify and refresh a saved Kemenkes session slot in the background (headless)
        against sehatindonesiaku.kemkes.go.id, renewing the 60-minute 'asik_web_stk' / 'asik_web_ctk'
        cookies via the 7-day 'refresh_token' and saving them back to slot_{id}.json.
        """
        from playwright.async_api import async_playwright

        slot_id = max(1, min(SessionVault.MAX_SLOTS, int(slot_id)))
        slot_path = self.session_vault.get_slot_path(slot_id)
        if not slot_path.exists() or slot_path.stat().st_size <= 50:
            return {"ok": False, "slot_id": slot_id, "message": f"Slot #{slot_id} masih kosong."}

        if self.is_running:
            slot_info = self.session_vault.inspect_slot(slot_id)
            return {
                "ok": not self.session_expired,
                "slot_id": slot_id,
                "message": "Pelayanan sedang berjalan; verifikasi tidak membuka sesi ganda agar token tetap aman.",
                "slot": slot_info,
            }

        if not quiet:
            self.log(f"🩺 Memverifikasi kesehatan sesi Akun Nakes #{slot_id} ke server Kemenkes...", "info")
        try:
            async with async_playwright() as p:
                browser = await self._launch_browser(p, headless=True)
                context = await browser.new_context(
                    user_agent=get_cross_platform_user_agent(),
                    viewport={"width": 1366, "height": 840},
                    storage_state=str(slot_path),
                )
                await context.add_init_script(DISABLE_ANIMATIONS_INIT_SCRIPT)

                # Fast authoritative API check & token refresh before Nuxt SSR navigation
                api_check = await self._verify_or_refresh_context_session(context)
                if api_check.get("expired"):
                    self.session_vault.mark_slot_expired(slot_id, "Sesi berakhir di server Kemenkes (Perlu Login Ulang)")
                    self.session_expired = len(self.session_vault.get_healthy_slots()) == 0
                    await browser.close()
                    if not quiet:
                        self.log(f"⚠️ Sesi Akun Nakes #{slot_id} sudah berakhir. Silakan Login Ulang.", "warning")
                    else:
                        self.log(
                            f"⚠️ [AUTO KEEP-ALIVE] Sesi Akun Nakes #{slot_id} telah berakhir di server Kemenkes. Silakan klik 'Akun Kemenkes' -> 'Login Ulang'.",
                            "warning",
                        )
                    return {
                        "ok": False,
                        "slot_id": slot_id,
                        "message": f"Sesi Akun Nakes #{slot_id} sudah berakhir di server Kemenkes.",
                        "slot": self.session_vault.inspect_slot(slot_id),
                    }

                page = await context.new_page()
                resp_home = await page.goto(URL_BASE, wait_until="domcontentloaded", timeout=35000)
                if resp_home is not None and resp_home.status >= 500:
                    await browser.close()
                    return {
                        "ok": False,
                        "slot_id": slot_id,
                        "message": f"Server Kemenkes sedang sibuk (HTTP {resp_home.status}).",
                        "slot": self.session_vault.inspect_slot(slot_id),
                    }
                await self.wait_loading_smart(page, timeout_ms=8000, initial_delay_ms=400)
                await asyncio.sleep(1.2)
                await self._bypass_privacy_modal(page)

                check = await page.evaluate(
                    """() => {
                        const url = window.location.href.toLowerCase();
                        const body = (document.body && document.body.innerText) ? document.body.innerText : '';
                        const bodyTrim = body.trim().toLowerCase();
                        const serviceUnavailable = (
                            bodyTrim === 'service unavailable' ||
                            bodyTrim.includes('503 service unavailable')
                        );
                        const expired = (
                            url.includes('/auth/login') ||
                            body.includes('Sesi Telah Berakhir') ||
                            body.includes('digunakan oleh perangkat lain') ||
                            body.includes('Sesi Anda telah berakhir')
                        );
                        const hasUser = Boolean(localStorage.getItem('user_eksternal'));
                        return { expired, hasUser, url, serviceUnavailable };
                    }"""
                )
                if check.get("serviceUnavailable"):
                    await browser.close()
                    return {
                        "ok": False,
                        "slot_id": slot_id,
                        "message": "Server Kemenkes sedang mengembalikan Service Unavailable (HTTP 503).",
                        "slot": self.session_vault.inspect_slot(slot_id),
                    }
                if check.get("expired") or not check.get("hasUser"):
                    self.session_vault.mark_slot_expired(slot_id, "Sesi ditolak server Kemenkes")
                    self.session_expired = len(self.session_vault.get_healthy_slots()) == 0
                    await browser.close()
                    if not quiet:
                        self.log(f"⚠️ Sesi Akun Nakes #{slot_id} sudah berakhir. Silakan Login Ulang.", "warning")
                    return {
                        "ok": False,
                        "slot_id": slot_id,
                        "message": f"Sesi Akun Nakes #{slot_id} sudah berakhir di server Kemenkes.",
                        "slot": self.session_vault.inspect_slot(slot_id),
                    }

                await context.storage_state(path=str(slot_path))
                if slot_id == 1:
                    await context.storage_state(path=str(self.storage_state_path))
                self.session_vault.mark_slot_healthy(slot_id)
                self._load_session_metadata()
                await browser.close()
                slot_info = self.session_vault.inspect_slot(slot_id)
                if quiet:
                    self.log(
                        f"🔄 [AUTO KEEP-ALIVE] Sesi Akun Nakes #{slot_id} ({slot_info.get('officer_name') or slot_info.get('faskes_name')}) berhasil diperpanjang otomatis.",
                        "info",
                    )
                else:
                    self.log(
                        f"✅ Sesi Akun Nakes #{slot_id} ({slot_info.get('officer_name') or slot_info.get('faskes_name')}) AKTIF & TERVERIFIKASI!",
                        "success",
                    )
                return {
                    "ok": True,
                    "slot_id": slot_id,
                    "message": f"Sesi Akun Nakes #{slot_id} Aktif & Terverifikasi!",
                    "slot": slot_info,
                }
        except Exception as exc:
            return {"ok": False, "slot_id": slot_id, "message": f"Gagal memeriksa sesi: {exc}"}

    async def login_and_save_session(
        self, slot_id: int = 1, timeout_sec: int = 300, fresh_login: bool = False
    ) -> Dict[str, Any]:
        """
        Opens a visible login window to authenticate a specific Account Slot (1..4) with Kemenkes,
        recognizes /profile, /, /ckg-pelayanan-sekolah or any authenticated page immediately,
        saves cookies & localStorage to slot_{id}.json + storage_state.json, and hot-reloads active workers!
        """
        from playwright.async_api import async_playwright

        slot_id = max(1, min(SessionVault.MAX_SLOTS, int(slot_id)))
        slot_path = self.session_vault.get_slot_path(slot_id)
        slot_info_before = self.session_vault.inspect_slot(slot_id)

        self.log(
            f"🔐 Membuka jendela Login Sehat Indonesiaku untuk [Akun Nakes #{slot_id}]...",
            "info",
        )
        _detach_dead_tty_stdio(getattr(self, "data_dir", None))
        try:
            async with async_playwright() as p:
                browser = await self._launch_browser(p, headless=False)
                ctx_kwargs: Dict[str, Any] = {
                    "user_agent": get_cross_platform_user_agent(),
                    "viewport": {"width": 1366, "height": 840},
                }
                # Always open /auth/login with a clean cookie jar so expired token_eksternal
                # never causes Kemenkes Nuxt SSR to hang 30s with HTTP 503 Service Unavailable.
                context = await browser.new_context(**ctx_kwargs)
                await context.add_init_script(DISABLE_ANIMATIONS_INIT_SCRIPT)
                page = await context.new_page()
                try:
                    await page.bring_to_front()
                except Exception:
                    pass

                await page.goto(URL_LOGIN, wait_until="domcontentloaded", timeout=60000)
                try:
                    await page.bring_to_front()
                except Exception:
                    pass
                self.log(
                    f"⏳ Silakan login Akun Nakes #{slot_id} di jendela browser. Begitu masuk Beranda/Profil, sesi otomatis disimpan & jendela ditutup...",
                    "warning",
                )

                deadline = asyncio.get_event_loop().time() + timeout_sec
                logged_in = False
                while asyncio.get_event_loop().time() < deadline:
                    if page.is_closed():
                        break
                    try:
                        login_status = await page.evaluate(
                            """() => {
                                const url = window.location.href.toLowerCase();
                                if (!url.includes('sehatindonesiaku.kemkes.go.id')) return { ok: false };
                                if (url.includes('/auth/login')) return { ok: false };
                                const body = (document.body && document.body.innerText) ? document.body.innerText : '';
                                if (body.includes('Sesi Telah Berakhir') || body.includes('digunakan oleh perangkat lain')) {
                                    return { ok: false };
                                }
                                const hasPrivacy = body.includes('Pemberitahuan Privasi dan Ketentuan Penggunaan');
                                const hasMenuOrProfile = (
                                    body.includes('CKG Sekolah') ||
                                    body.includes('CKG Umum') ||
                                    body.includes('Informasi akun') ||
                                    body.includes('Keluar') ||
                                    body.includes('Pelayanan') ||
                                    body.includes('Pendaftaran')
                                );
                                const hasToken = Boolean(
                                    localStorage.getItem('user_eksternal') ||
                                    localStorage.getItem('token') ||
                                    localStorage.getItem('access_token')
                                );
                                if (hasPrivacy || (hasMenuOrProfile && hasToken) || (url.includes('/profile') && hasToken) || url.includes('/ckg-')) {
                                    return { ok: true, hasPrivacy };
                                }
                                return { ok: false };
                            }"""
                        )
                        if isinstance(login_status, dict) and login_status.get("ok"):
                            if login_status.get("hasPrivacy"):
                                await self._bypass_privacy_modal(page)
                            logged_in = True
                            await context.storage_state(path=str(slot_path))
                            self.session_vault.mark_slot_healthy(slot_id)
                            break
                    except Exception:
                        pass
                    await asyncio.sleep(0.35)

                if not logged_in:
                    try:
                        await browser.close()
                    except Exception:
                        pass
                    self.log(f"⚠️ Jendela login Akun Nakes #{slot_id} ditutup sebelum masuk.", "warning")
                    return {"ok": False, "message": "Login dibatalkan atau waktu tunggu habis."}

                # Wait briefly for final localStorage writes (user_eksternal), bypass privacy if shown, and save again
                await asyncio.sleep(0.8)
                await self._bypass_privacy_modal(page)
                try:
                    await context.storage_state(path=str(slot_path))
                    self.session_vault.mark_slot_healthy(slot_id)
                except Exception:
                    pass
                self._load_session_metadata()

                if self.active_faskes in ("Belum Terdeteksi", "Akun Kemenkes Aktif"):
                    detected = await self._detect_faskes_name(page)
                    if detected:
                        self.active_faskes = detected
                        self.state_db.save_setting("active_faskes", detected)

                try:
                    await browser.close()
                except Exception:
                    pass

                # Hot-reload session into any paused/running background workers and auto-resume!
                self.trigger_session_hot_reload(slot_id=slot_id, auto_resume=True)
                slot_meta = self.session_vault.inspect_slot(slot_id)

                self.log(
                    f"✅ Sesi Akun Nakes #{slot_id} berhasil disimpan! Faskes: {slot_meta.get('faskes_name') or self.active_faskes}. "
                    + (
                        "Mesin robot otomatis dilanjutkan (Auto-Resume)!"
                        if self.is_running
                        else "Siap berjalan di Background (Headless)."
                    ),
                    "success",
                )
                return {
                    "ok": True,
                    "slot_id": slot_id,
                    "faskes": self.active_faskes,
                    "slot": slot_meta,
                    "storage_state": str(slot_path),
                }
        except Exception as exc:
            self.log(f"❌ Gagal membuka jendela login Akun Nakes #{slot_id}: {exc}", "error")
            return {"ok": False, "slot_id": slot_id, "message": f"Gagal membuka jendela login: {exc}"}

    def trigger_session_hot_reload(
        self, slot_id: Optional[int] = None, auto_resume: bool = True
    ) -> None:
        """
        Marks all active workers to reload cookies & localStorage from their assigned slot
        and clears session_expired + pause flags so paused jobs resume automatically.
        """
        if slot_id is not None:
            self.session_vault.mark_slot_healthy(slot_id)
        else:
            for s in self.session_vault.get_all_slots():
                if s["has_file"]:
                    self.session_vault.mark_slot_healthy(s["slot_id"])
        self._load_session_metadata()
        self._session_reload_seq += 1
        self.session_expired = False
        if auto_resume and self.is_running and self.is_paused:
            self.is_paused = False

    async def _restore_session_to_page(self, page: Any, worker_id: int) -> None:
        """
        Injects freshly saved cookies and localStorage from the worker's assigned Account Slot
        (or first healthy slot in SessionVault) into an active worker page and navigates away
        from /auth/login so a paused batch resumes seamlessly without losing progress.
        """
        assigned_slot = self._worker_slot_map.get(worker_id, 1)
        slot_path = self.session_vault.get_slot_path(assigned_slot)
        if not slot_path.exists() or slot_path.stat().st_size <= 50:
            healthy = self.session_vault.get_healthy_slots()
            if healthy:
                assigned_slot = healthy[0]["slot_id"]
                slot_path = self.session_vault.get_slot_path(assigned_slot)
                self._worker_slot_map[worker_id] = assigned_slot
            elif self.storage_state_path.exists():
                slot_path = self.storage_state_path
            else:
                return

        try:
            self.log(
                f"🔄 Menyuntikkan sesi terbaru [Akun Nakes #{assigned_slot}] ke dalam Worker #{worker_id}...",
                "info",
                worker_id,
            )
            raw = json.loads(slot_path.read_text(encoding="utf-8"))
            cookies = raw.get("cookies", [])
            if cookies:
                try:
                    await page.context.clear_cookies()
                except Exception:
                    pass
                await page.context.add_cookies(cookies)

            ls_items: List[Dict[str, str]] = []
            for origin in raw.get("origins", []):
                if "sehatindonesiaku.kemkes.go.id" in (origin.get("origin") or ""):
                    ls_items = origin.get("localStorage", [])
                    break

            if "sehatindonesiaku.kemkes.go.id" not in page.url.lower():
                await page.goto(URL_BASE, wait_until="domcontentloaded", timeout=40000)

            if ls_items:
                await page.evaluate(
                    """(items) => {
                        try {
                            for (const it of items) {
                                if (it && it.name) {
                                    localStorage.setItem(it.name, it.value);
                                }
                            }
                        } catch (e) {}
                    }""",
                    ls_items,
                )

            await page.goto(URL_BASE, wait_until="domcontentloaded", timeout=40000)
            await self.wait_loading_smart(page, timeout_ms=10000, initial_delay_ms=250)
            await self._bypass_privacy_modal(page)
            self._worker_session_seq[worker_id] = self._session_reload_seq
            self.session_vault.mark_slot_healthy(assigned_slot)
            self.session_expired = False
            await self.capture_worker_peek(page, worker_id)
            self.log(
                f"✅ Sesi Worker #{worker_id} (Akun #{assigned_slot}) berhasil dipulihkan! Melanjutkan siswa...",
                "success",
                worker_id,
            )
        except Exception as exc:
            self.log(f"⚠️ Gagal menyuntikkan sesi baru ke Worker: {exc}", "warning", worker_id)

    async def _bypass_privacy_modal(self, page: Any) -> None:
        """Fast bypass for 'Pemberitahuan Privasi dan Ketentuan Penggunaan' modal."""
        try:
            judul = page.get_by_text("Pemberitahuan Privasi dan Ketentuan Penggunaan").first
            if not await judul.is_visible():
                return
            self.log("⚡ Membypass pop-up Pemberitahuan Privasi & Ketentuan...", "info")
            await page.evaluate(
                """() => {
                    const containers = document.querySelectorAll('div, .ant-modal-body, .modal-body');
                    for (const c of containers) {
                        if (c.scrollHeight > c.clientHeight + 20) {
                            c.scrollTop = c.scrollHeight;
                        }
                    }
                }"""
            )
            await asyncio.sleep(0.2)
            cb = page.locator("input#verify, input[type='checkbox']").first
            await cb.click(force=True, timeout=3000)
            btn_setuju = page.get_by_role("button", name="Setuju").first
            await btn_setuju.click(force=True, timeout=3000)
            await asyncio.sleep(0.3)
        except Exception:
            pass

    async def _detect_faskes_name(self, page: Any) -> str:
        """Extract active Puskesmas / Faskes & Officer name from localStorage or header."""
        try:
            info = await page.evaluate(
                """() => {
                    try {
                        const raw = localStorage.getItem('user_eksternal');
                        if (raw) {
                            const u = JSON.parse(raw);
                            if (u.faskes_name && u.name) return `${u.faskes_name} • ${u.name}`;
                            if (u.faskes_name) return u.faskes_name;
                        }
                    } catch (e) {}
                    const headerEls = Array.from(document.querySelectorAll('header *, nav *, .ant-layout-header *, div'));
                    for (const el of headerEls) {
                        const t = (el.innerText || '').trim();
                        if (/^(PUSKESMAS|PKM|KLINIK|RS|UPTD)\\s+[A-Z0-9 ]+/i.test(t) && t.length < 60) {
                            return t.split('\\n')[0].trim();
                        }
                    }
                    return '';
                }"""
            )
            return info or self.active_faskes or "Akun Kemenkes Aktif"
        except Exception:
            return self.active_faskes or "Akun Kemenkes Aktif"

    async def wait_loading_smart(
        self, page: Any, timeout_ms: int = 20000, initial_delay_ms: int = 160
    ) -> None:
        """
        High-frequency V3.3 tunggu_loading_cerdas (Kacamata 1 & Kacamata 2):
        Polls every 80ms so the engine resumes the instant Kemenkes finishes loading.
        """
        if initial_delay_ms > 0:
            await asyncio.sleep(min(initial_delay_ms, 220) / 1000.0)

        deadline = asyncio.get_event_loop().time() + (timeout_ms / 1000.0)
        was_loading = False
        while asyncio.get_event_loop().time() < deadline:
            try:
                is_loading = await page.evaluate(JS_IS_LOADING_ACTIVE)
                if not is_loading:
                    if was_loading:
                        await asyncio.sleep(0.12)
                    return
                was_loading = True
            except Exception:
                return
            await asyncio.sleep(0.08)

    async def capture_worker_peek(self, page: Any, worker_id: int) -> None:
        """Capture lightweight JPEG frame for the Web Dashboard Live Background Peek."""
        try:
            if not page.is_closed():
                jpg = await page.screenshot(type="jpeg", quality=55)
                self.worker_screenshots[worker_id] = jpg
        except Exception:
            pass

    async def _safe_click(self, locator: Any, timeout: int = 3000) -> None:
        """
        Click a Playwright locator safely even if it is inside a floating dropdown or modal
        that extends outside the viewport. Scrolls element to center first, tries Playwright
        click, and falls back to DOM el.click() if Playwright reports 'outside of the viewport'.
        """
        eval_timeout = min(max(timeout, 500), 1500)
        try:
            await locator.evaluate(
                "el => el.scrollIntoView({ block: 'center', inline: 'nearest' })",
                timeout=eval_timeout,
            )
        except Exception:
            pass
        try:
            await locator.click(force=True, timeout=timeout)
        except Exception as exc:
            err_lower = str(exc).lower()
            if "navigation" in err_lower:
                return
            if (
                "outside of the viewport" in err_lower
                or "not visible" in err_lower
                or "timeout" in err_lower
                or "intercept" in err_lower
            ):
                await locator.evaluate(
                    "el => { el.scrollIntoView({ block: 'center', inline: 'nearest' }); el.click(); }",
                    timeout=eval_timeout,
                )
            else:
                raise

    async def _safe_fill(self, locator: Any, value: str, timeout: int = 3000) -> None:
        """
        Fill an input safely without calling .click() (which can fail with 'outside of the viewport'
        inside floating Vue/Tailwind dropdowns). Scrolls to center, tries locator.fill(), and falls
        back to native HTMLInputElement value setter + input/change event dispatch.
        """
        val_str = str(value or "")
        eval_timeout = min(max(timeout, 500), 1500)
        try:
            await locator.evaluate(
                "el => el.scrollIntoView({ block: 'center', inline: 'nearest' })",
                timeout=eval_timeout,
            )
        except Exception:
            pass
        try:
            await locator.fill(val_str, timeout=timeout)
        except Exception:
            await locator.evaluate(
                """(el, val) => {
                    el.scrollIntoView({ block: 'center', inline: 'nearest' });
                    el.focus();
                    const proto = el.tagName === 'TEXTAREA'
                        ? window.HTMLTextAreaElement.prototype
                        : window.HTMLInputElement.prototype;
                    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
                    if (setter) setter.call(el, val);
                    else el.value = val;
                    el.dispatchEvent(new Event('input', { bubbles: true }));
                    el.dispatchEvent(new Event('change', { bubbles: true }));
                }""",
                val_str,
                timeout=eval_timeout,
            )

    async def _safe_focus_end(self, locator: Any) -> None:
        """
        Focus an input and move caret to the end via DOM JS without requiring mouse coordinates
        inside the viewport.
        """
        try:
            await locator.evaluate(
                """el => {
                    el.scrollIntoView({ block: 'center', inline: 'nearest' });
                    el.focus();
                    if (typeof el.setSelectionRange === 'function') {
                        const len = (el.value || '').length;
                        el.setSelectionRange(len, len);
                    }
                }""",
                timeout=1500,
            )
        except Exception:
            pass

    async def radar_sapu_jagat(
        self, page: Any, worker_id: int, force_session_expired: bool = False
    ) -> None:
        """
        Exact V2.6 Radar Sapu Jagat: detects session expiry or Kemenkes modal errors.
        Automatically triggers session hot-reload if user already logged in again.
        """
        # If a new session was saved via login_and_save_session or Resume, apply it first!
        if self._session_reload_seq > self._worker_session_seq.get(worker_id, 0):
            await self._restore_session_to_page(page, worker_id)
            raise BomAutoRetryUniversal("Sesi baru telah dimuat, mengulang langkah siswa saat ini.")

        url_now = (page.url or "").lower()
        sesi_habis = bool(force_session_expired)
        if not sesi_habis:
            try:
                page_state = await page.evaluate(
                    """() => {
                        const body = (document.body && document.body.innerText) ? document.body.innerText : '';
                        const bodyTrim = body.trim().toLowerCase();
                        const expired = body.includes('Sesi Telah Berakhir') ||
                               body.includes('digunakan oleh perangkat lain') ||
                               body.includes('Sesi Anda telah berakhir');
                        const serviceUnavailable = (
                            bodyTrim === 'service unavailable' ||
                            bodyTrim.includes('503 service unavailable')
                        );
                        return { expired, serviceUnavailable };
                    }"""
                )
                sesi_habis = bool(page_state.get("expired"))
                if not sesi_habis and page_state.get("serviceUnavailable"):
                    api_check = await self._verify_or_refresh_context_session(page.context)
                    if api_check.get("expired"):
                        sesi_habis = True
            except Exception:
                sesi_habis = False

        if "auth/login" in url_now or sesi_habis:
            seq_before_pause = self._session_reload_seq
            assigned_slot = self._worker_slot_map.get(worker_id, 1)
            self.session_vault.mark_slot_expired(assigned_slot, "Sesi berakhir atau digunakan perangkat lain")
            self.session_expired = True
            self.is_paused = True
            self.log(
                f"🚨 SESI KEMENKES [Akun Nakes #{assigned_slot}] BERAKHIR DI SERVER KEMENKES! "
                f"Robot otomatis masuk mode Pause aman (tanpa menggagalkan siswa). Silakan klik tombol 'Akun Kemenkes' di kanan atas -> 'Login Ulang / Perbarui' (Akun #{assigned_slot}); "
                f"begitu selesai login, robot akan OTOMATIS melanjutkan (Auto-Resume)!",
                "error",
                worker_id,
            )
            try:
                btn_ok = page.locator('button:has-text("Ok"), button:has-text("OK")').first
                if await btn_ok.is_visible():
                    await btn_ok.click(force=True, timeout=2000)
            except Exception:
                pass

            # Wait while paused until user logs in again or clicks Resume
            while self.is_paused and not self.stop_requested:
                self.worker_status[worker_id] = f"Paused (Menunggu Login Akun #{assigned_slot})"
                await asyncio.sleep(0.3)

            if self.stop_requested:
                raise asyncio.CancelledError("Dihentikan oleh pengguna.")

            # Restore fresh session from slot file into this page before retrying student!
            if self._session_reload_seq <= seq_before_pause:
                self._session_reload_seq += 1
            await self._restore_session_to_page(page, worker_id)
            raise BomAutoRetryUniversal("Sesi telah diperbarui setelah Pause, mengulang siswa saat ini.")

        try:
            err_text = await page.evaluate(JS_RADAR_ERROR_CHECK)
            if err_text:
                if "data peserta" in err_text.lower() and "ckg-pendaftaran" in url_now:
                    return
                self.log(
                    f"⚠️ Pop-up Error Kemenkes terdeteksi: '{err_text}'. Melakukan evakuasi...",
                    "warning",
                    worker_id,
                )
                btn_close = page.locator(
                    'button:has-text("OK"), button:has-text("Ok"), button:has-text("Tutup"), button:has-text("Kembali")'
                ).first
                if await btn_close.is_visible():
                    await btn_close.click(force=True, timeout=2000)
                else:
                    await page.keyboard.press("Escape")
                await asyncio.sleep(0.3)
                raise BomAutoRetryUniversal(f"Kemenkes Pop-up Error: {err_text}")
        except BomAutoRetryUniversal:
            raise
        except Exception:
            pass

    @staticmethod
    def _is_network_error(exc_or_msg: Any) -> bool:
        """Detect browser or OS network disconnection errors."""
        msg = str(exc_or_msg or "").lower()
        net_tokens = (
            "err_internet_disconnected",
            "err_name_not_resolved",
            "err_network_changed",
            "err_connection_timed_out",
            "err_connection_reset",
            "err_connection_closed",
            "err_connection_refused",
            "err_address_unreachable",
            "err_timed_out",
            "net::err_",
            "failed to fetch",
            "networkerror",
            "load failed",
            "connection reset",
            "Temporary failure in name resolution".lower(),
            "nodename nor servname provided",
        )
        return any(tok in msg for tok in net_tokens)

    @staticmethod
    def _is_closed_target_error(exc_or_msg: Any) -> bool:
        """Detect crashed/closed Playwright page, context, or browser errors."""
        msg = str(exc_or_msg or "").lower()
        closed_tokens = (
            "target page, context or browser has been closed",
            "browser has been closed",
            "context or browser has been closed",
            "target closed",
            "page has been closed",
            "connection closed while reading from the driver",
        )
        return any(tok in msg for tok in closed_tokens)

    @staticmethod
    def _is_permanent_failure(student: StudentRecord) -> bool:
        """
        Return True if the student's failure reason is a permanent data/quota rejection
        that should NOT be endlessly retried in automatic end-of-batch retry waves.
        """
        status_low = (student.status_sistem or "").lower()
        perm_tokens = (
            "data peserta atau wali tidak valid",
            "data tidak sama dengan disdukcapil",
            "kuota faskes penuh",
            "nik kosong atau kurang dari 16 digit",
        )
        if any(tok in status_low for tok in perm_tokens):
            return True
        return False

    async def _probe_kemenkes_connectivity(self) -> bool:
        """Non-blocking TCP/DNS probe to sehatindonesiaku.kemkes.go.id:443."""
        try:
            _reader, writer = await asyncio.wait_for(
                asyncio.open_connection("sehatindonesiaku.kemkes.go.id", 443),
                timeout=3.5,
            )
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass
            return True
        except Exception:
            return False

    async def _wait_for_internet_recovery(
        self, page: Any, worker_id: int, student: StudentRecord, exc_or_msg: Any
    ) -> bool:
        """
        Smart Network Outage Guardian:
        If the error is caused by an internet disconnection (or Kemenkes portal is unreachable),
        automatically holds the queue without burning retry attempts or quota, saves partial
        student checkpoint (e.g., Nomor Tiket), and resumes automatically once internet returns.
        """
        is_explicit_net_err = self._is_network_error(exc_or_msg)
        is_online = await self._probe_kemenkes_connectivity()
        if is_online and not is_explicit_net_err:
            return False

        # Save partial progress (such as obtained no_tiket) immediately to SQLite
        if self.current_file_key and student.no_tiket and student.no_tiket != "-":
            try:
                self.state_db.save_student_checkpoint(self.current_file_key, student)
            except Exception:
                pass

        # If it was just a transient 1-second blip and internet is already back online:
        if is_online and is_explicit_net_err:
            self.log(
                f"📡 Koneksi sempat terputus sesaat pada tahap [{student.last_step}]. Menyambung ulang otomatis tanpa mengurangi percobaan...",
                "warning",
                worker_id,
            )
            await asyncio.sleep(1.5)
            return True

        self.log(
            f"📡 KONEKSI INTERNET TERPUTUS saat memproses {student.nama} di tahap [{student.last_step}]! "
            f"Robot otomatis menahan antrean (Auto-Hold) dan tidak memotong kuota. Menunggu koneksi internet pulih...",
            "warning",
            worker_id,
        )

        waited_sec = 0
        while not self.stop_requested:
            self.worker_status[worker_id] = f"📡 Menunggu Internet Pulih... ({waited_sec} dtk)"
            if await self._probe_kemenkes_connectivity():
                break
            for _ in range(6):
                if self.stop_requested:
                    raise asyncio.CancelledError("Dihentikan oleh pengguna saat menunggu koneksi internet.")
                await asyncio.sleep(0.5)
            waited_sec += 3

        if self.stop_requested:
            raise asyncio.CancelledError("Dihentikan oleh pengguna.")

        assigned_slot = self._worker_slot_map.get(worker_id, 1)
        self.worker_status[worker_id] = f"[Akun #{assigned_slot}] Menyambung ulang {student.nama}..."
        self.log(
            f"🌐 Koneksi internet pulih kembali! Melanjutkan pemrosesan {student.nama} secara otomatis...",
            "success",
            worker_id,
        )
        try:
            cur_u = (page.url or "").lower()
            if "chrome-error" in cur_u or "about:blank" in cur_u or "kemkes.go.id" not in cur_u:
                target_u = (
                    URL_PELAYANAN_UMUM
                    if getattr(student, "service_type", "sekolah") == "umum"
                    else URL_BASE
                )
                await page.goto(target_u, wait_until="domcontentloaded", timeout=35000)
                await self.wait_loading_smart(page, timeout_ms=6000, initial_delay_ms=250)
        except Exception:
            pass
        return True

    async def check_pause_and_stop(self, page: Any, worker_id: int) -> None:
        was_paused = False
        while self.is_paused and not self.stop_requested:
            was_paused = True
            self.worker_status[worker_id] = "Paused"
            await asyncio.sleep(0.3)
        if self.stop_requested:
            raise asyncio.CancelledError("Dihentikan oleh pengguna.")
        if was_paused and (
            self._session_reload_seq > self._worker_session_seq.get(worker_id, 0)
            or "auth/login" in page.url.lower()
        ):
            await self._restore_session_to_page(page, worker_id)
            raise BomAutoRetryUniversal("Dilanjutkan setelah Pause & pembaruan sesi.")
        await self.radar_sapu_jagat(page, worker_id)

    async def run_batch(self, config: JobConfig, retry_failed_only: bool = False) -> None:
        """
        Main entry point for running the background automation batch.
        Uses a single shared BrowserContext with _filter_lock so Kemenkes never flags
        multiple competing sessions ('digunakan oleh perangkat lain').
        """
        from playwright.async_api import async_playwright

        if self.is_running:
            self.log("⚠️ Mesin robot sedang berjalan!", "warning")
            return
        if not self.students:
            self.log("⚠️ Belum ada data siswa Excel yang dimuat!", "error")
            return

        self.config = config
        self.is_running = True
        self.is_paused = False
        self.stop_requested = False
        self.session_expired = False

        if self.current_file_key and self.students:
            try:
                self.state_db.restore_checkpoints(self.current_file_key, self.students)
            except Exception:
                pass

        queue: asyncio.Queue[StudentRecord] = asyncio.Queue()
        candidates: List[StudentRecord] = []
        has_pending_targets = any(s.state == "pending" for s in self.students)
        for s in self.students:
            if "Melengkapi Skrining Mandiri" in (s.status_sistem or ""):
                s._check_selesai_first = True  # type: ignore[attr-defined]
                s._already_selesai_pemeriksaan = True  # type: ignore[attr-defined]
                s._mandiri_already_lengkap = False  # type: ignore[attr-defined]
            if retry_failed_only:
                if s.state in ("failed", "pending"):
                    if "Menekan Selesaikan Layanan" in (s.status_sistem or "") or "Melengkapi Skrining Mandiri" in (s.status_sistem or ""):
                        s._check_selesai_first = True  # type: ignore[attr-defined]
                    s.state = "pending"
                    candidates.append(s)
            elif has_pending_targets and not config.update_data_lama:
                if s.state == "pending":
                    candidates.append(s)
            elif config.mode == "B" or config.update_data_lama:
                # In Mode B (Skrining Mandiri) or update_data_lama when no pending targets exist,
                # allow scanning already-finished students unless skipped due to invalid NIK or CKG Umum
                if "ckg umum" not in (s.status_sistem or "").lower() and "nik kosong" not in (s.status_sistem or "").lower():
                    if s.state in ("success", "warning", "skipped"):
                        s._check_selesai_first = True  # type: ignore[attr-defined]
                    candidates.append(s)
            else:
                if s.state not in ("success", "warning", "skipped"):
                    s.state = "pending"
                    candidates.append(s)

        # Prioritize students who already have a Ticket (in Sedang/Belum/Selesai Pemeriksaan) first
        candidates.sort(
            key=lambda st: (0 if (st.no_tiket and st.no_tiket != "-") else 1, st.row_index)
        )
        for s in candidates:
            queue.put_nowait(s)
        queued_count = len(candidates)

        if queued_count == 0 and not (config.mode in ("B", "C") and not config.lewati_skrining):
            self.log("✅ Seluruh siswa dalam file ini sudah berstatus SUKSES!", "success")
            self.is_running = False
            return

        if config.headless and not self.has_saved_session():
            self.log(
                "🔑 Belum ada sesi login tersimpan di Brankas Sesi. Membuka jendela login Akun Nakes #1...",
                "warning",
            )
            login_res = await self.login_and_save_session(slot_id=1)
            if not login_res.get("ok"):
                self.is_running = False
                return

        # SaaS License & Faskes-Lock Verification (Opsi A)
        batch_srv = (
            "umum"
            if (
                getattr(config, "service_type", "sekolah") == "umum"
                or any(getattr(s, "service_type", "sekolah") == "umum" for s in self.students)
            )
            else "sekolah"
        )
        lic_ok, lic_msg = self.license_mgr.verify_faskes_and_quota(
            self.active_faskes, service_type=batch_srv
        )
        if not lic_ok:
            self.log(f"🛡️ [SAAS LICENSE LOCK] {lic_msg}", "error")
            self.is_running = False
            return

        lic_status = self.license_mgr.get_status()
        max_lic_workers = max(1, int(lic_status.get("max_workers", 4) or 1))

        healthy_slots = self.session_vault.get_healthy_slots()
        active_slot_ids = [s["slot_id"] for s in healthy_slots] or [1]
        requested_workers = max(1, min(4, int(getattr(config, "workers", 1) or 1)))
        num_workers = max(1, min(requested_workers, max_lic_workers, len(active_slot_ids)))

        mode_label = {
            "C": "Paket Lengkap (Pendaftaran, Skrining Mandiri & Pemeriksaan Nakes)",
            "A": "Tahap 1 (Pendaftaran & Konfirmasi Kehadiran)",
            "B": "Tahap 2 (Kuesioner Skrining Mandiri)",
            "D": "Tahap 3 (Pemeriksaan Fisik & Klinis Nakes)",
        }.get(config.mode, f"Tahap {config.mode}")

        session_strategy = (
            "1 Petugas Turbo Stabil (Anti-Putus Sesi)"
            if num_workers == 1
            else f"{num_workers} Jalur Petugas Paralel (Multi-Slot Terisolasi)"
        )
        is_umum_batch = (
            getattr(config, "service_type", "sekolah") == "umum"
            or any(getattr(s, "service_type", "sekolah") == "umum" for s in self.students)
        )
        prog_title = "CKG Umum (Dewasa & Lansia)" if is_umum_batch else "CKG Sekolah"
        target_unit = "peserta" if is_umum_batch else "peserta didik"
        self.log(
            f"🚀 Memulai Pelayanan {prog_title} — {mode_label} | "
            f"{session_strategy} | "
            f"Target: {queued_count} {target_unit}",
            "info",
        )

        try:
            async with async_playwright() as p:
                browser = await self._launch_browser(p, headless=config.headless)
                self._playwright_instance = p
                self._browser_instance = browser
                self._slot_contexts.clear()
                self._worker_slot_map.clear()
                worker_contexts: Dict[int, Any] = {}
                self._worker_contexts = worker_contexts

                # Create one isolated BrowserContext per Worker (so each Petugas has its own
                # isolated localStorage for dataDetail/dataDetailTicket & its own filter table DOM!)
                for w_id in range(1, num_workers + 1):
                    assigned_slot = active_slot_ids[(w_id - 1) % len(active_slot_ids)]
                    self._worker_slot_map[w_id] = assigned_slot
                    ctx = await self._create_worker_context(w_id)
                    worker_contexts[w_id] = ctx

                self._active_context = worker_contexts.get(1)

                workers = []
                for w_id in range(1, num_workers + 1):
                    w_ctx = worker_contexts[w_id]
                    workers.append(asyncio.create_task(self._worker_loop(w_id, w_ctx, queue)))

                await asyncio.gather(*workers, return_exceptions=True)

                # Automatic End-of-Batch Retry Wave for any remaining failed participants (Strictly Bounded)
                if getattr(self.config, "auto_retry_failed", True):
                    max_retry_waves = 2
                    for retry_wave in range(1, max_retry_waves + 1):
                        if self.stop_requested or self.session_expired:
                            break
                        failed_list = [
                            s
                            for s in self.students
                            if s.state == "failed" and not self._is_permanent_failure(s)
                        ]
                        if not failed_list:
                            break
                        prev_failed_total = sum(1 for s in self.students if s.state == "failed")
                        self.log(
                            f"🔄 [AUTO-RETRY OTOMATIS GELOMBANG #{retry_wave}/{max_retry_waves}] "
                            f"Mengulangi {len(failed_list)} {target_unit} yang terkendala di akhir antrean...",
                            "warning",
                        )
                        failed_list.sort(
                            key=lambda st: (
                                0 if (st.no_tiket and st.no_tiket != "-") else 1,
                                st.row_index,
                            )
                        )
                        for s in failed_list:
                            if (
                                "Menekan Selesaikan Layanan" in (s.status_sistem or "")
                                or "Melengkapi Skrining Mandiri" in (s.status_sistem or "")
                            ):
                                s._check_selesai_first = True  # type: ignore[attr-defined]
                            s.state = "pending"
                            queue.put_nowait(s)
                        retry_workers = []
                        for w_id in range(1, num_workers + 1):
                            w_ctx = self._worker_contexts.get(w_id) or worker_contexts[w_id]
                            retry_workers.append(
                                asyncio.create_task(self._worker_loop(w_id, w_ctx, queue))
                            )
                        await asyncio.gather(*retry_workers, return_exceptions=True)
                        new_failed_total = sum(1 for s in self.students if s.state == "failed")
                        recovered_in_wave = max(0, prev_failed_total - new_failed_total)
                        if recovered_in_wave == 0 and new_failed_total > 0:
                            self.log(
                                f"🛑 [SMART STOP AUTO-RETRY] Gelombang #{retry_wave}/{max_retry_waves} tidak menghasilkan tambahan {target_unit} yang tuntas (masih {new_failed_total} terkendala). Menghentikan pengulangan otomatis agar tidak berputar terus.",
                                "warning",
                            )
                            break

                if not self.session_expired:
                    for slot_id, ctx in list(self._slot_contexts.items()):
                        try:
                            s_path = self.session_vault.get_slot_path(slot_id)
                            await asyncio.wait_for(ctx.storage_state(path=str(s_path)), timeout=5.0)
                            self.session_vault.mark_slot_healthy(slot_id)
                        except Exception:
                            pass
                for ctx in list(worker_contexts.values()):
                    try:
                        await asyncio.wait_for(ctx.close(), timeout=4.0)
                    except Exception:
                        pass
                self._active_context = None
                self._slot_contexts.clear()
                self._active_pages.clear()
                try:
                    if self._browser_instance:
                        await asyncio.wait_for(self._browser_instance.close(), timeout=5.0)
                except Exception:
                    pass
                self._browser_instance = None
                self._playwright_instance = None
        except Exception as exc:
            self.log(f"❌ Error mesin utama: {exc}", "error")
        finally:
            for s in self.students:
                if s.state == "pending" and "gagal" in (s.status_sistem or "").lower():
                    s.state = "failed"
            await self._save_report_snapshot()
            self.is_running = False
            self.worker_status.clear()
            self.log(
                f"🏁 Tugas selesai! Laporan Excel tersimpan otomatis di: {self.latest_report_path}",
                "success",
            )

    async def _create_worker_context(self, worker_id: int) -> Any:
        """Create or recreate an isolated BrowserContext for a worker, relaunching browser if needed."""
        assigned_slot = self._worker_slot_map.get(worker_id, 1)
        slot_path = self.session_vault.get_slot_path(assigned_slot)
        ctx_kwargs: Dict[str, Any] = {
            "user_agent": get_cross_platform_user_agent(),
            "viewport": {"width": 1440, "height": 1080},
        }
        if slot_path.exists() and slot_path.stat().st_size > 50:
            ctx_kwargs["storage_state"] = str(slot_path)
        elif self.storage_state_path.exists() and self.storage_state_path.stat().st_size > 50:
            ctx_kwargs["storage_state"] = str(self.storage_state_path)

        browser = getattr(self, "_browser_instance", None)
        p_inst = getattr(self, "_playwright_instance", None)
        if browser is None or (hasattr(browser, "is_connected") and not browser.is_connected()):
            if p_inst is not None:
                browser = await self._launch_browser(p_inst, headless=self.config.headless)
                self._browser_instance = browser

        try:
            ctx = await browser.new_context(**ctx_kwargs)
        except Exception:
            if p_inst is not None:
                browser = await self._launch_browser(p_inst, headless=self.config.headless)
                self._browser_instance = browser
                ctx = await browser.new_context(**ctx_kwargs)
            else:
                raise

        await ctx.add_init_script(DISABLE_ANIMATIONS_INIT_SCRIPT)
        if hasattr(self, "_worker_contexts") and isinstance(self._worker_contexts, dict):
            self._worker_contexts[worker_id] = ctx
        self._slot_contexts[assigned_slot] = ctx
        if worker_id == 1:
            self._active_context = ctx
        return ctx

    async def _ensure_worker_page_alive(
        self, worker_id: int, current_page: Any = None, force_reopen: bool = False
    ) -> Any:
        """Ensure worker has an open, responsive Playwright page; recreate page/context/browser if closed."""
        if current_page is not None and not force_reopen:
            try:
                if not current_page.is_closed():
                    return current_page
            except Exception:
                pass
        if current_page is not None:
            try:
                if not current_page.is_closed():
                    await asyncio.wait_for(current_page.close(), timeout=2.5)
            except Exception:
                pass

        ctx = getattr(self, "_worker_contexts", {}).get(worker_id)
        page = None
        if ctx is not None:
            try:
                page = await asyncio.wait_for(ctx.new_page(), timeout=10.0)
            except Exception:
                page = None
        if page is None:
            ctx = await self._create_worker_context(worker_id)
            page = await asyncio.wait_for(ctx.new_page(), timeout=15.0)

        page.set_default_timeout(30000)
        self._attach_api_response_sniffer(page)
        self._active_pages[worker_id] = page
        try:
            await page.goto(URL_BASE, wait_until="domcontentloaded", timeout=40000)
            await self.wait_loading_smart(page, timeout_ms=8000, initial_delay_ms=200)
            await self._bypass_privacy_modal(page)
        except Exception:
            pass
        return page

    def _attach_api_response_sniffer(self, page: Any) -> None:
        """
        Passive Hybrid API Sniffer:
        Listens to JSON responses from sehatindonesiaku.kemkes.go.id and automatically
        extracts Nomor Tiket for any matching students in self.students so subsequent
        students in the same class can Fast-Track directly without Phase 1 or multi-tab searches.
        """
        ticket_re = re.compile(r"\b([A-Za-z0-9]{3}-[A-Za-z0-9]{3})\b")

        async def _on_response(resp: Any) -> None:
            try:
                url = resp.url or ""
                if "kemkes.go.id" not in url:
                    return
                ctype = (resp.headers.get("content-type") or "").lower()
                if "json" not in ctype:
                    return
                payload = await resp.json()
                self._ingest_api_json_for_tickets(payload, ticket_re)
            except Exception:
                pass

        try:
            page.on("response", lambda r: asyncio.create_task(_on_response(r)))
        except Exception:
            pass

    def _ingest_api_json_for_tickets(self, node: Any, ticket_re: Any) -> None:
        if isinstance(node, dict):
            vals_str = " | ".join(str(v) for v in node.values() if isinstance(v, (str, int)))
            m_tkt = ticket_re.search(vals_str)
            if m_tkt:
                tkt = m_tkt.group(1).upper()
                lower_blob = vals_str.lower()
                for s in getattr(self, "students", []):
                    if s.no_tiket and s.no_tiket != "-":
                        continue
                    nama_low = (s.nama or "").strip().lower()
                    nik_low = (s.nik or "").strip().lower()
                    if (nik_low and nik_low in lower_blob) or (
                        nama_low and len(nama_low) >= 4 and nama_low in lower_blob
                    ):
                        s.no_tiket = tkt
            for v in node.values():
                if isinstance(v, (dict, list)):
                    self._ingest_api_json_for_tickets(v, ticket_re)
        elif isinstance(node, list):
            for item in node[:200]:
                if isinstance(item, (dict, list)):
                    self._ingest_api_json_for_tickets(item, ticket_re)

    async def _worker_loop(
        self, worker_id: int, context: Any, queue: asyncio.Queue[StudentRecord]
    ) -> None:
        assigned_slot = self._worker_slot_map.get(worker_id, 1)
        try:
            page = await asyncio.wait_for(context.new_page(), timeout=12.0)
            page.set_default_timeout(30000)
            self._attach_api_response_sniffer(page)
            self._active_pages[worker_id] = page
        except Exception:
            page = await self._ensure_worker_page_alive(worker_id, None, force_reopen=True)
            context = getattr(self, "_worker_contexts", {}).get(worker_id, context)
        self._worker_session_seq[worker_id] = self._session_reload_seq
        self.worker_status[worker_id] = f"Menyiapkan Sesi (Akun #{assigned_slot})"

        try:
            api_precheck = await self._verify_or_refresh_context_session(context)
            if api_precheck.get("expired"):
                try:
                    await self.radar_sapu_jagat(page, worker_id, force_session_expired=True)
                except BomAutoRetryUniversal:
                    pass
            try:
                await page.goto(URL_BASE, wait_until="domcontentloaded", timeout=45000)
            except Exception as nav_exc:
                if self._is_closed_target_error(nav_exc) or page.is_closed():
                    page = await self._ensure_worker_page_alive(worker_id, page, force_reopen=True)
                    context = getattr(self, "_worker_contexts", {}).get(worker_id, context)
                else:
                    api_postcheck = await self._verify_or_refresh_context_session(context)
                    if api_postcheck.get("expired"):
                        try:
                            await self.radar_sapu_jagat(page, worker_id, force_session_expired=True)
                        except BomAutoRetryUniversal:
                            pass
                    else:
                        self.log(
                            f"⚠️ Server Kemenkes lambat merespons saat membuka beranda ({nav_exc}). Melanjutkan langsung ke halaman pelayanan...",
                            "warning",
                            worker_id,
                        )
            await self.wait_loading_smart(page, timeout_ms=10000, initial_delay_ms=250)
            await self._bypass_privacy_modal(page)
            try:
                await self.radar_sapu_jagat(page, worker_id)
            except BomAutoRetryUniversal:
                pass
            faskes = await self._detect_faskes_name(page)
            if faskes:
                self.active_faskes = faskes
            if not self.session_expired:
                self.session_vault.mark_slot_healthy(assigned_slot)
            if not self.session_expired and not page.is_closed() and "auth/login" not in (page.url or "").lower():
                try:
                    s_path = self.session_vault.get_slot_path(assigned_slot)
                    await asyncio.wait_for(context.storage_state(path=str(s_path)), timeout=5.0)
                    if assigned_slot == 1:
                        await asyncio.wait_for(context.storage_state(path=str(self.storage_state_path)), timeout=5.0)
                except Exception:
                    pass
            await self.capture_worker_peek(page, worker_id)

            queued_items = list(getattr(queue, "_queue", []))
            is_umum_queue = (
                getattr(self.config, "service_type", "sekolah") == "umum"
                or any(getattr(st, "service_type", "sekolah") == "umum" for st in queued_items)
            )
            lic_ok_post_login, lic_msg_post_login = self.license_mgr.verify_faskes_and_quota(
                self.active_faskes, service_type="umum" if is_umum_queue else "sekolah"
            )
            if not lic_ok_post_login:
                self.log(f"🛡️ [SAAS LICENSE LOCK] {lic_msg_post_login}", "error", worker_id)
                self.stop_requested = True
                return
            if (
                worker_id == 1
                and not is_umum_queue
                and self.config.mode in ("B", "C")
                and not self.config.lewati_skrining
                and not self.stop_requested
            ):
                all_pretargeted = bool(queued_items) and all(
                    getattr(st, "_check_selesai_first", False)
                    and getattr(st, "_mandiri_already_lengkap", None) is False
                    and bool(st.no_tiket and st.no_tiket != "-")
                    for st in queued_items
                )
                all_unticketed_retry = (
                    self.config.mode == "C"
                    and not self.config.update_data_lama
                    and bool(queued_items)
                    and any(s.state in ("success", "warning") for s in self.students)
                    and all(
                        not (st.no_tiket and st.no_tiket != "-")
                        and not getattr(st, "_check_selesai_first", False)
                        for st in queued_items
                    )
                )
                if all_pretargeted:
                    self.log(
                        f"⚡ Langsung memproses {len(queued_items)} siswa target yang Pemeriksaan Mandirinya belum lengkap (tanpa perlu memindai ulang 16 halaman tabel)...",
                        "info",
                        worker_id,
                    )
                elif not all_unticketed_retry:
                    await self._prescan_selesai_mandiri_status(page, worker_id, queue)

            while not queue.empty() and not self.stop_requested:
                try:
                    student = queue.get_nowait()
                except asyncio.QueueEmpty:
                    break

                eff_srv = (
                    "umum"
                    if (
                        getattr(self.config, "service_type", "sekolah") == "umum"
                        or getattr(student, "service_type", "sekolah") == "umum"
                    )
                    else "sekolah"
                )
                lic_ok_mid, lic_msg_mid = self.license_mgr.try_reserve_quota(
                    self.active_faskes, service_type=eff_srv
                )
                if not lic_ok_mid:
                    self.log(f"🛡️ [SAAS LICENSE LOCK] {lic_msg_mid}", "error")
                    self.stop_requested = True
                    try:
                        queue.task_done()
                    except ValueError:
                        pass
                    break

                if page.is_closed():
                    page = await self._ensure_worker_page_alive(worker_id, page, force_reopen=True)
                    context = getattr(self, "_worker_contexts", {}).get(worker_id, context)

                student.worker_id = worker_id
                student.state = "running"
                student.last_step = "Memulai pemrosesan"
                self.worker_status[worker_id] = f"[Akun #{assigned_slot}] {student.nama} ({student.nik})"

                try:
                    await self._process_single_student_with_retry(page, worker_id, student)
                    page = self._active_pages.get(worker_id, page)
                    context = getattr(self, "_worker_contexts", {}).get(worker_id, context)
                finally:
                    if student.state in ("success", "warning"):
                        self.license_mgr.commit_reserved_quota(1)
                    else:
                        self.license_mgr.release_reserved_quota(1)
                self.state_db.save_student_checkpoint(self.current_file_key, student)
                if (
                    student.state in ("success", "warning", "skipped")
                    and not self.session_expired
                    and not page.is_closed()
                    and "auth/login" not in (page.url or "").lower()
                ):
                    try:
                        s_path = self.session_vault.get_slot_path(assigned_slot)
                        await asyncio.wait_for(context.storage_state(path=str(s_path)), timeout=5.0)
                        if assigned_slot == 1:
                            await asyncio.wait_for(
                                context.storage_state(path=str(self.storage_state_path)), timeout=5.0
                            )
                    except Exception:
                        pass
                await self._save_report_snapshot()
                try:
                    queue.task_done()
                except ValueError:
                    pass
        except asyncio.CancelledError:
            self.log("🛑 Worker dihentikan.", "warning", worker_id)
        except Exception as exc:
            self.log(f"❌ Worker terhenti: {exc}", "error", worker_id)
        finally:
            self.worker_status[worker_id] = "Selesai"
            self._active_pages.pop(worker_id, None)
            try:
                if not page.is_closed():
                    await asyncio.wait_for(page.close(), timeout=3.0)
            except Exception:
                pass

    async def _save_report_snapshot(self) -> Optional[Path]:
        if not self.students:
            return None
        async with self._report_lock:
            is_umum = any(getattr(s, "service_type", "sekolah") == "umum" for s in self.students)
            sekolah_raw = (
                self.students[0].nama_sekolah_bersih
                or self.students[0].nama_sekolah
                or ("CKG_Umum" if is_umum else "Sekolah")
            )
            sekolah_safe = re.sub(r'[\\/*?:"<>|\s•]+', "_", sekolah_raw).strip("_") or "Sekolah"
            kelas_set = {
                re.sub(r'[\\/*?:"<>|\s]+', "_", (s.kelas or "").strip()).strip("_")
                for s in self.students
                if (s.kelas or "").strip()
            }
            kelas_part = f"_{next(iter(kelas_set))}" if len(kelas_set) == 1 else ""
            prog_prefix = "Laporan_Pelayanan_CKG_Umum" if is_umum else "Laporan_Pelayanan_CKG"
            if (
                self.latest_report_path is None
                or "Robot" in self.latest_report_path.name
            ):
                ts = dt.datetime.now().strftime("%Y%m%d_%H%M")
                self.latest_report_path = (
                    self.reports_dir / f"{prog_prefix}_{sekolah_safe}{kelas_part}_{ts}.xlsx"
                )
            import importlib
            from . import excel_io as _excel_io_mod

            importlib.reload(_excel_io_mod)
            _excel_io_mod.export_report_excel(
                self.current_excel_path, self.students, self.latest_report_path
            )
            return self.latest_report_path

    async def _process_single_student_with_retry(
        self, page: Any, worker_id: int, student: StudentRecord
    ) -> None:
        if not student.nik or len(student.nik.strip()) < 16 or not student.nik.strip().isdigit():
            student.status_sistem = "Skipped: NIK kosong atau kurang dari 16 digit di Excel"
            student.state = "skipped"
            student.last_step = "Validasi Format NIK"
            self.log(f"⏩ {student.nama}: {student.status_sistem}", "warning", worker_id)
            return

        if (
            getattr(student, "service_type", "sekolah") == "umum"
            or getattr(self.config, "service_type", "sekolah") == "umum"
        ):
            await self._process_single_umum_with_retry(page, worker_id, student)
            return

        tahap_short = {
            "C": "Paket Lengkap: Daftar + Skrining + Nakes",
            "A": "Tahap 1: Pendaftaran & Kehadiran",
            "B": "Tahap 2: Skrining Mandiri",
            "D": "Tahap 3: Pemeriksaan Nakes",
        }.get(self.config.mode, self.config.mode)
        self.log(
            f"🏫 MEMPROSES SISWA: {student.nama} (NIK: {student.nik} | {student.nama_sekolah_bersih} - {student.kelas}) -> [{tahap_short}]",
            "info",
            worker_id,
        )
        sudah_tukar_tgl = False
        force_isi_manual = False
        attempt = 1
        net_recoveries = 0
        browser_recoveries = 0

        while attempt <= 3:
            try:
                if page.is_closed():
                    page = await self._ensure_worker_page_alive(worker_id, page, force_reopen=True)
                await self.check_pause_and_stop(page, worker_id)
                await self._close_registration_modals_completely(page)
                if attempt > 1:
                    self.log(
                        f"🔄 [AUTO-RETRY {attempt}/3] Mengulang siswa {student.nama}...",
                        "warning",
                        worker_id,
                    )

                # Smart Fast-Track: If Mode C and student already has a Ticket (already registered in Phase 1),
                # check Pelayanan directly first to save ~20s per student; fall back to Phase 1 if not found.
                fast_track_pelayanan = bool(
                    self.config.mode == "C"
                    and not self.config.mode_bypass
                    and not self.config.mode_booking
                    and (
                        (student.no_tiket and student.no_tiket != "-")
                        or getattr(student, "_check_selesai_first", False)
                    )
                )
                found_in_pelayanan = False

                if fast_track_pelayanan:
                    self.log(
                        f"⚡ [FAST-TRACK] {student.nama} sudah memiliki Tiket ({student.no_tiket}). Langsung menuju Menu Pelayanan...",
                        "info",
                        worker_id,
                    )
                    found_in_pelayanan = await self._step_buka_pelayanan_dan_cari_siswa(
                        page, worker_id, student
                    )
                    if not found_in_pelayanan and student.state in ("skipped", "success", "warning"):
                        return

                # PHASE 1: Pendaftaran & Konfirmasi Hadir (Modes A & C, unless bypassed or already found via fast-track)
                if not found_in_pelayanan and self.config.mode in ("A", "C") and not self.config.mode_bypass:
                    reg_ok = await self._step_pendaftaran_dan_konfirmasi(
                        page, worker_id, student, sudah_tukar_tgl, force_isi_manual=force_isi_manual
                    )
                    if not reg_ok:
                        if student.last_step == "FORCE_ISI_MANUAL_RETRY" and not force_isi_manual:
                            force_isi_manual = True
                            continue
                        if student.last_step == "SWAP_DOB_RETRY" and not sudah_tukar_tgl:
                            sudah_tukar_tgl = True
                            force_isi_manual = True
                            continue
                        return

                    if self.config.mode == "A" or self.config.mode_booking:
                        if self.config.mode_booking:
                            student.status_sistem = "Terdaftar Booking (Belum Konfirmasi Kehadiran)"
                        else:
                            student.status_sistem = "Selesai Tahap 1 (Pendaftaran & Konfirmasi Kehadiran)"
                        student.state = "success"
                        student.last_step = "Selesai Tahap 1"
                        self.log(f"✅ {student.nama}: {student.status_sistem}", "success", worker_id)
                        return

                # PHASE 2: Buka Menu Pelayanan & Cari Siswa Lintas Tab (Modes B, C, D)
                if not found_in_pelayanan:
                    found_in_pelayanan = await self._step_buka_pelayanan_dan_cari_siswa(
                        page, worker_id, student
                    )
                    if not found_in_pelayanan:
                        return

                # PHASE 3: Skrining Mandiri (Modes B & C, unless lewati_skrining or Mode D)
                if self.config.mode in ("B", "C") and not self.config.lewati_skrining:
                    if (
                        getattr(student, "_mandiri_already_lengkap", False)
                        and self.config.mode == "C"
                        and not self.config.update_data_lama
                    ):
                        self.log(
                            f"⏩ Skrining Mandiri {student.nama} sudah 'Lengkap', langsung ke Pemeriksaan Nakes...",
                            "info",
                            worker_id,
                        )
                    else:
                        await self._step_skrining_mandiri(page, worker_id, student)

                    if self.config.mode == "B" or (
                        getattr(student, "_already_selesai_pemeriksaan", False)
                        and not self.config.update_data_lama
                    ):
                        verified_lengkap = await self._verify_mandiri_status_on_pelayanan_table(
                            page, worker_id, student
                        )
                        if not verified_lengkap:
                            self.log(
                                f"ℹ️ Detail Pemeriksaan Mandiri {student.nama} sudah 10/10 Lengkap (centang hijau), namun badge tabel daftar SATUSEHAT masih tertahan di server Kemenkes.",
                                "info",
                                worker_id,
                            )
                        if getattr(student, "_already_selesai_pemeriksaan", False):
                            student.status_sistem = "Selesai Lengkap (Skrining Mandiri & Pemeriksaan Nakes)"
                        else:
                            student.status_sistem = "Selesai Tahap 2 (Kuesioner Skrining Mandiri)"
                        if not student.tatalaksana or student.tatalaksana == "-":
                            student.tatalaksana = "Aman (Tidak Ada Tindakan)"
                        student.state = (
                            "warning" if student.tatalaksana == "Harus tatalaksana" else "success"
                        )
                        student.last_step = "Selesai"
                        self.log(
                            f"🏆 {student.nama} -> {student.status_sistem} | Tiket: {student.no_tiket}",
                            "success",
                            worker_id,
                        )
                        return

                # PHASE 4: Pelayanan oleh Nakes (Gizi, GDS, Tensi + Sniper Mode)
                if self.config.mode in ("C", "D"):
                    await self._step_pelayanan_nakes(page, worker_id, student)

                # PHASE 5: Kirim Rapor (3/3), Selesaikan Layanan & Cek Tatalaksana
                await self._step_finalisasi_layanan(page, worker_id, student)
                return

            except BomAutoRetryUniversal as bom:
                if (self._is_closed_target_error(bom) or page.is_closed()) and browser_recoveries < 3:
                    browser_recoveries += 1
                    self.log(
                        f"🔄 [AUTO-HEAL BROWSER] Memulihkan tab browser otomatis untuk {student.nama} tanpa mengurangi kesempatan percobaan...",
                        "warning",
                        worker_id,
                    )
                    page = await self._ensure_worker_page_alive(worker_id, page, force_reopen=True)
                    continue
                if net_recoveries < 10 and await self._wait_for_internet_recovery(page, worker_id, student, bom):
                    net_recoveries += 1
                    continue
                self.log(
                    f"⚠️ Gangguan di tahap [{student.last_step}]: {bom}",
                    "warning",
                    worker_id,
                )
                await self._close_registration_modals_completely(page)
                if attempt == 3:
                    if "Pemeriksaan Mandiri" in str(bom) and "Belum lengkap" in str(bom):
                        student.status_sistem = (
                            "Belum Lengkap: Pemeriksaan Mandiri di SATUSEHAT masih Belum Lengkap"
                        )
                        student.last_step = "Pemeriksaan Mandiri Belum Lengkap"
                        student.state = "failed"
                    else:
                        student.status_sistem = f"Gagal (3x Coba) di tahap: {student.last_step}"
                        student.state = "failed"
                attempt += 1
            except asyncio.CancelledError:
                student.status_sistem = "Dihentikan Pengguna"
                student.state = "pending"
                raise
            except Exception as exc:
                if (self._is_closed_target_error(exc) or page.is_closed()) and browser_recoveries < 3:
                    browser_recoveries += 1
                    self.log(
                        f"🔄 [AUTO-HEAL BROWSER] Tab browser tertutup pada tahap [{student.last_step}]. Membuka ulang tab otomatis untuk {student.nama} tanpa mengurangi kesempatan percobaan...",
                        "warning",
                        worker_id,
                    )
                    page = await self._ensure_worker_page_alive(worker_id, page, force_reopen=True)
                    continue
                if net_recoveries < 10 and await self._wait_for_internet_recovery(page, worker_id, student, exc):
                    net_recoveries += 1
                    continue
                self.log(
                    f"❌ Error pada {student.nama} (Percobaan {attempt}/3 di {student.last_step}): {exc}",
                    "error",
                    worker_id,
                )
                await self._close_registration_modals_completely(page)
                if attempt == 3:
                    student.status_sistem = f"Gagal di tahap: {student.last_step} ({exc})"
                    student.state = "failed"
                attempt += 1

    # =========================================================================
    # SHARED FILTER & SEARCH HELPERS (Exact V2.6 Pilih Sekolah + Pilih Kelas + Cari NIK)
    # =========================================================================

    async def _select_filter_sekolah_dan_kelas(
        self, page: Any, worker_id: int, student: StudentRecord
    ) -> bool:
        """
        Exact V2.6 filter selector used on BOTH /ckg-pendaftaran-anak-sekolah (Konfirmasi Hadir)
        AND /ckg-pelayanan-sekolah (Pelayanan Nakes).
        Handles both empty placeholders ('Pilih sekolah' / 'Pilih kelas') AND already-selected
        school/class values in the filter row before 'Tampilkan Pencarian'!
        Returns True if the school or class filter was changed (meaning 'Tampilkan Pencarian' MUST be clicked).
        """
        filter_changed = False
        last_filter_map = getattr(self, "_last_worker_filter_key", None)
        if last_filter_map is None:
            last_filter_map = {}
            self._last_worker_filter_key = last_filter_map
        cur_filter_key = f"{page.url.split('?')[0].rstrip('/')}|{(student.nama_sekolah_bersih or student.nama_sekolah or '').strip().lower()}|{(student.kelas or '').strip().lower()}"
        if last_filter_map.get(worker_id) != cur_filter_key:
            filter_changed = True

        raw_cands = student.sekolah_candidates or [student.nama_sekolah_bersih or student.nama_sekolah]
        candidates = [c for c in raw_cands if c]
        cached_winner = self._verified_school_cache.get(student.nama_sekolah_bersih)
        if cached_winner and cached_winner in candidates:
            candidates = [cached_winner] + [c for c in candidates if c != cached_winner]

        # 1. Select 'Pilih sekolah' (skip re-selecting if the exact school is already active in filter bar)
        try:
            await page.evaluate("() => window.scrollTo(0, 0)")
        except Exception:
            pass
        if candidates:
            try:
                school_state = await page.evaluate(
                    """(cands) => {
                        document.querySelectorAll('[data-ckg-school-dd]').forEach(e => e.removeAttribute('data-ckg-school-dd'));
                        const candsLower = cands.map(c => (c || '').toLowerCase().trim()).filter(Boolean);
                        const tableEl = document.querySelector('table');
                        const maxTop = tableEl ? Math.max(420, tableEl.getBoundingClientRect().top) : 650;

                        // Check if any visible element or input above the table already shows the target school
                        const aboveEls = Array.from(document.querySelectorAll('input, div, span, button')).filter(el => {
                            if (el.offsetWidth <= 40 || el.offsetHeight <= 16) return false;
                            if (el.closest('ul, [role="listbox"], [role="option"], .ant-select-dropdown')) return false;
                            const r = el.getBoundingClientRect();
                            return r.top >= 40 && r.top < maxTop && r.left > 180 && r.height <= 64;
                        });
                        for (const el of aboveEls) {
                            const txt = ((el.value || el.innerText || '') + '').toLowerCase().trim();
                            if (txt && txt.length < 90 && candsLower.some(c => txt === c || txt.includes(c))) {
                                return { alreadySelected: true, found: true };
                            }
                        }

                        const inp = document.querySelector('input[placeholder="Pilih sekolah"]');
                        if (inp && inp.offsetWidth > 0 && !inp.disabled) {
                            inp.setAttribute('data-ckg-school-dd', 'true');
                            return { alreadySelected: false, found: true };
                        }

                        const phCandidates = aboveEls.filter(el => {
                            const t = ((el.innerText || el.getAttribute('placeholder') || '') + '').toLowerCase().trim();
                            return t === 'pilih sekolah';
                        });
                        if (phCandidates.length > 0) {
                            phCandidates[phCandidates.length - 1].setAttribute('data-ckg-school-dd', 'true');
                            return { alreadySelected: false, found: true };
                        }
                        return { alreadySelected: false, found: false };
                    }""",
                    candidates,
                )

                if not school_state.get("alreadySelected") and school_state.get("found"):
                    filter_changed = True
                    dd_sekolah = page.locator('[data-ckg-school-dd="true"]').first
                    if await dd_sekolah.is_visible():
                        await self._safe_click(dd_sekolah, timeout=2500)
                        await asyncio.sleep(0.18)

                        opsi_ketemu = False
                        for idx_cand, kandidat in enumerate(candidates):
                            if idx_cand > 0:
                                await page.keyboard.press("End")
                                for _ in range(35):
                                    await page.keyboard.press("Backspace")
                                await asyncio.sleep(0.12)

                            await page.keyboard.insert_text(kandidat)
                            kandidat_aman = kandidat.replace('"', "").strip()
                            opsi_target = page.locator(f'text="{kandidat_aman}"').last

                            for _ in range(10):
                                await asyncio.sleep(0.1)
                                if await page.evaluate(JS_KLIK_OPSI, kandidat_aman):
                                    self._verified_school_cache[student.nama_sekolah_bersih] = kandidat
                                    opsi_ketemu = True
                                    break
                                if await opsi_target.is_visible():
                                    await self._safe_click(opsi_target, timeout=1500)
                                    self._verified_school_cache[student.nama_sekolah_bersih] = kandidat
                                    opsi_ketemu = True
                                    break
                            if opsi_ketemu:
                                break

                            await self.wait_loading_smart(page, timeout_ms=3000, initial_delay_ms=100)
                            if await page.evaluate(JS_KLIK_OPSI, kandidat_aman):
                                self._verified_school_cache[student.nama_sekolah_bersih] = kandidat
                                opsi_ketemu = True
                                break
                            if await opsi_target.is_visible():
                                await self._safe_click(opsi_target, timeout=1500)
                                self._verified_school_cache[student.nama_sekolah_bersih] = kandidat
                                opsi_ketemu = True
                                break

                            await page.keyboard.press("End")
                            for _ in range(min(15, max(3, len(kandidat_aman) - 4))):
                                await page.keyboard.press("Backspace")
                                await asyncio.sleep(0.25)
                                if await page.evaluate(JS_KLIK_OPSI, kandidat_aman):
                                    opsi_ketemu = True
                                    break
                                if await opsi_target.is_visible():
                                    await self._safe_click(opsi_target, timeout=1500)
                                    opsi_ketemu = True
                                    break
                            if opsi_ketemu:
                                break

                        if not opsi_ketemu:
                            await page.keyboard.press("ArrowDown")
                            await asyncio.sleep(0.15)
                            await page.keyboard.press("Enter")

                        await self.wait_loading_smart(page, timeout_ms=5000, initial_delay_ms=350)
                        await asyncio.sleep(0.25)
            except Exception as exc:
                self.log(f"⚠️ Peringatan filter sekolah: {exc}", "warning", worker_id)

        # 2. Select 'Pilih kelas' (retries up to 4 times in case class options are still loading after school selection)
        if student.kelas:
            for _try_kls in range(4):
                try:
                    await page.evaluate("() => window.scrollTo(0, 0)")
                    class_state = await page.evaluate(
                        """(targetKelas) => {
                            document.querySelectorAll('[data-ckg-class-dd]').forEach(e => e.removeAttribute('data-ckg-class-dd'));
                            const tgt = (targetKelas || '').toLowerCase().trim();
                            const tableEl = document.querySelector('table');
                            const maxTop = tableEl ? Math.max(420, tableEl.getBoundingClientRect().top) : 650;

                            const aboveEls = Array.from(document.querySelectorAll('input, div, span, button')).filter(el => {
                                if (el.offsetWidth <= 50 || el.offsetHeight <= 16) return false;
                                if (el.closest('ul, [role="listbox"], [role="option"], .ant-select-dropdown')) return false;
                                const r = el.getBoundingClientRect();
                                return r.top >= 40 && r.top < maxTop && r.left > 180 && r.height <= 64;
                            });
                            for (const el of aboveEls) {
                                const txt = ((el.value || el.innerText || '') + '').toLowerCase().trim();
                                if (txt === tgt) {
                                    return { alreadySelected: true, found: true };
                                }
                            }

                            const inp = document.querySelector('input[placeholder="Pilih kelas"]');
                            if (inp && inp.offsetWidth > 0 && !inp.disabled) {
                                inp.setAttribute('data-ckg-class-dd', 'true');
                                return { alreadySelected: false, found: true };
                            }

                            const classBoxes = aboveEls.filter(el => {
                                const t = ((el.value || el.innerText || '') + '').toLowerCase().trim();
                                return t === 'pilih kelas' || /^kelas\\s+\\d+$/i.test(t);
                            });
                            if (classBoxes.length > 0) {
                                classBoxes[classBoxes.length - 1].setAttribute('data-ckg-class-dd', 'true');
                                return { alreadySelected: false, found: true };
                            }
                            return { alreadySelected: false, found: false };
                        }""",
                        student.kelas,
                    )

                    if class_state.get("alreadySelected"):
                        break
                    if not class_state.get("found"):
                        await asyncio.sleep(0.35)
                        continue

                    filter_changed = True
                    dd_kelas = page.locator('[data-ckg-class-dd="true"]').first
                    if await dd_kelas.is_visible():
                        await self._safe_click(dd_kelas, timeout=2500)
                        await asyncio.sleep(0.3)

                        picked_kelas = await page.evaluate(JS_KLIK_OPSI, student.kelas)
                        if not picked_kelas:
                            await asyncio.sleep(0.25)
                            await self._safe_click(dd_kelas, timeout=2500)
                            await asyncio.sleep(0.35)
                            picked_kelas = await page.evaluate(JS_KLIK_OPSI, student.kelas)

                        if not picked_kelas:
                            inp_kelas_open = page.locator(
                                'input[placeholder="Pilih kelas"], input[placeholder*="Cari"]'
                            ).last
                            if await inp_kelas_open.is_visible():
                                await self._safe_fill(inp_kelas_open, student.kelas)
                            else:
                                await page.keyboard.insert_text(student.kelas)
                            await asyncio.sleep(0.25)
                            if not await page.evaluate(JS_KLIK_OPSI, student.kelas):
                                opsi_kelas = page.locator(f'text="{student.kelas}"').last
                                if await opsi_kelas.is_visible():
                                    await self._safe_click(opsi_kelas, timeout=2000)
                                else:
                                    await page.keyboard.press("ArrowDown")
                                    await asyncio.sleep(0.15)
                                    await page.keyboard.press("Enter")
                        await asyncio.sleep(0.3)
                except Exception as exc:
                    if _try_kls == 3:
                        self.log(f"⚠️ Peringatan filter kelas: {exc}", "warning", worker_id)

        last_filter_map[worker_id] = cur_filter_key
        return filter_changed

    async def _search_by_nik_or_tiket_on_table(
        self,
        page: Any,
        worker_id: int,
        student: StudentRecord,
        force_use_ticket: Optional[bool] = None,
        click_tampilkan: bool = True,
        search_by_name: bool = False,
    ) -> Any:
        """
        Exact V2.6 search bar handler (lines 273-325, 1273-1315, 1528-1580) enhanced so it:
        1. Never clicks <th>Nomor Tiket</th> or <th>Nama</th> inside <table> when switching filter mode
        2. Checks kolom_cari placeholder first so it skips clicking the dropdown if already in the right mode
        3. Supports optional click_tampilkan=False when switching filter mode on an already-loaded tab
        """
        if click_tampilkan:
            try:
                tombol_cari = page.get_by_text("Tampilkan Pencarian", exact=False).first
                await tombol_cari.wait_for(state="visible", timeout=3000)
                await self._safe_click(tombol_cari)
                await asyncio.sleep(0.45)
                await self.wait_loading_smart(page, timeout_ms=10000, initial_delay_ms=250)
                # If the search bar / tabs didn't appear yet (e.g., class filter wasn't ready on first click),
                # re-verify school+class filter and click Tampilkan Pencarian once more.
                if not await page.locator(
                    'input#searchNik, input[placeholder*="Masukkan"], div.cursor-pointer:has-text("Sedang Pemeriksaan")'
                ).first.is_visible():
                    await self._select_filter_sekolah_dan_kelas(page, worker_id, student)
                    await self._safe_click(tombol_cari)
                    await asyncio.sleep(0.45)
                    await self.wait_loading_smart(page, timeout_ms=10000, initial_delay_ms=250)
            except Exception:
                pass

        if search_by_name:
            target_filter_name = "Nama"
            query_val = student.nama.strip()
        else:
            if force_use_ticket is not None:
                use_ticket = bool(
                    force_use_ticket and student.no_tiket and student.no_tiket != "-"
                )
            else:
                use_ticket = bool(
                    self.config.cari_by_tiket
                    and student.no_tiket
                    and student.no_tiket != "-"
                )
            target_filter_name = "Nomor Tiket" if use_ticket else "NIK"
            query_val = student.no_tiket.strip() if use_ticket else student.nik.strip()

        kolom_cari = page.locator(
            'input#searchNik, input[placeholder*="NIK"], input[placeholder*="Masukkan"], input[placeholder*="Cari"], input.ant-input'
        ).last
        try:
            await kolom_cari.wait_for(state="visible", timeout=6000)
        except Exception:
            pass

        # Switch filter dropdown ONLY if current input placeholder doesn't match target_filter_name,
        # and NEVER match <th>/<td> elements inside <table>!
        try:
            need_switch = await page.evaluate(
                """(targetMode) => {
                    document.querySelectorAll('[data-ckg-filter-dd]').forEach(e => e.removeAttribute('data-ckg-filter-dd'));
                    const inputs = Array.from(document.querySelectorAll('input#searchNik, input[placeholder*="NIK"], input[placeholder*="Masukkan"], input[placeholder*="Cari"], input.ant-input'))
                        .filter(el => el.offsetWidth > 0 && el.offsetHeight > 0);
                    const inp = inputs[inputs.length - 1];
                    if (inp) {
                        const ph = (inp.getAttribute('placeholder') || '').toLowerCase();
                        if (targetMode === 'Nomor Tiket' && ph.includes('tiket')) return false;
                        if (targetMode === 'NIK' && ph.includes('nik')) return false;
                        if (targetMode === 'Nama' && ph.includes('nama')) return false;
                    }
                    const candidates = Array.from(document.querySelectorAll('div, span, button')).filter(el => {
                        if (el.offsetWidth <= 0 || el.offsetHeight <= 0) return false;
                        if (el.closest('table, thead, tbody, tr, th, td')) return false;
                        const t = (el.innerText || '').trim();
                        return t === 'Nomor Tiket' || t === 'NIK' || t === 'Nama';
                    });
                    if (candidates.length > 0) {
                        candidates[candidates.length - 1].setAttribute('data-ckg-filter-dd', 'true');
                        return true;
                    }
                    return false;
                }""",
                target_filter_name,
            )
            if need_switch:
                dd_loc = page.locator('[data-ckg-filter-dd="true"]').first
                if await dd_loc.is_visible(timeout=500):
                    await self._safe_click(dd_loc)
                    await asyncio.sleep(0.25)
                    await page.evaluate(
                        """(targetMode) => {
                            const items = Array.from(document.querySelectorAll('li, div[role="option"], button, div.cursor-pointer, span, div'))
                                .filter(el => el.offsetWidth > 0 && el.offsetHeight > 0 && !el.closest('table, thead, tbody, tr, th, td'));
                            const matches = items.filter(el => (el.innerText || '').trim() === targetMode);
                            if (matches.length > 0) {
                                matches[matches.length - 1].click();
                                return true;
                            }
                            return false;
                        }""",
                        target_filter_name,
                    )
                    await asyncio.sleep(0.25)
        except Exception:
            pass

        if await kolom_cari.is_visible():
            await self._safe_focus_end(kolom_cari)
            await self._safe_fill(kolom_cari, "")
            await asyncio.sleep(0.18)
            await kolom_cari.press_sequentially(query_val, delay=0)
            await asyncio.sleep(0.35)
            await page.keyboard.press("Enter")
            await self.wait_loading_smart(page, timeout_ms=15000, initial_delay_ms=450)
            await asyncio.sleep(0.45)

        return kolom_cari

    # =========================================================================
    # PHASE 1: PENDAFTARAN BARU & KONFIRMASI HADIR (/ckg-pendaftaran-anak-sekolah)
    # =========================================================================

    async def _step_pendaftaran_dan_konfirmasi(
        self,
        page: Any,
        worker_id: int,
        student: StudentRecord,
        sudah_tukar_tgl: bool,
        force_isi_manual: bool = False,
    ) -> bool:
        """
        Executes Pendaftaran Baru + Konfirmasi Kehadiran on /ckg-pendaftaran-anak-sekolah
        following V2.6 lines 582-1460.
        """
        student.last_step = "Membuka Pendaftaran CKG Sekolah"
        try:
            resp_nav = await page.goto(URL_PENDAFTARAN, wait_until="domcontentloaded", timeout=45000)
        except Exception:
            api_check = await self._verify_or_refresh_context_session(page.context)
            if api_check.get("expired"):
                await self.radar_sapu_jagat(page, worker_id, force_session_expired=True)
            raise
        if resp_nav is not None and resp_nav.status >= 500:
            api_check = await self._verify_or_refresh_context_session(page.context)
            if api_check.get("expired"):
                await self.radar_sapu_jagat(page, worker_id, force_session_expired=True)
            elif api_check.get("alive"):
                resp_nav = await page.reload(wait_until="domcontentloaded", timeout=45000)
        await self.radar_sapu_jagat(page, worker_id)

        btn_daftar_selector = 'button:has-text("Daftar Baru"), button:has-text("+ Daftar Baru")'
        try:
            await page.wait_for_selector(btn_daftar_selector, timeout=30000)
        except Exception:
            await self.radar_sapu_jagat(page, worker_id)
            self.log("⚠️ Halaman Pendaftaran lambat dimuat, me-reload...", "warning", worker_id)
            await page.reload(wait_until="domcontentloaded", timeout=45000)
            await self.radar_sapu_jagat(page, worker_id)
            await page.wait_for_selector(btn_daftar_selector, timeout=30000)

        await self.wait_loading_smart(page, timeout_ms=10000, initial_delay_ms=300)
        await self.capture_worker_peek(page, worker_id)

        if not self.config.mode_proses_booking:
            student.last_step = "Memasukkan NIK Pendaftaran"
            btn_daftar_baru = page.locator(btn_daftar_selector).first
            await btn_daftar_baru.click(force=True, timeout=10000)
            await asyncio.sleep(0.4)

            nik_input = page.locator('input[placeholder*="NIK"], input[placeholder*="nik"]').first
            try:
                await nik_input.wait_for(state="visible", timeout=5000)
            except Exception:
                nik_input = page.locator(
                    'div.ant-modal-content input[type="text"], form input[type="text"]'
                ).first
            await nik_input.click(force=True)
            await nik_input.fill(student.nik)
            await asyncio.sleep(0.2)

            btn_cek = page.locator('button:has-text("Cek NIK"), button:has-text("Cek")').first
            await btn_cek.click(force=True, timeout=5000)

            indikator_loading = page.locator(
                "text=/Proses pencarian data|Proses validasi data|Memuat data/i"
            ).first
            try:
                await indikator_loading.wait_for(state="visible", timeout=2000)
                await indikator_loading.wait_for(state="hidden", timeout=30000)
            except Exception:
                pass
            await self.wait_loading_smart(page, timeout_ms=12000, initial_delay_ms=300)

            # Check if Cek NIK immediately returned 'sudah_dilayani' or 'sudah_terdaftar' or opened action buttons
            setattr(student, "_sudah_dilayani_detail", "")
            early_check = "menunggu"
            is_pasien_lama = False
            has_isi_manual = False
            form_already_open = False
            btn_gunakan = page.locator('button:has-text("Gunakan Data")').first
            btn_manual = page.locator('button:has-text("Isi Manual")').first
            inp_nama_probe = page.locator('input[placeholder*="nama"], input[placeholder*="Nama"]').first

            for _ in range(24):
                early_check = await page.evaluate(JS_CHECK_STEP1_STATUS)
                if early_check in ("sudah_dilayani", "sudah_terdaftar", "tidak_valid", "error_sistem"):
                    break
                if await btn_gunakan.is_visible():
                    is_pasien_lama = True
                    break
                if await btn_manual.is_visible():
                    has_isi_manual = True
                    break
                try:
                    if await inp_nama_probe.is_visible() and await inp_nama_probe.is_enabled():
                        form_already_open = True
                        break
                except Exception:
                    pass
                await asyncio.sleep(0.25)

            await self.capture_worker_peek(page, worker_id)

            if early_check == "sudah_dilayani":
                detail = await self._extract_sudah_dilayani_detail(page)
                await self._close_registration_modals_completely(page, reload_after=False)
                if self.config.mode in ("B", "C", "D") and "ckg umum" not in detail.lower():
                    setattr(student, "_sudah_dilayani_detail", detail)
                    self.log(
                        f"ℹ️ {student.nama} sudah terdaftar di CKG Sekolah ({detail}). Mengecek status pemeriksaan di Menu Pelayanan...",
                        "info",
                        worker_id,
                    )
                    return True
                student.status_sistem = f"Sudah Dilayani ({detail})"
                student.state = "skipped"
                self.log(f"⏩ {student.nama}: {student.status_sistem}", "info", worker_id)
                return False

            if early_check == "sudah_terdaftar":
                self.log(
                    f"ℹ️ {student.nama} sudah terdaftar sebelumnya. Lanjut ke Konfirmasi Hadir...",
                    "info",
                    worker_id,
                )
                await self._close_registration_modals_completely(page, reload_after=False)
                if self.config.mode_booking:
                    return True
                student.last_step = "Konfirmasi Kehadiran di Dashboard"
                await self._konfirmasi_kehadiran_siswa(page, worker_id, student)
                await self.capture_worker_peek(page, worker_id)
                return True

            used_gunakan_data = False
            if (
                is_pasien_lama
                and not self.config.update_data_lama
                and not force_isi_manual
                and not sudah_tukar_tgl
            ):
                self.log("ℹ️ Data siswa ditemukan di database! Klik Gunakan Data...", "info", worker_id)
                await btn_gunakan.click(force=True)
                used_gunakan_data = True
                await asyncio.sleep(0.35)
                await self._ensure_step1_wali_and_wa(page, student)
            else:
                self.log(
                    f"📝 Mengisi biodata manual untuk {student.nama}...",
                    "info",
                    worker_id,
                )
                if has_isi_manual or await btn_manual.is_visible():
                    await btn_manual.click(force=True)
                    await asyncio.sleep(0.4)
                elif not form_already_open and await btn_gunakan.is_visible():
                    await btn_gunakan.click(force=True)
                    await asyncio.sleep(0.4)
                if not await inp_nama_probe.is_visible() or not await inp_nama_probe.is_enabled():
                    if await btn_manual.is_visible():
                        await btn_manual.click(force=True)
                        await asyncio.sleep(0.4)
                    elif await btn_gunakan.is_visible():
                        await btn_gunakan.click(force=True)
                        await asyncio.sleep(0.4)
                await self._fill_biodata_manual(page, worker_id, student)

            # Scroll modal down so Selanjutnya button at the bottom of Formulir Pendaftaran is in view
            try:
                await page.evaluate(
                    """() => {
                        document.querySelectorAll('div, form').forEach(el => {
                            if (el.scrollHeight > el.clientHeight + 40 && (el.innerText || '').includes('Data Peserta')) {
                                el.scrollTop = el.scrollHeight;
                            }
                        });
                    }"""
                )
            except Exception:
                pass

            # Click Selanjutnya on Step 1 and run the outcome race loop
            student.last_step = "Validasi Duplikasi & Dukcapil"
            btn_selanjutnya = page.locator(
                'button:has-text("Selanjutnya"):visible, button:has-text("Lanjutkan"):visible, button:has-text("Selanjutnya")'
            ).last
            try:
                await btn_selanjutnya.wait_for(state="visible", timeout=5000)
            except Exception:
                # If Cek NIK was slow and 'Gunakan Data' / 'Isi Manual' just appeared late, handle it now
                btn_gd_late = page.locator('button:has-text("Gunakan Data")').first
                btn_im_late = page.locator('button:has-text("Isi Manual")').first
                if (
                    await btn_gd_late.is_visible()
                    and not force_isi_manual
                    and not sudah_tukar_tgl
                    and not self.config.update_data_lama
                ):
                    await btn_gd_late.click(force=True)
                    used_gunakan_data = True
                    await asyncio.sleep(0.4)
                    await self._ensure_step1_wali_and_wa(page, student)
                elif await btn_im_late.is_visible():
                    await btn_im_late.click(force=True)
                    await asyncio.sleep(0.4)
                    await self._fill_biodata_manual(page, worker_id, student)
                elif await btn_gd_late.is_visible():
                    await btn_gd_late.click(force=True)
                    await asyncio.sleep(0.4)
                    await self._fill_biodata_manual(page, worker_id, student)
                try:
                    await btn_selanjutnya.wait_for(state="visible", timeout=4000)
                except Exception:
                    await self.capture_worker_peek(page, worker_id)
                    await self._close_registration_modals_completely(page, reload_after=True)
                    raise BomAutoRetryUniversal(
                        "Form pendaftaran belum terbuka (Tombol Selanjutnya tidak muncul)"
                    )

            await asyncio.sleep(0.2)
            if await btn_selanjutnya.is_disabled():
                await self._fill_biodata_manual(page, worker_id, student)
                await asyncio.sleep(0.2)
            if await btn_selanjutnya.is_disabled():
                student.status_sistem = "Gagal: Tombol Selanjutnya terkunci (Cek WA/Biodata)"
                student.state = "failed"
                await self._close_registration_modals_completely(page, reload_after=True)
                return False

            await self._safe_click(btn_selanjutnya, timeout=4000)

            status_langkah_1 = "timeout"
            for _ in range(90):
                res_step1 = await page.evaluate(JS_CHECK_STEP1_STATUS)
                if res_step1 == "kuota_habis_clicked":
                    await asyncio.sleep(0.25)
                    continue
                if res_step1 in ("sudah_dilayani", "sudah_terdaftar", "tidak_valid", "error_sistem", "lanjut"):
                    status_langkah_1 = res_step1
                    break
                await asyncio.sleep(0.1)

            # In-place recovery if 'Gunakan Data' failed validation: dismiss inner alert, fill open form manually & resubmit
            if status_langkah_1 == "tidak_valid" and used_gunakan_data:
                self.log(
                    f"🔄 [SMART SENSOR] Profil lama '{student.nama}' di Kemenkes belum lengkap/valid. Melengkapi form langsung dengan data Excel...",
                    "warning",
                    worker_id,
                )
                try:
                    btn_periksa = page.locator(
                        'button:has-text("Periksa Kembali"), button:has-text("Tutup"), button:has-text("OK"), button:has-text("Ok")'
                    ).last
                    if await btn_periksa.is_visible(timeout=2000):
                        await btn_periksa.click(force=True)
                        await asyncio.sleep(0.35)
                except Exception:
                    pass
                await self._fill_biodata_manual(page, worker_id, student)
                await asyncio.sleep(0.2)
                if await btn_selanjutnya.is_visible() and not await btn_selanjutnya.is_disabled():
                    await self._safe_click(btn_selanjutnya, timeout=4000)
                    status_langkah_1 = "timeout"
                    for _ in range(90):
                        res_step1 = await page.evaluate(JS_CHECK_STEP1_STATUS)
                        if res_step1 == "kuota_habis_clicked":
                            await asyncio.sleep(0.25)
                            continue
                        if res_step1 in ("sudah_dilayani", "sudah_terdaftar", "tidak_valid", "error_sistem", "lanjut"):
                            status_langkah_1 = res_step1
                            break
                        await asyncio.sleep(0.1)

            if status_langkah_1 == "sudah_dilayani":
                detail = await self._extract_sudah_dilayani_detail(page)
                await self._close_registration_modals_completely(page, reload_after=False)
                if self.config.mode in ("B", "C", "D") and "ckg umum" not in detail.lower():
                    setattr(student, "_sudah_dilayani_detail", detail)
                    self.log(
                        f"ℹ️ {student.nama} sudah terdaftar di CKG Sekolah ({detail}). Mengecek status pemeriksaan di Menu Pelayanan...",
                        "info",
                        worker_id,
                    )
                    return True
                student.status_sistem = f"Sudah Dilayani ({detail})"
                student.state = "skipped"
                self.log(f"⏩ {student.nama}: {student.status_sistem}", "info", worker_id)
                return False

            if status_langkah_1 == "tidak_valid":
                await self._close_registration_modals_completely(page, reload_after=True)
                if used_gunakan_data and not force_isi_manual:
                    self.log(
                        f"🔄 [SMART SENSOR] Mengulang pendaftaran '{student.nama}' dari awal dengan mode 'Isi Manual'...",
                        "warning",
                        worker_id,
                    )
                    student.last_step = "FORCE_ISI_MANUAL_RETRY"
                    return False
                if not sudah_tukar_tgl and swap_day_month_if_possible(student):
                    self.log(
                        f"🧠 [SMART SENSOR] Dukcapil menolak! Menukar Tanggal & Bulan Lahir menjadi {student.tgl_iso}...",
                        "warning",
                        worker_id,
                    )
                    student.last_step = "SWAP_DOB_RETRY"
                    return False
                student.status_sistem = "Gagal: Data peserta atau wali tidak valid"
                student.state = "failed"
                self.log(
                    f"⚠️ {student.nama}: Data peserta atau wali tidak valid (Ditolak Disdukcapil). Lanjut ke siswa berikutnya...",
                    "warning",
                    worker_id,
                )
                return False

            if status_langkah_1 == "error_sistem":
                await self._close_registration_modals_completely(page, reload_after=True)
                raise BomAutoRetryUniversal("Server Kemenkes Sibuk di Pendaftaran")

            if status_langkah_1 == "timeout":
                await self._close_registration_modals_completely(page, reload_after=True)
                raise BomAutoRetryUniversal("Loading Pendaftaran Macet (Timeout)")

            if status_langkah_1 == "sudah_terdaftar":
                self.log(
                    f"ℹ️ {student.nama} sudah terdaftar sebelumnya. Lanjut ke Konfirmasi Hadir...",
                    "info",
                    worker_id,
                )
                await self._close_registration_modals_completely(page)
            elif status_langkah_1 == "lanjut":
                btn_lanjutkan = page.locator('button:has-text("Lanjutkan")').first
                if await btn_lanjutkan.is_visible():
                    await self._safe_click(btn_lanjutkan)
                    await asyncio.sleep(0.4)

                # Fill Step 2: Status Pernikahan/Disabilitas/Pekerjaan + Sekolah + Kelas + Domisili
                student.last_step = "Mengisi Sekolah, Kelas & Domisili"
                dom_ok = await self._fill_sekolah_kelas_domisili(page, worker_id, student)
                if not dom_ok:
                    return False

                # Save Registration & Capture Ticket (Jaring 1)
                student.last_step = "Menyimpan Pendaftaran & Ambil Tiket"
                saved_ok = await self._submit_pendaftaran_and_capture_ticket(page, worker_id, student)
                if not saved_ok:
                    return False

        if self.config.mode_booking:
            return True

        # Confirm Attendance (Konfirmasi Hadir)
        student.last_step = "Konfirmasi Kehadiran di Dashboard"
        await self._konfirmasi_kehadiran_siswa(page, worker_id, student)
        await self.capture_worker_peek(page, worker_id)
        return True

    async def _close_registration_modals_completely(
        self, page: Any, reload_after: bool = False
    ) -> None:
        """
        Exact V2.6 two-step modal cleanup (lines 780-782, 792-796, 837-841):
        Closes inner alert ('Periksa Kembali' / 'Tutup' / 'OK') AND outer registration drawer ('Kembali' / 'Batal' / 'Close')
        so the next student never collides with a leftover modal!
        """
        try:
            btn_inner = page.locator(
                'button:has-text("Periksa Kembali"), button:has-text("Tutup"), button:has-text("OK"), button:has-text("Ok")'
            ).last
            if await btn_inner.is_visible(timeout=1500):
                await btn_inner.click(force=True)
                await asyncio.sleep(0.35)
        except Exception:
            pass

        try:
            btn_outer = page.locator(
                'button:has-text("Kembali"), button:has-text("Batal"), .ant-modal-close, .ant-drawer-close, button[aria-label="Close"]'
            ).first
            if await btn_outer.is_visible(timeout=1500):
                await btn_outer.click(force=True)
                await asyncio.sleep(0.35)
        except Exception:
            pass

        try:
            if await page.locator('.ant-modal-content, .ant-drawer-body, [role="dialog"]').first.is_visible():
                await page.keyboard.press("Escape")
                await asyncio.sleep(0.25)
        except Exception:
            pass

        if reload_after:
            try:
                await page.reload(wait_until="domcontentloaded", timeout=30000)
                await asyncio.sleep(0.4)
            except Exception:
                pass

    async def _ensure_step1_wali_and_wa(self, page: Any, student: StudentRecord) -> None:
        """Ensure 'Daftarkan tanpa data wali' is checked and WhatsApp number is filled after clicking 'Gunakan Data'."""
        try:
            await page.locator(
                'button:has-text("Selanjutnya"), label:has-text("Daftarkan tanpa data wali"), input[placeholder*="whatsapp"], input[placeholder*="WhatsApp"]'
            ).first.wait_for(state="visible", timeout=3500)
        except Exception:
            pass

        try:
            # Only click 'Daftarkan tanpa data wali' if the Wali NIK input is currently ENABLED (not greyed out)
            wali_nik_enabled = await page.evaluate(
                """() => {
                    const nikInps = Array.from(document.querySelectorAll('input[placeholder*="NIK"], input[placeholder*="nik"]'))
                        .filter(el => el.offsetWidth > 0 && el.offsetHeight > 0);
                    if (nikInps.length >= 2) {
                        return !nikInps[1].disabled;
                    }
                    return false;
                }"""
            )
            if wali_nik_enabled:
                await page.evaluate(
                    """() => {
                        const els = Array.from(document.querySelectorAll('label, div, span'));
                        const target = els.find(el => (el.innerText || '').trim() === 'Daftarkan tanpa data wali' && el.offsetHeight > 0);
                        if (target) {
                            const row = target.parentElement || target;
                            const cb = row.querySelector('input[type="checkbox"], .check, [role="checkbox"]') || target;
                            cb.click();
                        }
                    }"""
                )
                await asyncio.sleep(0.25)
        except Exception:
            pass

        try:
            fallback_wa = self._get_faskes_fallback_wa()
            if not student.wa_pasien or (
                student.wa_pasien == "081234567890" and fallback_wa != "081234567890"
            ):
                student.wa_pasien = fallback_wa
            wa_step1 = re.sub(r"^(?:62|0)+", "", re.sub(r"\D+", "", student.wa_pasien))
            if not wa_step1.startswith("8") or len(wa_step1) < 9:
                wa_step1 = fallback_wa.lstrip("0")
            inp_wa = page.locator(
                'input[placeholder*="whatsapp"], input[placeholder*="WhatsApp"]'
            ).first
            if await inp_wa.is_visible() and await inp_wa.is_enabled():
                cur_wa = (await inp_wa.input_value()) or ""
                cur_digits = re.sub(r"\D+", "", cur_wa)
                if len(cur_digits) < 9 or not cur_digits.startswith("8"):
                    await inp_wa.fill(wa_step1)
                    await asyncio.sleep(0.15)
        except Exception:
            pass

    async def _close_modal_safely(self, page: Any) -> None:
        try:
            btn = page.locator(
                'button:has-text("Tutup"), button:has-text("Kembali"), button:has-text("OK"), button:has-text("Ok"), button:has-text(" Mengerti")'
            ).last
            if await btn.is_visible():
                await btn.click(force=True, timeout=2500)
                await asyncio.sleep(0.3)
        except Exception:
            pass

    async def _fill_biodata_manual(
        self, page: Any, worker_id: int, student: StudentRecord
    ) -> None:
        """
        Exact V2.6 manual biodata filler (lines 650-712):
        1. Waits for Step 1 form to be visible, then ensures 'Daftarkan tanpa data wali' is checked (Wali NIK disabled)
        2. Fills Nama (stripping apostrophes), WA (starting with 8 without leading 0), Jenis Kelamin
        3. Clicks box_label['x'] + 10, box_label['y'] + 30 on form_container.get_by_text('Tanggal Lahir', exact=False).first
        """
        try:
            await page.locator(
                'input[placeholder*="nama"], input[placeholder*="Nama"]'
            ).first.wait_for(state="visible", timeout=4000)
        except Exception:
            pass

        try:
            wali_nik_enabled = await page.evaluate(
                """() => {
                    const nikInps = Array.from(document.querySelectorAll('input[placeholder*="NIK"], input[placeholder*="nik"]'))
                        .filter(el => el.offsetWidth > 0 && el.offsetHeight > 0);
                    if (nikInps.length >= 2) {
                        return !nikInps[1].disabled;
                    }
                    return false;
                }"""
            )
            if wali_nik_enabled:
                await page.evaluate(
                    """() => {
                        const els = Array.from(document.querySelectorAll('label, div, span'));
                        const target = els.find(el => (el.innerText || '').trim() === 'Daftarkan tanpa data wali' && el.offsetHeight > 0);
                        if (target) {
                            const row = target.parentElement || target;
                            const cb = row.querySelector('input[type="checkbox"], .check, [role="checkbox"]') || target;
                            cb.click();
                        }
                    }"""
                )
                await asyncio.sleep(0.25)
        except Exception:
            pass

        try:
            inp_nama = page.locator('input[placeholder*="nama"], input[placeholder*="Nama"]').first
            await inp_nama.wait_for(state="visible", timeout=3000)
            if await inp_nama.is_enabled():
                clean_nama = re.sub(r"['`’]+", "", student.nama).strip()
                await inp_nama.fill(clean_nama or student.nama)
                await asyncio.sleep(0.15)
        except Exception:
            pass

        try:
            fallback_wa = self._get_faskes_fallback_wa()
            if not student.wa_pasien or (
                student.wa_pasien == "081234567890" and fallback_wa != "081234567890"
            ):
                student.wa_pasien = fallback_wa
            wa_step1 = re.sub(r"^(?:62|0)+", "", re.sub(r"\D+", "", student.wa_pasien))
            if not wa_step1.startswith("8") or len(wa_step1) < 9:
                wa_step1 = fallback_wa.lstrip("0")
            inp_wa = page.locator(
                'input[placeholder*="whatsapp"], input[placeholder*="WhatsApp"]'
            ).first
            if await inp_wa.is_visible() and await inp_wa.is_enabled():
                await inp_wa.fill(wa_step1)
                await asyncio.sleep(0.15)
        except Exception:
            pass

        # Gender dropdown (Exact V2.6 lines 663-665)
        try:
            lbl_jk = page.locator("text=Pilih jenis kelamin").first
            if await lbl_jk.is_visible():
                await lbl_jk.click(force=True, timeout=2000)
                await asyncio.sleep(0.2)
                await page.evaluate(
                    """(jk) => {
                        const node = document.evaluate(
                            `//div[contains(text(), '${jk}')]`,
                            document,
                            null,
                            XPathResult.FIRST_ORDERED_NODE_TYPE,
                            null
                        ).singleNodeValue;
                        if (node) node.click();
                    }""",
                    student.jk_pasien,
                )
                await asyncio.sleep(0.15)
        except Exception:
            pass

        # Datepicker (.mx-datepicker-popup) - Direct placeholder click with box_label fallback
        if student.target_tahun and student.target_bulan_idx and student.target_tanggal:
            try:
                kalender_popup = page.locator(".mx-datepicker-popup:visible").last
                inp_tgl_direct = page.locator(
                    'input[placeholder*="tanggal lahir"], input[placeholder*="Tanggal Lahir"], input[name*="birth"], input[name*="dob"]'
                ).first
                if await inp_tgl_direct.is_visible():
                    await inp_tgl_direct.click(force=True, timeout=2500)
                    await asyncio.sleep(0.2)

                if not await kalender_popup.is_visible():
                    form_container = page.locator("div.ant-modal-content, div.ant-drawer-body, form").first
                    label_tgl = form_container.get_by_text("Tanggal Lahir", exact=False).first
                    box_label = await label_tgl.bounding_box()
                    await asyncio.sleep(0.15)
                    if box_label:
                        await page.mouse.click(box_label["x"] + 10, box_label["y"] + 30)

                try:
                    await kalender_popup.wait_for(state="visible", timeout=3000)
                except Exception:
                    if await inp_tgl_direct.is_visible():
                        await inp_tgl_direct.click(force=True)
                        await kalender_popup.wait_for(state="visible", timeout=3000)

                index_bulan = int(student.target_bulan_idx) - 1
                title_target = f"{int(student.target_tahun)}-{index_bulan + 1:02d}-{int(student.target_tanggal):02d}"

                await asyncio.sleep(0.25)
                await kalender_popup.locator(".mx-btn-current-year").click(force=True)
                await asyncio.sleep(0.25)

                target_tahun_elemen = kalender_popup.locator(
                    f'td.cell[data-year="{int(student.target_tahun)}"]'
                )
                for _ in range(12):
                    if await target_tahun_elemen.is_visible():
                        await target_tahun_elemen.click(force=True)
                        break
                    await kalender_popup.locator(".mx-btn-icon-double-left").click(force=True)
                    await asyncio.sleep(0.18)

                await asyncio.sleep(0.25)
                cell_mo = kalender_popup.locator(f'td.cell[data-month="{index_bulan}"]')
                await cell_mo.wait_for(state="visible", timeout=1500)
                await cell_mo.click(force=True)

                await asyncio.sleep(0.25)
                cell_day = kalender_popup.locator(f'td.cell[title="{title_target}"]')
                await cell_day.wait_for(state="visible", timeout=1500)
                await cell_day.click(force=True)
                await asyncio.sleep(0.25)
            except Exception as exc:
                self.log(f"⚠️ Catatan kalender tanggal lahir: {exc}", "warning", worker_id)

    async def _extract_sudah_dilayani_detail(self, page: Any) -> str:
        try:
            modal_text = await page.evaluate(
                """() => {
                    const el = document.querySelector('.ant-modal-content, .modal-content, [role="dialog"]');
                    return el ? el.innerText : document.body.innerText;
                }"""
            )
            pkm = re.search(r"Puskesmas pemeriksa:\s*(.*)", modal_text, re.IGNORECASE)
            tgl = re.search(r"Tanggal pemeriksaan:\s*(.*)", modal_text, re.IGNORECASE)
            lay = re.search(r"Layanan:\s*(.*)", modal_text, re.IGNORECASE)
            parts = []
            if pkm:
                parts.append(f"Puskesmas: {pkm.group(1).strip()}")
            if tgl:
                parts.append(f"Tgl: {tgl.group(1).strip()}")
            if lay:
                parts.append(f"Layanan: {lay.group(1).strip()}")
            return " | ".join(parts) if parts else "Sudah Selesai Diperiksa"
        except Exception:
            return "Sudah Selesai Diperiksa"

    async def _fill_sekolah_kelas_domisili(
        self, page: Any, worker_id: int, student: StudentRecord
    ) -> bool:
        """
        Exact V2.6 Step 2 filler (lines 856-1095) with viewport-safe DOM interaction
        and strict modal scoping so background table headers/filters on /ckg-pendaftaran-anak-sekolah
        are never clicked by mistake.
        """
        try:
            btn_lanjutkan_pop = page.locator('button:has-text("Lanjutkan"):visible').first
            if await btn_lanjutkan_pop.is_visible():
                await self._safe_click(btn_lanjutkan_pop)
                await asyncio.sleep(0.35)
        except Exception:
            pass

        try:
            await page.locator(
                'label:has-text("Pernikahan"), label:has-text("Nama Sekolah"), label:has-text("Jenjang Pendidikan")'
            ).last.wait_for(state="visible", timeout=4500)
        except Exception:
            pass

        modal_scope = page.locator(
            'div.ant-modal-content:visible, div.ant-drawer-body:visible, [role="dialog"]:visible, form:visible'
        ).last
        if not await modal_scope.is_visible():
            modal_scope = page

        # Fill Status Pernikahan / Disabilitas / Pekerjaan if New Patient (each in its own try block)
        try:
            dd_nikah = modal_scope.locator('text="Pilih status pernikahan"').last
            if await dd_nikah.is_visible():
                await self._safe_click(dd_nikah)
                await asyncio.sleep(0.2)
                if not await page.evaluate(JS_KLIK_OPSI, "Belum Menikah"):
                    await self._safe_click(modal_scope.locator('text="Belum Menikah"').last)
                await asyncio.sleep(0.15)
        except Exception:
            pass

        try:
            dd_disab = modal_scope.locator('text="Pilih penyandang disabilitas"').last
            if await dd_disab.is_visible():
                await self._safe_click(dd_disab)
                await asyncio.sleep(0.2)
                if not await page.evaluate(JS_KLIK_OPSI, "Tidak memiliki disabilitas"):
                    if not await page.evaluate(JS_KLIK_OPSI, "Tidak Disabilitas"):
                        await self._safe_click(modal_scope.locator('text="Tidak memiliki disabilitas"').last)
                await asyncio.sleep(0.15)
        except Exception:
            pass

        try:
            dd_kerja = modal_scope.locator('text="Pilih pekerjaan"').last
            if await dd_kerja.is_visible():
                await self._safe_click(dd_kerja)
                await asyncio.sleep(0.2)
                if not await page.evaluate(JS_KLIK_OPSI, "Pelajar"):
                    inp_k = modal_scope.locator('input[placeholder*="Cari"]').last
                    if await inp_k.is_visible():
                        await self._safe_fill(inp_k, "Pelajar")
                        await asyncio.sleep(0.25)
                    if not await page.evaluate(JS_KLIK_OPSI, "Pelajar"):
                        await self._safe_click(modal_scope.locator('text="Pelajar"').last)
                await asyncio.sleep(0.15)
        except Exception:
            pass

        await asyncio.sleep(0.35)

        # Select School (Nama Sekolah) - Strictly scoped inside modal_scope so <th>Nama Sekolah</th> on background table is never matched
        lbl_sekolah = modal_scope.locator('text="Nama Sekolah"').last
        if await lbl_sekolah.is_visible():
            dd_sekolah = lbl_sekolah.locator(
                'xpath=following::div[contains(@class, "cursor-pointer")][1]'
            ).first
            candidates = [
                c.replace('"', "").strip()
                for c in (
                    student.sekolah_candidates
                    or [student.nama_sekolah_bersih or student.nama_sekolah]
                )
                if c and c.strip()
            ]
            cached_winner = self._verified_school_cache.get(student.nama_sekolah_bersih)
            if cached_winner and cached_winner in candidates:
                candidates = [cached_winner] + [c for c in candidates if c != cached_winner]

            cur_school_txt = ""
            try:
                cur_school_txt = ((await dd_sekolah.inner_text()) or "").strip()
            except Exception:
                pass
            already_has_school = bool(
                cur_school_txt
                and "pilih" not in cur_school_txt.lower()
                and any(
                    c.lower() in cur_school_txt.lower() or cur_school_txt.lower() in c.lower()
                    for c in candidates
                )
            )
            opsi_sekolah_ketemu = already_has_school

            if not opsi_sekolah_ketemu:
                for _sch_try in range(2):
                    inp_cari = modal_scope.locator(
                        'input[placeholder*="Cari nama sekolah"], input[placeholder*="Cari sekolah"], input[placeholder*="Cari"]'
                    ).last
                    if not await inp_cari.is_visible():
                        await self._safe_click(dd_sekolah, timeout=4000)
                        await asyncio.sleep(0.25)
                    if not await inp_cari.is_visible():
                        inp_cari = page.locator(
                            'input[placeholder*="Cari nama sekolah"], input[placeholder*="Cari sekolah"], input[placeholder*="Cari"]'
                        ).last
                    try:
                        await inp_cari.wait_for(state="visible", timeout=4000)
                    except Exception:
                        await self._safe_click(dd_sekolah, timeout=4000)
                        await inp_cari.wait_for(state="visible", timeout=4000)

                    # Pass 1: Direct fill for each candidate, waiting for real dropdown option buttons before JS fallback
                    for kandidat_aman in candidates:
                        await self._safe_fill(inp_cari, kandidat_aman)
                        await self.wait_loading_smart(page, timeout_ms=4000, initial_delay_ms=150)
                        target_dropdown = modal_scope.locator(f'button >> text="{kandidat_aman}"').last
                        target_partial = modal_scope.locator(f'button:has-text("{kandidat_aman}")').last

                        for poll_i in range(16):
                            await asyncio.sleep(0.14)
                            if await target_dropdown.is_visible():
                                await self._safe_click(target_dropdown)
                                self._verified_school_cache[student.nama_sekolah_bersih] = kandidat_aman
                                opsi_sekolah_ketemu = True
                                break
                            if await target_partial.is_visible():
                                await self._safe_click(target_partial)
                                self._verified_school_cache[student.nama_sekolah_bersih] = kandidat_aman
                                opsi_sekolah_ketemu = True
                                break
                            if poll_i >= 3 and await page.evaluate(JS_KLIK_OPSI, kandidat_aman):
                                self._verified_school_cache[student.nama_sekolah_bersih] = kandidat_aman
                                opsi_sekolah_ketemu = True
                                break
                        if opsi_sekolah_ketemu:
                            break

                    # Pass 2: Progressive Backspace character-by-character fallback (Exact V2.6 lines 916-932)
                    if not opsi_sekolah_ketemu and candidates:
                        for kandidat_aman in candidates[:2]:
                            await self._safe_fill(inp_cari, kandidat_aman)
                            await asyncio.sleep(0.4)
                            await self._safe_focus_end(inp_cari)
                            for _ in range(min(15, max(3, len(kandidat_aman) - 4))):
                                await page.keyboard.press("Backspace")
                                await asyncio.sleep(0.45)
                                for cand_check in candidates:
                                    btn_exact = modal_scope.locator(f'button >> text="{cand_check}"').last
                                    if await btn_exact.is_visible():
                                        await self._safe_click(btn_exact)
                                        opsi_sekolah_ketemu = True
                                        break
                                    btn_part = modal_scope.locator(f'button:has-text("{cand_check}")').last
                                    if await btn_part.is_visible():
                                        await self._safe_click(btn_part)
                                        opsi_sekolah_ketemu = True
                                        break
                                    if await page.evaluate(JS_KLIK_OPSI, cand_check):
                                        opsi_sekolah_ketemu = True
                                        break
                                if opsi_sekolah_ketemu:
                                    break
                            if opsi_sekolah_ketemu:
                                break

                    if opsi_sekolah_ketemu:
                        break
                    await asyncio.sleep(0.4)

                await asyncio.sleep(0.35)
                if not opsi_sekolah_ketemu:
                    await page.keyboard.press("Escape")
                    await asyncio.sleep(0.25)
                    await self._close_registration_modals_completely(page, reload_after=True)
                    raise BomAutoRetryUniversal(f"Sekolah '{student.nama_sekolah}' tidak ditemukan")

        # Wait briefly for the school's class options (Jenjang Pendidikan) to load after school selection
        await self.wait_loading_smart(page, timeout_ms=4000, initial_delay_ms=250)

        # Select Class (Jenjang Pendidikan / Kelas) - Strictly scoped inside modal_scope with up to 3 retries
        lbl_jenjang = modal_scope.locator('text="Jenjang Pendidikan"').last
        if await lbl_jenjang.is_visible() and student.kelas:
            dd_kelas = lbl_jenjang.locator(
                'xpath=following::div[contains(@class, "cursor-pointer")][1]'
            ).first
            kelas_selected = False
            for _kls_try in range(3):
                try:
                    cur_kls_txt = ((await dd_kelas.inner_text()) or "").strip()
                    if (
                        cur_kls_txt
                        and "pilih" not in cur_kls_txt.lower()
                        and student.kelas.lower() in cur_kls_txt.lower()
                    ):
                        kelas_selected = True
                        break
                except Exception:
                    pass

                inp_kelas = modal_scope.locator(
                    'input[placeholder*="Cari jenjang"], input[placeholder*="Cari"]'
                ).last
                btn_kelas = modal_scope.locator(f'button >> text="{student.kelas}"').last
                btn_kelas_part = modal_scope.locator(f'button:has-text("{student.kelas}")').last
                if not await inp_kelas.is_visible() and not await btn_kelas.is_visible() and not await btn_kelas_part.is_visible():
                    await self._safe_click(dd_kelas, timeout=3000)
                    await asyncio.sleep(0.35)
                await self.wait_loading_smart(page, timeout_ms=3500, initial_delay_ms=120)

                if await inp_kelas.is_visible():
                    await self._safe_fill(inp_kelas, student.kelas)
                    await asyncio.sleep(0.35)

                for _poll_k in range(14):
                    if await btn_kelas.is_visible():
                        await self._safe_click(btn_kelas)
                        kelas_selected = True
                        break
                    if await btn_kelas_part.is_visible():
                        await self._safe_click(btn_kelas_part)
                        kelas_selected = True
                        break
                    if _poll_k >= 3 and await page.evaluate(JS_KLIK_OPSI, student.kelas):
                        kelas_selected = True
                        break
                    await asyncio.sleep(0.14)

                await asyncio.sleep(0.25)
                if kelas_selected:
                    try:
                        after_kls_txt = ((await dd_kelas.inner_text()) or "").strip()
                        if "pilih" not in after_kls_txt.lower():
                            break
                    except Exception:
                        break
                    kelas_selected = False

            if not kelas_selected:
                await self._close_registration_modals_completely(page, reload_after=True)
                raise BomAutoRetryUniversal(
                    f"Dropdown Jenjang Pendidikan ({student.kelas}) belum termuat, mengulang pendaftaran"
                )

        # Address: Same as school vs Manual from Excel (Exact V2.6 lines 983-1062)
        await asyncio.sleep(0.35)
        if self.config.alamat_sekolah:
            need_click_sama = await page.evaluate(
                """() => {
                    const modals = Array.from(document.querySelectorAll('.ant-modal-content, .ant-drawer-body, [role="dialog"], form'))
                        .filter(m => m.offsetWidth > 0 && m.offsetHeight > 0);
                    const scope = modals.length > 0 ? modals[modals.length - 1] : document;
                    const cb = scope.querySelector('input[name="sameAddress"]');
                    if (cb) return !cb.checked;
                    const scopeTxt = (scope.innerText || '');
                    if (scopeTxt.includes('Pilih alamat domisili')) return true;
                    const ta = Array.from(scope.querySelectorAll('textarea')).find(el => el.offsetWidth > 0 && el.offsetHeight > 0);
                    if (ta) {
                        if (ta.disabled) return false;
                        if (!(ta.value || '').trim()) return true;
                    }
                    const divCheck = scope.querySelector('div#alamat-sama-dengan-sekolah.check');
                    if (divCheck) {
                        const cls = (divCheck.className || '').toLowerCase();
                        if (cls.includes('checked') || cls.includes('active')) return false;
                        if (divCheck.querySelector('svg, img, i, .check-icon')) return false;
                    }
                    return true;
                }"""
            )
            if need_click_sama:
                div_check_loc = modal_scope.locator('div#alamat-sama-dengan-sekolah.check').first
                inp_check_loc = modal_scope.locator('input[name="sameAddress"]').first
                if await div_check_loc.is_visible():
                    await div_check_loc.click(force=True, timeout=2500)
                    await asyncio.sleep(0.3)
                is_checked_now = await page.evaluate(
                    """() => {
                        const cb = document.querySelector('input[name="sameAddress"]');
                        const dc = document.querySelector('div#alamat-sama-dengan-sekolah.check');
                        if (cb && (cb.checked || cb.value === 'true')) return true;
                        if (dc && !dc.className.includes('bg-white')) return true;
                        return false;
                    }"""
                )
                if not is_checked_now and await inp_check_loc.is_visible():
                    await inp_check_loc.click(force=True, timeout=2500)
                    await asyncio.sleep(0.3)
                await asyncio.sleep(0.35)
                # Ensure Detail Alamat Domisili * (textarea[name="detail-domisili"]) is non-empty!
                # Some schools in Kemenkes master data (e.g. SD NEGERI 011 BENGKONG) only populate
                # Provinsi/KabKota/Kecamatan/Kelurahan when sameAddress is checked, leaving detail-domisili blank!
                ta_domisili = modal_scope.locator(
                    'textarea[name="detail-domisili"], textarea[placeholder*="Cth:"], textarea:visible'
                ).first
                if await ta_domisili.is_visible() and await ta_domisili.is_enabled():
                    cur_ta_val = ((await ta_domisili.input_value()) or "").strip()
                    if not cur_ta_val:
                        fallback_detail = (
                            (student.detail_alamat or "").strip()
                            or (student.nama_sekolah_bersih or "").strip()
                            or (student.nama_sekolah or "").strip()
                            or "Alamat Sekolah"
                        )
                        await self._safe_fill(ta_domisili, fallback_detail)
                        await asyncio.sleep(0.25)
        else:
            await page.evaluate(
                """() => {
                    const cb = document.querySelector('input[name="sameAddress"]');
                    if (cb && cb.checked) cb.click();
                }"""
            )
            await asyncio.sleep(0.5)
            await self._fill_manual_domisili_modal(page, student)

        await asyncio.sleep(0.35)
        btn_lanjut = modal_scope.locator(
            'button:has-text("Selanjutnya"):visible, button:has-text("Lanjutkan"):visible'
        ).last
        if not await btn_lanjut.is_visible():
            btn_lanjut = page.locator(
                'button:has-text("Selanjutnya"):visible, button:has-text("Lanjutkan"):visible'
            ).last
        if await btn_lanjut.is_visible():
            await btn_lanjut.evaluate("el => el.scrollIntoView({ block: 'center', inline: 'nearest' })")
            if await btn_lanjut.is_disabled():
                student.status_sistem = "Gagal: Tombol 'Selanjutnya' terkunci abu-abu. Periksa format Nomor WA/Alamat di Excel!"
                student.state = "failed"
                await self._close_registration_modals_completely(page)
                return False
            await self._safe_click(btn_lanjut, timeout=4000)
            await self.wait_loading_smart(page, timeout_ms=8000, initial_delay_ms=500)

        err_msg = await page.evaluate(JS_READ_FORM_ERRORS)
        if err_msg:
            student.status_sistem = f"Gagal: Ditolak Kemenkes -> {err_msg}"
            student.state = "failed"
            await self._close_registration_modals_completely(page)
            return False

        return True

    async def _fill_manual_domisili_modal(self, page: Any, student: StudentRecord) -> None:
        """Exact V2.6 manual domisili filler (lines 1015-1062)."""
        try:
            await page.evaluate(
                """() => {
                    const els = Array.from(document.querySelectorAll('span, div, input'));
                    const target = els.find(e => e.innerText && e.innerText.includes('Pilih alamat domisili'));
                    if (target) target.click();
                }"""
            )
            await asyncio.sleep(0.6)
            modal = page.locator('.modal-content, div[class*="modal-content"], .ant-modal-content').first
            if await modal.is_visible(timeout=3000):
                for wilayah in (student.provinsi, student.kabkota, student.kecamatan, student.desa):
                    if not wilayah:
                        continue
                    kotak_cari = modal.locator('input[type="text"], input.ant-input').first
                    if await kotak_cari.is_visible(timeout=2500):
                        await self._safe_fill(kotak_cari, str(wilayah))
                        await asyncio.sleep(0.6)
                        presisi = modal.locator(
                            f'div:text-is("{wilayah}"), span:text-is("{wilayah}"), li:text-is("{wilayah}")'
                        ).first
                        if await presisi.is_visible(timeout=1500):
                            await self._safe_click(presisi)
                        else:
                            kasar = modal.locator(
                                f'div:has-text("{wilayah}"), li:has-text("{wilayah}")'
                            ).last
                            if await kasar.is_visible():
                                await self._safe_click(kasar)
                        await asyncio.sleep(0.4)

            if student.detail_alamat:
                kotak_detail = page.locator('textarea[placeholder*="Cth:"], textarea').first
                if await kotak_detail.is_visible():
                    isi = await kotak_detail.input_value()
                    if not isi or not isi.strip():
                        await self._safe_fill(kotak_detail, student.detail_alamat)
        except Exception:
            pass

    async def _submit_pendaftaran_and_capture_ticket(
        self, page: Any, worker_id: int, student: StudentRecord
    ) -> bool:
        """Exact V2.6 registration submitter + Jaring 1 Ticket Extractor (lines 1098-1197)."""
        try:
            btn_pilih = page.locator('button:has-text("Pilih"):visible').last
            btn_daftar = (
                page.locator(
                    'button:has-text("Daftarkan dengan NIK"):visible, button:has-text("Simpan"):visible, button:has-text("Daftar"):visible'
                )
                .filter(has_not_text="Baru")
                .filter(has_not_text="wali")
                .last
            )
            pop_up_awal = page.locator('text="Berhasil Daftar"').first

            for _ in range(10):
                if (
                    await pop_up_awal.is_visible()
                    or await btn_pilih.is_visible()
                    or await btn_daftar.is_visible()
                ):
                    break
                await asyncio.sleep(0.25)

            if (
                not await pop_up_awal.is_visible()
                and not await btn_pilih.is_visible()
                and not await btn_daftar.is_visible()
            ):
                btn_lanjut_retry = page.locator(
                    'button:has-text("Selanjutnya"):visible, button:has-text("Lanjutkan"):visible'
                ).last
                if await btn_lanjut_retry.is_visible() and not await btn_lanjut_retry.is_disabled():
                    await self._safe_click(btn_lanjut_retry, timeout=3000)
                    await self.wait_loading_smart(page, timeout_ms=6000, initial_delay_ms=350)

            if await btn_pilih.is_visible():
                await self._safe_click(btn_pilih)
                await asyncio.sleep(0.4)

            if not await pop_up_awal.is_visible() and await btn_daftar.is_visible():
                await self._safe_click(btn_daftar)

            await self.wait_loading_smart(page, timeout_ms=25000, initial_delay_ms=400)

            for _w_idx in range(80):
                await self.radar_sapu_jagat(page, worker_id)
                teks_layar = (
                    await page.evaluate(
                        """() => {
                            const modals = Array.from(document.querySelectorAll('.ant-modal-content, .ant-drawer-body, [role="dialog"], .modal-content, div[class*="modal"], div[class*="fixed"], form'))
                                .filter(m => m.offsetWidth > 100 && m.offsetHeight > 80 && !m.querySelector('table'));
                            const txt = modals.length > 0 ? modals.map(m => m.innerText || '').join('\\n') : (document.body.innerText || '');
                            return txt.toLowerCase();
                        }"""
                    )
                ) or ""
                if (
                    "berhasil daftar" in teks_layar
                    or "individu sudah terdaftar" in teks_layar
                    or "dukcapil" in teks_layar
                    or "kesalahan saat mengambil data" in teks_layar
                    or "kuota pada tanggal" in teks_layar
                    or "sudah penuh" in teks_layar
                ):
                    break
                if _w_idx in (4, 12, 24):
                    if await btn_pilih.is_visible():
                        await self._safe_click(btn_pilih)
                        await asyncio.sleep(0.3)
                    if await btn_daftar.is_visible() and not await btn_daftar.is_disabled():
                        await self._safe_click(btn_daftar)
                await asyncio.sleep(0.35)

            await asyncio.sleep(0.3)
            modal_text = (
                await page.evaluate(
                    """() => {
                        const modals = Array.from(document.querySelectorAll('.ant-modal-content, .ant-drawer-body, [role="dialog"], .modal-content, div[class*="modal"], div[class*="fixed"], form'))
                            .filter(m => m.offsetWidth > 100 && m.offsetHeight > 80 && !m.querySelector('table'));
                        return modals.length > 0 ? modals.map(m => m.innerText || '').join('\\n') : '';
                    }"""
                )
            ) or ""
            lower_text = modal_text.lower()

            if "kuota pada tanggal" in lower_text or "sudah penuh" in lower_text:
                student.status_sistem = "Gagal: Kuota Faskes Penuh"
                student.state = "failed"
                await self._close_registration_modals_completely(page)
                return False

            if "dukcapil" in lower_text or "kesalahan saat mengambil data" in lower_text:
                student.status_sistem = "Gagal: Data tidak sama dengan Disdukcapil"
                student.state = "failed"
                await self._close_registration_modals_completely(page)
                return False

            # Jaring 1: Extract Ticket Number strictly from Modal text
            m_tiket = re.search(
                r"Tiket:\s*([A-Za-z0-9]{3}\s*-\s*[A-Za-z0-9]{3})", modal_text, re.IGNORECASE
            )
            if not m_tiket:
                m_tiket = re.search(r"\b([A-Za-z0-9]{3}\s*-\s*[A-Za-z0-9]{3})\b", modal_text)
            if m_tiket:
                student.no_tiket = m_tiket.group(1).replace(" ", "")
                self.log(
                    f"🎟️ [JARING 1] Nomor Tiket berhasil diamankan: {student.no_tiket}",
                    "success",
                    worker_id,
                )

            if (
                not m_tiket
                and "berhasil daftar" not in lower_text
                and "sudah terdaftar" not in lower_text
            ):
                await self.capture_worker_peek(page, worker_id)
                err_msg = await page.evaluate(JS_READ_FORM_ERRORS)
                await self._close_registration_modals_completely(page, reload_after=True)
                raise BomAutoRetryUniversal(
                    f"Pendaftaran belum menghasilkan tiket ({err_msg or 'form belum tersimpan'})"
                )

            await self._close_modal_safely(page)
            return True
        except BomAutoRetryUniversal:
            raise
        except Exception as exc:
            self.log(f"⚠️ Peringatan simpan pendaftaran: {exc}", "warning", worker_id)
            await self._close_modal_safely(page)
            return True

    async def _konfirmasi_kehadiran_siswa(
        self, page: Any, worker_id: int, student: StudentRecord
    ) -> None:
        """
        Exact V2.6 Konfirmasi Kehadiran flow (lines 1207-1458).
        Uses per-slot _get_worker_filter_lock so school/class selection never collides.
        """
        try:
            async with self._get_worker_filter_lock(worker_id):
                if "ckg-pendaftaran-anak-sekolah" not in page.url:
                    await page.goto(URL_PENDAFTARAN, wait_until="domcontentloaded", timeout=40000)

                await page.wait_for_selector(
                    'button:has-text("Daftar Baru"), button:has-text("+ Daftar Baru")', timeout=30000
                )
                await self.wait_loading_smart(page, timeout_ms=10000, initial_delay_ms=250)

                await self._select_filter_sekolah_dan_kelas(page, worker_id, student)
                use_tkt = bool(student.no_tiket and student.no_tiket != "-")
                await self._search_by_nik_or_tiket_on_table(
                    page, worker_id, student, force_use_ticket=use_tkt if use_tkt else None
                )

                btn_konfirmasi = page.locator(
                    'button:has-text("Konfirmasi Hadir"), a:has-text("Konfirmasi Hadir"), div[role="button"]:has-text("Konfirmasi Hadir")'
                ).first

                kata_pertama = student.nama.split()[0] if student.nama else student.nik
                baris_siswa = page.locator(f'tr:has-text("{kata_pertama}")').first

                for _ in range(15):
                    if await btn_konfirmasi.is_visible() or await baris_siswa.is_visible():
                        break
                    await asyncio.sleep(0.25)

                if not await btn_konfirmasi.is_visible():
                    self.log(
                        f"ℹ️ Tombol 'Konfirmasi Hadir' tidak muncul untuk {student.nama} (Sudah dikonfirmasi hadir).",
                        "info",
                        worker_id,
                    )
                    return

                await self._safe_click(btn_konfirmasi)
                await asyncio.sleep(0.5)

            # Check if Kemenkes requests re-validation fields inside Konfirmasi Hadir modal
            try:
                inp_wa = page.locator(
                    'input[placeholder*="whatsapp"], input[placeholder*="WhatsApp"]'
                ).last
                if await inp_wa.is_visible(timeout=1000) and not await inp_wa.is_disabled():
                    val_wa = await inp_wa.input_value()
                    if not val_wa or len(val_wa.strip()) < 5:
                        await self._safe_fill(inp_wa, student.wa_pasien or self._get_faskes_fallback_wa())

                dd_disab = page.locator('text="Pilih penyandang disabilitas"').last
                if await dd_disab.is_visible(timeout=500):
                    await self._safe_click(dd_disab)
                    await asyncio.sleep(0.2)
                    await self._safe_click(page.locator('text="Tidak memiliki disabilitas"').last)

                inp_det = page.locator(
                    'textarea[placeholder*="detail"], input[placeholder*="detail"], textarea'
                ).last
                if await inp_det.is_visible(timeout=500) and not await inp_det.is_disabled():
                    val_det = await inp_det.input_value()
                    if not val_det or len(val_det.strip()) < 2:
                        await self._safe_fill(
                            inp_det,
                            student.detail_alamat or student.desa or student.kecamatan or "Indonesia",
                        )
            except Exception:
                pass

            area_popup = page.locator(
                '.ant-modal-content, .ant-drawer-body, [role="dialog"]'
            ).last
            if not await area_popup.is_visible():
                area_popup = page

            kotak_centang = area_popup.locator(
                'input[type="checkbox"], .ant-checkbox-input, .ant-checkbox'
            ).first
            if await kotak_centang.is_visible():
                await self._safe_click(kotak_centang)
            else:
                lbl_setuju = area_popup.locator(
                    'label:has-text("Setuju"), label:has-text("Hadir"), label:has-text("Konfirmasi"), label:has-text("Benar"), label'
                ).first
                if await lbl_setuju.is_visible():
                    await self._safe_click(lbl_setuju)

            await asyncio.sleep(0.25)
            btn_hadir_final = area_popup.locator(
                'button:has-text("Hadir"), button:has-text("Simpan"), button:has-text("Konfirmasi"), button:has-text("Ya")'
            ).last
            if await btn_hadir_final.is_visible():
                await self._safe_click(btn_hadir_final)
                student._just_registered = True  # type: ignore[attr-defined]
                await self.wait_loading_smart(page, timeout_ms=10000, initial_delay_ms=400)

            await self._close_modal_safely(page)
        except BomAutoRetryUniversal:
            raise
        except Exception as exc:
            self.log(f"ℹ️ Catatan Konfirmasi Hadir: {exc}", "info", worker_id)

    # =========================================================================
    # PHASE 2: MENU PELAYANAN & PENCARIAN LINTAS TAB (/ckg-pelayanan-sekolah)
    # =========================================================================

    async def _prescan_selesai_mandiri_status(
        self, page: Any, worker_id: int, queue: asyncio.Queue[StudentRecord]
    ) -> None:
        """
        Fast Table Pre-Scanner for /ckg-pelayanan-sekolah -> 'Selesai Pemeriksaan':
        Scans each class's Selesai Pemeriksaan table (including pagination) to:
        1. Automatically detect any student in 'Selesai Pemeriksaan' whose 'Pemeriksaan Mandiri' badge
           is still 'Belum lengkap' or 'Belum Dilakukan', and schedule them at the front of the queue!
        2. Immediately mark students in 'Selesai Pemeriksaan' whose 'Pemeriksaan Mandiri' is already 'Lengkap'
           as SUKSES PARIPURNA without wasting time opening their examination forms.
        """
        try:
            class_reps: List[StudentRecord] = []
            seen_classes: set[Tuple[str, str]] = set()
            for st in self.students:
                key = ((st.nama_sekolah_bersih or st.nama_sekolah or "").strip().upper(), (st.kelas or "").strip())
                if key[0] and key[1] and key not in seen_classes:
                    seen_classes.add(key)
                    class_reps.append(st)

            if not class_reps:
                return

            self.log(
                f"🔎 Memindai status kelengkapan Pemeriksaan Mandiri di tab 'Selesai Pemeriksaan' ({len(class_reps)} kelas)...",
                "info",
                worker_id,
            )
            priority_mandiri_students: List[StudentRecord] = []
            priority_ids: set[int] = set()
            completed_skip_ids: set[int] = set()
            global_seen_signatures: set[str] = set()

            async with self._get_worker_filter_lock(worker_id):
                if not page.url.rstrip("/").endswith("/ckg-pelayanan-sekolah"):
                    await page.goto(URL_PELAYANAN, wait_until="domcontentloaded", timeout=45000)
                    await self.wait_loading_smart(page, timeout_ms=15000, initial_delay_ms=350)
                await self.radar_sapu_jagat(page, worker_id)

                # Dismiss Pengaturan Pelayanan modal if shown
                try:
                    teks_modal = page.locator("text=Pengaturan Pelayanan").first
                    if await teks_modal.is_visible(timeout=800):
                        cb_lokasi = page.locator("input#sameLocation").first
                        if await cb_lokasi.count() > 0:
                            await cb_lokasi.click(force=True)
                        await asyncio.sleep(0.2)
                        btn_simpan = page.locator('button:has-text("Simpan")').first
                        if await btn_simpan.is_visible():
                            await btn_simpan.click(force=True, timeout=3000)
                        await self.wait_loading_smart(page, timeout_ms=8000, initial_delay_ms=250)
                except Exception:
                    pass

                for rep in class_reps:
                    if self.stop_requested:
                        break
                    await page.evaluate("() => window.scrollTo(0, 0)")
                    await self._select_filter_sekolah_dan_kelas(page, worker_id, rep)
                    # Clear search input so all rows in the class are listed
                    try:
                        kolom = page.locator('input#searchNik, input[placeholder*="Masukkan"]').first
                        if await kolom.is_visible():
                            val = (await kolom.input_value()) or ""
                            if val.strip():
                                await kolom.fill("")
                                await asyncio.sleep(0.15)
                    except Exception:
                        pass

                    btn_tampil = page.locator('button:has-text("Tampilkan Pencarian")').first
                    if await btn_tampil.is_visible():
                        await self._safe_click(btn_tampil, timeout=4000)
                        await self.wait_loading_smart(page, timeout_ms=12000, initial_delay_ms=350)

                    # Re-verify if tabs haven't appeared yet on first load
                    if not await page.locator('div.cursor-pointer:has-text("Selesai Pemeriksaan")').first.is_visible():
                        await self._select_filter_sekolah_dan_kelas(page, worker_id, rep)
                        if await btn_tampil.is_visible():
                            await self._safe_click(btn_tampil, timeout=4000)
                            await self.wait_loading_smart(page, timeout_ms=12000, initial_delay_ms=400)

                    tabs_to_scan = (
                        ["Selesai Pemeriksaan", "Sedang Pemeriksaan"]
                        if self.config.mode == "B"
                        else ["Selesai Pemeriksaan"]
                    )
                    for tab_label in tabs_to_scan:
                        if self.stop_requested:
                            break
                        tab_el = page.locator(f'div.cursor-pointer:has-text("{tab_label}")').last
                        if not await tab_el.is_visible():
                            tab_el = page.locator(f'text=/^\\s*{re.escape(tab_label)}/i').first
                        if not await tab_el.is_visible():
                            continue
                        await self._safe_click(tab_el, timeout=4000)
                        await self.wait_loading_smart(page, timeout_ms=10000, initial_delay_ms=350)

                        # Reset pagination back to page 1 if a previous scan left it on page > 1
                        try:
                            for _reset_pg in range(12):
                                on_first_page = await page.evaluate(
                                    """() => {
                                        const bodyTxt = document.body.innerText || '';
                                        const m = bodyTxt.match(/Menampilkan\\s+(\\d+)\\s*-\\s*(\\d+)\\s+dari\\s+(\\d+)\\s+data/i);
                                        if (m && parseInt(m[1], 10) === 1) return true;
                                        const table = document.querySelector('table');
                                        const minTop = table ? (table.getBoundingClientRect().bottom - 24) : 280;
                                        const els = Array.from(document.querySelectorAll('div.cursor-pointer, button, li, a, span.cursor-pointer, div[role="button"]'))
                                            .filter(el => {
                                                if (el.offsetWidth <= 0 || el.offsetHeight <= 0 || el.offsetWidth > 80) return false;
                                                const r = el.getBoundingClientRect();
                                                return r.top >= minTop && /^\\d+$/.test((el.innerText || '').trim());
                                            });
                                        if (els.length > 0) {
                                            const pgBox = els[els.length - 1];
                                            if ((pgBox.innerText || '').trim() === '1') return true;
                                            const prevBtn = pgBox.previousElementSibling;
                                            if (prevBtn && prevBtn.offsetWidth > 0) {
                                                prevBtn.click();
                                                return false;
                                            }
                                        }
                                        return true;
                                    }"""
                                )
                                if on_first_page:
                                    break
                                await asyncio.sleep(0.25)
                        except Exception:
                            pass

                        is_selesai_tab = tab_label == "Selesai Pemeriksaan"
                        for page_num in range(1, 14):
                            if self.stop_requested:
                                break
                            rows_data: List[Dict[str, Any]] = []
                            sig = ""
                            for poll_idx in range(20):
                                if page_num == 1 and poll_idx == 7:
                                    try:
                                        await self._safe_click(tab_el, timeout=2500)
                                        await self.wait_loading_smart(page, timeout_ms=6000, initial_delay_ms=250)
                                    except Exception:
                                        pass
                                rows_now = await page.evaluate(
                                    """() => {
                                        const rows = Array.from(document.querySelectorAll('tbody tr'));
                                        const out = [];
                                        for (const tr of rows) {
                                            const txt = (tr.innerText || '').trim();
                                            const lower = txt.toLowerCase();
                                            if (!txt || lower.includes('data tidak ditemukan') || lower.includes('cek data di status')) continue;
                                            const mTiket = txt.match(/\\b([A-Za-z0-9]{3}-[A-Za-z0-9]{3})\\b/);
                                            const tiket = mTiket ? mTiket[1].toUpperCase() : '';
                                            const cells = Array.from(tr.querySelectorAll('td')).map(td => (td.innerText || '').trim());
                                            const nama = cells.length >= 2 ? cells[1] : '';
                                            const belumLengkap = Boolean(lower.includes('belum lengkap') || lower.includes('belum dilakukan'));
                                            const lengkap = Boolean(!belumLengkap && lower.includes('lengkap'));
                                            if (tiket || nama) {
                                                out.push({ tiket, nama, belumLengkap, lengkap });
                                            }
                                        }
                                        return out;
                                    }"""
                                )
                                if rows_now:
                                    sig_now = f"{tab_label}|" + "|".join(
                                        f"{r.get('tiket','')}:{r.get('nama','')}" for r in rows_now
                                    )
                                    if sig_now not in global_seen_signatures:
                                        rows_data = rows_now
                                        sig = sig_now
                                        break
                                await asyncio.sleep(0.2)

                            if not rows_data or not sig:
                                break
                            global_seen_signatures.add(sig)

                            for r in rows_data:
                                r_tiket = (r.get("tiket") or "").strip().upper()
                                r_nama = (r.get("nama") or "").strip().lower()
                                for st in self.students:
                                    st_tkt = (st.no_tiket or "").strip().upper()
                                    has_st_tkt = bool(st_tkt and st_tkt != "-")
                                    match_tkt = bool(r_tiket and has_st_tkt and r_tiket == st_tkt)
                                    if r_tiket and has_st_tkt and not match_tkt:
                                        continue
                                    same_class = (st.kelas or "").strip().lower() == (rep.kelas or "").strip().lower()
                                    if not match_tkt and not same_class:
                                        continue
                                    st_nama = (st.nama or "").strip().lower()
                                    match_nm = bool(
                                        same_class
                                        and r_nama
                                        and st_nama
                                        and r_nama == st_nama
                                    )
                                    if match_tkt or match_nm:
                                        if r_tiket and (not st.no_tiket or st.no_tiket == "-"):
                                            st.no_tiket = r_tiket
                                        if is_selesai_tab:
                                            st._already_selesai_pemeriksaan = True  # type: ignore[attr-defined]
                                            st._check_selesai_first = True  # type: ignore[attr-defined]
                                        else:
                                            st._already_selesai_pemeriksaan = False  # type: ignore[attr-defined]
                                            st._check_selesai_first = False  # type: ignore[attr-defined]
                                        if r.get("belumLengkap"):
                                            st._mandiri_already_lengkap = False  # type: ignore[attr-defined]
                                            st.state = "pending"
                                            st.status_sistem = "Menunggu Melengkapi Skrining Mandiri"
                                            if id(st) not in priority_ids:
                                                priority_ids.add(id(st))
                                                priority_mandiri_students.append(st)
                                                self.log(
                                                    f"🔎 [SCAN TABEL] {st.nama} ({st.kelas} | Tiket: {st.no_tiket}) -> Pemeriksaan Mandiri 'Belum lengkap', dijadwalkan dilengkapi!",
                                                    "warning",
                                                    worker_id,
                                                )
                                        elif r.get("lengkap") and not self.config.update_data_lama:
                                            st._mandiri_already_lengkap = True  # type: ignore[attr-defined]
                                            if is_selesai_tab or self.config.mode == "B":
                                                completed_skip_ids.add(id(st))
                                            if is_selesai_tab and st.state in ("failed", "skipped", "pending"):
                                                st.status_sistem = "Selesai Lengkap (Pendaftaran, Skrining Mandiri & Pemeriksaan Nakes)"
                                                if not st.tatalaksana or st.tatalaksana == "-":
                                                    st.tatalaksana = "Aman (Tidak Ada Tindakan)"
                                                st.state = (
                                                    "warning"
                                                    if st.tatalaksana == "Harus tatalaksana"
                                                    else "success"
                                                )
                                                st.last_step = "Selesai"
                                                self.state_db.save_student_checkpoint(self.current_file_key, st)
                                                self.log(
                                                    f"✅ [SCAN TABEL] {st.nama} ({st.kelas} | Tiket: {st.no_tiket}) sudah Selesai & Pemeriksaan Mandiri Lengkap.",
                                                    "success",
                                                    worker_id,
                                                )
                                            elif not is_selesai_tab and self.config.mode == "B" and st.state in ("failed", "skipped", "pending"):
                                                st.status_sistem = "Selesai Tahap 2 (Kuesioner Skrining Mandiri)"
                                                st.state = (
                                                    "warning"
                                                    if st.tatalaksana == "Harus tatalaksana"
                                                    else "success"
                                                )
                                                st.last_step = "Skrining Mandiri Selesai"
                                                self.state_db.save_student_checkpoint(self.current_file_key, st)
                                        break

                            # Scroll down and click next pagination page ([ › ] or page_num + 1) if present
                            try:
                                await page.evaluate("() => window.scrollTo(0, document.body.scrollHeight)")
                                await asyncio.sleep(0.15)
                            except Exception:
                                pass
                            curr_page_str = str(page_num)
                            next_page_str = str(page_num + 1)
                            clicked_next = await page.evaluate(
                                """({ currPageStr, targetPageStr }) => {
                                    const bodyTxt = document.body.innerText || '';
                                    const m = bodyTxt.match(/Menampilkan\\s+(\\d+)\\s*-\\s*(\\d+)\\s+dari\\s+(\\d+)\\s+data/i);
                                    if (m) {
                                        const endRow = parseInt(m[2], 10);
                                        const totalRows = parseInt(m[3], 10);
                                        if (endRow >= totalRows) return false;
                                    }
                                    const table = document.querySelector('table');
                                    const minTop = table ? (table.getBoundingClientRect().bottom - 24) : 280;
                                    const pageBoxes = Array.from(document.querySelectorAll('div, button, li, a, span'))
                                        .filter(el => {
                                            if (el.offsetWidth <= 0 || el.offsetHeight <= 0 || el.offsetWidth > 90) return false;
                                            const rect = el.getBoundingClientRect();
                                            if (rect.top < minTop) return false;
                                            return (el.innerText || '').trim() === currPageStr;
                                        });
                                    const leafBoxes = pageBoxes.filter(el => !pageBoxes.some(o => o !== el && el.contains(o)));
                                    const activeBoxes = leafBoxes.length > 0 ? leafBoxes : pageBoxes;
                                    for (let i = activeBoxes.length - 1; i >= 0; i--) {
                                        const box = activeBoxes[i];
                                        const nextSibling = box.nextElementSibling || (box.parentElement && box.parentElement.nextElementSibling);
                                        if (nextSibling && nextSibling.offsetWidth > 0 && nextSibling.offsetHeight > 0) {
                                            const disabled = nextSibling.hasAttribute('disabled') ||
                                                (nextSibling.className && String(nextSibling.className).includes('disabled'));
                                            if (!disabled) {
                                                nextSibling.click();
                                                return true;
                                            }
                                        }
                                    }
                                    const raw = Array.from(document.querySelectorAll('div.cursor-pointer, button, li, a, span.cursor-pointer, div[role="button"]'))
                                        .filter(el => {
                                            if (el.offsetWidth <= 0 || el.offsetHeight <= 0 || el.offsetWidth > 90) return false;
                                            const rect = el.getBoundingClientRect();
                                            if (rect.top < minTop) return false;
                                            return (el.innerText || '').trim() === targetPageStr;
                                        });
                                    const leaf = raw.filter(el => !raw.some(o => o !== el && el.contains(o)));
                                    const candidates = leaf.length > 0 ? leaf : raw;
                                    if (candidates.length > 0) {
                                        candidates[candidates.length - 1].click();
                                        return true;
                                    }
                                    const nextBtns = Array.from(document.querySelectorAll(
                                        'li.ant-pagination-next:not(.ant-pagination-disabled) button, li.ant-pagination-next:not(.ant-pagination-disabled), button[aria-label*="next" i]:not(:disabled)'
                                    )).filter(el => el.offsetWidth > 0 && el.offsetHeight > 0);
                                    if (nextBtns.length > 0) {
                                        nextBtns[nextBtns.length - 1].click();
                                        return true;
                                    }
                                    return false;
                                }""",
                                {"currPageStr": curr_page_str, "targetPageStr": next_page_str},
                            )
                            if not clicked_next:
                                break
                            await self.wait_loading_smart(page, timeout_ms=8000, initial_delay_ms=250)

            # Synchronize asyncio.Queue cleanly so task_done() never mismatches _unfinished_tasks
            if priority_mandiri_students or completed_skip_ids:
                existing_items: List[StudentRecord] = []
                while not queue.empty():
                    try:
                        item = queue.get_nowait()
                        queue.task_done()
                        if id(item) not in priority_ids and id(item) not in completed_skip_ids:
                            existing_items.append(item)
                    except asyncio.QueueEmpty:
                        break
                    except ValueError:
                        pass
                for st in priority_mandiri_students:
                    queue.put_nowait(st)
                for st in existing_items:
                    queue.put_nowait(st)
        except Exception as exc:
            self.log(f"ℹ️ Catatan pemindaian awal tabel Selesai Pemeriksaan: {exc}", "info", worker_id)

    def _handle_selesai_tab_match(
        self, res_selesai: Dict[str, Any], student: StudentRecord, worker_id: int
    ) -> Optional[Dict[str, Any]]:
        """
        Handles a student row matched on the 'Selesai Pemeriksaan' tab:
        - If 'Pemeriksaan Mandiri' is still 'Belum lengkap' / 'Belum Dilakukan' (or update_data_lama is True),
          marks student._already_selesai_pemeriksaan = True and returns res_selesai so '[Mulai]' is clicked
          to complete the remaining Skrining Mandiri forms.
        - If 'Pemeriksaan Mandiri' is already 'Lengkap', marks the student as SUKSES PARIPURNA and returns None
          so we don't needlessly open their completed examination page.
        """
        if res_selesai.get("extractedTiket") and (
            not student.no_tiket or student.no_tiket == "-"
        ):
            student.no_tiket = res_selesai["extractedTiket"]

        student._already_selesai_pemeriksaan = True  # type: ignore[attr-defined]
        mandiri_belum_lengkap = bool(res_selesai.get("mandiriBelumLengkap"))
        can_open = res_selesai.get("state") == "found"

        if can_open and (
            self.config.update_data_lama
            or (
                mandiri_belum_lengkap
                and self.config.mode in ("B", "C")
                and not self.config.lewati_skrining
            )
        ):
            student._mandiri_already_lengkap = False  # type: ignore[attr-defined]
            self.log(
                f"📋 {student.nama} berada di 'Selesai Pemeriksaan' namun Pemeriksaan Mandiri masih 'Belum lengkap'. Membuka & melengkapi Skrining Mandiri...",
                "info",
                worker_id,
            )
            return res_selesai

        student._mandiri_already_lengkap = True  # type: ignore[attr-defined]
        student.status_sistem = "Selesai Lengkap (Pendaftaran, Skrining Mandiri & Pemeriksaan Nakes)"
        if not student.tatalaksana or student.tatalaksana == "-":
            student.tatalaksana = "Aman (Tidak Ada Tindakan)"
        student.state = "warning" if student.tatalaksana == "Harus tatalaksana" else "success"
        student.last_step = "Selesai"
        self.log(
            f"✅ {student.nama}: Sudah di Selesai Pemeriksaan & Pemeriksaan Mandiri Lengkap (Tiket: {student.no_tiket}).",
            "success",
            worker_id,
        )
        return None

    async def _find_student_row_in_current_tab(
        self, page: Any, student: StudentRecord, max_wait_sec: float = 2.0
    ) -> Dict[str, Any]:
        """
        Fast, exact student row matcher for /ckg-pelayanan-sekolah tabs:
        1. Never matches a different student's 'Mulai' button when a tab has unfiltered rows.
        2. Waits across multiple polls before accepting 'empty' so stale 'Data tidak ditemukan'
           text from a previous tab or in-flight search never causes a premature exit.
        3. Tags the exact matching student row's button with [data-ckg-target-mulai="true"], extracts Nomor Tiket,
           and inspects the 'Pemeriksaan Mandiri' badge ('Lengkap' vs 'Belum lengkap' / 'Belum Dilakukan').
        """
        loops = max(1, int(max_wait_sec / 0.2))
        last_res: Dict[str, Any] = {
            "state": "empty",
            "extractedTiket": "",
            "mandiriBelumLengkap": False,
            "mandiriLengkap": False,
        }
        empty_streak = 0
        for poll_idx in range(loops):
            try:
                res = await page.evaluate(
                    """({ tiket, nik, nama }) => {
                        document.querySelectorAll('[data-ckg-target-mulai]').forEach(
                            el => el.removeAttribute('data-ckg-target-mulai')
                        );
                        const rows = Array.from(document.querySelectorAll('tbody tr'));
                        if (rows.length === 0) return { state: 'loading', extractedTiket: '', mandiriBelumLengkap: false, mandiriLengkap: false };
                        const allText = rows.map(r => (r.innerText || '').trim()).join('\\n').toLowerCase();
                        if (
                            allText.includes('data tidak ditemukan') ||
                            allText.includes('cek data di status pemeriksaan lain')
                        ) {
                            return { state: 'empty', extractedTiket: '', mandiriBelumLengkap: false, mandiriLengkap: false };
                        }
                        const tktLower = (tiket && tiket !== '-') ? tiket.trim().toLowerCase() : '';
                        const nikLower = (nik || '').trim().toLowerCase();
                        const namaFull = (nama || '').trim().toLowerCase();

                        for (const tr of rows) {
                            const txt = (tr.innerText || '').trim();
                            const lower = txt.toLowerCase();
                            const mTiket = txt.match(/\\b([A-Za-z0-9]{3}-[A-Za-z0-9]{3})\\b/);
                            const extracted = mTiket ? mTiket[1].toUpperCase() : '';
                            const cells = Array.from(tr.querySelectorAll('td')).map(td => (td.innerText || '').trim());
                            const rowNama = (cells.length >= 2 ? cells[1] : '').toLowerCase();

                            const matchTiket = Boolean(tktLower && extracted && extracted.toLowerCase() === tktLower);
                            if (tktLower && extracted && !matchTiket) continue;

                            const matchNik = Boolean(nikLower && lower.includes(nikLower));
                            const matchNama = Boolean(
                                !tktLower && namaFull && (
                                    rowNama === namaFull ||
                                    (!rowNama && lower.includes(namaFull))
                                )
                            );
                            if (matchTiket || matchNik || matchNama) {
                                const btn = Array.from(tr.querySelectorAll('button, a')).find(b => {
                                    const bt = (b.innerText || '').trim().toLowerCase();
                                    return bt.includes('mulai') || bt.includes('lanjutkan') || bt.includes('pemeriksaan');
                                });
                                const mandiriBelumLengkap = Boolean(
                                    lower.includes('belum lengkap') || lower.includes('belum dilakukan')
                                );
                                const mandiriLengkap = Boolean(!mandiriBelumLengkap && lower.includes('lengkap'));
                                if (btn) {
                                    btn.setAttribute('data-ckg-target-mulai', 'true');
                                    return {
                                        state: 'found',
                                        extractedTiket: extracted,
                                        mandiriBelumLengkap,
                                        mandiriLengkap,
                                    };
                                }
                                return {
                                    state: 'found_no_btn',
                                    extractedTiket: extracted,
                                    mandiriBelumLengkap,
                                    mandiriLengkap,
                                };
                            }
                        }
                        return { state: 'not_in_rows', extractedTiket: '', mandiriBelumLengkap: false, mandiriLengkap: false };
                    }""",
                    {"tiket": student.no_tiket, "nik": student.nik, "nama": student.nama},
                )
                last_res = res or last_res
                state_now = last_res.get("state")
                if state_now in ("found", "found_no_btn"):
                    return last_res
                if state_now == "empty":
                    empty_streak += 1
                    if poll_idx >= 4 and empty_streak >= 4:
                        return last_res
                else:
                    empty_streak = 0
            except Exception:
                pass
            await asyncio.sleep(0.2)
        return last_res

    async def _switch_pelayanan_tab_and_check(
        self, page: Any, tab_label: str, kolom_cari: Any, student: StudentRecord
    ) -> Dict[str, Any]:
        """Clicks a tab on /ckg-pelayanan-sekolah, triggers search filter, waits for loading, and checks for the student."""
        tab_loc = page.locator(f'div.cursor-pointer:has-text("{tab_label}")').last
        if not await tab_loc.is_visible():
            tab_loc = page.locator(f'text=/^\\s*{re.escape(tab_label)}/i').first
        if not await tab_loc.is_visible():
            return {"state": "empty", "extractedTiket": "", "mandiriBelumLengkap": False, "mandiriLengkap": False}

        await self._safe_click(tab_loc, timeout=4000)
        await asyncio.sleep(0.45)

        if await kolom_cari.is_visible():
            val_now = (await kolom_cari.input_value()) or ""
            if val_now.strip():
                await self._safe_focus_end(kolom_cari)
                await asyncio.sleep(0.2)
                await page.keyboard.press("Enter")
                await asyncio.sleep(0.25)

        await self.wait_loading_smart(page, timeout_ms=10000, initial_delay_ms=350)
        await asyncio.sleep(0.3)

        return await self._find_student_row_in_current_tab(page, student, max_wait_sec=2.0)

    async def _step_buka_pelayanan_dan_cari_siswa(
        self, page: Any, worker_id: int, student: StudentRecord
    ) -> bool:
        """
        Exact V2.6 Pelayanan Nakes entry & cross-tab search (lines 1445-1746).
        Protected by per-slot _get_worker_filter_lock during filter selection & table search.
        """
        student.last_step = "Mencari Siswa di Menu Pelayanan"
        student._already_selesai_pemeriksaan = False  # type: ignore[attr-defined]
        student._mandiri_already_lengkap = False  # type: ignore[attr-defined]
        student._mandiri_done_in_run = False  # type: ignore[attr-defined]
        async with self._get_worker_filter_lock(worker_id):
            if not page.url.rstrip("/").endswith("/ckg-pelayanan-sekolah"):
                await page.goto(URL_PELAYANAN, wait_until="domcontentloaded", timeout=45000)
                await self.wait_loading_smart(page, timeout_ms=15000, initial_delay_ms=350)
            await self.radar_sapu_jagat(page, worker_id)

            # Auto-confirm Pengaturan Pelayanan modal if shown (Exact V2.6 lines 1448-1470)
            try:
                teks_modal = page.locator("text=Pengaturan Pelayanan").first
                if await teks_modal.is_visible(timeout=800):
                    cb_lokasi = page.locator("input#sameLocation").first
                    if await cb_lokasi.count() > 0:
                        await cb_lokasi.click(force=True)
                    else:
                        await page.evaluate(
                            """() => {
                                const cb = document.getElementById('sameLocation');
                                if (cb && !cb.checked) {
                                    cb.checked = true;
                                    cb.dispatchEvent(new Event('change', { bubbles: true }));
                                }
                            }"""
                        )
                    await asyncio.sleep(0.25)
                    btn_simpan = page.locator('button:has-text("Simpan")').first
                    for _ in range(5):
                        if not await teks_modal.is_visible():
                            break
                        if await btn_simpan.is_visible():
                            await btn_simpan.click(force=True, timeout=3000)
                        await asyncio.sleep(0.4)
                    await self.wait_loading_smart(page, timeout_ms=8000, initial_delay_ms=250)
            except Exception:
                pass

            try:
                await page.get_by_text("Tampilkan Pencarian", exact=False).first.wait_for(
                    state="visible", timeout=8000
                )
            except Exception:
                await page.reload(wait_until="domcontentloaded", timeout=30000)
                await self.wait_loading_smart(page, timeout_ms=8000, initial_delay_ms=300)

            # 1. Select School and Class filter FIRST
            filter_changed = await self._select_filter_sekolah_dan_kelas(page, worker_id, student)

            has_valid_ticket = bool(student.no_tiket and student.no_tiket != "-")
            primary_use_ticket = has_valid_ticket
            just_registered = bool(getattr(student, "_just_registered", False))
            check_selesai_first = bool(
                getattr(student, "_check_selesai_first", False)
                or "Mandiri Belum Lengkap" in (student.last_step or "")
                or (has_valid_ticket and self.config.mode == "B")
            )
            prefer_sedang_first = bool(not just_registered and (has_valid_ticket or getattr(student, "_sudah_dilayani_detail", "")))

            # Select initial tab: 'Selesai Pemeriksaan' if known Selesai, else 'Sedang Pemeriksaan' / 'Belum Pemeriksaan'
            if check_selesai_first:
                first_tab = "Selesai Pemeriksaan"
                second_tab = "Sedang Pemeriksaan"
            elif prefer_sedang_first:
                first_tab = "Sedang Pemeriksaan"
                second_tab = "Belum Pemeriksaan"
            else:
                first_tab = "Belum Pemeriksaan"
                second_tab = "Sedang Pemeriksaan"

            try:
                tab_first = page.locator(f'div.cursor-pointer:has-text("{first_tab}")').last
                if not await tab_first.is_visible():
                    tab_first = page.locator(f'text=/^\\s*{re.escape(first_tab)}/i').first
                if await tab_first.is_visible():
                    await self._safe_click(tab_first, timeout=2500)
                    await asyncio.sleep(0.15)
            except Exception:
                pass

            # 2. Primary Search (Nomor Tiket when available, else NIK)
            already_has_search_bar = await page.locator(
                'input#searchNik, input[placeholder*="Masukkan"], div.cursor-pointer:has-text("Sedang Pemeriksaan")'
            ).first.is_visible()
            need_click_tampilkan = (not already_has_search_bar) or filter_changed
            kolom_cari = await self._search_by_nik_or_tiket_on_table(
                page,
                worker_id,
                student,
                force_use_ticket=primary_use_ticket,
                click_tampilkan=need_click_tampilkan,
            )
            if (check_selesai_first or prefer_sedang_first) and need_click_tampilkan:
                # Clicking Tampilkan Pencarian defaults to Belum Pemeriksaan; switch immediately to first_tab
                match_info = await self._switch_pelayanan_tab_and_check(
                    page, first_tab, kolom_cari, student
                )
            else:
                match_info = await self._find_student_row_in_current_tab(page, student, max_wait_sec=1.8)

            if check_selesai_first and match_info.get("state") in ("found", "found_no_btn"):
                handled = self._handle_selesai_tab_match(match_info, student, worker_id)
                if handled is None:
                    return False
                match_info = handled
            elif match_info.get("state") == "found":
                student._mandiri_already_lengkap = bool(match_info.get("mandiriLengkap"))  # type: ignore[attr-defined]

            # 3. Check second tab if not found on first tab
            if match_info.get("state") != "found":
                self.log(
                    f"ℹ️ Tidak ada di '{first_tab}', mengecek tab '{second_tab}'...",
                    "info",
                    worker_id,
                )
                match_info = await self._switch_pelayanan_tab_and_check(
                    page, second_tab, kolom_cari, student
                )
                if match_info.get("state") == "found":
                    student._mandiri_already_lengkap = bool(match_info.get("mandiriLengkap"))  # type: ignore[attr-defined]

            # 4. Check third tab ('Selesai Pemeriksaan' or 'Belum Pemeriksaan') while primary query is active
            if match_info.get("state") != "found":
                third_tab = "Belum Pemeriksaan" if check_selesai_first else "Selesai Pemeriksaan"
                res_third = await self._switch_pelayanan_tab_and_check(
                    page, third_tab, kolom_cari, student
                )
                if res_third.get("state") in ("found", "found_no_btn"):
                    if third_tab == "Selesai Pemeriksaan":
                        handled = self._handle_selesai_tab_match(res_third, student, worker_id)
                        if handled is None:
                            return False
                        match_info = handled
                    else:
                        student._mandiri_already_lengkap = bool(res_third.get("mandiriLengkap"))  # type: ignore[attr-defined]
                        match_info = res_third

            # 5. Smart Fallback by NIK (if primary search used Nomor Tiket and was not found in any tab)
            if match_info.get("state") != "found" and primary_use_ticket and student.nik:
                self.log(
                    f"🔎 Mencoba fallback pencarian via NIK ({student.nik})...",
                    "info",
                    worker_id,
                )
                kolom_cari = await self._search_by_nik_or_tiket_on_table(
                    page,
                    worker_id,
                    student,
                    force_use_ticket=False,
                    click_tampilkan=False,
                )
                for tab_name in ("Sedang Pemeriksaan", "Belum Pemeriksaan", "Selesai Pemeriksaan"):
                    res_fb = await self._switch_pelayanan_tab_and_check(
                        page, tab_name, kolom_cari, student
                    )
                    if res_fb.get("state") in ("found", "found_no_btn"):
                        if tab_name == "Selesai Pemeriksaan":
                            handled = self._handle_selesai_tab_match(res_fb, student, worker_id)
                            if handled is None:
                                return False
                            match_info = handled
                        else:
                            student._mandiri_already_lengkap = bool(res_fb.get("mandiriLengkap"))  # type: ignore[attr-defined]
                            match_info = res_fb
                        break

            # 6. Smart Fallback by Nama (if still not found)
            if match_info.get("state") != "found" and student.nama:
                self.log(
                    f"🔎 Mencoba fallback pencarian via Nama ({student.nama})...",
                    "info",
                    worker_id,
                )
                kolom_cari = await self._search_by_nik_or_tiket_on_table(
                    page,
                    worker_id,
                    student,
                    search_by_name=True,
                    click_tampilkan=False,
                )
                for tab_name in ("Sedang Pemeriksaan", "Belum Pemeriksaan", "Selesai Pemeriksaan"):
                    res_fb = await self._switch_pelayanan_tab_and_check(
                        page, tab_name, kolom_cari, student
                    )
                    if res_fb.get("state") in ("found", "found_no_btn"):
                        if tab_name == "Selesai Pemeriksaan":
                            handled = self._handle_selesai_tab_match(res_fb, student, worker_id)
                            if handled is None:
                                return False
                            match_info = handled
                        else:
                            student._mandiri_already_lengkap = bool(res_fb.get("mandiriLengkap"))  # type: ignore[attr-defined]
                            match_info = res_fb
                        break

            # If confirmed 'sudah_dilayani' in Phase 1 and STILL not found in Belum/Sedang Pemeriksaan
            # even after NIK and Nama fallback, then safely mark as Sudah Dilayani
            sudah_dilayani_detail = getattr(student, "_sudah_dilayani_detail", "") or ""
            tabs_loaded = await page.locator(
                'div.cursor-pointer:has-text("Sedang Pemeriksaan")'
            ).first.is_visible()
            if (
                match_info.get("state") != "found"
                and sudah_dilayani_detail
                and tabs_loaded
                and not self.config.update_data_lama
            ):
                student.status_sistem = f"Sudah Dilayani ({sudah_dilayani_detail})"
                student.state = "skipped"
                student.last_step = "Sudah Selesai Dilayani"
                self.log(f"⏩ {student.nama}: {student.status_sistem}", "info", worker_id)
                return False

            await self.radar_sapu_jagat(page, worker_id)

            if match_info.get("state") != "found":
                student.status_sistem = (
                    "Gagal: Peserta tidak ditemukan di Belum/Sedang/Selesai Pemeriksaan"
                )
                student.state = "failed"
                self.log(f"❌ {student.nama}: {student.status_sistem}", "error", worker_id)
                return False

            # 7. Extract Nomor Tiket if missing, then click the EXACT student row's 'Mulai' button
            student.last_step = "Membuka Halaman Pemeriksaan Siswa"
            if match_info.get("extractedTiket") and (
                not student.no_tiket or student.no_tiket == "-"
            ):
                student.no_tiket = match_info["extractedTiket"]

            btn_mulai = page.locator('[data-ckg-target-mulai="true"]').first
            if not await btn_mulai.is_visible(timeout=800):
                re_match = await self._find_student_row_in_current_tab(
                    page, student, max_wait_sec=2.0
                )
                if re_match.get("state") == "found":
                    btn_mulai = page.locator('[data-ckg-target-mulai="true"]').first
                else:
                    raise BomAutoRetryUniversal(
                        f"Baris tabel {student.nama} bergeser saat hendak klik Mulai, mengulang pencarian baris..."
                    )

            await self._safe_click(btn_mulai, timeout=8000)

        await self.wait_loading_smart(page, timeout_ms=15000, initial_delay_ms=500)

        # Wait up to 20s for either 'Mulai Pemeriksaan' (Belum Pemeriksaan -> Sedang Pemeriksaan transition)
        # OR the examination dashboard ('Pelayanan oleh Nakes' / 'Input Data' cards)
        btn_mulai_inner = page.locator(
            'button:has-text("Mulai Pemeriksaan"), a:has-text("Mulai Pemeriksaan"), button:has-text("Mulai Pelayanan")'
        ).first

        for poll_mulai in range(40):
            if await btn_mulai_inner.is_visible():
                try:
                    await self._safe_click(btn_mulai_inner, timeout=6000)
                    await asyncio.sleep(0.45)
                    btn_simpan_awal = page.get_by_role("button", name="Simpan").last
                    try:
                        await btn_simpan_awal.wait_for(state="visible", timeout=3500)
                        await self._safe_click(btn_simpan_awal, timeout=4000)
                    except Exception:
                        pass
                    await self.wait_loading_smart(page, timeout_ms=15000, initial_delay_ms=500)
                except Exception:
                    pass
                break

            if (
                await page.locator('text="Pelayanan oleh Nakes"').first.is_visible()
                or await page.locator('button:has-text("Input Data")').first.is_visible()
                or await page.locator('button:has-text("Selesaikan Layanan")').first.is_visible()
            ):
                break

            if poll_mulai in (6, 14) and "detail-pemeriksaan" not in page.url.lower():
                try:
                    btn_mulai_retry = page.locator('[data-ckg-target-mulai="true"]').first
                    if not await btn_mulai_retry.is_visible():
                        await self._find_student_row_in_current_tab(page, student, max_wait_sec=1.0)
                        btn_mulai_retry = page.locator('[data-ckg-target-mulai="true"]').first
                    if await btn_mulai_retry.is_visible():
                        await self._safe_click(btn_mulai_retry, timeout=5000)
                except Exception:
                    pass

            await asyncio.sleep(0.4)

        # Ensure the examination dashboard is settled before returning
        for _ in range(25):
            if (
                await page.locator('text="Pelayanan oleh Nakes"').first.is_visible()
                or await page.locator('button:has-text("Input Data")').first.is_visible()
                or await page.locator('button:has-text("Selesaikan Layanan")').first.is_visible()
            ):
                break
            await asyncio.sleep(0.4)

        await asyncio.sleep(0.6)
        await self.capture_worker_peek(page, worker_id)
        return True

    async def _is_on_exam_dashboard(self, page: Any) -> bool:
        """
        Atomic check for whether the page is currently on the student examination dashboard
        (/ckg-pelayanan-sekolah/detail-pemeriksaan main view, NOT inside a SurveyJS sub-form
        and NOT kicked back to the /ckg-pelayanan-sekolah table).
        """
        try:
            return bool(
                await page.evaluate(
                    """() => {
                        const url = (window.location.href || '').toLowerCase();
                        if (url.includes('/ckg-pelayanan-sekolah') && !url.includes('detail-pemeriksaan')) {
                            return false;
                        }
                        const body = (document.body && document.body.innerText) ? document.body.innerText : '';
                        if (
                            body.includes('Silakan lakukan filter sekolah dan kelas') ||
                            body.includes('Tampilkan Pencarian')
                        ) {
                            return false;
                        }
                        const backBtns = Array.from(document.querySelectorAll('button, a')).filter(el => {
                            if (el.offsetWidth <= 0 || el.offsetHeight <= 0) return false;
                            return (el.innerText || '').trim().includes('Kembali ke Halaman Utama');
                        });
                        if (backBtns.length > 0) return false;

                        const kirimBtns = Array.from(document.querySelectorAll(
                            'input.sd-navigation__complete-btn, input[value="Kirim"], button'
                        )).filter(el => {
                            if (el.offsetWidth <= 0 || el.offsetHeight <= 0) return false;
                            const t = ((el.value || el.innerText || '') + '').trim().toLowerCase();
                            return t === 'kirim' || el.classList.contains('sd-navigation__complete-btn');
                        });
                        if (kirimBtns.length > 0) return false;

                        return (
                            body.includes('Pemeriksaan Mandiri') ||
                            body.includes('Jumlah Pemeriksaan') ||
                            body.includes('Pelayanan oleh Nakes') ||
                            body.includes('Selesaikan Layanan')
                        );
                    }"""
                )
            )
        except Exception:
            return False

    async def _wait_for_exam_dashboard(self, page: Any, timeout_ms: int = 4000) -> bool:
        loops = max(1, int(timeout_ms / 200))
        for _ in range(loops):
            if await self._is_on_exam_dashboard(page):
                return True
            await asyncio.sleep(0.2)
        return False

    async def sadar_diri_dan_kembali(
        self, page: Any, worker_id: int, student: StudentRecord
    ) -> None:
        """
        Exact V2.6 Auto-Recovery Protocol using 1-ms atomic JS check + sub-form escape.
        """
        try:
            # If trapped inside a SurveyJS form with 'Kembali ke Halaman Utama', exit back to dashboard first
            btn_back = page.locator(
                'button:has-text("Kembali ke Halaman Utama"), a:has-text("Kembali ke Halaman Utama")'
            ).first
            if await btn_back.is_visible():
                await self._safe_click(btn_back, timeout=4000)
                await self.wait_loading_smart(page, timeout_ms=10000, initial_delay_ms=400)
                await asyncio.sleep(0.4)

            is_outside = await page.evaluate(JS_IS_OUTSIDE_EXAM_PAGE)
            if is_outside:
                self.log(
                    f"🚨 [AUTO-RECOVERY] Robot mendeteksi keluar dari halaman pemeriksaan! Masuk kembali untuk {student.nama}...",
                    "warning",
                    worker_id,
                )
                await self._step_buka_pelayanan_dan_cari_siswa(page, worker_id, student)
        except Exception:
            pass

    async def _commit_survey_inputs_and_click_kirim(self, page: Any) -> None:
        """
        Commits any active/focused SurveyJS input (blurring & firing input/change/blur)
        and clicks 'Kirim' using native Playwright click (like V2.6 L2547-2549) + JS fallback.
        """
        try:
            await page.evaluate(
                """() => {
                    const active = document.activeElement;
                    if (active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA' || active.tagName === 'SELECT')) {
                        active.dispatchEvent(new Event('input', { bubbles: true }));
                        active.dispatchEvent(new Event('change', { bubbles: true }));
                        active.blur();
                    }
                    document.querySelectorAll('input.sd-input, input[type="number"], input.form-input').forEach(inp => {
                        if (inp.offsetWidth > 0 && inp.value !== '') {
                            inp.dispatchEvent(new Event('input', { bubbles: true }));
                            inp.dispatchEvent(new Event('change', { bubbles: true }));
                            inp.dispatchEvent(new Event('blur', { bubbles: true }));
                        }
                    });
                }"""
            )
        except Exception:
            pass
        await asyncio.sleep(0.2)

        btn_kirim = page.locator(
            'button:has-text("Kirim"):not(:has-text("Rapor")):visible, input[value="Kirim"]:visible, input.sd-navigation__complete-btn:visible'
        ).last
        clicked_native = False
        try:
            if await btn_kirim.is_visible(timeout=1200):
                await btn_kirim.scroll_into_view_if_needed(timeout=2000)
                await btn_kirim.click(force=True, timeout=4000)
                clicked_native = True
        except Exception:
            pass

        if not clicked_native:
            await page.evaluate(JS_CLICK_KIRIM)

    async def _heal_unanswered_survey_questions(self, page: Any) -> None:
        """
        Guarantees every visible SurveyJS question (.sd-question, .sv-question) has a valid answer
        before Kirim is clicked:
        1. Runs _sweep_universal_safe_defaults(page)
        2. For any question still missing a checked radio/checkbox, clicks the best safe option
           (or the first visible option as fallback)
        3. For any question with an empty visible number/text input (not combobox), fills a safe default
        4. For any combobox/dropdown still showing placeholder ('Pilih...'), opens it and picks a safe option
        """
        await self._sweep_universal_safe_defaults(page)
        try:
            await page.evaluate(
                """() => {
                    const safeOrder = [
                        'tidak benar', 'tidak pernah', 'tidak sama sekali', 'tidak ada kelainan',
                        'tidak ditemukan kelainan', 'tidak ada', 'belum/tidak tahu', 'belum pernah',
                        'tidak tahu', 'tidak ingat', 'tidak batuk', 'tidak berubah', 'tidak, berubah',
                        'tidak', 'belum', 'normal', 'negatif', 'baik', 'mandiri', 'non disabilitas',
                        'ya', 'sudah'
                    ];
                    const qs = Array.from(document.querySelectorAll('.sd-question, .sv-question, tr.sd-table__row, tbody tr'))
                        .filter(q => q.offsetWidth > 0 && q.offsetHeight > 0 && q.querySelectorAll('input[type="radio"], input[type="checkbox"], label, input[type="number"], input.sd-input').length > 0 && !q.querySelector('button[data-mandiri-target]'));
                    for (const q of qs) {
                        const hasChecked = Boolean(q.querySelector('input[type="radio"]:checked, input[type="checkbox"]:checked'));
                        if (!hasChecked) {
                            const rawLabels = Array.from(q.querySelectorAll('label, span.sv-string-viewer'))
                                .filter(el => el.offsetWidth > 0 && el.offsetHeight > 0);
                            const labels = rawLabels.filter(el => !rawLabels.some(o => o !== el && o.contains(el)));
                            if (labels.length > 0) {
                                let picked = false;
                                for (const kw of safeOrder) {
                                    for (const l of labels) {
                                        const txt = (l.innerText || '').trim().toLowerCase();
                                        if (txt === kw && !txt.includes('menyelesaikan')) {
                                            const target = l.closest('label') || l;
                                            target.click();
                                            picked = true;
                                            break;
                                        }
                                    }
                                    if (picked) break;
                                }
                                if (!picked) {
                                    for (const kw of safeOrder) {
                                        for (const l of labels) {
                                            const txt = (l.innerText || '').trim().toLowerCase();
                                            if (txt.includes(kw) && !txt.includes('menyelesaikan')) {
                                                const target = l.closest('label') || l;
                                                target.click();
                                                picked = true;
                                                break;
                                            }
                                        }
                                        if (picked) break;
                                    }
                                }
                                if (!picked) {
                                    const firstTarget = labels[0].closest('label') || labels[0];
                                    firstTarget.click();
                                }
                            }
                        }

                        // Check empty number/text inputs inside this question (excluding comboboxes)
                        const numInps = Array.from(q.querySelectorAll('input[type="number"], input.sd-input.sd-text'))
                            .filter(inp => inp.offsetWidth > 0 && inp.offsetHeight > 0 && !inp.disabled && inp.getAttribute('role') !== 'combobox');
                        for (const inp of numInps) {
                            if ((inp.value || '').trim() === '') {
                                const qText = (q.innerText || '').toLowerCase();
                                const fillVal = (qText.includes('hari') || qText.includes('minggu')) ? '6' : (qText.includes('menit') || qText.includes('jam') ? '30' : '6');
                                const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
                                if (setter) setter.call(inp, fillVal);
                                else inp.value = fillVal;
                                inp.dispatchEvent(new Event('input', { bubbles: true }));
                                inp.dispatchEvent(new Event('change', { bubbles: true }));
                                inp.dispatchEvent(new Event('blur', { bubbles: true }));
                            }
                        }
                    }
                }"""
            )
            await asyncio.sleep(0.2)
            await self._sweep_universal_safe_defaults(page)
            # Native Playwright fill for any visible number inputs that SurveyJS reactive state still sees as empty
            num_loc = page.locator('input[type="number"]:visible, input.sd-input.sd-text:visible')
            cnt_num = await num_loc.count()
            for idx_n in range(cnt_num):
                inp_n = num_loc.nth(idx_n)
                role_attr = await inp_n.get_attribute("role")
                if role_attr == "combobox":
                    continue
                cur_v = (await inp_n.input_value()) if await inp_n.is_visible() else ""
                if not cur_v.strip():
                    await self._safe_fill(inp_n, "6")
                    await page.keyboard.press("Tab")
                    await asyncio.sleep(0.1)
        except Exception:
            pass

    async def _submit_survey_form_and_wait_dashboard(
        self, page: Any, worker_id: int, form_label: str
    ) -> bool:
        """
        Clicks 'Kirim' on a SurveyJS form (Skrining Mandiri or Pelayanan Nakes)
        and waits until the examination dashboard ('Pemeriksaan Mandiri' / 'Pelayanan oleh Nakes') is visible again.
        If SurveyJS validation fails, auto-heals unanswered dropdown/radio inputs and retries Kirim,
        or escapes via 'Kembali ke Halaman Utama' (never generic 'Kembali') so the browser stays on /detail-pemeriksaan.
        """
        if await self._is_on_exam_dashboard(page):
            # Never entered the form (click on Input Data was swallowed during dashboard re-render)
            return False

        await asyncio.sleep(0.25)
        await self._commit_survey_inputs_and_click_kirim(page)

        await self.wait_loading_smart(page, timeout_ms=10000, initial_delay_ms=350)
        if await self._wait_for_exam_dashboard(page, timeout_ms=3200):
            await asyncio.sleep(0.35)
            return True

        # Auto-heal unanswered / newly-cascaded fields inside SurveyJS and retry Kirim
        try:
            await self._heal_unanswered_survey_questions(page)
            await asyncio.sleep(0.25)
            await self._commit_survey_inputs_and_click_kirim(page)
            await self.wait_loading_smart(page, timeout_ms=10000, initial_delay_ms=350)
            if await self._wait_for_exam_dashboard(page, timeout_ms=5500):
                await asyncio.sleep(0.35)
                return True
        except Exception:
            pass

        self.log(
            f"⚠️ Form '{form_label}' belum kembali ke dashboard, mengeksekusi Kembali ke Halaman Utama...",
            "warning",
            worker_id,
        )
        try:
            btn_back = page.locator(
                'button:has-text("Kembali ke Halaman Utama"), a:has-text("Kembali ke Halaman Utama")'
            ).first
            if await btn_back.is_visible():
                await self._safe_click(btn_back, timeout=4000)
                await self.wait_loading_smart(page, timeout_ms=10000, initial_delay_ms=400)
                await self._wait_for_exam_dashboard(page, timeout_ms=5000)
        except Exception:
            pass
        return False

    async def _sweep_universal_safe_defaults(self, page: Any) -> None:
        """
        Universal Multi-Control Safe Default Sweep:
        1. Native <select:visible>
        2. SurveyJS comboboxes (.sv-dropdown, .sd-dropdown, input[role="combobox"]) - deduplicated & skips already-answered
        3. SurveyJS radio/checkbox labels matching SAFE_DEFAULT_ANSWERS - deduplicated & skips already-answered radio groups
        """
        # 1. Native <select:visible>
        try:
            selects = await page.locator("select:visible").all()
            for sel in selects:
                for opt in SAFE_DEFAULT_ANSWERS:
                    try:
                        await sel.select_option(label=opt, timeout=300)
                        break
                    except Exception:
                        pass
        except Exception:
            pass

        # 2. SurveyJS dropdowns (.sv-dropdown, .sd-dropdown, input[role="combobox"])
        # Deduplicate outer container vs inner input[role="combobox"] and skip already-answered dropdowns
        try:
            for _dd_pass in range(2):
                unanswered_count = await page.evaluate(
                    """(safeOpts) => {
                        document.querySelectorAll('[data-ckg-dd]').forEach(el => el.removeAttribute('data-ckg-dd'));
                        const raw = Array.from(document.querySelectorAll('.sd-dropdown, .sv-dropdown, input[role="combobox"]'))
                            .filter(el => el.offsetWidth > 0 && el.offsetHeight > 0);
                        const unique = raw.filter(el => !raw.some(other => other !== el && other.contains(el)));
                        const safeLower = safeOpts.map(s => s.toLowerCase());
                        let idx = 0;
                        for (const dd of unique) {
                            const container = dd.closest('.sd-dropdown, .sv-dropdown') || dd;
                            const cleanBtn = container.querySelector('.sd-dropdown__clean-button, .sv-dropdown__clean-button');
                            const hasCleanBtn = cleanBtn && cleanBtn.offsetWidth > 0 && cleanBtn.offsetHeight > 0;
                            const valEl = container.querySelector('.sd-dropdown__value, .sv-dropdown__value');
                            const inpEl = container.matches('input') ? container : container.querySelector('input[role="combobox"], input');
                            const currentText = ((valEl ? valEl.innerText : container.innerText) || '').trim().toLowerCase();
                            const currentVal = ((inpEl && (inpEl.value || inpEl.placeholder)) ? (inpEl.value || inpEl.placeholder) : '').trim().toLowerCase();
                            const isPlaceholder = (!currentText || currentText.includes('pilih') || currentText.includes('select') || currentText === 'clear')
                                && (!currentVal || currentVal.includes('pilih') || currentVal.includes('select'));
                            const alreadySafe = hasCleanBtn
                                || (!isPlaceholder && safeLower.some(s => currentText === s || currentText.startsWith(s + '\\n') || currentVal === s));
                            if (!alreadySafe) {
                                dd.setAttribute('data-ckg-dd', String(idx));
                                idx++;
                            }
                        }
                        return idx;
                    }""",
                    SAFE_DEFAULT_ANSWERS,
                )
                if not unanswered_count:
                    break

                any_picked_in_pass = False
                for dd_idx in range(unanswered_count):
                    dd = page.locator(f'[data-ckg-dd="{dd_idx}"]').first
                    if not await dd.is_visible():
                        continue
                    await self._safe_click(dd, timeout=1500)
                    await asyncio.sleep(0.25)
                    picked = await page.evaluate(
                        """(safeOpts) => {
                            const items = Array.from(document.querySelectorAll('li, div[role="option"], .sv-list__item, .sd-list__item')).filter(
                                el => el.offsetWidth > 0 && el.offsetHeight > 0
                            );
                            for (const opt of safeOpts) {
                                const lowerOpt = opt.toLowerCase();
                                for (let i = items.length - 1; i >= 0; i--) {
                                    const text = (items[i].innerText || '').trim();
                                    if (text.toLowerCase() === lowerOpt && !text.toLowerCase().includes('menyelesaikan')) {
                                        items[i].click();
                                        return true;
                                    }
                                }
                            }
                            const fallbackKws = ['tidak benar', 'tidak pernah', 'tidak sama sekali', 'tidak ada', 'belum', 'tidak', 'normal', 'negatif', 'baik', 'mandiri', 'ya', 'sudah'];
                            for (const kw of fallbackKws) {
                                for (let i = items.length - 1; i >= 0; i--) {
                                    const text = (items[i].innerText || '').trim().toLowerCase();
                                    if (text && text.length < 100 && text.includes(kw) && !text.includes('menyelesaikan')) {
                                        items[i].click();
                                        return true;
                                    }
                                }
                            }
                            return false;
                        }""",
                        SAFE_DEFAULT_ANSWERS,
                    )
                    if picked:
                        any_picked_in_pass = True
                    else:
                        await page.keyboard.press("Escape")
                    await asyncio.sleep(0.15)

                if not any_picked_in_pass:
                    break
        except Exception:
            pass

        # 3. SurveyJS labels & string-viewers (check per radio group / matrix row, not just outer .sd-question)
        await page.evaluate(
            """(safeAnswers) => {
                const rawLabels = Array.from(document.querySelectorAll('label, span.sv-string-viewer')).filter(
                    el => el.offsetWidth > 0 && el.offsetHeight > 0
                );
                const labels = rawLabels.filter(el => !rawLabels.some(other => other !== el && other.contains(el)));
                for (const ans of safeAnswers) {
                    const lowerAns = ans.toLowerCase();
                    for (const l of labels) {
                        const rowScope = l.closest('tr, fieldset, [role="radiogroup"]') || l.closest('.sd-question, .sv-question');
                        const lblNode = l.closest('label') || l;
                        const inp = lblNode.querySelector ? lblNode.querySelector('input[type="radio"], input[type="checkbox"]') : null;
                        if (inp && inp.name && rowScope) {
                            const escapedName = typeof CSS !== 'undefined' && CSS.escape ? CSS.escape(inp.name) : inp.name;
                            if (rowScope.querySelector(`input[name="${escapedName}"]:checked`)) {
                                continue;
                            }
                        } else if (rowScope && rowScope.querySelector('input[type="radio"]:checked, input[type="checkbox"]:checked')) {
                            continue;
                        }
                        const txt = (l.innerText || '').trim().toLowerCase();
                        if (txt === lowerAns && !txt.includes('menyelesaikan')) {
                            const target = l.closest('label') || l;
                            target.click();
                        }
                    }
                }
            }""",
            SAFE_DEFAULT_ANSWERS,
        )

    # =========================================================================
    # PHASE 3: SKRINING MANDIRI (Atomic JS + 3-Pass Dynamic Cascading + Recovery)
    # =========================================================================

    async def _verify_mandiri_status_on_pelayanan_table(
        self, page: Any, worker_id: int, student: StudentRecord
    ) -> bool:
        """
        Post-verification on /ckg-pelayanan-sekolah after _step_skrining_mandiri:
        Checks the actual SATUSEHAT Pelayanan table ('Selesai Pemeriksaan' / 'Sedang Pemeriksaan')
        to verify that the student's 'Pemeriksaan Mandiri' badge truly changed from
        'Belum lengkap' (red) to 'Lengkap' (green) before marking SUKSES PARIPURNA.
        """
        try:
            student.last_step = "Memverifikasi Status Mandiri di Tabel SATUSEHAT"
            async with self._get_worker_filter_lock(worker_id):
                await page.goto(URL_PELAYANAN, wait_until="domcontentloaded", timeout=45000)
                await self.wait_loading_smart(page, timeout_ms=12000, initial_delay_ms=350)
                await self.radar_sapu_jagat(page, worker_id)

                try:
                    teks_modal = page.locator("text=Pengaturan Pelayanan").first
                    if await teks_modal.is_visible(timeout=800):
                        cb_lokasi = page.locator("input#sameLocation").first
                        if await cb_lokasi.count() > 0:
                            await cb_lokasi.click(force=True)
                        await asyncio.sleep(0.2)
                        btn_simpan = page.locator('button:has-text("Simpan")').first
                        if await btn_simpan.is_visible():
                            await btn_simpan.click(force=True, timeout=3000)
                        await self.wait_loading_smart(page, timeout_ms=8000, initial_delay_ms=250)
                except Exception:
                    pass

                await self._select_filter_sekolah_dan_kelas(page, worker_id, student)
                has_valid_ticket = bool(student.no_tiket and student.no_tiket != "-")
                kolom_cari = await self._search_by_nik_or_tiket_on_table(
                    page,
                    worker_id,
                    student,
                    force_use_ticket=has_valid_ticket,
                    click_tampilkan=True,
                )

                tabs_order = (
                    ["Selesai Pemeriksaan", "Sedang Pemeriksaan", "Belum Pemeriksaan"]
                    if getattr(student, "_already_selesai_pemeriksaan", False)
                    else ["Sedang Pemeriksaan", "Selesai Pemeriksaan", "Belum Pemeriksaan"]
                )
                for tab_lbl in tabs_order:
                    res_v = await self._switch_pelayanan_tab_and_check(
                        page, tab_lbl, kolom_cari, student
                    )
                    if res_v.get("state") in ("found", "found_no_btn"):
                        if res_v.get("mandiriBelumLengkap"):
                            self.log(
                                f"⚠️ Verifikasi Tabel SATUSEHAT: Badge Pemeriksaan Mandiri {student.nama} (Tiket: {student.no_tiket}) di '{tab_lbl}' masih 'Belum lengkap'!",
                                "warning",
                                worker_id,
                            )
                            return False
                        if res_v.get("mandiriLengkap"):
                            self.log(
                                f"✅ Verifikasi Tabel SATUSEHAT: Badge Pemeriksaan Mandiri {student.nama} (Tiket: {student.no_tiket}) di '{tab_lbl}' sudah 'Lengkap'!",
                                "success",
                                worker_id,
                            )
                            return True
                        return True
        except Exception as exc:
            self.log(f"ℹ️ Catatan verifikasi tabel Mandiri {student.nama}: {exc}", "info", worker_id)
        return True

    async def _ensure_mandiri_accordion_open(self, page: Any) -> None:
        """If the Pemeriksaan Mandiri accordion ('Jumlah Pemeriksaan (X/Y)') is collapsed, click it to expand."""
        try:
            all_btns = await page.evaluate(JS_TAG_MANDIRI_BUTTONS, True)
            if not all_btns:
                hdr = page.locator("text=/Jumlah\\s+Pemeriksaan/i").first
                if await hdr.is_visible():
                    await self._safe_click(hdr, timeout=2500)
                    await asyncio.sleep(0.35)
        except Exception:
            pass

    async def _wait_for_mandiri_section_loaded(
        self, page: Any, timeout_ms: int = 12000
    ) -> Optional[Dict[str, Any]]:
        """
        Polls up to timeout_ms until the 'Pemeriksaan Mandiri' section on /detail-pemeriksaan
        has finished fetching from the Kemenkes API:
        - 'Jumlah Pemeriksaan (X/Y)' inside 'Pemeriksaan Mandiri' is present with total > 0 (e.g. 10)
        - At least 1 'Input Data' button in the 'Pemeriksaan Mandiri' section is mounted in the DOM.
        Prevents false-positive completion when /detail-pemeriksaan renders 'Pelayanan oleh Nakes (10/10)'
        before the 'Pemeriksaan Mandiri' table rows return!
        """
        loops = max(1, int(timeout_ms / 300))
        last_prog: Optional[Dict[str, Any]] = None
        for poll in range(loops):
            try:
                if poll in (6, 14, 24):
                    await self._ensure_mandiri_accordion_open(page)
                prog = await page.evaluate(JS_GET_MANDIRI_PROGRESS)
                if prog and prog.get("total", 0) > 0:
                    last_prog = prog
                    all_cards = await page.evaluate(JS_TAG_MANDIRI_BUTTONS, True)
                    if all_cards and len(all_cards) > 0:
                        return prog
                    await self._ensure_mandiri_accordion_open(page)
                    all_cards = await page.evaluate(JS_TAG_MANDIRI_BUTTONS, True)
                    if all_cards and len(all_cards) > 0:
                        return prog
            except Exception:
                pass
            await asyncio.sleep(0.3)
        return last_prog

    async def _wait_for_survey_form_ready(
        self, page: Any, include_completed: bool, target_index: int
    ) -> bool:
        """
        Polls up to 6.0s after clicking 'Input Data' until BOTH the SurveyJS form container
        ('Kirim' or 'Kembali ke Halaman Utama') AND at least 1 visible SurveyJS question/input
        have mounted in the DOM. Re-clicks 'Input Data' at 1.75s if the initial click was swallowed
        during a dashboard table re-render.
        """
        for poll in range(24):
            state = await page.evaluate(
                """() => {
                    const backBtns = Array.from(document.querySelectorAll('button, a')).filter(
                        el => el.offsetWidth > 0 && el.offsetHeight > 0 && (el.innerText || '').includes('Kembali ke Halaman Utama')
                    );
                    const kirimBtns = Array.from(document.querySelectorAll(
                        'input.sd-navigation__complete-btn, input[value="Kirim"], button'
                    )).filter(el => {
                        if (el.offsetWidth <= 0 || el.offsetHeight <= 0) return false;
                        const t = ((el.value || el.innerText || '') + '').trim().toLowerCase();
                        return t === 'kirim' || el.classList.contains('sd-navigation__complete-btn');
                    });
                    const qEls = Array.from(document.querySelectorAll(
                        '.sd-question, .sv-question, .sd-dropdown, .sv-dropdown, input[role="combobox"], input.sd-input, input[type="number"], input[type="radio"], input[type="checkbox"], label'
                    )).filter(el => el.offsetWidth > 0 && el.offsetHeight > 0 && !el.closest('button'));
                    return {
                        inForm: backBtns.length > 0 || kirimBtns.length > 0,
                        hasKirim: kirimBtns.length > 0,
                        qCount: qEls.length,
                    };
                }"""
            )
            if state.get("inForm") and state.get("qCount", 0) > 0:
                return True

            if poll == 7 and not state.get("inForm"):
                # Initial click on Input Data was swallowed during dashboard re-render; re-click once
                try:
                    cards_retry = await page.evaluate(JS_TAG_MANDIRI_BUTTONS, include_completed)
                    if cards_retry:
                        idx_to_click = min(target_index, len(cards_retry) - 1)
                        btn_retry = page.locator('button[data-mandiri-target="true"]').nth(idx_to_click)
                        if await btn_retry.is_visible():
                            await self._safe_click(btn_retry, timeout=4000)
                            await self.wait_loading_smart(page, timeout_ms=8000, initial_delay_ms=300)
                except Exception:
                    pass

            await asyncio.sleep(0.25)
        return False

    async def _detect_jiwa_subform_signature(self, page: Any) -> str:
        """
        Distinguishes the two 'Kesehatan Jiwa' sub-forms on /detail-pemeriksaan
        by inspecting visible SurveyJS questions (including matrix table rows!)
        so table row re-ordering after submitting the 1st Kesehatan Jiwa never causes
        the 2nd Kesehatan Jiwa to be skipped ('Salah masuk kamar' protection).
        """
        try:
            sig = await page.evaluate(
                """() => {
                    const ignoreOpts = new Set([
                        'ya', 'tidak', 'tidak pernah', 'tidak benar', 'agak benar', 'selalu benar',
                        'tidak ada', 'tidak sama sekali', 'beberapa hari', 'lebih dari separuh waktu',
                        'hampir setiap hari', 'kirim', 'batal', 'simpan', 'kesehatan jiwa', 'sdq',
                        'kembali ke halaman utama', 'formulir kuesioner', 'pertanyaan'
                    ]);
                    const rawTexts = Array.from(document.querySelectorAll(
                        '.sd-question__title, .sv-question__title, tr.sd-table__row td:first-child, tbody tr td:first-child, .sd-title, span.sv-string-viewer, .sd-question, .sv-question, h3, h4, h5'
                    ))
                        .filter(el => el.offsetWidth > 0 && el.offsetHeight > 0 && !el.closest('button') && !el.closest('nav') && !el.closest('aside'))
                        .map(el => (el.innerText || '').split('\\n')[0].trim().toLowerCase().replace(/\\s+/g, ' '))
                        .filter(t => t.length > 10 && !ignoreOpts.has(t) && !t.includes('kesehatan jiwa') && !t.includes('kembali ke halaman'));
                    const unique = [];
                    for (const t of rawTexts) {
                        if (!unique.includes(t)) unique.push(t);
                        if (unique.length >= 3) break;
                    }
                    if (unique.length > 0) {
                        return 'jiwa_q_' + unique.join(' || ').slice(0, 110);
                    }
                    const body = ((document.body && document.body.innerText) ? document.body.innerText : '').toLowerCase();
                    if (body.includes('gejala cemas') || body.includes('kecemasan') || body.includes('merasa gugup') || body.includes('cemas atau gelisah')) {
                        return 'jiwa_cemas';
                    }
                    if (body.includes('gejala depresi') || body.includes('depresi') || body.includes('kurang berminat') || body.includes('merasa murung')) {
                        return 'jiwa_depresi';
                    }
                    return 'jiwa_unknown';
                }"""
            )
            return str(sig or "jiwa_unknown")
        except Exception:
            return "jiwa_unknown"

    async def _step_skrining_mandiri(
        self, page: Any, worker_id: int, student: StudentRecord
    ) -> None:
        """
        Exact V2.6 Skrining Mandiri Loop enhanced with:
        - Green vs Gray Checkmark icon detection (skips already-completed green rows)
        - 'Jumlah Pemeriksaan (X/Y)' progress verification (ensures 10/10 completion)
        - Two-room 'Kesehatan Jiwa' ([1, 1, 0] combinatorial sequence + question signature tracker)
        - Multi-pass cascading question wait + Universal Unanswered Question Healer
        """
        student.last_step = "Mengisi Skrining Mandiri"
        processed_forms: set[str] = set()
        processed_jiwa_subtypes: set[str] = set()
        # The 3-step sequence [1, 0, 1] is mathematically guaranteed to open BOTH 'Kesehatan Jiwa'
        # sub-forms whether the Kemenkes backend keeps order static ([1, 0] finishes in 2 steps),
        # sorts newest-first (moves 1->0), sorts newest-last (moves 0->1), or swaps rows.
        jiwa_index_sequence: list[int] = [1, 0, 1]
        jiwa_seq_pos: int = 0
        jiwa_attempts: int = 0
        attempt_counts: dict[str, int] = {}

        # Ensure the examination dashboard is rendered and the Mandiri API has finished loading
        for _w in range(18):
            if await self._is_on_exam_dashboard(page) or await page.locator('button:has-text("Input Data")').first.is_visible():
                break
            await asyncio.sleep(0.35)

        include_completed = bool(
            self.config.update_data_lama or getattr(student, "_force_deep_mandiri_resync", False)
        )
        table_said_belum_lengkap = getattr(student, "_mandiri_already_lengkap", None) is False
        init_prog = await self._wait_for_mandiri_section_loaded(page, timeout_ms=12000)
        if not init_prog or init_prog.get("total", 0) <= 0:
            # Page shell rendered without Mandiri API payload; reload /detail-pemeriksaan once
            try:
                await page.reload(wait_until="domcontentloaded", timeout=30000)
                await self.wait_loading_smart(page, timeout_ms=10000, initial_delay_ms=400)
                init_prog = await self._wait_for_mandiri_section_loaded(page, timeout_ms=12000)
            except Exception:
                pass

        if init_prog:
            incomplete_init_cards = await page.evaluate(JS_TAG_MANDIRI_BUTTONS, False)
            if not include_completed and init_prog.get("isComplete") and not incomplete_init_cards:
                if table_said_belum_lengkap:
                    include_completed = True
                    self.log(
                        f"🔄 Tabel Kemenkes {student.nama} masih 'Belum lengkap' (tertulis {init_prog.get('text')}), menyinkronkan ulang form Skrining Mandiri...",
                        "info",
                        worker_id,
                    )
                else:
                    self.log(
                        f"✅ Pemeriksaan Mandiri {student.nama} sudah lengkap ({init_prog.get('text')})!",
                        "success",
                        worker_id,
                    )
                    student._mandiri_done_in_run = True  # type: ignore[attr-defined]
                    return
            else:
                gray_note = (
                    f" ({len(incomplete_init_cards)} form belum lengkap terdeteksi)"
                    if incomplete_init_cards
                    else ""
                )
                self.log(
                    f"📊 Status Pemeriksaan Mandiri {student.nama}: {init_prog.get('text')} selesai{gray_note}.",
                    "info",
                    worker_id,
                )

        reset_attempted = False
        for _round in range(32):
            await self.check_pause_and_stop(page, worker_id)
            await self.sadar_diri_dan_kembali(page, worker_id, student)

            prog_now = await self._wait_for_mandiri_section_loaded(page, timeout_ms=8000)
            if not include_completed and prog_now and prog_now.get("isComplete"):
                incomplete_now = await page.evaluate(JS_TAG_MANDIRI_BUTTONS, False)
                if not incomplete_now and (not table_said_belum_lengkap or len(processed_forms) > 0):
                    self.log(
                        f"🎉 Semua form Skrining Mandiri selesai diisi ({prog_now.get('text')} Lengkap) untuk {student.nama}!",
                        "success",
                        worker_id,
                    )
                    break

            cards = await page.evaluate(JS_TAG_MANDIRI_BUTTONS, include_completed)
            if not cards:
                await asyncio.sleep(0.8)
                await self.sadar_diri_dan_kembali(page, worker_id, student)
                prog_now = await self._wait_for_mandiri_section_loaded(page, timeout_ms=8000)
                if not include_completed and prog_now and prog_now.get("isComplete"):
                    incomplete_now = await page.evaluate(JS_TAG_MANDIRI_BUTTONS, False)
                    if not incomplete_now and (not table_said_belum_lengkap or len(processed_forms) > 0):
                        self.log(
                            f"🎉 Semua form Skrining Mandiri selesai diisi ({prog_now.get('text')} Lengkap) untuk {student.nama}!",
                            "success",
                            worker_id,
                        )
                        break
                    if not incomplete_now and table_said_belum_lengkap and len(processed_forms) == 0:
                        include_completed = True
                cards = await page.evaluate(JS_TAG_MANDIRI_BUTTONS, include_completed)
                if not cards and prog_now and not prog_now.get("isComplete"):
                    cards = await page.evaluate(JS_TAG_MANDIRI_BUTTONS, True)
                if not cards:
                    break

            target_card = None
            jiwa_candidates = [c for c in cards if c.get("is_jiwa")]
            total_jiwa = max((int(c.get("total_jiwa_cards", 2)) for c in cards), default=2)
            need_more_jiwa = (
                len(processed_jiwa_subtypes) < len(jiwa_candidates)
                and jiwa_seq_pos < len(jiwa_index_sequence)
                and jiwa_attempts < 6
            )

            # Prioritize 'Kesehatan Jiwa' cards FIRST using the [1, 1, 0] sequence
            if jiwa_candidates and need_more_jiwa:
                if len(jiwa_candidates) >= 2:
                    desired_j_idx = jiwa_index_sequence[min(jiwa_seq_pos, len(jiwa_index_sequence) - 1)]
                    target_card = next(
                        (jc for jc in jiwa_candidates if jc.get("jiwa_index") == desired_j_idx),
                        jiwa_candidates[-1],
                    )
                else:
                    target_card = jiwa_candidates[0]

            if not target_card:
                for c in cards:
                    if c.get("is_jiwa"):
                        if len(processed_jiwa_subtypes) < total_jiwa and jiwa_seq_pos < len(jiwa_index_sequence) and jiwa_attempts < 6 and len(jiwa_candidates) >= 2:
                            desired_j_idx = jiwa_index_sequence[min(jiwa_seq_pos, len(jiwa_index_sequence) - 1)]
                            target_card = next(
                                (jc for jc in jiwa_candidates if jc.get("jiwa_index") == desired_j_idx),
                                jiwa_candidates[-1],
                            )
                            break
                        continue
                    form_id = c.get("form_id") or c.get("title") or c["text"][:80]
                    if form_id not in processed_forms and attempt_counts.get(form_id, 0) < 3:
                        target_card = c
                        break

            if not target_card:
                prog_check = await self._wait_for_mandiri_section_loaded(page, timeout_ms=6000)
                if prog_check and not prog_check.get("isComplete") and not reset_attempted:
                    reset_attempted = True
                    processed_forms.clear()
                    processed_jiwa_subtypes.clear()
                    jiwa_seq_pos = 0
                    jiwa_attempts = 0
                    continue
                break

            card_text = target_card["text"]
            is_jiwa_card = bool(target_card.get("is_jiwa"))
            form_id = target_card.get("form_id") or target_card.get("title") or card_text[:80]
            display_title = target_card.get("title") or form_id
            if is_jiwa_card:
                jiwa_attempts += 1
                j_row_num = int(target_card.get("jiwa_index", 0)) + 1
                display_title = f"{display_title} (Bagian #{j_row_num})"
            else:
                attempt_counts[form_id] = attempt_counts.get(form_id, 0) + 1
            student.last_step = f"Skrining Mandiri: {display_title[:38]}"
            self.log(f"📝 Mengisi Skrining Mandiri: {display_title[:50]}", "info", worker_id)

            btn_target = page.locator('button[data-mandiri-target="true"]').nth(target_card["index"])
            if not await btn_target.is_visible():
                continue

            await self._safe_click(btn_target, timeout=6000)
            await self.wait_loading_smart(page, timeout_ms=10000, initial_delay_ms=350)

            form_ready = await self._wait_for_survey_form_ready(
                page, include_completed, target_card["index"]
            )
            if not form_ready and await self._is_on_exam_dashboard(page):
                continue

            await asyncio.sleep(0.3)

            jiwa_sig = ""
            if is_jiwa_card or "kesehatan jiwa" in card_text or "sdq" in card_text:
                jiwa_sig = await self._detect_jiwa_subform_signature(page)
                if jiwa_sig != "jiwa_unknown":
                    self.log(
                        f"🔍 Sub-form Kesehatan Jiwa ({display_title}): {jiwa_sig[:72]}",
                        "info",
                        worker_id,
                    )
                if jiwa_sig != "jiwa_unknown" and jiwa_sig in processed_jiwa_subtypes and jiwa_attempts < 6:
                    # This row opened the already-submitted Kesehatan Jiwa sub-form; advance sequence & exit without re-sorting
                    jiwa_seq_pos += 1
                    next_j_idx = jiwa_index_sequence[min(jiwa_seq_pos, len(jiwa_index_sequence) - 1)]
                    self.log(
                        f"🔄 Sub-form Kesehatan Jiwa ini sudah diisi, beralih ke baris Kesehatan Jiwa #{next_j_idx + 1}...",
                        "info",
                        worker_id,
                    )
                    await self.sadar_diri_dan_kembali(page, worker_id, student)
                    continue

            # 3-Pass Dynamic Cascading Loop (runs across passes so cascading questions are always filled)
            for _coba_dinamis in range(3):
                jml_awal = await page.locator(
                    "label:visible, .sv-dropdown:visible, .sd-dropdown:visible, select:visible, input[type='number']:visible, input.sd-input:visible"
                ).count()

                if "reproduksi" in card_text:
                    if "putri" in card_text or student.jk_pasien == "Perempuan":
                        mode_mens = "ya_atau_sudah" if student.umur >= 12 else "tidak_atau_belum"
                        mode_kep = (
                            "ya_atau_sudah"
                            if student.keputihan_putri in ("ya", "iya", "ada", "sudah")
                            else "tidak_atau_belum"
                        )
                        await page.evaluate(
                            JS_FILL_REPRODUKSI_PUTRI,
                            {"modeMenstruasi": mode_mens, "modeKeputihan": mode_kep},
                        )
                        await asyncio.sleep(0.45)
                        await page.evaluate(
                            JS_FILL_REPRODUKSI_PUTRI,
                            {"modeMenstruasi": mode_mens, "modeKeputihan": mode_kep},
                        )
                    else:
                        mode_pub = "ya_atau_sudah" if student.umur >= 12 else "tidak_atau_belum"
                        await page.evaluate(JS_FILL_REPRODUKSI_PUTRA, {"modePubertas": mode_pub})
                        await asyncio.sleep(0.45)
                        await page.evaluate(JS_FILL_REPRODUKSI_PUTRA, {"modePubertas": mode_pub})
                    await self._sweep_universal_safe_defaults(page)

                elif "faktor risiko tb" in card_text or "faktor resiko tb" in card_text:
                    tgt_batuk = "Tidak"
                    if "lebih" in student.batuk_tb or "> 2" in student.batuk_tb or ">2" in student.batuk_tb:
                        tgt_batuk = "lebih dari 2 minggu"
                    elif "kurang" in student.batuk_tb or "< 2" in student.batuk_tb or "<2" in student.batuk_tb:
                        tgt_batuk = "kurang dari 2 minggu"
                    await page.evaluate(JS_FILL_FAKTOR_TB, tgt_batuk)
                    await self._sweep_universal_safe_defaults(page)

                elif "imunisasi" in card_text:
                    for _pass_imun in range(3):
                        clicked_imun = await page.evaluate(JS_FILL_IMUNISASI)
                        await asyncio.sleep(0.5)
                        if not clicked_imun:
                            break
                    await self._sweep_universal_safe_defaults(page)

                elif "perilaku merokok" in card_text:
                    if student.perilaku_merokok in ("ya", "iya", "merokok"):
                        lbl_ya = page.locator(
                            'label:has-text("Ya"), span.sv-string-viewer:text-is("Ya")'
                        ).first
                        if await lbl_ya.is_visible():
                            await self._safe_click(lbl_ya, timeout=2000)
                        await asyncio.sleep(0.4)
                        lbl_konv = page.locator('label:has-text("Rokok konvensional")').first
                        if await lbl_konv.is_visible():
                            await self._safe_click(lbl_konv, timeout=2000)
                        await asyncio.sleep(0.4)
                        num_inputs = page.locator('input[type="number"]:visible')
                        cnt = await num_inputs.count()
                        for i in range(cnt):
                            await num_inputs.nth(i).fill("1")
                        await page.evaluate(
                            """() => {
                                for (const q of document.querySelectorAll('.sd-question, .sv-question')) {
                                    const t = (q.innerText || '').toLowerCase();
                                    if (t.includes('paparan') || t.includes('rumah') || t.includes('berhenti')) {
                                        for (const l of q.querySelectorAll('label')) {
                                            if ((l.innerText || '').trim() === 'Tidak' && l.offsetWidth > 0) {
                                                l.click();
                                                break;
                                            }
                                        }
                                    }
                                }
                            }"""
                        )
                    else:
                        await page.evaluate(
                            """() => {
                                const raw = Array.from(document.querySelectorAll('label, span.sv-string-viewer')).filter(
                                    e => e.offsetWidth > 0 && e.offsetHeight > 0
                                );
                                const lbls = raw.filter(e => !raw.some(o => o !== e && o.contains(e)));
                                lbls.forEach(e => {
                                    if ((e.innerText || '').trim() === 'Tidak') {
                                        const target = e.closest('label') || e;
                                        target.click();
                                    }
                                });
                            }"""
                        )
                    await self._sweep_universal_safe_defaults(page)

                elif "aktivitas fisik" in card_text:
                    cb_awal = page.locator('input[role="combobox"]:visible')
                    num_inps = page.locator(
                        'input[type="number"]:visible, input.sd-input.sd-text:visible'
                    )
                    if await cb_awal.count() == 0 and await num_inps.count() > 0:
                        if _coba_dinamis == 0:
                            inp0 = num_inps.nth(0)
                            if await inp0.is_visible():
                                await self._safe_fill(inp0, "")
                                await asyncio.sleep(0.08)
                                try:
                                    await inp0.press_sequentially("6", delay=60, timeout=2000)
                                except Exception:
                                    await self._safe_fill(inp0, "6")
                                await page.keyboard.press("Tab")
                                await asyncio.sleep(0.2)
                            if await num_inps.count() >= 2:
                                inp1 = num_inps.nth(1)
                                if await inp1.is_visible():
                                    await self._safe_fill(inp1, "")
                                    await asyncio.sleep(0.08)
                                    try:
                                        await inp1.press_sequentially("6", delay=60, timeout=2000)
                                    except Exception:
                                        await self._safe_fill(inp1, "6")
                                    await page.keyboard.press("Tab")
                                    await asyncio.sleep(0.2)
                    else:
                        ans = (
                            "Ya"
                            if student.aktivitas_fisik in ("ya", "iya", "aktif", "rutin")
                            else "Tidak"
                        )
                        if ans == "Ya" and await cb_awal.count() > 0:
                            await self._safe_click(cb_awal.nth(0), timeout=2000)
                            await asyncio.sleep(0.35)
                            await page.evaluate(JS_KLIK_OPSI, "Ya")
                            await asyncio.sleep(0.45)
                            inps_muncul = page.locator(
                                'input[type="number"]:visible, input.sd-input.sd-text:visible'
                            )
                            if await inps_muncul.count() >= 2:
                                await self._safe_fill(inps_muncul.nth(0), "7")
                                await page.keyboard.press("Tab")
                                await asyncio.sleep(0.2)
                                await self._safe_fill(inps_muncul.nth(1), "120")
                                await page.keyboard.press("Tab")
                                await asyncio.sleep(0.25)
                            cb_baru = page.locator('input[role="combobox"]:visible')
                            for idx_cb in range(1, await cb_baru.count()):
                                await self._safe_click(cb_baru.nth(idx_cb), timeout=2000)
                                await asyncio.sleep(0.3)
                                await page.evaluate(JS_KLIK_OPSI, "Tidak")
                                await asyncio.sleep(0.25)
                        else:
                            for idx_cb in range(await cb_awal.count()):
                                await self._safe_click(cb_awal.nth(idx_cb), timeout=2000)
                                await asyncio.sleep(0.3)
                                await page.evaluate(JS_KLIK_OPSI, "Tidak")
                                await asyncio.sleep(0.25)
                    await self._sweep_universal_safe_defaults(page)

                elif (
                    "diabetes melitus" in card_text
                    or "riwayat dm" in card_text
                    or "gula darah" in card_text
                ):
                    if student.riwayat_dm in ("ya", "iya", "ada"):
                        await page.evaluate(JS_KLIK_OPSI, "Ya")
                        await asyncio.sleep(0.4)
                        inp_dm = page.locator(
                            "input[type='number']:visible, input.sd-input:visible"
                        ).first
                        if await inp_dm.is_visible() and student.lama_dm:
                            await inp_dm.fill(student.lama_dm)
                    else:
                        await page.evaluate(
                            """() => {
                                const raw = Array.from(document.querySelectorAll('label, span.sv-string-viewer')).filter(
                                    e => e.offsetWidth > 0 && e.offsetHeight > 0
                                );
                                const lbls = raw.filter(e => !raw.some(o => o !== e && o.contains(e)));
                                lbls.forEach(e => {
                                    if ((e.innerText || '').trim() === 'Tidak') {
                                        const target = e.closest('label') || e;
                                        target.click();
                                    }
                                });
                            }"""
                        )
                    await self._sweep_universal_safe_defaults(page)

                elif "kesehatan jiwa" in card_text or "sdq" in card_text:
                    await page.evaluate(
                        """() => {
                            const raw = Array.from(document.querySelectorAll('label, span.sv-string-viewer')).filter(
                                e => e.offsetWidth > 0 && e.offsetHeight > 0
                            );
                            const lbls = raw.filter(e => !raw.some(o => o !== e && o.contains(e)));
                            lbls.forEach(e => {
                                const t = (e.innerText || '').trim().toLowerCase();
                                if (t === 'tidak' || t === 'tidak pernah' || t === 'tidak benar' || t === 'tidak ada' || t === 'tidak sama sekali') {
                                    const target = e.closest('label') || e;
                                    target.click();
                                }
                            });
                        }"""
                    )
                    await self._sweep_universal_safe_defaults(page)

                else:
                    await self._sweep_universal_safe_defaults(page)

                await asyncio.sleep(0.3)
                jml_akhir = await page.locator(
                    "label:visible, .sv-dropdown:visible, .sd-dropdown:visible, select:visible, input[type='number']:visible, input.sd-input:visible"
                ).count()
                if _coba_dinamis >= 1 and jml_akhir > 0 and jml_awal == jml_akhir:
                    break

            await self._heal_unanswered_survey_questions(page)
            submitted = await self._submit_survey_form_and_wait_dashboard(page, worker_id, display_title)
            if submitted:
                processed_forms.add(form_id)
                if is_jiwa_card:
                    if jiwa_sig and jiwa_sig != "jiwa_unknown":
                        processed_jiwa_subtypes.add(jiwa_sig)
                    jiwa_seq_pos += 1
            else:
                await self.sadar_diri_dan_kembali(page, worker_id, student)

        # Final verification of 'Jumlah Pemeriksaan (X/Y)' before marking Mandiri as done
        final_prog = await self._wait_for_mandiri_section_loaded(page, timeout_ms=10000)
        if not final_prog or final_prog.get("total", 0) <= 0 or not final_prog.get("isComplete"):
            prog_txt = final_prog.get("text") if final_prog else "belum termuat (0/10)"
            raise BomAutoRetryUniversal(
                f"Pemeriksaan Mandiri baru terisi {prog_txt}, mengulang pengisian form yang belum lengkap"
            )

        student._mandiri_done_in_run = True  # type: ignore[attr-defined]

    # =========================================================================
    # PHASE 4: PELAYANAN OLEH NAKES & SNIPER MODE
    # =========================================================================

    async def _step_pelayanan_nakes(
        self, page: Any, worker_id: int, student: StudentRecord
    ) -> None:
        """
        Exact V2.6 Pelayanan oleh Nakes execution (source_lines.txt lines 1210-1643).
        """
        await self.check_pause_and_stop(page, worker_id)
        await self.sadar_diri_dan_kembali(page, worker_id, student)

        try:
            btn_mulai_nakes = page.locator(
                'button:has-text("Mulai Pemeriksaan"), a:has-text("Mulai Pemeriksaan"), button:has-text("Mulai Pelayanan")'
            ).first
            if await btn_mulai_nakes.is_visible(timeout=2000):
                await self._safe_click(btn_mulai_nakes, timeout=5000)
                await asyncio.sleep(0.45)
                btn_simpan_awal = page.get_by_role("button", name="Simpan").last
                if await btn_simpan_awal.is_visible(timeout=2500):
                    await self._safe_click(btn_simpan_awal, timeout=4000)
                await self.wait_loading_smart(page, timeout_ms=10000, initial_delay_ms=400)
        except Exception:
            pass

        include_completed = bool(self.config.update_data_lama)

        # 1. Gizi (BB & TB) - up to 2 attempts if card still has uncompleted Input Data
        if student.berat and student.tinggi and self.config.mode == "C":
            for _try_gizi in range(2):
                student.last_step = "Menginput Data Gizi (BB/TB)"
                await self.sadar_diri_dan_kembali(page, worker_id, student)
                opened_gizi = await self._fill_nakes_gizi(page, worker_id, student)
                if not opened_gizi:
                    break
                rem_nakes = await page.evaluate(JS_TAG_NAKES_BUTTONS, include_completed)
                if not any("gizi" in c["text"] for c in rem_nakes):
                    break

        # 2. Pemeriksaan Gula Darah (Riwayat DM + GDS)
        if student.gds and self.config.mode == "C":
            student.last_step = "Menginput Data Gula Darah (GDS)"
            await self.sadar_diri_dan_kembali(page, worker_id, student)
            await self._fill_nakes_gds(page, worker_id, student)

        # 3. Tekanan Darah (Sistolik & Diastolik) (up to 2 attempts if card still has uncompleted Input Data)
        if student.sistolik and student.diastolik and self.config.mode == "C":
            for _try_tensi in range(2):
                student.last_step = "Menginput Tekanan Darah (Tensi)"
                await self.sadar_diri_dan_kembali(page, worker_id, student)
                opened_tensi = await self._fill_nakes_tensi(page, worker_id, student)
                if not opened_tensi:
                    break
                rem_nakes = await page.evaluate(JS_TAG_NAKES_BUTTONS, include_completed)
                if not any("tekanan darah" in c["text"] for c in rem_nakes):
                    break

        # 4. Sniper Nakes Forms (Telinga/Mata, Gigi, TB, Kulit, PPOK, Kebugaran, Lab)
        await self._run_sniper_nakes_forms(page, worker_id, student)
        await self.capture_worker_peek(page, worker_id)

    async def _open_nakes_card_by_keyword(self, page: Any, keyword: str) -> bool:
        """
        Finds and clicks the 'Input Data' button for a specific Nakes card using
        JS_TAG_NAKES_BUTTONS (which skips cards already marked 'Selesai Pemeriksaan'
        unless update_data_lama is enabled). Re-clicks once if swallowed by React re-render.
        """
        include_completed = bool(self.config.update_data_lama)
        cards = await page.evaluate(JS_TAG_NAKES_BUTTONS, include_completed)
        lower_kw = keyword.lower()
        for c in cards:
            if lower_kw in c["text"] or lower_kw in c.get("title", ""):
                btn = page.locator('button[data-nakes-target="true"]').nth(c["index"])
                if await btn.is_visible():
                    await self._safe_click(btn, timeout=5000)
                    await self.wait_loading_smart(page, timeout_ms=10000, initial_delay_ms=400)
                    kirim_loc = page.locator(
                        'input.sd-navigation__complete-btn, input[value="Kirim"], button:text-is("Kirim")'
                    ).last
                    try:
                        await kirim_loc.wait_for(state="visible", timeout=3000)
                    except Exception:
                        if await page.locator('text="Pelayanan oleh Nakes"').first.is_visible():
                            cards_retry = await page.evaluate(JS_TAG_NAKES_BUTTONS, include_completed)
                            for cr in cards_retry:
                                if lower_kw in cr["text"] or lower_kw in cr.get("title", ""):
                                    btn_retry = page.locator('button[data-nakes-target="true"]').nth(
                                        cr["index"]
                                    )
                                    if await btn_retry.is_visible():
                                        await self._safe_click(btn_retry, timeout=4000)
                                        await self.wait_loading_smart(
                                            page, timeout_ms=8000, initial_delay_ms=350
                                        )
                                    break
                    return True
        return False

    async def _fill_nakes_gizi(
        self, page: Any, worker_id: int, student: StudentRecord
    ) -> bool:
        if not await self._open_nakes_card_by_keyword(page, "Gizi"):
            return False
        self.log(
            f"⚖️ Mengisi Gizi ({student.berat} kg / {student.tinggi} cm)...",
            "info",
            worker_id,
        )
        try:
            inps = page.locator("input[type='number']:visible, input.sd-input.sd-text:visible")
            await inps.first.wait_for(state="visible", timeout=8000)
            await asyncio.sleep(0.35)
            await inps.nth(0).click(force=True)
            await inps.nth(0).fill(str(student.berat))
            await page.keyboard.press("Tab")
            await asyncio.sleep(0.25)
            if await inps.count() > 1:
                await inps.nth(1).click(force=True)
                await inps.nth(1).fill(str(student.tinggi))
                await page.keyboard.press("Tab")
                await asyncio.sleep(0.25)
            await self._submit_survey_form_and_wait_dashboard(page, worker_id, "Gizi")
            return True
        except Exception as exc:
            self.log(f"⚠️ Gagal mengisi form Gizi: {exc}", "warning", worker_id)
            return True

    async def _fill_nakes_gds(
        self, page: Any, worker_id: int, student: StudentRecord
    ) -> bool:
        if not await self._open_nakes_card_by_keyword(page, "Pemeriksaan Gula Darah"):
            return False
        self.log(f"🩸 Mengisi Gula Darah (GDS: {student.gds})...", "info", worker_id)
        try:
            await asyncio.sleep(0.5)
            # Answer Riwayat DM radio first if present on the Gula Darah form (V2.6 lines 1265-1282)
            opsi_dm = page.locator(
                'label:has-text("Tidak"), span.sv-string-viewer:text-is("Tidak")'
            ).first
            if await opsi_dm.is_visible(timeout=1500):
                await self._safe_click(opsi_dm, timeout=2000)
                await asyncio.sleep(0.4)

            inps = page.locator("input[type='number']:visible, input.sd-input.sd-text:visible")
            await inps.last.wait_for(state="visible", timeout=8000)
            await inps.last.click(force=True)
            await inps.last.fill(str(student.gds))
            await page.keyboard.press("Tab")
            await asyncio.sleep(0.3)
            await self._submit_survey_form_and_wait_dashboard(
                page, worker_id, "Pemeriksaan Gula Darah"
            )
            return True
        except Exception as exc:
            self.log(f"⚠️ Gagal mengisi form Gula Darah: {exc}", "warning", worker_id)
            return True

    async def _fill_nakes_tensi(
        self, page: Any, worker_id: int, student: StudentRecord
    ) -> bool:
        if not await self._open_nakes_card_by_keyword(page, "Tekanan Darah"):
            return False
        self.log(
            f"💓 Mengisi Tekanan Darah ({student.sistolik}/{student.diastolik})...",
            "info",
            worker_id,
        )
        try:
            inps = page.locator(
                "input[type='number']:visible, input.sd-input.sd-text:visible, input.form-input:visible"
            )
            await inps.first.wait_for(state="visible", timeout=8000)
            await asyncio.sleep(0.4)

            inp_sis = page.locator(
                'input[placeholder*="Sistolik" i]:visible, input[aria-label*="Sistolik" i]:visible'
            ).first
            inp_dias = page.locator(
                'input[placeholder*="Diastolik" i]:visible, input[aria-label*="Diastolik" i]:visible'
            ).first

            if await inp_sis.is_visible() and await inp_dias.is_visible():
                await inp_sis.click(force=True)
                await inp_sis.fill(str(student.sistolik))
                await page.keyboard.press("Tab")
                await asyncio.sleep(0.25)
                await inp_dias.click(force=True)
                await inp_dias.fill(str(student.diastolik))
                await page.keyboard.press("Tab")
            else:
                cnt = await inps.count()
                if cnt >= 2:
                    await inps.nth(cnt - 2).click(force=True)
                    await inps.nth(cnt - 2).fill(str(student.sistolik))
                    await page.keyboard.press("Tab")
                    await asyncio.sleep(0.25)
                    await inps.nth(cnt - 1).click(force=True)
                    await inps.nth(cnt - 1).fill(str(student.diastolik))
                    await page.keyboard.press("Tab")

            await asyncio.sleep(0.3)
            await self._submit_survey_form_and_wait_dashboard(page, worker_id, "Tekanan Darah")
            return True
        except Exception as exc:
            self.log(f"⚠️ Gagal mengisi form Tekanan Darah: {exc}", "warning", worker_id)
            return True

    async def _run_sniper_nakes_forms(
        self, page: Any, worker_id: int, student: StudentRecord
    ) -> None:
        """
        Exact V2.6 Sniper Nakes loop (source_lines.txt lines 1344-1643).
        Iterates over all remaining 'Input Data' cards in Pelayanan oleh Nakes and fills
        those matching the user's selected Sniper targets.
        """
        processed_nakes: set[str] = set()
        attempt_nakes: dict[str, int] = {}

        include_completed = bool(self.config.update_data_lama)
        for _round in range(20):
            await self.check_pause_and_stop(page, worker_id)
            await self.sadar_diri_dan_kembali(page, worker_id, student)

            cards = await page.evaluate(JS_TAG_NAKES_BUTTONS, include_completed)
            if not cards:
                for _wait_nakes in range(6):
                    await asyncio.sleep(0.5)
                    cards = await page.evaluate(JS_TAG_NAKES_BUTTONS, include_completed)
                    if cards:
                        break
                    btn_selesai_probe = page.locator('button:has-text("Selesaikan Layanan")').first
                    if await btn_selesai_probe.is_visible() and not await btn_selesai_probe.is_disabled():
                        break
                if not cards:
                    break

            target_card = None
            target_kind = ""

            for c in cards:
                form_id = c.get("title") or c["text"][:80]
                if form_id in processed_nakes or attempt_nakes.get(form_id, 0) >= 3:
                    continue

                t_low = c["text"]
                kind = ""
                if self.config.is_telinga_mata and ("telinga" in t_low or "mata" in t_low):
                    kind = "telinga_mata"
                elif self.config.is_gigi and "pemeriksaan gigi" in t_low:
                    kind = "gigi"
                elif self.config.is_tb and "tuberkulosis" in t_low:
                    kind = "tb"
                elif self.config.is_kulit and any(
                    kw in t_low
                    for kw in ("kulit", "kusta", "frambusia", "skabies", "scabies", "tropis")
                ):
                    kind = "kulit"
                elif self.config.is_ppok and ("ppok" in t_low or "puma" in t_low):
                    kind = "ppok"
                elif self.config.is_kebugaran and "kebugaran" in t_low:
                    kind = "kebugaran"
                elif self.config.is_co and student.kadar_co_mentah and (
                    "kadar co" in t_low or "karbon monoksida" in t_low
                ):
                    kind = "co"
                elif self.config.is_malaria and student.malaria_mentah and "malaria" in t_low:
                    kind = "malaria"
                elif (
                    self.config.is_hepatitis
                    and (student.hepb_mentah or student.hepc_mentah)
                    and "hepatitis" in t_low
                ):
                    kind = "hepatitis"
                elif (
                    self.config.is_anemia
                    and student.hb_anemia_mentah
                    and ("anemia" in t_low or "hemoglobin" in t_low or "hb" in t_low)
                ):
                    kind = "anemia"

                if kind:
                    target_card = c
                    target_kind = kind
                    break

            if not target_card:
                break

            form_id = target_card.get("title") or target_card["text"][:80]
            attempt_nakes[form_id] = attempt_nakes.get(form_id, 0) + 1
            student.last_step = f"Pelayanan Nakes: {form_id[:36]}"
            self.log(f"🩺 Mengisi Pelayanan Nakes: {form_id[:45]}", "info", worker_id)

            btn_target = page.locator('button[data-nakes-target="true"]').nth(target_card["index"])
            if not await btn_target.is_visible():
                continue

            await self._safe_click(btn_target, timeout=6000)
            await self.wait_loading_smart(page, timeout_ms=10000, initial_delay_ms=400)

            kirim_loc = page.locator(
                'input.sd-navigation__complete-btn, input[value="Kirim"], button:text-is("Kirim")'
            ).last
            try:
                await kirim_loc.wait_for(state="visible", timeout=4000)
            except Exception:
                if await page.locator('text="Pelayanan oleh Nakes"').first.is_visible():
                    cards_retry = await page.evaluate(JS_TAG_NAKES_BUTTONS, include_completed)
                    if cards_retry and target_card["index"] < len(cards_retry):
                        btn_retry = page.locator('button[data-nakes-target="true"]').nth(
                            target_card["index"]
                        )
                        if await btn_retry.is_visible():
                            await self._safe_click(btn_retry, timeout=4000)
                            await self.wait_loading_smart(
                                page, timeout_ms=8000, initial_delay_ms=350
                            )
                try:
                    await kirim_loc.wait_for(state="visible", timeout=4000)
                except Exception:
                    await asyncio.sleep(0.3)

            await asyncio.sleep(0.35)

            for _coba_dinamis in range(3):
                jml_awal = await page.locator(
                    "label:visible, .sv-dropdown:visible, .sd-dropdown:visible, select:visible, input[type='number']:visible"
                ).count()

                if target_kind == "telinga_mata":
                    await page.evaluate(
                        JS_FILL_TELINGA_MATA,
                        {
                            "katarak": student.curiga_katarak,
                            "visus": student.visus_mentah,
                            "kacamata": student.kacamata_mentah,
                            "serumen": student.serumen_mentah,
                        },
                    )
                    await asyncio.sleep(0.25)
                    await page.evaluate(
                        JS_FILL_TELINGA_MATA,
                        {
                            "katarak": student.curiga_katarak,
                            "visus": student.visus_mentah,
                            "kacamata": student.kacamata_mentah,
                            "serumen": student.serumen_mentah,
                        },
                    )
                    await self._sweep_universal_safe_defaults(page)
                    break
                elif target_kind == "gigi":
                    # Exact V2.6 Pemeriksaan Gigi - Anak logic (source_lines.txt lines 1468-1482)
                    await page.evaluate(
                        """(kariesVal) => {
                            let cleanTarget = (kariesVal || 'tidak ada').trim().toLowerCase();
                            if (cleanTarget === 'tidak' || cleanTarget === '0' || cleanTarget === '') {
                                cleanTarget = 'tidak ada';
                            }
                            const raw = Array.from(document.querySelectorAll('label, span.sv-string-viewer')).filter(
                                e => e.offsetWidth > 0 && e.offsetHeight > 0
                            );
                            const els = raw.filter(e => !raw.some(o => o !== e && o.contains(e)));
                            const normTarget = cleanTarget.replace(/\\s+/g, '');
                            const match = els.find(e => {
                                const txt = (e.innerText || '').trim().toLowerCase();
                                return txt === cleanTarget || txt.replace(/\\s+/g, '') === normTarget;
                            });
                            if (match) {
                                const lbl = match.closest('label') || match;
                                const inp = lbl.querySelector('input[type="radio"], input[type="checkbox"]');
                                if (!inp || !inp.checked) lbl.click();
                            }
                            els.forEach(e => {
                                if (e.innerText && e.innerText.trim().toLowerCase() === 'tidak ada') {
                                    e.innerText = 'Tidak Ada.';
                                }
                            });
                        }""",
                        student.gigi_karies,
                    )
                    await self._sweep_universal_safe_defaults(page)
                    break
                elif target_kind == "kulit":
                    await page.evaluate(
                        """() => {
                            const raw = Array.from(document.querySelectorAll('label, span.sv-string-viewer')).filter(
                                e => e.offsetWidth > 0 && e.offsetHeight > 0
                            );
                            const lbls = raw.filter(e => !raw.some(o => o !== e && o.contains(e)));
                            lbls.forEach(e => {
                                const t = (e.innerText || '').trim().toLowerCase();
                                if (
                                    t === 'tidak' ||
                                    t === 'tidak ada' ||
                                    t === 'tidak ditemukan' ||
                                    t === 'tidak ditemukan kelainan' ||
                                    t === 'normal' ||
                                    t === 'negatif'
                                ) {
                                    const target = e.closest('label') || e;
                                    const inp = target.querySelector('input[type="radio"], input[type="checkbox"]');
                                    if (!inp || !inp.checked) target.click();
                                }
                            });
                        }"""
                    )
                    await self._sweep_universal_safe_defaults(page)
                elif target_kind in ("co", "anemia"):
                    val = student.kadar_co_mentah if target_kind == "co" else student.hb_anemia_mentah
                    inp = page.locator(
                        "input[type='number']:visible, input.sd-input.sd-text:visible"
                    ).first
                    if await inp.is_visible() and val:
                        await inp.fill(str(val))
                    await self._sweep_universal_safe_defaults(page)
                    break
                elif target_kind == "malaria":
                    tgt = (
                        "Reaktif"
                        if "reaktif" in student.malaria_mentah.lower()
                        and "non" not in student.malaria_mentah.lower()
                        else "Non-Reaktif"
                    )
                    await page.evaluate(
                        """(tgt) => {
                            for (const l of document.querySelectorAll('label')) {
                                if ((l.innerText || '').toLowerCase().includes(tgt.toLowerCase())) { l.click(); break; }
                            }
                        }""",
                        tgt,
                    )
                    await self._sweep_universal_safe_defaults(page)
                    break
                elif target_kind == "hepatitis":
                    for hep_label, raw_val in (
                        ("hepatitis b", student.hepb_mentah),
                        ("hepatitis c", student.hepc_mentah),
                    ):
                        tgt = (
                            "Reaktif"
                            if raw_val
                            and "reaktif" in raw_val.lower()
                            and "non" not in raw_val.lower()
                            else "Non Reaktif"
                        )
                        await page.evaluate(
                            """({ hep, tgt }) => {
                                for (const q of document.querySelectorAll('.sd-question')) {
                                    if ((q.innerText || '').toLowerCase().includes(hep)) {
                                        for (const l of q.querySelectorAll('label')) {
                                            if ((l.innerText || '').toLowerCase().includes(tgt.toLowerCase())) { l.click(); return; }
                                        }
                                    }
                                }
                            }""",
                            {"hep": hep_label, "tgt": tgt},
                        )
                    await self._sweep_universal_safe_defaults(page)
                    break

                await self._sweep_universal_safe_defaults(page)
                await asyncio.sleep(0.25)

                jml_akhir = await page.locator(
                    "label:visible, .sv-dropdown:visible, .sd-dropdown:visible, select:visible, input[type='number']:visible"
                ).count()
                if jml_akhir > 0 and jml_awal == jml_akhir:
                    break

            submitted = await self._submit_survey_form_and_wait_dashboard(page, worker_id, form_id)
            if submitted:
                processed_nakes.add(form_id)
            else:
                await self.sadar_diri_dan_kembali(page, worker_id, student)

    # =========================================================================
    # PHASE 5: KIRIM RAPOR (3/3), SELESAIKAN LAYANAN, JARING 2 & TATALAKSANA
    # =========================================================================

    async def _dismiss_rapor_limit_modal_if_any(self, page: Any) -> bool:
        """
        Closes the 'Tidak dapat mengirim rapor (Kirim rapor hanya dapat dilakukan 1 kali)'
        modal if it is visible on screen so it never blocks 'Selesaikan Layanan'.
        """
        try:
            modal_limit = page.locator(
                "text=/Tidak dapat mengirim rapor|hanya dapat dilakukan 1 kali/i"
            ).first
            if await modal_limit.is_visible(timeout=400):
                btn_kembali = page.locator(
                    'div[role="dialog"] button:has-text("Kembali"), button:text-is("Kembali"):visible'
                ).first
                if await btn_kembali.is_visible(timeout=500):
                    await self._safe_click(btn_kembali, timeout=2500)
                else:
                    await page.keyboard.press("Escape")
                await asyncio.sleep(0.3)
                return True
        except Exception:
            pass
        return False

    async def _step_finalisasi_layanan(
        self, page: Any, worker_id: int, student: StudentRecord
    ) -> None:
        """
        Exact V2.6 Finalisasi Layanan (source_lines.txt lines 1644-1755):
        1. Verify all Skrining Mandiri & Mandatory Nakes forms are completed
        2. Kirim Rapor (handles Kemenkes 1x limit modal cleanly without blocking UI)
        3. Selesaikan Layanan -> Konfirmasi -> Wait for completion
        4. Strictly verify no error popup ('Gagal memproses data') and that 'Selesaikan Layanan'
           is no longer active (never falsely mark an unfinished student as SUKSES PARIPURNA!)
        """
        await self.sadar_diri_dan_kembali(page, worker_id, student)

        if self.config.mode == "C":
            rem_nakes = await page.evaluate(JS_TAG_NAKES_BUTTONS, False)
            if any("gizi" in c["text"] for c in rem_nakes) and student.berat and student.tinggi:
                await self._fill_nakes_gizi(page, worker_id, student)
            if (
                any("tekanan darah" in c["text"] for c in rem_nakes)
                and student.sistolik
                and student.diastolik
            ):
                await self._fill_nakes_tensi(page, worker_id, student)

        if self.config.kirim_rapor:
            student.last_step = "Mengeksekusi Kirim Rapor"
            await asyncio.sleep(0.4)
            btn_rapor = page.locator(
                '.btn-sent-report:visible, button:has-text("Kirim Rapor"):visible'
            ).first
            if await btn_rapor.is_visible():
                txt_rapor = ((await btn_rapor.inner_text()) or "").lower()
                m = re.search(r"\((\d+)/(\d+)\)", txt_rapor)
                angka_saat_ini = int(m.group(1)) if m else 0
                batas_rapor = int(m.group(2)) if m else 3

                if angka_saat_ini >= 1:
                    # Kemenkes CKG Sekolah limits report sending to 1x ('Kirim rapor hanya dapat dilakukan 1 kali')
                    student.status_rapor = f"Sukses ({angka_saat_ini}/{batas_rapor})"
                elif not await btn_rapor.is_disabled():
                    await self._safe_click(btn_rapor, timeout=4000)
                    await asyncio.sleep(0.45)
                    if await self._dismiss_rapor_limit_modal_if_any(page):
                        student.status_rapor = f"Sukses (1/{batas_rapor})"
                    else:
                        btn_kirim_modal = page.locator(
                            'div[role="dialog"] button:has-text("Kirim"), .swal2-confirm, button:has-text("Ya, Kirim"), button:has-text("Kirim"):visible'
                        ).last
                        if await btn_kirim_modal.is_visible():
                            await self._safe_click(btn_kirim_modal, timeout=4000)
                        try:
                            await self.wait_loading_smart(page, timeout_ms=10000, initial_delay_ms=400)
                        except Exception:
                            pass
                        await self._dismiss_rapor_limit_modal_if_any(page)
                        student.status_rapor = f"Sukses ({max(angka_saat_ini + 1, 1)}/{batas_rapor})"

        if self.config.auto_selesai:
            student.last_step = "Menekan Selesaikan Layanan"
            await self._dismiss_rapor_limit_modal_if_any(page)
            await self.sadar_diri_dan_kembali(page, worker_id, student)

            btn_selesai = page.locator('button:has-text("Selesaikan Layanan")').first
            try:
                await btn_selesai.wait_for(state="attached", timeout=10000)
            except Exception:
                pass

            # Check if button exists and is enabled
            btn_state = await page.evaluate(
                """() => {
                    const btns = Array.from(document.querySelectorAll('button'));
                    const b = btns.find(el => (el.innerText || '').includes('Selesaikan Layanan'));
                    if (!b) return { exists: false, disabled: true };
                    const cls = (b.className || '').toLowerCase();
                    const isDis = b.disabled || cls.includes('disabled') || cls.includes('cursor-not-allowed') || cls.includes('bg-disabled');
                    return { exists: true, disabled: isDis };
                }"""
            )

            if not btn_state.get("exists") or btn_state.get("disabled"):
                # Ensure we are on the dashboard and complete any remaining Skrining Mandiri / Nakes forms
                await self.sadar_diri_dan_kembali(page, worker_id, student)
                if not getattr(student, "_mandiri_done_in_run", False) and not self.config.lewati_skrining:
                    rem_mandiri = await page.evaluate(JS_TAG_MANDIRI_BUTTONS, False)
                    if rem_mandiri:
                        self.log(
                            f"🔄 Masih ada {len(rem_mandiri)} form Skrining Mandiri belum terisi, melengkapi...",
                            "warning",
                            worker_id,
                        )
                        await self._step_skrining_mandiri(page, worker_id, student)
                if self.config.mode in ("C", "D"):
                    await self._step_pelayanan_nakes(page, worker_id, student)
                student.last_step = "Menekan Selesaikan Layanan"

                btn_state = await page.evaluate(
                    """() => {
                        const btns = Array.from(document.querySelectorAll('button'));
                        const b = btns.find(el => (el.innerText || '').includes('Selesaikan Layanan'));
                        if (!b) return { exists: false, disabled: true };
                        const cls = (b.className || '').toLowerCase();
                        const isDis = b.disabled || cls.includes('disabled') || cls.includes('cursor-not-allowed') || cls.includes('bg-disabled');
                        return { exists: true, disabled: isDis };
                    }"""
                )

            if not btn_state.get("exists") or btn_state.get("disabled"):
                raise BomAutoRetryUniversal(
                    "Tombol 'Selesaikan Layanan' belum aktif (masih ada form pemeriksaan yang belum lengkap)"
                )

            # Click Selesaikan Layanan (Exact V2.6 lines 1660-1668)
            try:
                await btn_selesai.scroll_into_view_if_needed(timeout=3000)
                await asyncio.sleep(0.2)
                await btn_selesai.evaluate("node => node.click()")
            except Exception:
                await self._safe_click(btn_selesai, timeout=5000)

            await asyncio.sleep(0.5)
            btn_konf = page.locator('button:has-text("Konfirmasi")').last
            try:
                await btn_konf.wait_for(state="visible", timeout=10000)
                await asyncio.sleep(0.25)
                try:
                    await btn_konf.evaluate("node => node.click()")
                except Exception:
                    await self._safe_click(btn_konf, timeout=5000)
            except Exception as exc:
                raise BomAutoRetryUniversal(
                    f"Popup Konfirmasi Selesaikan Layanan tidak muncul: {exc}"
                ) from exc

            await self.wait_loading_smart(page, timeout_ms=15000, initial_delay_ms=500)
            await asyncio.sleep(0.8)

            # Check for Kemenkes error pop-ups ("Gagal memproses data", "Terjadi kesalahan", etc.) BEFORE closing modals!
            err_popup = await page.evaluate(JS_RADAR_ERROR_CHECK)
            has_toast_err = await page.locator(
                "text=/Gagal memproses|Terjadi kesalahan|Belum bisa memproses/i"
            ).first.is_visible()

            if err_popup or has_toast_err:
                self.log(
                    f"⚠️ Server Kemenkes menolak Selesaikan Layanan ({err_popup or 'Terjadi kesalahan'}), me-reload & memverifikasi kelengkapan...",
                    "warning",
                    worker_id,
                )
                await self._close_registration_modals_completely(page)
                await page.reload(wait_until="domcontentloaded", timeout=40000)
                await self.wait_loading_smart(page, timeout_ms=12000, initial_delay_ms=500)

            # Verify whether Selesaikan Layanan is STILL active/enabled on the page
            still_unfinished = await page.evaluate(
                """() => {
                    const btns = Array.from(document.querySelectorAll('button'));
                    const b = btns.find(el => (el.innerText || '').includes('Selesaikan Layanan'));
                    if (!b || b.offsetWidth === 0) return false;
                    const cls = (b.className || '').toLowerCase();
                    const isDis = b.disabled || cls.includes('disabled') || cls.includes('cursor-not-allowed') || cls.includes('bg-disabled');
                    return !isDis;
                }"""
            )
            if still_unfinished or err_popup:
                raise BomAutoRetryUniversal(
                    f"Selesaikan Layanan belum terkunci di server Kemenkes ({err_popup or 'masih berstatus Sedang Pemeriksaan'})"
                )

            if self.config.mode == "D":
                student.status_sistem = "Selesai Tahap 3 (Pemeriksaan Fisik & Klinis Nakes)"
            else:
                student.status_sistem = "Selesai Lengkap (Pendaftaran, Skrining Mandiri & Pemeriksaan Nakes)"
        else:
            student.status_sistem = "Tersimpan Draft (Menunggu Klik Selesaikan Layanan)"

        if student.no_tiket == "-":
            try:
                body_txt = (await page.evaluate("() => document.body.innerText")) or ""
                kandidat_list = re.findall(r"\b([A-Za-z0-9]{3}\s*-\s*[A-Za-z0-9]{3})\b", body_txt)
                blacklist = {"LAK-LAK", "PER-EMP", "TID-ADA", "NOR-MAL", "BEL-MEN", "NON-REA"}
                for k in kandidat_list:
                    clean_k = k.replace(" ", "").upper()
                    if clean_k not in blacklist and any(ch.isdigit() for ch in clean_k):
                        student.no_tiket = clean_k
                        break
            except Exception:
                pass

        student.last_step = "Mengecek Status Tatalaksana"
        try:
            tata_status = await page.evaluate(
                """() => {
                    const els = Array.from(document.querySelectorAll('button, .btn, [role="button"], a'));
                    const btn = els.find(e => e.innerText && /^\\s*Mulai Tatalaksana\\s*$/i.test(e.innerText));
                    if (!btn) return "Aman (Tidak Ada Tindakan)";
                    const cls = (btn.className || "").toLowerCase();
                    if (btn.disabled || cls.includes("bg-disabled") || cls.includes("cursor-not-allowed") || cls.includes("disabled")) {
                        return "Aman (Tidak Ada Tindakan)";
                    }
                    return "Harus tatalaksana";
                }"""
            )
            student.tatalaksana = tata_status
        except Exception:
            student.tatalaksana = "Aman (Tidak Ada Tindakan)"

        student.state = "warning" if student.tatalaksana == "Harus tatalaksana" else "success"
        student.last_step = "Selesai"
        await self.capture_worker_peek(page, worker_id)
        self.log(
            f"🏆 {student.nama} -> {student.status_sistem} | Tiket: {student.no_tiket} | {student.tatalaksana}",
            "success",
            worker_id,
        )

    # =========================================================================
    # CKG UMUM (DEWASA & LANSIA • 37 KOLOM) AUTOMATION ENGINE
    # =========================================================================
    async def _ensure_umum_portal_ready(self, page: Any, worker_id: int) -> None:
        cur_url = (page.url or "").lower()
        if "sehatindonesiaku.kemkes.go.id" not in cur_url or "form.kemkes.go.id" in cur_url:
            await page.goto(URL_PELAYANAN_UMUM, wait_until="domcontentloaded", timeout=45000)
            await self.wait_loading_smart(page, timeout_ms=8000, initial_delay_ms=250)

        await self.radar_sapu_jagat(page, worker_id)
        await self._bypass_privacy_modal(page)

        # Auto-initialize localStorage.pengaturan_pelayanan from user_eksternal so /ckg-pelayanan never blocks on setup modal
        try:
            await page.evaluate(
                """async () => {
                    try {
                        if (localStorage.getItem('pengaturan_pelayanan')) return true;
                        const cr = await import('/_nuxt/pp5sFs6w.js');
                        const enc = cr.e;
                        const dec = cr.d;
                        const ueRaw = localStorage.getItem('user_eksternal');
                        const uaRaw = localStorage.getItem('user_area');
                        if (!ueRaw) return false;
                        const ue = JSON.parse(dec(ueRaw));
                        const ua = uaRaw ? JSON.parse(dec(uaRaw)) : {};
                        const cfg = {
                            role: ue.subrole_code || 'puskesmas',
                            isMitraUseFaskesLocation: true,
                            categoryLocation: 'fasilitas-kesehatan',
                            subcategoryLocation: ue.subrole_code || 'puskesmas',
                            province: { id: ua.province_id || ue.province_id || '', name: ua.province_name || '' },
                            city: { id: ua.city_id || ue.city_id || '', name: ua.city_name || '' },
                            district: { id: ua.district_id || ue.district_id || '', name: ua.district_name || '' },
                            subdistrict: { id: ua.sub_district_id || ue.sub_district_id || '', name: ua.sub_district_name || '' },
                            postalCode: '',
                            address: ''
                        };
                        localStorage.setItem('pengaturan_pelayanan', enc(JSON.stringify(cfg)));
                        return true;
                    } catch (e) {
                        return false;
                    }
                }"""
            )
        except Exception:
            pass

    async def _umum_lookup_or_register(
        self,
        page: Any,
        worker_id: int,
        student: StudentRecord,
        sudah_tukar_tgl: bool = False,
    ) -> Dict[str, Any]:
        await self._ensure_umum_portal_ready(page, worker_id)

        payload = {
            "nik": student.nik,
            "nama": student.nama,
            "tgl_iso": student.tgl_iso,
            "jk_pasien": student.jk_pasien,
            "wa_pasien": student.wa_pasien,
            "tgl_pemeriksaan": student.tgl_pemeriksaan or dt.date.today().strftime("%Y-%m-%d"),
            "pekerjaan": student.pekerjaan or "Lainnya",
            "provinsi": student.provinsi,
            "kabkota": student.kabkota,
            "kecamatan": student.kecamatan,
            "desa": student.desa,
            "detail_alamat": student.detail_alamat,
            "no_tiket": student.no_tiket if student.no_tiket != "-" else "",
            "mode": self.config.mode,
            "mode_bypass": self.config.mode_bypass,
            "mode_booking": self.config.mode_booking,
            "sudah_tukar_tgl": sudah_tukar_tgl,
        }

        res = await page.evaluate(
            """async (p) => {
                const OCC = {
                    'ASN (Kantor Pemerintah)': '01',
                    'BUMN': '02',
                    'TNI': '03',
                    'Polri': '04',
                    'Pegawai Swasta': '05',
                    'Wirausaha / Pekerja Mandiri': '06',
                    'Petani / Pekebun': '07',
                    'Nelayan': '08',
                    'Buruh / Karyawan Lepas': '09',
                    'Pengemudi': '10',
                    'Pelajar / Mahasiswa': '11',
                    'Ibu Rumah Tangga': '12',
                    'Pensiunan': '13',
                    'Belum/Tidak Bekerja': '14',
                    'Lainnya': '99'
                };
                const norm = s => (s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
                const pick = (items, targetName, idKey, nameKey) => {
                    if (!Array.isArray(items) || !items.length) return null;
                    const t = norm(targetName);
                    return (
                        items.find(x => norm(x[nameKey]) === t) ||
                        items.find(x => norm(x[nameKey]).includes(t) || t.includes(norm(x[nameKey]))) ||
                        items[0]
                    );
                };

                try {
                    const api = await import('/_nuxt/BJcR1Dm5.js');
                    const cr = await import('/_nuxt/pp5sFs6w.js');
                    const getFetch = api.g;
                    const postFetch = api.p;
                    const enc = cr.e;
                    const dec = cr.d;

                    const ueRaw = localStorage.getItem('user_eksternal');
                    if (!ueRaw) return { ok: false, error: 'Sesi login tidak ditemukan (user_eksternal kosong)' };
                    const ue = JSON.parse(dec(ueRaw));
                    const faskesId = ue.faskes_id;

                    const findVisit = async (nikVal, nameVal, ticketVal) => {
                        const statuses = ['pemeriksaan-selesai', 'sedang-pemeriksaan', 'belum-pemeriksaan'];
                        for (const st of statuses) {
                            const queryObj = {
                                page: 1,
                                limit: 20,
                                status_code: st,
                                screening_start_date: '',
                                screening_end_date: ''
                            };
                            if (nikVal) queryObj.nik = nikVal;
                            else if (ticketVal) queryObj.ticket_number = ticketVal;
                            else if (nameVal) queryObj.name = nameVal;

                            const r = await postFetch('/api/pkg/ssi/list-kunjungan-umum', queryObj, {}, true);
                            const rawData = r?.data?.value?.data;
                            const d = typeof rawData === 'string' ? JSON.parse(dec(rawData)) : rawData;
                            const list = d?.data || [];
                            if (list.length > 0) {
                                const exact = list.find(it => (nikVal && it.nik === nikVal) || (ticketVal && it.ticket_number === ticketVal)) || list[0];
                                return { status_tab: st, visit: exact };
                            }
                        }
                        return null;
                    };

                    let found = await findVisit(p.nik, '', p.no_tiket);

                    // Register if not found and allowed by mode
                    if (!found) {
                        if (!['A', 'C'].includes(p.mode) || p.mode_bypass) {
                            return { ok: false, error: 'Peserta belum terdaftar di CKG Umum (jalankan Paket Lengkap / Mode A)' };
                        }

                        const gender = p.jk_pasien === 'Perempuan' ? 'female' : 'male';
                        let useNik = p.nik;
                        let pre = await postFetch('/api/pkg/ssi/register-pre', {
                            nik: useNik,
                            name: p.nama,
                            gender,
                            birth_date: p.tgl_iso
                        });
                        let preCode = pre?.data?.value?.code || pre?.error?.value?.data?.code;
                        let preData = pre?.data?.value?.data;
                        if (typeof preData === 'string') {
                            try { preData = JSON.parse(dec(preData)); } catch (e) {}
                        }

                        if (preData?.nikBirthDateMismatch) {
                            const sp = await postFetch('/api/pkg/ssi/search-people', {
                                name: p.nama,
                                birth_date: p.tgl_iso,
                                gender,
                                page: 1,
                                limit: 10
                            });
                            let spData = sp?.data?.value?.data;
                            if (typeof spData === 'string') {
                                try { spData = JSON.parse(dec(spData)); } catch (e) {}
                            }
                            const cand = (spData?.records || []).find(x => x.nik);
                            if (cand && cand.nik) {
                                useNik = cand.nik;
                                pre = await postFetch('/api/pkg/ssi/register-pre', {
                                    nik: useNik,
                                    name: p.nama,
                                    gender,
                                    birth_date: p.tgl_iso
                                });
                                preCode = pre?.data?.value?.code || pre?.error?.value?.data?.code;
                                preData = pre?.data?.value?.data;
                                if (typeof preData === 'string') {
                                    try { preData = JSON.parse(dec(preData)); } catch (e) {}
                                }
                            } else if (!p.sudah_tukar_tgl) {
                                return { ok: false, action: 'swap_dob', error: 'NIK & Tanggal Lahir tidak sesuai di Dukcapil' };
                            }
                        }

                        if (preCode !== 200 || preData?.nikBirthDateMismatch || preData?.nikInvalid) {
                            return {
                                ok: false,
                                error: 'Validasi Dukcapil gagal: ' + JSON.stringify(preData || pre?.error?.value?.data || preCode)
                            };
                        }

                        await getFetch('/api/pkg/get-quota', { faskes_id: faskesId, screening_date: p.tgl_pemeriksaan });

                        const provs = (await getFetch('/api/teritorial-service/provinces'))?.data?.value?.data || [];
                        const prov = pick(provs, p.provinsi || 'KEPULAUAN RIAU', 'province_id', 'province_name') || { province_id: 21, province_name: 'KEPULAUAN RIAU' };
                        const cities = (await getFetch('/api/teritorial-service/cities', { province_id: prov.province_id }))?.data?.value?.data || [];
                        const city = pick(cities, p.kabkota || 'KOTA BATAM', 'city_id', 'city_name') || { city_id: 2171, city_name: 'KOTA BATAM' };
                        const dists = (await getFetch('/api/teritorial-service/districts', { city_id: city.city_id }))?.data?.value?.data || [];
                        const dist = pick(dists, p.kecamatan || 'BENGKONG', 'district_id', 'district_name') || dists[0];
                        const subs = (await getFetch('/api/teritorial-service/sub-districts', { district_id: dist.district_id }))?.data?.value?.data || [];
                        const sub = pick(subs, p.desa || 'BENGKONG INDAH', 'sub_district_id', 'sub_district_name') || subs[0];

                        const occName = OCC[p.pekerjaan] ? p.pekerjaan : 'Lainnya';
                        const occCode = OCC[occName] || '99';

                        const regBody = {
                            guardian: null,
                            patient: {
                                nik: useNik,
                                name: p.nama,
                                birth_date: p.tgl_iso,
                                gender,
                                occupation_code: occCode,
                                occupation_name: occName,
                                mobile_number: p.wa_pasien,
                                address_ktp: {
                                    Write: true,
                                    province_id: String(prov.province_id),
                                    province_name: prov.province_name,
                                    city_id: String(city.city_id),
                                    city_name: city.city_name,
                                    district_id: String(dist.district_id),
                                    district_name: dist.district_name,
                                    subdistrict_id: String(sub.sub_district_id),
                                    subdistrict_name: sub.sub_district_name,
                                    address: (p.detail_alamat || p.desa || 'BENGKONG').slice(0, 100),
                                    use_Nakes_location: false
                                },
                                has_id_number: true,
                                has_guardian: false,
                                is_nik_valid: Boolean(preData?.nikValid),
                                is_disability: false
                            },
                            faskes_id: faskesId,
                            PackageID: '',
                            faskes_Province_id: String(ue.province_id || prov.province_id),
                            faskes_City_id: String(ue.city_id || city.city_id),
                            faskes_District_id: String(ue.district_id || dist.district_id),
                            faskes_Subdistrict_id: String(ue.sub_district_id || sub.sub_district_id),
                            screening_date: p.tgl_pemeriksaan,
                            register_source: 'Mandiri',
                            force: true,
                            is_walkin: true
                        };

                        const reg = await postFetch('/api/pkg/ssi/register-ckg', regBody);
                        let regData = reg?.data?.value?.data;
                        if (typeof regData === 'string') {
                            try { regData = JSON.parse(dec(regData)); } catch (e) {}
                        }
                        const errData = reg?.error?.value?.data;

                        if (regData?.screening_id && regData?.ticket_number) {
                            found = {
                                status_tab: 'belum-pemeriksaan',
                                visit: {
                                    screening_id: regData.screening_id,
                                    patient_id: regData.patient_id,
                                    ticket_number: regData.ticket_number,
                                    faskes_id: regData.faskes_id || faskesId,
                                    screening_date: regData.screening_date || p.tgl_pemeriksaan,
                                    nik: useNik,
                                    name: p.nama
                                }
                            };
                        } else if (errData?.data?.alreadyRegistered || errData?.data?.alreadyServedToday) {
                            found = await findVisit(useNik, p.nama, '');
                        } else {
                            return {
                                ok: false,
                                error: 'Gagal mendaftarkan peserta CKG Umum: ' + JSON.stringify(errData || regData || {})
                            };
                        }
                    }

                    if (!found || !found.visit) {
                        return { ok: false, error: 'Data kunjungan peserta tidak ditemukan setelah pendaftaran' };
                    }

                    const v = found.visit;
                    let currentStatus = found.status_tab;

                    // Start examination if still in belum-pemeriksaan and not booking-only
                    if (currentStatus === 'belum-pemeriksaan' && !p.mode_booking) {
                        await postFetch('/api/pkg/ssi/set-status', {
                            faskes_id: v.faskes_id || faskesId,
                            patient_id: v.patient_id,
                            screening_date: v.screening_date || p.tgl_pemeriksaan,
                            screening_id: v.screening_id,
                            status_code: 'layanan-mulai',
                            backdate: p.tgl_pemeriksaan
                        });
                        currentStatus = 'sedang-pemeriksaan';
                    }

                    // Fetch full detail-screening-ssi
                    const detRes = await postFetch('/api/pkg/ssi/detail-screening-ssi', {
                        id: v.screening_id,
                        ticket_number: v.ticket_number,
                        screening_date: v.screening_date || p.tgl_pemeriksaan
                    });
                    let det = detRes?.data?.value?.data;
                    if (typeof det === 'string') {
                        try { det = JSON.parse(dec(det)); } catch (e) {}
                    }

                    let encQuery = '';
                    if (det) {
                        localStorage.setItem('dataDetail', enc(JSON.stringify(det)));
                        localStorage.setItem('dataDetailTicket', enc(v.ticket_number));
                        encQuery = enc(JSON.stringify({
                            id: v.screening_id,
                            date: det.screening_date || v.screening_date || p.tgl_pemeriksaan,
                            ticket: v.ticket_number
                        }));
                    }

                    return {
                        ok: true,
                        status_tab: currentStatus,
                        visit: v,
                        detail: det,
                        enc_query: encQuery
                    };
                } catch (err) {
                    return { ok: false, error: String(err?.message || err) };
                }
            }""",
            payload,
        )
        return res or {"ok": False, "error": "Tidak ada respons dari browser"}

    async def _umum_get_form_url(
        self,
        page: Any,
        visit: Dict[str, Any],
        detail: Dict[str, Any],
        form_id: str,
        is_petugas: bool,
    ) -> Optional[str]:
        await self._ensure_umum_portal_ready(page, 1)
        args = {
            "form_id": form_id,
            "is_petugas": is_petugas,
            "patient_age": int(detail.get("age") or visit.get("age") or 30),
            "screening_date": detail.get("screening_date") or visit.get("screening_date"),
            "faskes_id": detail.get("faskes_id") or visit.get("faskes_id"),
            "patient_id": str(detail.get("patient_id") or visit.get("patient_id")),
            "screening_id": detail.get("screening_id") or visit.get("screening_id"),
        }
        return await page.evaluate(
            """async (a) => {
                try {
                    const api = await import('/_nuxt/BJcR1Dm5.js');
                    const cr = await import('/_nuxt/pp5sFs6w.js');
                    const r = await api.p('/api/pkg/form-url', a);
                    const raw = r?.data?.value?.data;
                    const d = typeof raw === 'string' ? JSON.parse(cr.d(raw)) : raw;
                    return d?.url || null;
                } catch (e) {
                    return null;
                }
            }""",
            args,
        )

    async def _umum_fill_survey_form(
        self,
        page: Any,
        worker_id: int,
        student: StudentRecord,
        form_id: str,
        form_name: str,
        form_url: str,
        is_petugas: bool,
    ) -> bool:
        await page.goto(form_url, wait_until="domcontentloaded", timeout=35000)
        try:
            await page.wait_for_selector(".sd-question, .sv-question, button", timeout=12000)
        except Exception:
            pass
        await page.wait_for_timeout(350)

        s_payload = {
            "form_id": form_id,
            "jk_pasien": student.jk_pasien,
            "umur": student.umur,
            "status_pernikahan": student.status_pernikahan or "Menikah",
            "riwayat_hubungan_intim": student.riwayat_hubungan_intim or "Ya",
            "perilaku_merokok": (student.perilaku_merokok or "tidak").lower(),
            "aktivitas_fisik": (student.aktivitas_fisik or "ya").lower(),
            "berat": student.berat,
            "tinggi": student.tinggi,
            "lingkar_perut": student.lingkar_perut,
            "riwayat_dm": (student.riwayat_dm or "tidak").lower(),
            "lama_dm": student.lama_dm,
            "gds": student.gds,
            "riwayat_hipertensi": (student.riwayat_hipertensi or "tidak").lower(),
            "lama_hipertensi": student.lama_hipertensi,
            "sistolik": student.sistolik,
            "diastolik": student.diastolik,
            "curiga_katarak": (student.curiga_katarak or "normal").lower(),
            "gigi_karies": student.gigi_karies or "Tidak",
            "gigi_hilang": student.gigi_hilang or "Tidak",
            "skrining_payudara": student.skrining_payudara or "Sadanis",
            "kolesterol_total": student.kolesterol_total,
        }

        # Step 1: Set exact SurveyJS question values via webpackChunk_N_E (instant & exact)
        await page.evaluate(
            """(s) => {
                try {
                    const models = [];
                    (window.webpackChunk_N_E || []).push([
                        ['ckg_' + Math.random().toString(36).slice(2, 7)],
                        {},
                        (req) => {
                            for (const id of Object.keys(req.c)) {
                                const exp = req.c[id]?.exports;
                                if (exp && typeof exp === 'object') {
                                    for (const k of Object.keys(exp)) {
                                        if (exp[k]?.Model) models.push(exp[k].Model);
                                    }
                                }
                            }
                        }
                    ]);
                    for (const M of models) {
                        if (M?.prototype && !M.prototype.__ckgHooked) {
                            const orig = M.prototype.getQuestionByName;
                            M.prototype.getQuestionByName = function (...a) {
                                window.__ckgSurvey = this;
                                return orig.apply(this, a);
                            };
                            M.prototype.__ckgHooked = true;
                        }
                    }
                    const el = document.querySelector('input, select, textarea, button');
                    if (el) el.dispatchEvent(new Event('change', { bubbles: true }));
                    const sv = window.__ckgSurvey;
                    if (!sv) return false;

                    const pickChoice = (qName, targetText) => {
                        const q = sv.getQuestionByName(qName);
                        if (!q) return false;
                        const t = String(targetText ?? '').trim().toLowerCase();
                        const choices = q.visibleChoices || q.choices || [];
                        if (!choices.length) {
                            sv.setValue(qName, targetText);
                            return true;
                        }
                        const hit =
                            choices.find(c => String(c.text || c.value || '').trim().toLowerCase() === t) ||
                            choices.find(c => String(c.value || '').trim().toLowerCase() === t) ||
                            choices.find(c => String(c.text || '').trim().toLowerCase().includes(t));
                        sv.setValue(qName, hit ? hit.value : targetText);
                        return true;
                    };

                    const setNum = (qName, val) => {
                        if (val === undefined || val === null || val === '') return;
                        const n = Number(String(val).replace(',', '.'));
                        if (!Number.isNaN(n)) sv.setValue(qName, n);
                    };

                    const fid = s.form_id;
                    // --- MANDIRI FORMS ---
                    if (fid === 'FRM000007') {
                        pickChoice('PPM00000172', s.status_pernikahan || 'Menikah');
                        pickChoice('PPM00000173', 'Tidak');
                        pickChoice('PPM00000299', 'Non disabilitas');
                    } else if (fid === 'FRM000008' || fid === 'FRM000006') {
                        pickChoice('PPM00000172', s.status_pernikahan || 'Menikah');
                        pickChoice('PPM00000299', 'Non disabilitas');
                    } else if (fid === 'FRM000064') {
                        if (s.perilaku_merokok === 'ya') {
                            pickChoice('PPM00000183', 'Ya');
                            pickChoice('PPM00000348', 'Rokok konvensional');
                            pickChoice('PPM00000218', 'Tidak');
                        } else {
                            pickChoice('PPM00000183', 'Tidak');
                            pickChoice('PPM00000185', 'Tidak');
                            pickChoice('PPM00000218', 'Tidak');
                        }
                    } else if (fid === 'FRM000088') {
                        pickChoice('PPM00000171', s.riwayat_hubungan_intim === 'Ya' ? 'Ya' : 'Tidak');
                    } else if (fid === 'FRM000169') {
                        const ya = s.aktivitas_fisik !== 'tidak';
                        pickChoice('PPM00000706', ya ? 'Ya' : 'Tidak');
                        if (ya) {
                            setNum('PPM00000707', 5);
                            setNum('PPM00000708', 30);
                        }
                        for (const qid of ['PPM00000709', 'PPM00000712', 'PPM00000715', 'PPM00000718', 'PPM00000721']) {
                            pickChoice(qid, 'Tidak');
                        }
                    } else if (fid === 'FRM000180') {
                        pickChoice('PPM00000477', 'Tidak batuk');
                    } else if (fid === 'FRM000067') {
                        for (const qid of ['PPM00000192', 'PPM00000193', 'PPM00000194', 'PPM00000195']) {
                            pickChoice(qid, 'Tidak sama sekali');
                        }
                    } else if (fid === 'FRM000028') {
                        for (const qid of ['PPM00000176', 'PPM00000177', 'PPM00000178', 'PPM00000179', 'PPM00000180', 'PPM00000181', 'PPM00000182', 'PPM00000221']) {
                            pickChoice(qid, 'Tidak');
                        }
                        const kolHigh = s.kolesterol_total && Number(s.kolesterol_total) >= 200;
                        pickChoice('PPM00000230', kolHigh ? 'Ya' : 'Tidak');
                    } else if (fid === 'FRM000138') {
                        const rokok = s.perilaku_merokok === 'ya';
                        pickChoice('PPM00000561', rokok ? 'Ya' : 'Tidak');
                        if (!rokok) pickChoice('PPM00000562', 'Tidak');
                        for (const qid of ['PPM00000563', 'PPM00000402', 'PPM00000564', 'PPM00000565']) {
                            pickChoice(qid, 'Tidak');
                        }
                    } else if (fid === 'FRM000027') {
                        pickChoice('PPM00000175', 'Tidak');
                        pickChoice('PPM00000288', s.perilaku_merokok === 'ya' ? 'Ya' : 'Tidak');
                        const ageGroup = s.umur >= 70 ? '>= 70' : (s.umur >= 50 ? '50 - 69' : '< 50');
                        pickChoice('PPM00000254', ageGroup);
                        pickChoice('PPM00000255', s.jk_pasien === 'Perempuan' ? 'Perempuan' : 'Laki-Laki');
                    } else if (fid === 'FRM000172') {
                        pickChoice('PPM00000505', 'Tidak tahu');
                    }
                    // --- NAKES FORMS ---
                    else if (fid === 'FRM000051' || fid === 'FRM000093') {
                        setNum('PPM00000248', s.berat);
                        setNum('PPM00000086', s.tinggi);
                        setNum('PPM00000090', s.lingkar_perut);
                        setNum('PPM00000202', s.lingkar_perut);
                    } else if (fid === 'FRM000265') {
                        const htYa = s.riwayat_hipertensi === 'ya' || (s.lama_hipertensi && Number(s.lama_hipertensi) > 0);
                        pickChoice('PPM00000203', htYa ? 'Ya' : 'Tidak');
                        if (htYa && s.lama_hipertensi) setNum('PPM00000698', s.lama_hipertensi);
                        setNum('PPM00000012', s.sistolik);
                        setNum('PPM00000019', s.diastolik);
                    } else if (fid === 'FRM000256') {
                        const dmYa = s.riwayat_dm === 'ya' || (s.lama_dm && Number(s.lama_dm) > 0);
                        pickChoice('PPM00000160', dmYa ? 'Ya' : 'Tidak');
                        if (dmYa && s.lama_dm) setNum('PPM00000558', s.lama_dm);
                        setNum('PPM00000731', s.gds);
                    } else if (fid === 'FRM000055') {
                        pickChoice('PPM00000025', s.gigi_karies === 'Ya' ? 'Ya' : 'Tidak');
                        pickChoice('PPM00000035', s.gigi_hilang === 'Ya' ? 'Ya' : 'Tidak');
                    } else if (fid === 'FRM000047') {
                        setNum('PPM00000010', s.kolesterol_total);
                    } else if (fid === 'FRM000059') {
                        pickChoice('PPM00000067', 'SADANIS');
                    } else if (fid === 'FRM000099') {
                        pickChoice('PPM00000559', 'Tidak ada serumen impaksi');
                        pickChoice('PPM00000560', 'Tidak ada infeksi telinga');
                        pickChoice('PPM00000020', 'Normal');
                        pickChoice('PPM00000040', 'Normal (visus 6/6 - 6/12)');
                        pickChoice('PPM00000072', s.curiga_katarak.includes('katarak') ? 'Curiga Katarak' : 'Normal');
                    }

                    // Fill any remaining unanswered visible SurveyJS questions with safe defaults
                    const safeDefaults = [
                        'Tidak sama sekali', 'Tidak batuk', 'Non disabilitas',
                        'Tidak ada serumen impaksi', 'Tidak ada infeksi telinga',
                        'Normal (visus 6/6 - 6/12)', 'Normal', 'Mandiri',
                        'Tidak tahu', 'Tidak'
                    ];
                    for (const q of (sv.getAllQuestions() || [])) {
                        if (!q.isVisible) continue;
                        const cur = sv.getValue(q.name);
                        if (cur !== undefined && cur !== null && cur !== '') continue;
                        const choices = q.visibleChoices || q.choices || [];
                        if (choices.length > 0) {
                            let matched = null;
                            for (const sd of safeDefaults) {
                                matched = choices.find(c => String(c.text || '').toLowerCase().includes(sd.toLowerCase()));
                                if (matched) break;
                            }
                            if (!matched) matched = choices[choices.length - 1];
                            if (matched) sv.setValue(q.name, matched.value);
                        }
                    }
                    return true;
                } catch (e) {
                    return false;
                }
            }""",
            s_payload,
        )

        # Step 2: Click Kirim and wait for redirect back to sehatindonesiaku.kemkes.go.id
        clicked_kirim = await page.evaluate(JS_CLICK_KIRIM)
        if not clicked_kirim:
            btn_kirim = page.locator("button:has-text('Kirim'), input[value='Kirim']").first
            if await btn_kirim.is_visible():
                await btn_kirim.click(force=True)

        for _ in range(32):
            await page.wait_for_timeout(350)
            cur_u = (page.url or "").lower()
            if "sehatindonesiaku.kemkes.go.id" in cur_u and "form.kemkes.go.id" not in cur_u:
                return True

        # Fallback: if still on form.kemkes.go.id, use universal DOM form filler and submit again
        if "form.kemkes.go.id" in (page.url or "").lower():
            if not is_petugas:
                await self._isi_satu_form_universal(page, student, form_name.lower())
            await page.evaluate(JS_CLICK_KIRIM)
            for _ in range(25):
                await page.wait_for_timeout(350)
                cur_u = (page.url or "").lower()
                if "sehatindonesiaku.kemkes.go.id" in cur_u and "form.kemkes.go.id" not in cur_u:
                    return True

        return "sehatindonesiaku.kemkes.go.id" in (page.url or "").lower()

    async def _process_single_umum_with_retry(
        self, page: Any, worker_id: int, student: StudentRecord
    ) -> None:
        self.log(
            f"👥 MEMPROSES PESERTA CKG UMUM: {student.nama} (NIK: {student.nik} | {student.umur} th • {student.kelas}) -> [MODE {self.config.mode}]",
            "info",
            worker_id,
        )
        sudah_tukar_tgl = False
        attempt = 1
        net_recoveries = 0

        while attempt <= 3:
            try:
                await self.check_pause_and_stop(page, worker_id)
                if attempt > 1:
                    self.log(
                        f"🔄 [AUTO-RETRY {attempt}/3] Mengulang peserta CKG Umum {student.nama}...",
                        "warning",
                        worker_id,
                    )

                student.last_step = "Pendaftaran & Cek Kunjungan CKG Umum"
                res = await self._umum_lookup_or_register(
                    page, worker_id, student, sudah_tukar_tgl=sudah_tukar_tgl
                )

                if not res.get("ok"):
                    if res.get("action") == "swap_dob" and not sudah_tukar_tgl:
                        if swap_day_month_if_possible(student):
                            sudah_tukar_tgl = True
                            self.log(
                                f"🔄 [Smart Sensor DOB] Menukar Tanggal/Bulan Lahir {student.nama} menjadi {student.tgl_iso}...",
                                "warning",
                                worker_id,
                            )
                            continue
                    err_msg = res.get("error") or "Gagal memproses pendaftaran CKG Umum"
                    if net_recoveries < 10 and await self._wait_for_internet_recovery(
                        page, worker_id, student, err_msg
                    ):
                        net_recoveries += 1
                        continue
                    student.status_sistem = f"Gagal: {err_msg[:90]}"
                    student.state = "failed"
                    student.last_step = "Terkendala di Pendaftaran/Cek Kunjungan"
                    self.log(f"❌ {student.nama}: {err_msg}", "error", worker_id)
                    return

                visit = res.get("visit") or {}
                detail = res.get("detail") or {}
                enc_query = res.get("enc_query") or ""
                status_tab = res.get("status_tab") or "sedang-pemeriksaan"

                if visit.get("ticket_number"):
                    student.no_tiket = visit["ticket_number"]
                if visit.get("nik") and len(str(visit["nik"])) == 16:
                    student.nik = str(visit["nik"])

                # Open detail-pemeriksaan page so user sees live progress in Lihat Layar Pemeriksaan
                if enc_query:
                    detail_url = f"{URL_PELAYANAN_UMUM}/detail-pemeriksaan?_d={enc_query}"
                    await page.goto(detail_url, wait_until="domcontentloaded", timeout=35000)
                    await self.wait_loading_smart(page, timeout_ms=6000, initial_delay_ms=250)
                    await self.capture_worker_peek(page, worker_id)

                # If Mode A or Booking only
                if self.config.mode == "A" or self.config.mode_booking:
                    student.status_sistem = (
                        "Terdaftar Booking (Belum Konfirmasi Kehadiran)"
                        if self.config.mode_booking
                        else "Selesai Tahap 1 (Pendaftaran & Konfirmasi Kehadiran)"
                    )
                    student.state = "success"
                    student.last_step = "Selesai Tahap 1"
                    self.log(
                        f"✅ {student.nama}: {student.status_sistem} | Tiket: {student.no_tiket}",
                        "success",
                        worker_id,
                    )
                    return

                # Check if already completed on server
                mandiri_forms = detail.get("screening_forms") or []
                mandiri_unfilled = [
                    f for f in mandiri_forms if (f.get("status_form") or "").lower() != "terisi"
                ]
                if (
                    status_tab == "pemeriksaan-selesai"
                    and not self.config.update_data_lama
                    and (self.config.mode != "B" or len(mandiri_unfilled) == 0)
                ):
                    student.tatalaksana = (
                        "Harus tatalaksana"
                        if detail.get("status_followup")
                        else "Aman (Tidak Ada Tindakan)"
                    )
                    student.status_sistem = "Selesai Lengkap (Pendaftaran, Skrining Mandiri & Pemeriksaan Nakes)"
                    student.state = "warning" if student.tatalaksana == "Harus tatalaksana" else "success"
                    student.last_step = "Selesai"
                    self.log(
                        f"⏩ {student.nama} sudah berstatus Selesai Pemeriksaan di portal (Tiket: {student.no_tiket}).",
                        "success",
                        worker_id,
                    )
                    return

                # PHASE 2: Skrining Mandiri CKG Umum (Modes B & C)
                if self.config.mode in ("B", "C") and not self.config.lewati_skrining:
                    target_mandiri = (
                        mandiri_forms if self.config.update_data_lama else mandiri_unfilled
                    )
                    if target_mandiri:
                        self.log(
                            f"📝 Mengisi {len(target_mandiri)} Kuesioner Skrining Mandiri CKG Umum untuk {student.nama}...",
                            "info",
                            worker_id,
                        )
                    for idx_m, m_form in enumerate(target_mandiri, start=1):
                        await self.check_pause_and_stop(page, worker_id)
                        fid = m_form.get("form_id") or ""
                        fname = m_form.get("form_name") or fid
                        student.last_step = f"Skrining Mandiri ({idx_m}/{len(target_mandiri)}): {fname[:28]}"
                        f_url = await self._umum_get_form_url(page, visit, detail, fid, is_petugas=False)
                        if f_url:
                            await self._umum_fill_survey_form(
                                page, worker_id, student, fid, fname, f_url, is_petugas=False
                            )
                            self.log(
                                f"  ✓ Skrining Mandiri [{idx_m}/{len(target_mandiri)}] {fname} selesai",
                                "info",
                                worker_id,
                            )

                    if self.config.mode == "B":
                        if enc_query:
                            await page.goto(
                                f"{URL_PELAYANAN_UMUM}/detail-pemeriksaan?_d={enc_query}",
                                wait_until="domcontentloaded",
                                timeout=30000,
                            )
                            await self.capture_worker_peek(page, worker_id)
                        student.status_sistem = "Selesai Tahap 2 (Kuesioner Skrining Mandiri)"
                        student.state = "success"
                        student.last_step = "Selesai Tahap 2"
                        self.log(
                            f"🏆 {student.nama} -> {student.status_sistem} | Tiket: {student.no_tiket}",
                            "success",
                            worker_id,
                        )
                        return

                # PHASE 3: Pelayanan oleh Nakes CKG Umum (Modes C & D)
                if self.config.mode in ("C", "D"):
                    # Re-fetch fresh detail-screening-ssi after Mandiri forms
                    refreshed = await self._umum_lookup_or_register(
                        page, worker_id, student, sudah_tukar_tgl=sudah_tukar_tgl
                    )
                    if refreshed.get("ok") and refreshed.get("detail"):
                        detail = refreshed["detail"]
                        enc_query = refreshed.get("enc_query") or enc_query

                    layanan_groups = detail.get("screening_layanan") or []
                    nakes_Forms_to_fill: List[Dict[str, str]] = []
                    for grp in layanan_groups:
                        for f in grp.get("forms") or []:
                            fid = f.get("form_id") or ""
                            fname = f.get("form_name") or fid
                            st_lay = (f.get("status_layanan") or "").lower()
                            if st_lay == "selesai-pemeriksaan" and not self.config.update_data_lama:
                                continue

                            # Check config & student clinical data availability
                            if fid in ("FRM000051", "FRM000093"):
                                if not getattr(self.config, "is_gizi_umum", True) or not (student.berat and student.tinggi):
                                    continue
                            elif fid == "FRM000265":
                                if not getattr(self.config, "is_tensi_umum", True) or not (student.sistolik and student.diastolik):
                                    continue
                            elif fid == "FRM000256":
                                if not getattr(self.config, "is_gds_umum", True) or not student.gds:
                                    continue
                            elif fid == "FRM000055":
                                if not self.config.is_gigi:
                                    continue
                            elif fid == "FRM000047":
                                if not getattr(self.config, "is_lipid_umum", True) or not student.kolesterol_total:
                                    continue
                            elif fid == "FRM000059":
                                if (
                                    not getattr(self.config, "is_payudara_umum", True)
                                    or student.jk_pasien != "Perempuan"
                                    or not student.skrining_payudara
                                ):
                                    continue
                            elif fid == "FRM000099":
                                if not self.config.is_mata_telinga or student.umur < 40:
                                    continue
                            else:
                                # Skip optional lab/specialist forms unless explicitly present
                                continue

                            nakes_Forms_to_fill.append({"form_id": fid, "form_name": fname})

                    if nakes_Forms_to_fill:
                        self.log(
                            f"🩺 Mengisi {len(nakes_Forms_to_fill)} Pemeriksaan Klinis Nakes CKG Umum untuk {student.nama}...",
                            "info",
                            worker_id,
                        )
                    for idx_n, n_form in enumerate(nakes_Forms_to_fill, start=1):
                        await self.check_pause_and_stop(page, worker_id)
                        fid = n_form["form_id"]
                        fname = n_form["form_name"]
                        student.last_step = f"Pemeriksaan Nakes ({idx_n}/{len(nakes_Forms_to_fill)}): {fname[:28]}"
                        f_url = await self._umum_get_form_url(page, visit, detail, fid, is_petugas=True)
                        if f_url:
                            await self._umum_fill_survey_form(
                                page, worker_id, student, fid, fname, f_url, is_petugas=True
                            )
                            self.log(
                                f"  ✓ Pemeriksaan Nakes [{idx_n}/{len(nakes_Forms_to_fill)}] {fname} selesai",
                                "info",
                                worker_id,
                            )

                # PHASE 4: Selesaikan Layanan & Cek Tatalaksana
                await self._ensure_umum_portal_ready(page, worker_id)
                final_info = await page.evaluate(
                    """async (arg) => {
                        try {
                            const api = await import('/_nuxt/BJcR1Dm5.js');
                            const cr = await import('/_nuxt/pp5sFs6w.js');
                            if (arg.auto_selesai) {
                                await api.p('/api/pkg/ssi/set-status', {
                                    faskes_id: arg.faskes_id,
                                    patient_id: arg.patient_id,
                                    screening_date: arg.screening_date,
                                    screening_id: arg.screening_id,
                                    status_code: 'layanan-selesai'
                                });
                            }
                            const detRes = await api.p('/api/pkg/ssi/detail-screening-ssi', {
                                id: arg.screening_id,
                                ticket_number: arg.ticket_number,
                                screening_date: arg.screening_date
                            });
                            let det = detRes?.data?.value?.data;
                            if (typeof det === 'string') {
                                try { det = JSON.parse(cr.d(det)); } catch (e) {}
                            }
                            let encQuery = '';
                            if (det) {
                                localStorage.setItem('dataDetail', cr.e(JSON.stringify(det)));
                                localStorage.setItem('dataDetailTicket', cr.e(arg.ticket_number));
                                encQuery = cr.e(JSON.stringify({
                                    id: arg.screening_id,
                                    date: det.screening_date || arg.screening_date,
                                    ticket: arg.ticket_number
                                }));
                            }
                            return { ok: true, detail: det, enc_query: encQuery };
                        } catch (e) {
                            return { ok: false, error: String(e?.message || e) };
                        }
                    }""",
                    {
                        "auto_selesai": bool(self.config.auto_selesai),
                        "faskes_id": detail.get("faskes_id") or visit.get("faskes_id"),
                        "patient_id": detail.get("patient_id") or visit.get("patient_id"),
                        "screening_date": detail.get("screening_date") or visit.get("screening_date"),
                        "screening_id": detail.get("screening_id") or visit.get("screening_id"),
                        "ticket_number": student.no_tiket,
                    },
                )

                final_det = (final_info or {}).get("detail") or detail
                final_enc = (final_info or {}).get("enc_query") or enc_query
                if final_enc:
                    await page.goto(
                        f"{URL_PELAYANAN_UMUM}/detail-pemeriksaan?_d={final_enc}",
                        wait_until="domcontentloaded",
                        timeout=30000,
                    )
                    await self.wait_loading_smart(page, timeout_ms=6000, initial_delay_ms=250)

                student.tatalaksana = (
                    "Harus tatalaksana"
                    if final_det.get("status_followup")
                    else "Aman (Tidak Ada Tindakan)"
                )
                student.status_sistem = (
                    "Selesai Tahap 3 (Pemeriksaan Fisik & Klinis Nakes)"
                    if self.config.mode == "D" and self.config.auto_selesai
                    else "Selesai Lengkap (Pendaftaran, Skrining Mandiri & Pemeriksaan Nakes)"
                    if self.config.auto_selesai
                    else "Tersimpan Draft (Menunggu Klik Selesaikan Layanan)"
                )
                student.state = "warning" if student.tatalaksana == "Harus tatalaksana" else "success"
                student.last_step = "Selesai"
                await self.capture_worker_peek(page, worker_id)
                self.log(
                    f"🏆 {student.nama} -> {student.status_sistem} | Tiket: {student.no_tiket} | {student.tatalaksana}",
                    "success",
                    worker_id,
                )
                return

            except BomAutoRetryUniversal as retry_err:
                if net_recoveries < 10 and await self._wait_for_internet_recovery(
                    page, worker_id, student, retry_err
                ):
                    net_recoveries += 1
                    continue
                self.log(f"⚠️ {student.nama}: {retry_err}", "warning", worker_id)
                if attempt == 3:
                    student.status_sistem = f"Gagal: {str(retry_err)[:80]}"
                    student.state = "failed"
                    student.last_step = "Gagal setelah 3x percobaan"
                attempt += 1
            except asyncio.CancelledError:
                student.status_sistem = "Dihentikan Pengguna"
                student.state = "pending"
                raise
            except Exception as exc:
                if net_recoveries < 10 and await self._wait_for_internet_recovery(
                    page, worker_id, student, exc
                ):
                    net_recoveries += 1
                    continue
                self.log(f"❌ Error pada {student.nama}: {exc}", "error", worker_id)
                if attempt == 3:
                    student.status_sistem = f"Gagal: {str(exc)[:80]}"
                    student.state = "failed"
                    student.last_step = "Error Sistem"
                attempt += 1
