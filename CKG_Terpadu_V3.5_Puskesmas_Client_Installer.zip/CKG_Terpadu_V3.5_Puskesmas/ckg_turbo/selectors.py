from __future__ import annotations

# Core Kemenkes Sehat Indonesiaku URLs
URL_BASE = "https://sehatindonesiaku.kemkes.go.id/"
URL_LOGIN = "https://sehatindonesiaku.kemkes.go.id/auth/login"
URL_PENDAFTARAN = "https://sehatindonesiaku.kemkes.go.id/ckg-pendaftaran-anak-sekolah"
URL_PELAYANAN = "https://sehatindonesiaku.kemkes.go.id/ckg-pelayanan-sekolah"
URL_PENDAFTARAN_UMUM = "https://sehatindonesiaku.kemkes.go.id/ckg-pendaftaran-individu"
URL_PELAYANAN_UMUM = "https://sehatindonesiaku.kemkes.go.id/ckg-pelayanan"

# Injected init script to speed up CSS transitions while keeping React events intact
DISABLE_ANIMATIONS_INIT_SCRIPT = """
(() => {
    const inject = () => {
        if (document.getElementById('ckg-turbo-no-anim')) return;
        const style = document.createElement('style');
        style.id = 'ckg-turbo-no-anim';
        style.textContent = `
            *, *::before, *::after {
                transition-duration: 0.01s !important;
                transition-delay: 0s !important;
                animation-duration: 0.01s !important;
                animation-delay: 0s !important;
                scroll-behavior: auto !important;
            }
        `;
        (document.head || document.documentElement).appendChild(style);
    };
    if (document.documentElement) inject();
    document.addEventListener('DOMContentLoaded', inject);
})();
"""

# Click an Ant Design / Vue / Tailwind select option or dropdown item matching text
JS_KLIK_OPSI = """
(teks) => {
    const lower = (teks || '').toLowerCase().trim();
    if (!lower) return false;
    const blacklist = ['selanjutnya', 'lanjutkan', 'simpan', 'kembali', 'batal', 'daftar baru', 'tutup', 'keluar'];
    const rawItems = Array.from(document.querySelectorAll(
        '.ant-select-item-option-content, .ant-select-item, li[role="option"], div[role="option"], ul li, button, div.cursor-pointer, span'
    ));
    const items = rawItems.filter(i => {
        if (!i.innerText || i.offsetHeight <= 0 || i.offsetWidth <= 0) return false;
        const t = i.innerText.trim().toLowerCase();
        if (!t || t.length > 140) return false;
        if (blacklist.includes(t) && t !== lower) return false;
        return true;
    });
    const exactMatches = items.filter(i => i.innerText.trim().toLowerCase() === lower);
    if (exactMatches.length > 0) {
        const target = exactMatches[exactMatches.length - 1];
        target.scrollIntoView({ block: 'center', inline: 'nearest' });
        target.click();
        return true;
    }
    const partialMatches = items.filter(i => i.innerText.trim().toLowerCase().includes(lower));
    if (partialMatches.length > 0) {
        const target = partialMatches[partialMatches.length - 1];
        target.scrollIntoView({ block: 'center', inline: 'nearest' });
        target.click();
        return true;
    }
    return false;
}
"""

# Detect Kemenkes error pop-ups (Radar Sapu Jagat - exact V2.6 logic)
JS_RADAR_ERROR_CHECK = """
() => {
    const elemen = Array.from(document.querySelectorAll('div, span, p, h1, h2, h3'));
    const ketemu = elemen.find(e => e.innerText && (
        e.innerText.includes("Terjadi kesalahan") ||
        e.innerText.includes("Belum bisa memproses data") ||
        e.innerText.includes("Gagal memproses data") ||
        e.innerText.includes("Internal Server Error") ||
        e.innerText.includes("Data peserta tidak valid") ||
        e.innerText.includes("data identitas pasien tidak cocok") ||
        e.innerText.includes("Payload harus terenkripsi")
    ) && e.offsetParent !== null);
    return ketemu ? ketemu.innerText.trim().slice(0, 160) : null;
}
"""

# Detect active loading spinners or loading text on screen (Exact V2.6 Kacamata 1 & Kacamata 2)
JS_IS_LOADING_ACTIVE = """
() => {
    // KACAMATA 1: CEK ANIMASI TITIK 4 BERPUTAR (TANPA TEKS)
    const spinner = document.querySelector('.ant-spin-spinning, .ant-spin-dot-spin');
    if (spinner && spinner.offsetWidth > 0) return true;

    // KACAMATA 2: CEK LOADING BERUPA TEKS
    const load = Array.from(document.querySelectorAll('*')).find(el => {
        if (el.offsetWidth > 0 && el.offsetHeight > 0 && el.innerText) {
            const txt = el.innerText.toLowerCase();
            return txt.includes("memproses data") ||
                   txt.includes("memuat data") ||
                   txt.includes("sedang memproses data") ||
                   txt.includes("proses pencarian data") ||
                   txt.includes("proses validasi data");
        }
        return false;
    });
    return !!load;
}
"""

# Read form validation or toast error messages (Exact V2.6 logic)
JS_READ_FORM_ERRORS = """
() => {
    let pesan = [];
    const toasts = document.querySelectorAll('.Toastify__toast-body, .ant-message-notice-content, .ant-notification-notice-description, [role="alert"]');
    toasts.forEach(t => { if (t.innerText && t.offsetWidth > 0) pesan.push(t.innerText.trim()); });
    const teksMerah = document.querySelectorAll('.ant-form-item-explain-error, .text-red-500, .text-danger, span[style*="color: red"], p.text-red-500');
    teksMerah.forEach(m => { if (m.innerText && m.offsetWidth > 0) pesan.push(m.innerText.trim()); });
    if (pesan.length === 0) {
        const semua = document.querySelectorAll('div, span, p');
        semua.forEach(el => {
            if (el.children.length === 0 && el.innerText && el.offsetWidth > 0) {
                const txt = el.innerText.trim();
                if (/wajib diisi|tidak valid|harus diisi|minimal|maksimal|format salah|sudah digunakan|tidak ditemukan/i.test(txt) && txt.length < 100) {
                    pesan.push(txt);
                }
            }
        });
    }
    return pesan.length > 0 ? [...new Set(pesan)].join(' | ') : null;
}
"""

# Atomic 1-ms check for Step 1 registration outcome (replaces 11 Playwright IPC round-trips per loop!)
JS_CHECK_STEP1_STATUS = """
() => {
    const body = (document.body && document.body.innerText) ? document.body.innerText : '';
    if (!body) return null;
    if (body.includes('Kuota Pemeriksaan Habis')) {
        const btns = Array.from(document.querySelectorAll('button')).filter(b => b.innerText && b.innerText.includes('Lanjut') && b.offsetHeight > 0);
        if (btns.length > 0) btns[btns.length - 1].click();
        return 'kuota_habis_clicked';
    }
    if (body.includes('Individu sudah menerima layanan') || body.includes('telah selesai diperiksa') || body.includes('Hari ini sudah diperiksa')) {
        return 'sudah_dilayani';
    }
    if (body.includes('Individu sudah terdaftar')) {
        return 'sudah_terdaftar';
    }
    if (body.includes('Data peserta atau wali tidak valid') || body.includes('Data peserta tidak valid') || body.includes('Data Peserta Tidak Valid')) {
        return 'tidak_valid';
    }
    if (body.includes('Belum bisa memproses data') || body.includes('Terjadi kesalahan') || body.includes('Gagal memproses')) {
        return 'error_sistem';
    }
    if (body.includes('Data peserta valid') || body.includes('Nama Sekolah')) {
        return 'lanjut';
    }
    const btnLanjut = Array.from(document.querySelectorAll('button')).find(b => b.innerText && b.innerText.trim() === 'Lanjutkan' && b.offsetHeight > 0);
    if (btnLanjut) return 'lanjut';
    return null;
}
"""

# Atomic 1-ms check for whether the page was kicked back to the Pelayanan table
JS_IS_OUTSIDE_EXAM_PAGE = """
() => {
    const url = (window.location.href || '').toLowerCase();
    if ((url.includes('/ckg-pelayanan-sekolah') || url.includes('/ckg-pelayanan')) && !url.includes('detail-pemeriksaan')) {
        return true;
    }
    const el1 = document.querySelector('input[placeholder="Pilih sekolah"]');
    if (el1 && el1.offsetHeight > 0) return true;
    const el2 = document.querySelector('input[placeholder*="Masukkan"]');
    if (el2 && el2.offsetHeight > 0) return true;
    const bodyText = (document.body && document.body.innerText) ? document.body.innerText : '';
    if (
        bodyText.includes('Silakan lakukan filter sekolah dan kelas') ||
        bodyText.includes('Tampilkan Pencarian')
    ) {
        return true;
    }
    return false;
}
"""

# Read 'Jumlah Pemeriksaan (X/Y)' progress strictly inside the 'Pemeriksaan Mandiri' section
# (never matching 'Pelayanan oleh Nakes' below it!)
JS_GET_MANDIRI_PROGRESS = """
() => {
    const hMandiri = Array.from(document.querySelectorAll('div, h1, h2, h3, h4, span, p'))
        .find(e => e.innerText && e.innerText.trim() === 'Pemeriksaan Mandiri' && e.offsetHeight > 0);
    const hNakes = Array.from(document.querySelectorAll('div, h1, h2, h3, h4, span, p'))
        .find(e => e.innerText && e.innerText.trim() === 'Pelayanan oleh Nakes' && e.offsetHeight > 0);

    if (hMandiri) {
        const candidates = Array.from(document.querySelectorAll('div, span, p, button, h2, h3, h4')).filter(el => {
            if (!el || el.offsetHeight <= 0) return false;
            const txt = (el.innerText || '').trim();
            if (!/^Jumlah\\s+Pemeriksaan\\s*\\(\\s*\\d+\\s*\\/\\s*\\d+\\s*\\)$/i.test(txt)) return false;
            const afterMandiri = Boolean(hMandiri.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) || hMandiri.contains(el);
            if (!afterMandiri) return false;
            if (hNakes) {
                const beforeNakes = Boolean(hNakes.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_PRECEDING);
                if (!beforeNakes) return false;
            }
            return true;
        });
        if (candidates.length > 0) {
            const mDom = (candidates[0].innerText || '').match(/Jumlah\\s+Pemeriksaan\\s*\\(\\s*(\\d+)\\s*\\/\\s*(\\d+)\\s*\\)/i);
            if (mDom) {
                const done = parseInt(mDom[1], 10);
                const total = parseInt(mDom[2], 10);
                return {
                    done,
                    total,
                    isComplete: total > 0 && done >= total,
                    text: `${done}/${total}`,
                };
            }
        }
    }

    const body = (document.body && document.body.innerText) ? document.body.innerText : '';
    const idxMandiri = body.indexOf('Pemeriksaan Mandiri');
    if (idxMandiri < 0) return null;
    const idxNakes = body.indexOf('Pelayanan oleh Nakes', idxMandiri);
    const sectionText = idxNakes > idxMandiri ? body.slice(idxMandiri, idxNakes) : body.slice(idxMandiri, idxMandiri + 1200);
    const m = sectionText.match(/Jumlah\\s+Pemeriksaan\\s*\\(\\s*(\\d+)\\s*\\/\\s*(\\d+)\\s*\\)/i);
    if (m) {
        const done = parseInt(m[1], 10);
        const total = parseInt(m[2], 10);
        return {
            done,
            total,
            isComplete: total > 0 && done >= total,
            text: `${done}/${total}`,
        };
    }
    return null;
}
"""

# Tag Skrining Mandiri "Input Data" buttons (those preceding "Pelayanan oleh Nakes")
# Isolates each individual row/card container, detects both text status AND Green vs Gray checkmark icon
# in the Status column, and skips already-completed green-checkmark rows unless includeCompleted is true.
JS_TAG_MANDIRI_BUTTONS = """
(includeCompleted = false) => {
    document.querySelectorAll('button[data-mandiri-target]').forEach(b => b.removeAttribute('data-mandiri-target'));
    const bodyText = (document.body && document.body.innerText) ? document.body.innerText : '';
    const idxMandiri = bodyText.indexOf('Pemeriksaan Mandiri');
    const idxNakes = idxMandiri >= 0 ? bodyText.indexOf('Pelayanan oleh Nakes', idxMandiri) : -1;
    const mandiriSectionText = idxMandiri >= 0
        ? (idxNakes >= 0 ? bodyText.slice(idxMandiri, idxNakes) : bodyText.slice(idxMandiri))
        : '';
    const mProg = mandiriSectionText.match(/Jumlah\\s+Pemeriksaan\\s*\\(\\s*(\\d+)\\s*\\/\\s*(\\d+)\\s*\\)/i);
    const progDone = mProg ? parseInt(mProg[1], 10) : -1;
    const progTotal = mProg ? parseInt(mProg[2], 10) : -1;

    const batasNakes = Array.from(document.querySelectorAll('div, h1, h2, h3, h4, span, p'))
        .find(e => e.innerText && e.innerText.trim() === "Pelayanan oleh Nakes" && e.offsetHeight > 0);
    const semuaTombol = Array.from(document.querySelectorAll('button'))
        .filter(b => b.innerText && b.innerText.includes("Input Data") && b.offsetHeight > 0 && !b.disabled);

    const parseRgb = (cStr) => {
        if (!cStr || typeof cStr !== 'string') return null;
        const s = cStr.trim().toLowerCase();
        if (!s || s === 'none' || s === 'transparent' || s === 'currentcolor') return null;
        const mRgb = s.match(/rgba?\\(\\s*(\\d+)\\s*,\\s*(\\d+)\\s*,\\s*(\\d+)(?:\\s*,\\s*([0-9.]+))?\\s*\\)/);
        if (mRgb) {
            const a = mRgb[4] !== undefined ? parseFloat(mRgb[4]) : 1.0;
            if (a <= 0.1) return null;
            return { r: parseInt(mRgb[1], 10), g: parseInt(mRgb[2], 10), b: parseInt(mRgb[3], 10) };
        }
        const mHex6 = s.match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})/i);
        if (mHex6) {
            return { r: parseInt(mHex6[1], 16), g: parseInt(mHex6[2], 16), b: parseInt(mHex6[3], 16) };
        }
        return null;
    };

    const isRgbGreen = (rgb) => {
        if (!rgb) return false;
        return rgb.g >= 95 && (rgb.g - rgb.r) >= 25 && rgb.g >= (rgb.b - 20);
    };

    const isRgbGray = (rgb) => {
        if (!rgb) return false;
        // Neutral gray circle (#d1d5db, #9ca3af, #cbd5e1, #bdbdbd, #e5e7eb) — excludes white (>245) & black (<60)
        return (
            rgb.r >= 100 &&
            rgb.r <= 242 &&
            Math.abs(rgb.r - rgb.g) <= 20 &&
            Math.abs(rgb.g - rgb.b) <= 20 &&
            Math.abs(rgb.r - rgb.b) <= 22
        );
    };

    const inspectStatusIcon = (rowNode, actionBtn) => {
        if (!rowNode) return { isGreen: false, isGray: false, greenScore: 0, sig: '' };
        // Isolate the Status cell (2nd <td> if table row, otherwise non-button icon elements)
        let scopeNodes = [];
        if (rowNode.tagName && rowNode.tagName.toLowerCase() === 'tr') {
            const tds = Array.from(rowNode.querySelectorAll(':scope > td'));
            if (tds.length >= 2) {
                scopeNodes = [tds[1], ...Array.from(tds[1].querySelectorAll('*'))];
            }
        }
        if (scopeNodes.length === 0) {
            scopeNodes = Array.from(rowNode.querySelectorAll('svg, rect, g, circle, path, img, i, [class*="icon"], [class*="status"]'))
                .filter(el => el !== actionBtn && !actionBtn.contains(el) && !el.contains(actionBtn));
        }

        let foundGreen = false;
        let foundGray = false;
        let maxGreenDiff = -999;
        const sigParts = [];

        for (const el of scopeNodes) {
            if (!el || el === actionBtn || actionBtn.contains(el) || el.contains(actionBtn)) continue;
            const tag = (el.tagName || '').toLowerCase();
            const cls = ((el.getAttribute && (el.getAttribute('class') || '')) || '').toLowerCase();
            const styleAttr = ((el.getAttribute && (el.getAttribute('style') || '')) || '').toLowerCase();
            const fillAttr = ((el.getAttribute && (el.getAttribute('fill') || '')) || '').toLowerCase();
            const strokeAttr = ((el.getAttribute && (el.getAttribute('stroke') || '')) || '').toLowerCase();
            const srcAttr = ((el.getAttribute && (el.getAttribute('src') || '')) || '').toLowerCase();
            const combined = `${cls} ${styleAttr} ${fillAttr} ${strokeAttr} ${srcAttr}`;

            if (/gray|grey|slate|neutral|zinc|stone|disabled|muted|#d1d5db|#9ca3af|#e5e7eb|#cbd5e1|#bdbdbd|#ccc/i.test(combined)) {
                foundGray = true;
            }
            if (/(text|bg|fill|stroke)-(green|emerald|teal|success)|#(10b981|059669|22c55e|16a34a|14b8a6|0d9488|00a896|34d399|4ade80|52c41a)/i.test(combined)) {
                foundGreen = true;
                maxGreenDiff = Math.max(maxGreenDiff, 80);
            }

            const colorCandidates = [fillAttr, strokeAttr];
            if (tag === 'svg' || tag === 'rect' || tag === 'g' || tag === 'path' || tag === 'circle' || tag === 'i' || tag === 'span' || tag === 'div' || tag === 'img') {
                try {
                    const cs = window.getComputedStyle(el);
                    if (cs) {
                        colorCandidates.push(cs.fill, cs.stroke, cs.backgroundColor, cs.color);
                        if (tag === 'svg' || tag === 'rect' || tag === 'g' || tag === 'path' || tag === 'circle' || tag === 'img' || tag === 'i') {
                            sigParts.push(`${tag}:${cls}:${fillAttr}:${strokeAttr}:${srcAttr}:${cs.fill || ''}:${cs.color || ''}:${cs.backgroundColor || ''}`);
                        }
                    }
                } catch (e) {}
            }

            for (const cStr of colorCandidates) {
                const rgb = parseRgb(cStr);
                if (!rgb) continue;
                const diff = rgb.g - Math.max(rgb.r, rgb.b);
                if (diff > maxGreenDiff) maxGreenDiff = diff;
                if (isRgbGreen(rgb)) foundGreen = true;
                if (isRgbGray(rgb)) foundGray = true;
            }
        }

        return {
            isGreen: foundGreen && !foundGray,
            isGray: foundGray && !foundGreen,
            greenScore: maxGreenDiff,
            sig: sigParts.join('|')
        };
    };
    const hasGreenStatusIcon = (rowNode, actionBtn) => inspectStatusIcon(rowNode, actionBtn).isGreen;

    const extractSingleCard = (btn) => {
        let node = btn.closest('tr');
        if (!node) {
            node = btn.parentElement;
            for (let j = 0; j < 6 && node && node.parentElement; j++) {
                const parent = node.parentElement;
                const actionBtns = Array.from(parent.querySelectorAll('button')).filter(
                    b => b.innerText && /Input Data|Lihat Data|Ubah Data/i.test(b.innerText) && b.offsetHeight > 0
                );
                if (actionBtns.length > 1) break;
                node = parent;
            }
        }
        const raw = (node && node.innerText) ? node.innerText.trim() : "";
        const lines = raw.split('\\n').map(s => s.trim()).filter(Boolean);
        const lowerLines = lines.map(s => s.toLowerCase());
        const firstLine = lowerLines[0] || "";
        const fullText = raw.toLowerCase().replace(/\\s+/g, ' ').trim();
        const hasBelum = (
            fullText.includes('belum pemeriksaan') ||
            fullText.includes('belum diisi') ||
            fullText.includes('belum lengkap') ||
            fullText.includes('belum dilakukan')
        );
        const textCompleted = !hasBelum && (
            fullText.includes('selesai pemeriksaan') ||
            fullText.includes('sudah pemeriksaan') ||
            fullText.includes('sudah diisi') ||
            fullText.includes('sudah lengkap') ||
            lowerLines.includes('selesai pemeriksaan') ||
            lowerLines.includes('lengkap') ||
            lowerLines.includes('selesai')
        );
        const iconInfo = inspectStatusIcon(node, btn);
        const iconCompleted = !hasBelum && iconInfo.isGreen;
        return {
            firstLine,
            fullText,
            isCompleted: Boolean(textCompleted || iconCompleted),
            iconSig: iconInfo.sig,
            greenScore: iconInfo.greenScore,
            isGray: iconInfo.isGray,
        };
    };

    const mandiriCards = [];
    let ordinal = 0;
    semuaTombol.forEach((btn) => {
        let isMandiri = true;
        if (batasNakes) {
            isMandiri = Boolean(batasNakes.compareDocumentPosition(btn) & Node.DOCUMENT_POSITION_PRECEDING);
        }
        if (isMandiri) {
            const cardData = extractSingleCard(btn);
            mandiriCards.push({
                btn,
                ordinal,
                ...cardData,
            });
            ordinal++;
        }
    });

    // Cross-verify status icons using 2-group icon signature comparison (works even when progDone == progTotal due to duplicate submit)
    if (!includeCompleted && mandiriCards.length >= 2) {
        const sigGroups = new Map();
        for (const c of mandiriCards) {
            const k = c.iconSig || `score_${c.greenScore}`;
            if (!sigGroups.has(k)) sigGroups.set(k, []);
            sigGroups.get(k).push(c);
        }
        if (sigGroups.size === 2) {
            const entries = Array.from(sigGroups.entries());
            const [g1Key, g1Cards] = entries[0];
            const [g2Key, g2Cards] = entries[1];
            const expectedIncomplete = (progTotal > 0 && progDone > 0 && progDone < progTotal) ? (progTotal - progDone) : -1;
            if (expectedIncomplete > 0 && g1Cards.length === progDone && g2Cards.length === expectedIncomplete && progDone !== expectedIncomplete) {
                g1Cards.forEach(c => { c.isCompleted = true; c.isGray = false; });
                g2Cards.forEach(c => { c.isCompleted = false; c.isGray = true; });
            } else if (expectedIncomplete > 0 && g2Cards.length === progDone && g1Cards.length === expectedIncomplete && progDone !== expectedIncomplete) {
                g2Cards.forEach(c => { c.isCompleted = true; c.isGray = false; });
                g1Cards.forEach(c => { c.isCompleted = false; c.isGray = true; });
            } else {
                const g1Score = g1Cards[0].greenScore;
                const g2Score = g2Cards[0].greenScore;
                if (g1Score > g2Score) {
                    g1Cards.forEach(c => { c.isCompleted = true; c.isGray = false; });
                    g2Cards.forEach(c => { c.isCompleted = false; c.isGray = true; });
                } else if (g2Score > g1Score) {
                    g2Cards.forEach(c => { c.isCompleted = true; c.isGray = false; });
                    g1Cards.forEach(c => { c.isCompleted = false; c.isGray = true; });
                } else if (g1Cards[0].ordinal === 0 && g2Cards[g2Cards.length - 1].ordinal === mandiriCards.length - 1) {
                    // Kemenkes sorts completed (green) rows to the top and incomplete (gray) rows to the bottom
                    g1Cards.forEach(c => { c.isCompleted = true; c.isGray = false; });
                    g2Cards.forEach(c => { c.isCompleted = false; c.isGray = true; });
                }
            }
        }
    }

    let jiwaCounter = 0;
    mandiriCards.forEach((c) => {
        const bt = (c.firstLine || '').toLowerCase();
        if (bt.includes('kesehatan jiwa') || bt.includes('sdq')) {
            c.isJiwa = true;
            c.jiwaIndex = jiwaCounter;
            jiwaCounter++;
        } else {
            c.isJiwa = false;
            c.jiwaIndex = -1;
        }
    });

    let selectedCards = includeCompleted
        ? mandiriCards
        : mandiriCards.filter(c => !c.isCompleted);

    if (!includeCompleted && progTotal > 0 && progDone >= progTotal && !mandiriCards.some(c => c.isGray)) {
        selectedCards = [];
    }

    // Safety net: if 'Jumlah Pemeriksaan (X/Y)' says X < Y (incomplete), never return 0 cards when buttons exist
    if (!includeCompleted && selectedCards.length === 0 && progTotal > 0 && progDone >= 0 && progDone < progTotal && mandiriCards.length > 0) {
        selectedCards = mandiriCards;
    }

    const hasil = [];
    selectedCards.forEach((c, targetIdx) => {
        c.btn.setAttribute('data-mandiri-target', 'true');
        const baseTitle = c.firstLine || `form_index_${c.ordinal}`;
        const formId = c.isJiwa ? `${baseTitle}_${c.jiwaIndex}` : baseTitle;
        hasil.push({
            index: targetIdx,
            ordinal: c.ordinal,
            form_id: formId,
            title: baseTitle,
            text: c.fullText || baseTitle,
            is_completed: c.isCompleted,
            is_jiwa: Boolean(c.isJiwa),
            jiwa_index: c.jiwaIndex,
            total_jiwa_cards: jiwaCounter,
        });
    });
    return hasil;
}
"""

# Tag Pelayanan oleh Nakes "Input Data" buttons (those following "Pelayanan oleh Nakes")
# Skips cards already marked 'Selesai Pemeriksaan' / 'Lengkap' unless includeCompleted is true.
JS_TAG_NAKES_BUTTONS = """
(includeCompleted = false) => {
    document.querySelectorAll('button[data-nakes-target]').forEach(b => b.removeAttribute('data-nakes-target'));
    const batasNakes = Array.from(document.querySelectorAll('div, h1, h2, h3, h4, span, p'))
        .find(e => e.innerText && e.innerText.trim() === "Pelayanan oleh Nakes" && e.offsetHeight > 0);
    const semuaTombol = Array.from(document.querySelectorAll('button'))
        .filter(b => b.innerText && b.innerText.includes("Input Data") && b.offsetHeight > 0 && !b.disabled);

    const extractSingleCard = (btn) => {
        let node = btn.parentElement;
        for (let j = 0; j < 5 && node && node.parentElement; j++) {
            const parent = node.parentElement;
            const actionBtns = Array.from(parent.querySelectorAll('button')).filter(
                b => b.innerText && /Input Data|Lihat Data|Ubah Data/i.test(b.innerText) && b.offsetHeight > 0
            );
            if (actionBtns.length > 1) break;
            node = parent;
        }
        const raw = (node && node.innerText) ? node.innerText.trim() : "";
        const lines = raw.split('\\n').map(s => s.trim()).filter(Boolean);
        const lowerLines = lines.map(s => s.toLowerCase());
        const firstLine = lowerLines[0] || "";
        const fullText = raw.toLowerCase().replace(/\\s+/g, ' ').trim();
        const hasBelum = (
            fullText.includes('belum pemeriksaan') ||
            fullText.includes('belum diisi') ||
            fullText.includes('belum lengkap') ||
            fullText.includes('belum dilakukan')
        );
        const isCompleted = !hasBelum && (
            fullText.includes('selesai pemeriksaan') ||
            fullText.includes('sudah pemeriksaan') ||
            fullText.includes('sudah diisi') ||
            fullText.includes('sudah lengkap') ||
            lowerLines.includes('selesai pemeriksaan') ||
            lowerLines.includes('lengkap') ||
            lowerLines.includes('selesai')
        );
        return { firstLine, fullText, isCompleted };
    };

    const hasil = [];
    let targetIdx = 0;
    semuaTombol.forEach((btn) => {
        let isNakes = true;
        if (batasNakes) {
            isNakes = Boolean(batasNakes.compareDocumentPosition(btn) & Node.DOCUMENT_POSITION_FOLLOWING);
        }
        if (isNakes) {
            const { firstLine, fullText, isCompleted } = extractSingleCard(btn);
            if (!includeCompleted && isCompleted) {
                return;
            }
            btn.setAttribute('data-nakes-target', 'true');
            hasil.push({
                index: targetIdx,
                form_id: firstLine || `nakes_index_${targetIdx}`,
                title: firstLine || fullText,
                text: fullText,
            });
            targetIdx++;
        }
    });
    return hasil;
}
"""

# Safe default answers for general Skrining Mandiri questions
SAFE_DEFAULT_ANSWERS = [
    "Pernah imunisasi tetanus tetapi tidak ingat berapa kali",
    "Tidak sama sekali",
    "Tidak pernah",
    "Tidak benar",
    "Tidak Benar",
    "Tidak",
    "Tidak Ada",
    "Tidak ada",
    "Belum/Tidak Tahu",
    "Belum Pernah",
    "Belum pernah",
    "Tidak tahu",
    "Tidak Tahu",
    "Tidak ingat",
    "Belum",
    "Mandiri",
    "Terkendali teratur",
    "Bertahan 10 detik",
    "SUDAH DITANYAKAN",
    "Benar semua kata",
    "Benar semua",
    "Normal",
    "Negatif",
    "Tidak ada kelainan",
    "Tidak ditemukan kelainan",
    "Nafsu Makan Biasa saja",
    "Non disabilitas",
    "Tidak batuk",
    "Tidak, Berubah",
    "Tidak Berubah",
    "Bisa bepergian keluar rumah",
    "Tidak ada serumen impaksi",
    "Normal (visus 6/6 - 6/9)",
    "Tidak ada infeksi telinga",
    "Baik",
    "8 tahun -16 tahun",
    "Benar",
    "Sudah",
]

# Atomic in-page JS to fill Reproduksi Putri
JS_FILL_REPRODUKSI_PUTRI = """
({ modeMenstruasi, modeKeputihan }) => {
    const clickOnce = (q, pred) => {
        const raw = Array.from(q.querySelectorAll('label, span.sv-string-viewer')).filter(
            e => e.offsetWidth > 0 && e.offsetHeight > 0
        );
        const lbls = raw.filter(e => !raw.some(o => o !== e && o.contains(e)));
        for (const l of lbls) {
            const textL = (l.innerText || "").trim().toLowerCase();
            if (pred(textL)) {
                const target = l.closest('label') || l;
                const inp = target.querySelector('input[type="radio"], input[type="checkbox"]');
                if (!inp || !inp.checked) target.click();
                return true;
            }
        }
        return false;
    };
    let qs = Array.from(document.querySelectorAll('.sd-question, .sv-question'));
    if (qs.length === 0) {
        qs = Array.from(document.querySelectorAll('.sd-row, .sv-row, div.mb-4, div.mb-5'));
    }
    for (const q of qs) {
        const textQ = (q.innerText || "").toLowerCase();
        if (textQ.includes('menstruasi') || textQ.includes('haid')) {
            clickOnce(q, textL => modeMenstruasi === "ya_atau_sudah"
                ? (textL === 'ya' || textL === 'iya' || textL === 'sudah')
                : (textL === 'tidak' || textL === 'belum'));
        } else if (textQ.includes('usia') || textQ.includes('menarche')) {
            clickOnce(q, textL => textL.includes('8 tahun'));
        } else if (textQ.includes('keputihan')) {
            clickOnce(q, textL => modeKeputihan === "ya_atau_sudah"
                ? (textL === 'ya' || textL === 'iya' || textL === 'sudah')
                : (textL === 'tidak' || textL === 'belum'));
        } else if (['gatal', 'keluhan', 'kencing', 'luka', 'nyeri', 'buang air', 'bak', 'bab'].some(k => textQ.includes(k))) {
            clickOnce(q, textL => textL === 'tidak' || textL === 'belum');
        }
    }
}
"""

# Atomic in-page JS to fill Reproduksi Putra
JS_FILL_REPRODUKSI_PUTRA = """
({ modePubertas }) => {
    const clickOnce = (q, pred) => {
        const raw = Array.from(q.querySelectorAll('label, span.sv-string-viewer')).filter(
            e => e.offsetWidth > 0 && e.offsetHeight > 0
        );
        const lbls = raw.filter(e => !raw.some(o => o !== e && o.contains(e)));
        for (const l of lbls) {
            const textL = (l.innerText || "").trim().toLowerCase();
            if (pred(textL)) {
                const target = l.closest('label') || l;
                const inp = target.querySelector('input[type="radio"], input[type="checkbox"]');
                if (!inp || !inp.checked) target.click();
                return true;
            }
        }
        return false;
    };
    let qs = Array.from(document.querySelectorAll('.sd-question, .sv-question'));
    if (qs.length === 0) {
        qs = Array.from(document.querySelectorAll('.sd-row, .sv-row, div.mb-4, div.mb-5'));
    }
    for (const q of qs) {
        const textQ = (q.innerText || "").toLowerCase();
        if (textQ.includes('mimpi basah') || textQ.includes('pubertas')) {
            clickOnce(q, textL => modePubertas === "ya_atau_sudah"
                ? (textL === 'ya' || textL === 'iya' || textL === 'sudah')
                : (textL === 'tidak' || textL === 'belum'));
        } else if (['gatal', 'keluhan', 'kencing', 'luka', 'nyeri', 'buang air', 'bak', 'bab'].some(k => textQ.includes(k))) {
            clickOnce(q, textL => textL === 'tidak' || textL === 'belum');
        }
    }
}
"""

# Atomic in-page JS to fill Faktor Risiko TB
JS_FILL_FAKTOR_TB = """
(targetBatuk) => {
    let qs = Array.from(document.querySelectorAll('.sd-question, .sv-question'));
    if (qs.length === 0) {
        qs = Array.from(document.querySelectorAll('.sd-row, div.mb-4, div.mb-5'));
    }
    const katakunciTidak = ['berat badan', 'demam', 'keringat', 'lesu', 'malaise', 'kontak'];
    for (const q of qs) {
        const teksQ = (q.innerText || "").toLowerCase();
        const lbls = q.querySelectorAll('label');
        if (teksQ.includes('batuk')) {
            for (const l of lbls) {
                if ((l.innerText || "").toLowerCase().includes(targetBatuk.toLowerCase())) {
                    const inp = l.querySelector('input[type="radio"], input[type="checkbox"]');
                    if (!inp || !inp.checked) l.click();
                    break;
                }
            }
        } else if (katakunciTidak.some(k => teksQ.includes(k))) {
            for (const l of lbls) {
                if ((l.innerText || "").trim() === 'Tidak') {
                    const inp = l.querySelector('input[type="radio"], input[type="checkbox"]');
                    if (!inp || !inp.checked) l.click();
                    break;
                }
            }
        }
    }
}
"""

# Atomic in-page JS to fill Imunisasi Anak Sekolah
JS_FILL_IMUNISASI = """
() => {
    let qs = Array.from(document.querySelectorAll('.sd-question, .sv-question'));
    if (qs.length === 0) {
        qs = Array.from(document.querySelectorAll('.sd-row, .sv-row, div.mb-4, div.mb-5, div.bg-white'));
    }
    let clicked = 0;
    for (const q of qs) {
        const textQ = (q.innerText || "").toLowerCase();
        if (['imunisasi', 'polio', 'campak', 'rubela', 'catatan', 'dt', 'td', 'hpv', 'bias'].some(k => textQ.includes(k))) {
            const lbls = q.querySelectorAll('label');
            for (const l of lbls) {
                const textL = (l.innerText || "").trim().toLowerCase();
                if (textL === 'ya' || textL === 'sudah') {
                    if (l.offsetWidth > 0 && l.offsetHeight > 0) {
                        const inp = l.querySelector('input[type="radio"], input[type="checkbox"]');
                        if (!inp || !inp.checked) {
                            l.click();
                            clicked++;
                        }
                        break;
                    }
                }
            }
        }
    }
    return clicked;
}
"""

# Atomic in-page JS to fill Telinga & Mata (Sniper Nakes)
JS_FILL_TELINGA_MATA = """
({ katarak, visus, kacamata, serumen }) => {
    const dedup = (arr) => arr.filter(e => !arr.some(p => p !== e && p.contains(e)));
    const clickIfUnchecked = (el) => {
        if (!el) return;
        const target = el.closest('label') || el;
        const inp = target.querySelector('input[type="radio"], input[type="checkbox"]');
        if (!inp || !inp.checked) target.click();
    };

    // 1. Default all visible normal/tidak options first
    const labels = dedup(Array.from(document.querySelectorAll('label, span.sv-string-viewer')).filter(
        e => e.offsetWidth > 0 && e.offsetHeight > 0
    ));
    labels.forEach(e => {
        if (!e.innerText) return;
        const txt = e.innerText.trim().toLowerCase();
        if (txt.includes('normal') || txt.includes('tidak ada serumen') || txt.includes('tidak ada infeksi') || txt === 'tidak') {
            clickIfUnchecked(e);
        }
    });

    // 2. Override Kelainan Mata / Katarak
    const katLower = (katarak || "").toLowerCase();
    if (katLower && katLower !== "normal" && katLower !== "tidak" && katLower !== "0") {
        let els = dedup(Array.from(document.querySelectorAll('label, span.sv-string-viewer')).filter(e =>
            e.innerText && (e.innerText.trim().toLowerCase().includes('curiga kelainan mata') || e.innerText.trim().toLowerCase().includes('curiga katarak')) && e.offsetWidth > 0 && e.offsetHeight > 0
        ));
        if (katLower.includes('kanan') && els[0]) clickIfUnchecked(els[0]);
        if (katLower.includes('kiri') && els[1]) clickIfUnchecked(els[1]);
        if (!katLower.includes('kanan') && !katLower.includes('kiri')) {
            if (els[0]) clickIfUnchecked(els[0]);
            if (els[1]) clickIfUnchecked(els[1]);
        }
    }

    // 3. Override Visus
    const visLower = (visus || "").toLowerCase();
    if (visLower && visLower !== "normal" && visLower !== "tidak" && visLower !== "0") {
        let els = dedup(Array.from(document.querySelectorAll('label, span.sv-string-viewer')).filter(e =>
            e.innerText && e.innerText.trim().toLowerCase().includes('ada indikasi gangguan penglihatan') && e.offsetWidth > 0 && e.offsetHeight > 0
        ));
        if (visLower.includes('kanan') && els[0]) clickIfUnchecked(els[0]);
        if (visLower.includes('kiri') && els[1]) clickIfUnchecked(els[1]);
        if (!visLower.includes('kanan') && !visLower.includes('kiri')) {
            if (els[0]) clickIfUnchecked(els[0]);
            if (els[1]) clickIfUnchecked(els[1]);
        }
    }

    // 4. Override Kacamata
    const kmLower = (kacamata || "").toLowerCase();
    if (kmLower === "ya" || kmLower === "iya" || kmLower === "pakai") {
        const qs = Array.from(document.querySelectorAll('.sd-question, .sv-question, .sd-row, .sv-row, div.mb-4, div.mb-5'));
        for (const q of qs) {
            if ((q.innerText || "").toLowerCase().includes('kacamata')) {
                for (const l of q.querySelectorAll('label')) {
                    if ((l.innerText || "").trim().toLowerCase() === 'ya') { clickIfUnchecked(l); break; }
                }
            }
        }
    }

    // 5. Override Serumen & Pendengaran
    const serLower = (serumen || "").toLowerCase();
    if (serLower && serLower !== "normal" && serLower !== "tidak" && serLower !== "0") {
        let elsSer = dedup(Array.from(document.querySelectorAll('label, span.sv-string-viewer')).filter(e =>
            e.innerText && e.innerText.trim().toLowerCase() === 'ada serumen impaksi' && e.offsetWidth > 0 && e.offsetHeight > 0
        ));
        let elsPen = dedup(Array.from(document.querySelectorAll('label, span.sv-string-viewer')).filter(e =>
            e.innerText && e.innerText.trim().toLowerCase() === 'ada indikasi gangguan pendengaran' && e.offsetWidth > 0 && e.offsetHeight > 0
        ));
        if (serLower.includes('kanan')) {
            if (elsSer[0]) clickIfUnchecked(elsSer[0]);
            if (elsPen[0]) clickIfUnchecked(elsPen[0]);
        }
        if (serLower.includes('kiri')) {
            if (elsSer[1]) clickIfUnchecked(elsSer[1]);
            if (elsPen[1]) clickIfUnchecked(elsPen[1]);
        }
        if (!serLower.includes('kanan') && !serLower.includes('kiri')) {
            if (elsSer[0]) clickIfUnchecked(elsSer[0]);
            if (elsPen[0]) clickIfUnchecked(elsPen[0]);
        }
    }
}
"""

# Click the SurveyJS / Modal "Kirim" button atomically (never "Kirim Rapor")
JS_CLICK_KIRIM = """
() => {
    const selectors = ['input.sd-navigation__complete-btn', 'input[title="Kirim"]', 'input[value="Kirim"]', 'button'];
    for (const sel of selectors) {
        const els = document.querySelectorAll(sel);
        for (const el of els) {
            if (el.offsetWidth > 0 && el.offsetHeight > 0) {
                const text = (el.value || el.innerText || el.title || "").toLowerCase().trim();
                if (
                    text === 'kirim' ||
                    (text.includes('kirim') && !text.includes('rapor')) ||
                    el.classList.contains('sd-navigation__complete-btn')
                ) {
                    el.click();
                    return true;
                }
            }
        }
    }
    return false;
}
"""
