#!/usr/bin/env python3
"""
Owner Studio CLI for CKG Terpadu V3.5 (Sekolah & Umum).
Usage examples:
  python3 -m ckg_turbo.saas_cli generate --client "Puskesmas Sei Panas" --plan PRO_PUSKESMAS --faskes "PUSKESMAS SEI PANAS"
  python3 -m ckg_turbo.saas_cli verify --key "CKG-V3...."
  python3 -m ckg_turbo.saas_cli enable-owner
"""
from __future__ import annotations

import argparse
from pathlib import Path

from .saas import PLAN_DEFINITIONS, LicenseManager
from .state_db import StateDB


def main() -> None:
    parser = argparse.ArgumentParser(description="CKG Terpadu V3.5 — Owner License Generator CLI")
    sub = parser.add_subparsers(dest="cmd", required=True)

    gen_p = sub.add_parser("generate", help="Buat Kode Lisensi untuk Puskesmas Klien")
    gen_p.add_argument("--client", required=True, help="Nama Puskesmas / Instansi Klien")
    gen_p.add_argument(
        "--plan",
        default="PRO_PUSKESMAS",
        choices=list(PLAN_DEFINITIONS.keys()),
        help="Pilihan Paket Layanan",
    )
    gen_p.add_argument("--faskes", default="*", help="Kunci Nama Puskesmas (atau * untuk semua)")
    gen_p.add_argument("--days", type=int, default=0, help="Masa aktif dalam hari (0 = default paket)")
    gen_p.add_argument("--quota", type=int, default=0, help="Kuota peserta (0 = default paket)")
    gen_p.add_argument("--hw", default="*", help="Kunci kode perangkat (CKG-XXXX-XXXX-XXXX atau *)")

    ver_p = sub.add_parser("verify", help="Periksa keabsahan Kode Lisensi")
    ver_p.add_argument("--key", required=True, help="Kode Lisensi CKG-V3...")

    sub.add_parser("enable-owner", help="Aktifkan Mode Owner Studio di komputer ini")

    args = parser.parse_args()
    repo_root = Path(__file__).resolve().parent.parent

    if args.cmd == "enable-owner":
        marker = repo_root / ".owner_studio.key"
        marker.write_text("CKG-OWNER-STUDIO-ENABLED\n", encoding="utf-8")
        print(f"✅ Mode Owner Studio diaktifkan di: {marker}")
        return

    if args.cmd == "generate":
        meta = PLAN_DEFINITIONS[args.plan]
        days = args.days if args.days > 0 else meta["default_days"]
        quota = args.quota if args.quota > 0 else meta["default_quota"]
        key = LicenseManager.generate_license_key(
            client_name=args.client,
            plan=args.plan,
            faskes_lock=args.faskes,
            days_valid=days,
            quota_limit=quota,
            machine_lock=args.hw,
        )
        print("\n=======================================================")
        print("✨ KODE LISENSI RESMI CKG TERPADU V3.5 CLINICAL PRO ✨")
        print("=======================================================")
        print(f"Instansi    : {args.client}")
        print(f"Paket       : {meta['name']} ({args.plan})")
        print(f"Kunci Faskes: {args.faskes}")
        print(f"Kunci Mesin : {args.hw}")
        print(f"Masa Aktif  : {days} Hari")
        print(f"Kuota       : {quota:,} Peserta")
        print("-------------------------------------------------------")
        print(f"KODE LISENSI:\n{key}")
        print("=======================================================\n")
        return

    if args.cmd == "verify":
        db = StateDB(repo_root / "data" / "ckg_state.db")
        lm = LicenseManager(db, base_dir=repo_root)
        ok, msg, payload = lm.verify_license_key(args.key)
        print(f"Status : {'✅ VALID' if ok else '❌ TIDAK VALID'} — {msg}")
        if payload:
            for k, v in payload.items():
                print(f"  {k}: {v}")


if __name__ == "__main__":
    main()

