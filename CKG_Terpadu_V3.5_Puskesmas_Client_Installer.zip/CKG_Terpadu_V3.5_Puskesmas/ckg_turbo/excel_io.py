from __future__ import annotations

import datetime as dt
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

from .models import DataQualitySummary, StudentRecord

# Standard 33 column headers in the CKG Sekolah Excel template (indices 0..32)
TEMPLATE_COLUMNS: List[str] = [
    "NIK",                          # 0
    "Nama Lengkap",                 # 1
    "Tanggal Lahir",                # 2
    "Jenis Kelamin",                # 3
    "No WhatsApp",                  # 4
    "Nama Sekolah",                 # 5
    "Kelas",                        # 6
    "Provinsi",                     # 7
    "Kab/Kota",                     # 8
    "Kecamatan",                    # 9
    "Desa/Kelurahan",               # 10
    "Detail Alamat",                # 11
    "Batuk TB",                     # 12
    "Keputihan (Putri)",            # 13
    "Perilaku Merokok",             # 14
    "Aktivitas Fisik",              # 15
    "Berat Badan (kg)",             # 16
    "Tinggi Badan (cm)",            # 17
    "Riwayat DM",                   # 18
    "Lama DM (Bulan)",              # 19
    "GDS (mg/dL)",                  # 20
    "Sistolik (mmHg)",              # 21
    "Diastolik (mmHg)",             # 22
    "Curiga Katarak/Kelainan Mata", # 23
    "Visus Mata",                   # 24
    "Kacamata",                     # 25
    "Serumen/Pendengaran",          # 26
    "Gigi Karies",                  # 27
    "Kadar CO",                     # 28
    "Malaria",                      # 29
    "Hepatitis B",                  # 30
    "Hepatitis C",                  # 31
    "Hb / Anemia",                  # 32
]

# Standard 37 column headers in the CKG Umum Excel template (Data_Siap_CKG, indices 0..36)
TEMPLATE_UMUM_COLUMNS: List[str] = [
    "NIK",                          # 0
    "Nama",                         # 1
    "Tanggal Lahir",                # 2
    "Jenis Kelamin",                # 3
    "WhatsApp",                     # 4
    "Tanggal Pemeriksaan",          # 5
    "Status Pernikahan",            # 6
    "Pekerjaan",                    # 7
    "Provinsi",                     # 8
    "Kab/Kota",                     # 9
    "Kecamatan",                    # 10
    "Desa/Kelurahan",               # 11
    "Detail Alamat",                # 12
    "Riwayat Hubungan Intim",       # 13
    "Perilaku Merokok",             # 14
    "Aktifitas Fisik",              # 15
    "Berat Badan",                  # 16
    "Tinggi Badan",                 # 17
    "Lingkar Perut",                # 18
    "Riwayat Diabetes",             # 19
    "Lama Diabetes",                # 20
    "Gula Darah Sewaktu",           # 21
    "Riwayat Hipertensi",           # 22
    "Lama Hipertensi",              # 23
    "Sistolik",                     # 24
    "Diastolik",                    # 25
    "Curiga Katarak",               # 26
    "Gigi Karies",                  # 27
    "Gigi Hilang",                  # 28
    "Skrining Payudara",            # 29
    "Kadar CO (ppm)",               # 30
    "Hb Catin Perempuan",           # 31
    "Kolesterol Total",             # 32
    "HDL",                          # 33
    "LDL",                          # 34
    "Trigliserida",                 # 35
    "Hasil EKG Jantung",            # 36
]

# Header aliases for Smart Pro V3 header-based mapping
HEADER_ALIASES: Dict[str, List[str]] = {
    "nik": ["nik", "no nik", "nomor induk kependudukan", "nik siswa"],
    "nama": ["nama lengkap", "nama", "nama siswa", "nama peserta"],
    "tgl_lahir": ["tanggal lahir", "tgl lahir", "dob", "birth date", "tgllahir"],
    "jk": ["jenis kelamin", "jk", "gender", "kelamin", "l/p"],
    "wa": ["no whatsapp", "whatsapp", "no wa", "no hp", "telepon", "no telp", "nomor whatsapp"],
    "sekolah": ["nama sekolah", "sekolah", "asal sekolah", "satuan pendidikan"],
    "kelas": ["kelas", "jenjang", "tingkat", "rombel"],
    "provinsi": ["provinsi", "propinsi", "prov"],
    "kabkota": ["kab/kota", "kabupaten/kota", "kabupaten", "kota", "kab"],
    "kecamatan": ["kecamatan", "kec"],
    "desa": ["desa/kelurahan", "kelurahan", "desa", "kel"],
    "alamat": ["detail alamat", "alamat", "alamat lengkap", "alamat domisili"],
    "batuk_tb": ["batuk tb", "batuk", "skrining tb"],
    "keputihan": ["keputihan (putri)", "keputihan", "reproduksi putri"],
    "merokok": ["perilaku merokok", "merokok", "rokok"],
    "aktivitas": ["aktivitas fisik", "olahraga", "aktivitas"],
    "berat": ["berat badan (kg)", "berat badan", "bb", "berat (kg)", "berat"],
    "tinggi": ["tinggi badan (cm)", "tinggi badan", "tb", "tinggi (cm)", "tinggi"],
    "riwayat_dm": ["riwayat dm", "diabetes", "dm"],
    "lama_dm": ["lama dm (bulan)", "lama dm", "durasi dm"],
    "gds": ["gds (mg/dl)", "gds", "gula darah", "gula darah sewaktu"],
    "sistolik": ["sistolik (mmhg)", "sistolik", "tensi atas", "tds"],
    "diastolik": ["diastolik (mmhg)", "diastolik", "tensi bawah", "tdd"],
    "katarak": ["curiga katarak/kelainan mata", "curiga katarak", "kelainan mata", "katarak"],
    "visus": ["visus mata", "visus", "tajam penglihatan"],
    "kacamata": ["kacamata", "pakai kacamata"],
    "serumen": ["serumen/pendengaran", "serumen", "telinga", "pendengaran"],
    "gigi": ["gigi karies", "karies gigi", "karies", "gigi"],
    "co": ["kadar co", "co", "karbon monoksida"],
    "malaria": ["malaria", "rdt malaria"],
    "hepb": ["hepatitis b", "hbsag", "hep b"],
    "hepc": ["hepatitis c", "anti hcv", "hep c"],
    "hb": ["hb / anemia", "hb", "hemoglobin", "anemia"],
}

BULAN_INDO_MAP = {
    "januari": 1, "jan": 1, "january": 1,
    "februari": 2, "feb": 2, "february": 2,
    "maret": 3, "mar": 3, "march": 3,
    "april": 4, "apr": 4,
    "mei": 5, "may": 5,
    "juni": 6, "jun": 6, "june": 6,
    "juli": 7, "jul": 7, "july": 7,
    "agustus": 8, "agu": 8, "agt": 8, "aug": 8, "august": 8,
    "september": 9, "sep": 9, "sept": 9,
    "oktober": 10, "okt": 10, "oct": 10, "october": 10,
    "november": 11, "nov": 11,
    "desember": 12, "des": 12, "dec": 12, "december": 12,
}

KAMUS_BULAN_UI = [
    "", "Jan", "Feb", "Mar", "Apr", "Mei", "Jun",
    "Jul", "Agt", "Sep", "Okt", "Nov", "Des",
]

ROMAN_CLASS_MAP = {
    "I": "1", "II": "2", "III": "3", "IV": "4", "V": "5", "VI": "6",
    "VII": "7", "VIII": "8", "IX": "9", "X": "10", "XI": "11", "XII": "12",
}


def bersihkan_nama_sekolah(nama: str) -> str:
    """
    Exact V2.6 school name cleaner (lines 144-150 of Robot_CKG_Sekolah_V2.py):
    Strips any leading text before the school level keyword (SDN, SD, SMPN, SMP, etc.).
    """
    if not nama:
        return ""
    teks = re.sub(r"\s+", " ", str(nama)).strip()
    pola = r"\b(SDN|SD|SMPN|SMPS|SMP|SMAN|SMAS|SMA|SMKN|SMKS|SMK|MIN|MTSN|MTS|MAN|MAS|MA|TK|PAUD|KB|SLB)\b"
    cocok = re.search(pola, teks, re.IGNORECASE)
    if cocok:
        return teks[cocok.start():].strip()
    return teks


def build_school_candidates(nama_mentah: str) -> List[str]:
    """
    Build ordered list of school search candidates so dropdown search succeeds whether
    Kemenkes lists the school as 'SD NEGERI 005 BENGKONG' or 'SDN 005 BENGKONG'.
    """
    utama = bersihkan_nama_sekolah(nama_mentah)
    if not utama:
        return []

    candidates: List[str] = [utama]

    # Variant 2: Expand abbreviations (SDN -> SD NEGERI, SMPN -> SMP NEGERI, etc.)
    expanded = utama
    for abbr, full in (
        (r"\bSDN\b", "SD NEGERI"),
        (r"\bSMPN\b", "SMP NEGERI"),
        (r"\bSMAN\b", "SMA NEGERI"),
        (r"\bSMKN\b", "SMK NEGERI"),
        (r"\bMIN\b", "MI NEGERI"),
        (r"\bMTSN\b", "MTS NEGERI"),
        (r"\bMAN\b", "MA NEGERI"),
    ):
        expanded = re.sub(abbr, full, expanded, flags=re.IGNORECASE)
    expanded = re.sub(r"\s+", " ", expanded).strip()
    if expanded not in candidates:
        candidates.append(expanded)

    # Variant 3: Abbreviate (SD NEGERI -> SDN, SMP NEGERI -> SMPN, etc.)
    abbreviated = utama
    for full, abbr in (
        (r"\bSD\s+NEGERI\b", "SDN"),
        (r"\bSMP\s+NEGERI\b", "SMPN"),
        (r"\bSMA\s+NEGERI\b", "SMAN"),
        (r"\bSMK\s+NEGERI\b", "SMKN"),
        (r"\bMI\s+NEGERI\b", "MIN"),
        (r"\bMTS\s+NEGERI\b", "MTSN"),
        (r"\bMA\s+NEGERI\b", "MAN"),
    ):
        abbreviated = re.sub(full, abbr, abbreviated, flags=re.IGNORECASE)
    abbreviated = re.sub(r"\s+", " ", abbreviated).strip()
    if abbreviated not in candidates:
        candidates.append(abbreviated)

    # Variant 4: Without zero-padding in school number (e.g. 005 -> 5) and vice versa
    no_leading_zeros = re.sub(r"\b0+(\d+)\b", r"\1", utama)
    if no_leading_zeros not in candidates:
        candidates.append(no_leading_zeros)

    return candidates


DEFAULT_FALLBACK_WA = "081234567890"


def heal_whatsapp_number(raw_wa: str) -> Tuple[str, bool]:
    """
    Normalize Indonesian WhatsApp numbers and restore leading '0' stripped by Excel numeric formatting.
    Returns (normalized_wa, was_healed).
    """
    if not raw_wa:
        return (DEFAULT_FALLBACK_WA, True)
    digits = re.sub(r"\D", "", str(raw_wa))
    if not digits:
        return (DEFAULT_FALLBACK_WA, True)

    healed = False
    if digits.startswith("628"):
        digits = "0" + digits[2:]
        healed = True
    elif digits.startswith("8") and 8 <= len(digits) <= 13:
        digits = "0" + digits
        healed = True
    elif not digits.startswith("08"):
        if len(digits) >= 8:
            digits = "08" + digits[-10:]
            healed = True
        else:
            return (DEFAULT_FALLBACK_WA, True)

    if len(digits) < 10:
        digits = digits.ljust(11, "0")
        healed = True
    elif len(digits) > 13:
        digits = digits[:13]
        healed = True

    return (digits, healed or (digits != str(raw_wa).strip()))


def normalize_kelas(raw_kelas: str) -> Tuple[str, str]:
    """
    Normalize class values like '4', 'Kelas 4', '4A', 'IV', 'Kelas 4 B' -> ('Kelas 4', '4').
    """
    if not raw_kelas:
        return ("", "")
    s = re.sub(r"(?i)^(kelas|kls|class|tingkat)\s*", "", str(raw_kelas)).strip()
    if s.endswith(".0"):
        s = s[:-2].strip()
    upper = s.upper()
    if upper in ROMAN_CLASS_MAP:
        s = ROMAN_CLASS_MAP[upper]
    else:
        m_num = re.match(r"^(\d{1,2})", s)
        if m_num:
            s = m_num.group(1)
    if not s:
        return ("", "")
    return (f"Kelas {s}", s)


def _clean_cell(val: Any, strip_decimal_zero: bool = False) -> str:
    if val is None:
        return ""
    if isinstance(val, (dt.datetime, dt.date)):
        return val.strftime("%Y-%m-%d")
    s = str(val).strip()
    if s.startswith("'"):
        s = s[1:].strip()
    if s.lower() in ("nan", "none", "null", "nat"):
        return ""
    if strip_decimal_zero and s.endswith(".0"):
        s = s[:-2]
    return s.strip()


def _clean_numeric_str(val: Any, allow_decimal: bool = True) -> Tuple[str, bool]:
    raw = _clean_cell(val, strip_decimal_zero=True)
    if not raw:
        return ("", False)
    s = raw.replace(",", ".")
    s = re.sub(r"[^0-9.]", "", s)
    if not s:
        return ("", False)
    try:
        num = float(s)
        if not allow_decimal or num.is_integer():
            cleaned = str(int(round(num)))
        else:
            cleaned = f"{num:.1f}".rstrip("0").rstrip(".")
        return (cleaned, cleaned != raw)
    except ValueError:
        return (raw, False)


def parse_tanggal_lahir(raw_val: str) -> Tuple[str, str, int, str, str, int]:
    """
    Parse flexible date strings into:
    (target_tahun, target_bulan_teks, target_bulan_idx, target_tanggal, tgl_iso, umur)
    """
    if not raw_val:
        return ("", "", 0, "", "", 10)

    s = raw_val.strip().lower()
    for indo, m_num in BULAN_INDO_MAP.items():
        s = re.sub(rf"\b{indo}\b", f"{m_num:02d}", s, flags=re.IGNORECASE)

    parsed_date: Optional[dt.date] = None
    m_ymd = re.match(r"^(\d{4})[-/. ]+(\d{1,2})[-/. ]+(\d{1,2})", s)
    if m_ymd:
        y, m, d = int(m_ymd.group(1)), int(m_ymd.group(2)), int(m_ymd.group(3))
        if m > 12 and d <= 12:
            m, d = d, m
        try:
            parsed_date = dt.date(y, m, d)
        except ValueError:
            parsed_date = None

    if parsed_date is None:
        m_dmy = re.match(r"^(\d{1,2})[-/. ]+(\d{1,2})[-/. ]+(\d{4})", s)
        if m_dmy:
            d, m, y = int(m_dmy.group(1)), int(m_dmy.group(2)), int(m_dmy.group(3))
            if m > 12 and d <= 12:
                d, m = m, d
            try:
                parsed_date = dt.date(y, m, d)
            except ValueError:
                parsed_date = None

    if parsed_date is None:
        return ("", "", 0, "", raw_val, 10)

    today = dt.date.today()
    umur = today.year - parsed_date.year - (
        (today.month, today.day) < (parsed_date.month, parsed_date.day)
    )
    return (
        str(parsed_date.year),
        KAMUS_BULAN_UI[parsed_date.month],
        parsed_date.month,
        str(parsed_date.day),
        parsed_date.strftime("%Y-%m-%d"),
        max(1, umur),
    )


def swap_day_month_if_possible(record: StudentRecord) -> bool:
    """
    Smart Sensor (Jurus Tukar Tanggal Lahir & Bulan) when Disdukcapil rejects DOB:
    If day <= 12 and day != month, swaps day and month in-place and returns True.
    """
    try:
        day_int = int(record.target_tanggal)
        month_int = int(record.target_bulan_idx)
        year_int = int(record.target_tahun)
        if 1 <= day_int <= 12 and 1 <= month_int <= 12 and day_int != month_int:
            new_date = dt.date(year_int, day_int, month_int)
            record.target_bulan_idx = new_date.month
            record.target_bulan_teks = KAMUS_BULAN_UI[new_date.month]
            record.target_tanggal = str(new_date.day)
            record.tgl_iso = new_date.strftime("%Y-%m-%d")
            return True
    except Exception:
        pass
    return False


def _detect_column_offset(
    header_row: Tuple[Any, ...],
    sheet_names: Optional[List[str]] = None,
) -> Tuple[int, str, str]:
    """
    Detect if the uploaded Excel is:
    - Previously exported Report Excel (has 'Tatalaksana', 'Status Rapor', 'No Tiket', 'Status Sistem' at col 0..3)
    - CKG Umum (37 Kolom / Data_Siap_CKG)
    - Smart Pro V3 format
    - Standard V2.6 33-Column format
    Returns (col_offset, format_name, service_type) where service_type in ('sekolah', 'umum').
    """
    all_cells = [_clean_cell(c).lower() for c in header_row[:42]]
    col_offset = 0
    is_report = len(all_cells) >= 5 and "tatalaksana" in all_cells[0] and "status" in all_cells[1]
    if is_report:
        col_offset = 4

    data_cells = all_cells[col_offset:]
    umum_keywords = (
        "tanggal pemeriksaan",
        "status pernikahan",
        "lingkar perut",
        "riwayat hipertensi",
        "skrining payudara",
        "kolesterol total",
        "gigi hilang",
    )
    sheet_str = " ".join((s or "").lower() for s in (sheet_names or []))
    is_umum = any(any(kw in c for kw in umum_keywords) for c in data_cells) or (
        "data_siap_ckg" in sheet_str or ("umum" in sheet_str and "sekolah" not in sheet_str)
    )

    if is_umum:
        if is_report:
            return (4, "Laporan CKG Umum (Auto-Unwrapped)", "umum")
        return (0, "Format Standar CKG Umum (37 Kolom)", "umum")

    if is_report:
        return (4, "Laporan CKG Sekolah (Auto-Unwrapped)", "sekolah")
    for c in data_cells[:12]:
        if "smart pro" in c or "wa (08" in c:
            return (0, "CKG Smart Pro V3 (33 Kolom Validated)", "sekolah")
    return (0, "Format Standar CKG Sekolah (33 Kolom)", "sekolah")


def _normalize_status_pernikahan(raw_val: str, umur: int) -> str:
    s = (raw_val or "").strip().lower()
    if "cerai mati" in s or "janda" in s or "duda" in s:
        return "Cerai Mati"
    if "cerai hidup" in s or "cerai" in s:
        return "Cerai Hidup"
    if "belum" in s or "single" in s or "lajang" in s or "tidak kawin" in s:
        return "Belum Menikah"
    if "menikah" in s or "kawin" in s:
        return "Menikah"
    return "Menikah" if umur >= 23 else "Belum Menikah"


def _normalize_pekerjaan(raw_val: str) -> str:
    s = (raw_val or "").strip()
    if not s:
        return "Lainnya"
    sl = s.lower()
    if "asn" in sl or "pns" in sl or "pemerintah" in sl:
        return "ASN (Kantor Pemerintah)"
    if "ibu rumah tangga" in sl or sl == "irt" or "mengurus rumah" in sl:
        return "Ibu Rumah Tangga"
    if "belum" in sl or "tidak bekerja" in sl or "pelajar" in sl or "mahasiswa" in sl:
        return "Belum/Tidak Bekerja"
    if "swasta" in sl or "karyawan" in sl:
        return "Pegawai Swasta"
    if "petani" in sl or "pekebun" in sl:
        return "Petani / Pekebun"
    return s


def _clean_blangko_clinical_flag(val: Any, default: str = "Tidak") -> str:
    s = _clean_cell(val, strip_decimal_zero=True)
    sl = s.lower()
    if not sl or sl in (
        "-",
        "tidak",
        "tidaj",
        "ttidak",
        "tidsk",
        "tisak",
        "todal",
        "normal",
        "tidak infeksi",
        "bukan kusta",
        "bukan skabies",
        "bukan frambusia",
    ):
        return default
    return s


def _is_blangko_kemenkes_sheet(ws: Any) -> bool:
    """Detect official Kemenkes/Puskesmas CKG Sekolah multi-row header sheet (Row 3 Nama Sekolah, Row 6 Identitas Anak Sekolah)."""
    try:
        for r in range(1, min(10, ws.max_row + 1)):
            row_str = " ".join(
                _clean_cell(ws.cell(r, c).value).lower() for c in range(1, min(12, ws.max_column + 1))
            )
            if "identitas anak sekolah" in row_str or "identitas wali" in row_str:
                return True
    except Exception:
        pass
    return False


def _load_blangko_kemenkes_workbook(wb: Any) -> Tuple[List[StudentRecord], DataQualitySummary]:
    """
    Parse official Kemenkes/Puskesmas multi-sheet CKG Sekolah format ('Kelas 1' .. 'Kelas 6' / 'Kelas 12')
    where Row 3 has 'Nama Sekolah:', Row 6..9 has multi-level headers, and Row 10+ has student rows.
    """
    quality = DataQualitySummary(
        format_detected="Blangko Kemenkes CKG Sekolah TA 2026/2027 (Auto-Converted)",
        service_type="sekolah",
    )
    records: List[StudentRecord] = []

    target_sheets = [
        wb[name]
        for name in wb.sheetnames
        if "tabel" not in name.lower()
        and "panduan" not in name.lower()
        and _is_blangko_kemenkes_sheet(wb[name])
    ]
    if not target_sheets and _is_blangko_kemenkes_sheet(wb.active):
        target_sheets = [wb.active]

    for ws in target_sheets:
        raw_school = ""
        for r in range(1, 7):
            for c in range(1, 8):
                v = _clean_cell(ws.cell(r, c).value)
                if "nama sekolah" in v.lower():
                    nxt = _clean_cell(ws.cell(r, c + 1).value).lstrip(":").strip()
                    if nxt:
                        raw_school = nxt
                        break
            if raw_school:
                break
        if not raw_school:
            raw_school = "SD NEGERI"
        nama_sekolah_bersih = bersihkan_nama_sekolah(raw_school)
        sekolah_candidates = build_school_candidates(raw_school)

        kelas, kelas_angka = normalize_kelas(ws.title)
        if not kelas:
            kelas, kelas_angka = ("Kelas 1", "1")

        for r in range(10, ws.max_row + 1):
            raw_nik = _clean_cell(ws.cell(r, 2).value, strip_decimal_zero=True)
            nik = re.sub(r"\D", "", raw_nik)
            nama = re.sub(r"\s+", " ", _clean_cell(ws.cell(r, 3).value)).strip()
            if not nik and not nama:
                continue

            healed_notes: List[str] = []
            warning_parts: List[str] = []
            if len(nik) != 16:
                quality.invalid_nik_count += 1
                warning_parts.append(f"NIK {len(nik)} digit")

            tgl_mentah = _clean_cell(ws.cell(r, 4).value)
            t_tahun, t_bln_teks, t_bln_idx, t_tgl, tgl_iso, umur = parse_tanggal_lahir(tgl_mentah)
            if not t_tahun:
                quality.missing_dob_count += 1
                warning_parts.append("Tgl Lahir kosong/invalid")

            jk_mentah = _clean_cell(ws.cell(r, 6).value).lower()
            jk_pasien = (
                "Perempuan"
                if jk_mentah in ("female", "perempuan", "wanita", "p", "pr", "f", "cewek", "putri")
                else "Laki-laki"
            )

            wa_anak = _clean_cell(ws.cell(r, 7).value, strip_decimal_zero=True)
            wa_wali = _clean_cell(ws.cell(r, 12).value, strip_decimal_zero=True)
            wa_mentah = wa_anak if (wa_anak and wa_anak != "-") else wa_wali
            wa_pasien, wa_healed = heal_whatsapp_number(wa_mentah)
            if wa_healed:
                quality.healed_wa_count += 1
                healed_notes.append(f"WA '{wa_mentah or '-'}' -> '{wa_pasien}'")

            alamat = _clean_cell(ws.cell(r, 13).value)
            if not alamat or alamat == "-":
                alamat = "BENGKONG"
            kelurahan = _clean_cell(ws.cell(r, 14).value)
            if not kelurahan or kelurahan == "-":
                kelurahan = "SADAI"

            berat, b_healed = _clean_numeric_str(ws.cell(r, 16).value, allow_decimal=True)
            if berat:
                try:
                    if float(berat) < 10.0:
                        berat = str(int(round(float(berat) * 10.0)))
                        b_healed = True
                        healed_notes.append(f"Berat Badan outlier diperbaiki ke {berat} kg")
                except ValueError:
                    pass
            tinggi, t_healed = _clean_numeric_str(ws.cell(r, 17).value, allow_decimal=True)
            sistolik, s_healed = _clean_numeric_str(ws.cell(r, 20).value, allow_decimal=False)
            diastolik, d_healed = _clean_numeric_str(ws.cell(r, 21).value, allow_decimal=False)
            if any((b_healed, t_healed, s_healed, d_healed)):
                quality.healed_numeric_count += 1

            gigi_karies = _clean_blangko_clinical_flag(ws.cell(r, 26).value, default="Tidak")
            serumen_mentah = _clean_blangko_clinical_flag(ws.cell(r, 29).value, default="normal").lower()
            curiga_katarak = _clean_blangko_clinical_flag(ws.cell(r, 30).value, default="normal").lower()
            visus_mentah = _clean_blangko_clinical_flag(ws.cell(r, 31).value, default="normal").lower()
            kacamata_mentah = _clean_blangko_clinical_flag(ws.cell(r, 32).value, default="tidak").lower()

            rec = StudentRecord(
                row_index=len(records),
                nik=nik,
                nama=nama,
                tgl_lahir_mentah=tgl_mentah,
                target_tahun=t_tahun,
                target_bulan_teks=t_bln_teks,
                target_bulan_idx=t_bln_idx,
                target_tanggal=t_tgl,
                tgl_iso=tgl_iso,
                umur=umur,
                jk_mentah=jk_mentah,
                jk_pasien=jk_pasien,
                wa_mentah=wa_mentah,
                wa_pasien=wa_pasien,
                nama_sekolah=raw_school,
                nama_sekolah_bersih=nama_sekolah_bersih,
                sekolah_candidates=sekolah_candidates,
                kelas_mentah=ws.title,
                kelas=kelas,
                kelas_angka=kelas_angka,
                provinsi="KEPULAUAN RIAU",
                kabkota="KOTA BATAM",
                kecamatan="BENGKONG",
                desa=kelurahan,
                detail_alamat=alamat,
                batuk_tb="tidak",
                keputihan_putri="tidak",
                perilaku_merokok="tidak",
                aktivitas_fisik="ya",
                berat=berat or "30",
                tinggi=tinggi or "135",
                riwayat_dm="tidak",
                lama_dm="",
                gds="95",
                sistolik=sistolik or "100",
                diastolik=diastolik or "60",
                curiga_katarak=curiga_katarak,
                visus_mentah=visus_mentah,
                kacamata_mentah=kacamata_mentah,
                serumen_mentah=serumen_mentah,
                gigi_karies=gigi_karies,
                kadar_co_mentah="",
                malaria_mentah="Non-Reaktif",
                hepb_mentah="Non Reaktif",
                hepc_mentah="Non Reaktif",
                hb_anemia_mentah="",
                service_type="sekolah",
                healed_notes=healed_notes,
                validation_warning=", ".join(warning_parts),
            )
            records.append(rec)

    wb.close()
    quality.total_rows = len(records)
    quality.valid_rows = sum(1 for r in records if not r.validation_warning)
    return (records, quality)


def load_students_with_quality(
    excel_path: str | Path,
) -> Tuple[List[StudentRecord], DataQualitySummary]:
    """
    Load, validate, and auto-heal all rows from either:
    - CKG Sekolah (33-column Excel file / Report / Smart Pro V3 / Blangko Kemenkes TA 2026/2027)
    - CKG Umum (37-column Data_Siap_CKG Excel file / Report / Smart Pro V3)
    """
    wb = openpyxl.load_workbook(excel_path, data_only=True)
    if any(_is_blangko_kemenkes_sheet(wb[name]) for name in wb.sheetnames):
        return _load_blangko_kemenkes_workbook(wb)
    # Prefer sheet named 'Data_Siap_CKG', 'Data Siswa CKG', 'Laporan CKG...', or first non-guide/non-summary sheet
    ws = wb.active
    for name in wb.sheetnames:
        nl = name.lower()
        if (
            "panduan" not in nl
            and "kode" not in nl
            and "referensi" not in nl
            and "ringkasan" not in nl
        ):
            ws = wb[name]
            break

    rows = list(ws.iter_rows(values_only=True))
    quality = DataQualitySummary()
    if not rows:
        wb.close()
        return ([], quality)

    start_idx = 1
    first_cell = _clean_cell(rows[0][0], strip_decimal_zero=True)
    col_offset = 0
    service_type = "sekolah"
    if first_cell.isdigit() and len(first_cell) >= 12:
        start_idx = 0
        if len(rows[0]) >= 36:
            service_type = "umum"
            quality.format_detected = "Tanpa Header CKG Umum (37 Kolom Raw)"
        else:
            quality.format_detected = "Tanpa Header CKG Sekolah (33 Kolom Raw)"
    else:
        col_offset, fmt_name, service_type = _detect_column_offset(rows[0], wb.sheetnames)
        quality.format_detected = fmt_name
        # Check if row 2 is a subheader/instruction row in Smart Pro template
        if len(rows) > 1:
            second_first = _clean_cell(rows[1][col_offset], strip_decimal_zero=True).lower()
            if second_first in ("wajib 16 digit", "contoh:", "petunjuk"):
                start_idx = 2

    quality.service_type = service_type
    records: List[StudentRecord] = []
    min_cols = 37 if service_type == "umum" else 33

    for idx, raw_row in enumerate(rows[start_idx:]):
        if not raw_row:
            continue
        sliced = list(raw_row[col_offset:])
        padded = sliced + [None] * max(0, min_cols - len(sliced))

        raw_nik = _clean_cell(padded[0], strip_decimal_zero=True)
        nik = re.sub(r"\D", "", raw_nik)
        nama = re.sub(r"\s+", " ", _clean_cell(padded[1])).strip()
        if not nik and not nama:
            continue

        healed_notes: List[str] = []
        warning_parts: List[str] = []

        if len(nik) != 16:
            quality.invalid_nik_count += 1
            warning_parts.append(f"NIK {len(nik)} digit")

        tgl_mentah = _clean_cell(padded[2])
        t_tahun, t_bln_teks, t_bln_idx, t_tgl, tgl_iso, umur = parse_tanggal_lahir(tgl_mentah)
        if not t_tahun:
            quality.missing_dob_count += 1
            warning_parts.append("Tgl Lahir kosong/invalid")
        elif tgl_iso != tgl_mentah:
            quality.healed_date_count += 1
            healed_notes.append(f"Tgl Lahir dinormalisasi ke {tgl_iso}")

        jk_mentah = _clean_cell(padded[3]).lower()
        if jk_mentah in ("female", "perempuan", "wanita", "p", "pr", "f", "cewek", "putri"):
            jk_pasien = "Perempuan"
        elif jk_mentah in ("male", "laki-laki", "laki laki", "pria", "l", "lk", "m", "cowok", "putra"):
            jk_pasien = "Laki-laki"
        else:
            jk_pasien = "Laki-laki"

        wa_mentah = _clean_cell(padded[4], strip_decimal_zero=True)
        wa_pasien, wa_healed = heal_whatsapp_number(wa_mentah)
        if wa_healed:
            quality.healed_wa_count += 1
            healed_notes.append(f"WA '{wa_mentah or '-'}' -> '{wa_pasien}'")

        if service_type == "umum":
            tgl_periksa_raw = _clean_cell(padded[5])
            _, _, _, _, tgl_periksa_iso, _ = parse_tanggal_lahir(tgl_periksa_raw)
            tgl_pemeriksaan = tgl_periksa_iso if (tgl_periksa_iso and len(tgl_periksa_iso) == 10 and tgl_periksa_iso[4] == "-") else dt.date.today().strftime("%Y-%m-%d")

            status_pernikahan = _normalize_status_pernikahan(_clean_cell(padded[6]), umur)
            pekerjaan = _normalize_pekerjaan(_clean_cell(padded[7]))
            provinsi = _clean_cell(padded[8])
            kabkota = _clean_cell(padded[9])
            kecamatan = _clean_cell(padded[10])
            desa = _clean_cell(padded[11])
            detail_alamat = _clean_cell(padded[12])

            hub_raw = _clean_cell(padded[13]).lower()
            if hub_raw in ("ya", "y", "sudah", "pernah"):
                riwayat_hubungan_intim = "Ya"
            elif hub_raw in ("tidak", "tdk", "t", "belum"):
                riwayat_hubungan_intim = "Tidak"
            else:
                riwayat_hubungan_intim = "Ya" if status_pernikahan != "Belum Menikah" else "Tidak"

            perilaku_merokok = "ya" if _clean_cell(padded[14]).lower() in ("ya", "y", "merokok", "aktif") else "tidak"
            aktivitas_fisik = "ya" if _clean_cell(padded[15]).lower() in ("ya", "y", "aktif") else "tidak"

            berat, b_healed = _clean_numeric_str(padded[16], allow_decimal=True)
            tinggi, t_healed = _clean_numeric_str(padded[17], allow_decimal=True)
            lingkar_perut, lp_healed = _clean_numeric_str(padded[18], allow_decimal=True)

            lama_dm, ldm_healed = _clean_numeric_str(padded[20], allow_decimal=False)
            riwayat_dm_raw = _clean_cell(padded[19]).lower()
            riwayat_dm = "ya" if (riwayat_dm_raw in ("ya", "y") or (lama_dm and int(lama_dm) > 0)) else "tidak"
            if riwayat_dm == "ya" and riwayat_dm_raw not in ("ya", "y"):
                healed_notes.append(f"Riwayat DM otomatis 'Ya' (Lama DM {lama_dm} bln)")

            gds, g_healed = _clean_numeric_str(padded[21], allow_decimal=False)

            lama_hipertensi, lht_healed = _clean_numeric_str(padded[23], allow_decimal=False)
            riwayat_ht_raw = _clean_cell(padded[22]).lower()
            riwayat_hipertensi = "ya" if (riwayat_ht_raw in ("ya", "y") or (lama_hipertensi and int(lama_hipertensi) > 0)) else "tidak"
            if riwayat_hipertensi == "ya" and riwayat_ht_raw not in ("ya", "y"):
                healed_notes.append(f"Riwayat Hipertensi otomatis 'Ya' (Lama HT {lama_hipertensi} bln)")

            sistolik, s_healed = _clean_numeric_str(padded[24], allow_decimal=False)
            diastolik, d_healed = _clean_numeric_str(padded[25], allow_decimal=False)

            curiga_katarak_raw = _clean_cell(padded[26]).lower()
            curiga_katarak = "curiga katarak" if "katarak" in curiga_katarak_raw else "normal"
            gigi_karies = "Ya" if _clean_cell(padded[27]).lower() in ("ya", "y", "1", "2", "3", ">3") else "Tidak"
            gigi_hilang = "Ya" if _clean_cell(padded[28]).lower() in ("ya", "y", "1", "2", "3", ">3") else "Tidak"

            skrining_payudara_raw = _clean_cell(padded[29])
            if jk_pasien == "Laki-laki":
                if skrining_payudara_raw:
                    healed_notes.append("Skrining Payudara dikosongkan (Laki-laki)")
                skrining_payudara = ""
            else:
                skrining_payudara = skrining_payudara_raw or "Sadanis"

            kadar_co_mentah, _ = _clean_numeric_str(padded[30], allow_decimal=True)
            hb_catin, _ = _clean_numeric_str(padded[31], allow_decimal=True)
            kolesterol_total, kol_healed = _clean_numeric_str(padded[32], allow_decimal=False)
            hdl, _ = _clean_numeric_str(padded[33], allow_decimal=False)
            ldl, _ = _clean_numeric_str(padded[34], allow_decimal=False)
            trigliserida, _ = _clean_numeric_str(padded[35], allow_decimal=False)
            hasil_ekg = _clean_cell(padded[36])

            if any((b_healed, t_healed, lp_healed, g_healed, s_healed, d_healed, kol_healed)):
                quality.healed_numeric_count += 1

            if umur >= 60:
                kelompok_usia = "Lansia (≥60 th)"
                kelompok_short = "Lansia"
            elif umur >= 18:
                kelompok_usia = "Dewasa (18–59 th)"
                kelompok_short = "Dewasa"
            else:
                kelompok_usia = "Remaja (<18 th)"
                kelompok_short = "Remaja"

            domisili_label = desa or kecamatan or kabkota or "Peserta Umum"
            rec = StudentRecord(
                row_index=len(records),
                nik=nik,
                nama=nama,
                tgl_lahir_mentah=tgl_mentah,
                target_tahun=t_tahun,
                target_bulan_teks=t_bln_teks,
                target_bulan_idx=t_bln_idx,
                target_tanggal=t_tgl,
                tgl_iso=tgl_iso,
                umur=umur,
                jk_mentah=jk_mentah,
                jk_pasien=jk_pasien,
                wa_mentah=wa_mentah,
                wa_pasien=wa_pasien,
                nama_sekolah=domisili_label,
                nama_sekolah_bersih=f"{domisili_label} • {pekerjaan}",
                sekolah_candidates=[domisili_label],
                kelas_mentah=kelompok_usia,
                kelas=kelompok_usia,
                kelas_angka=kelompok_short,
                provinsi=provinsi,
                kabkota=kabkota,
                kecamatan=kecamatan,
                desa=desa,
                detail_alamat=detail_alamat,
                batuk_tb="tidak",
                keputihan_putri="tidak",
                perilaku_merokok=perilaku_merokok,
                aktivitas_fisik=aktivitas_fisik,
                berat=berat,
                tinggi=tinggi,
                riwayat_dm=riwayat_dm,
                lama_dm=lama_dm,
                gds=gds,
                sistolik=sistolik,
                diastolik=diastolik,
                curiga_katarak=curiga_katarak,
                visus_mentah="normal",
                kacamata_mentah="tidak",
                serumen_mentah="normal",
                gigi_karies=gigi_karies,
                kadar_co_mentah=kadar_co_mentah,
                hb_anemia_mentah=hb_catin,
                service_type="umum",
                tgl_pemeriksaan=tgl_pemeriksaan,
                status_pernikahan=status_pernikahan,
                pekerjaan=pekerjaan,
                riwayat_hubungan_intim=riwayat_hubungan_intim,
                lingkar_perut=lingkar_perut,
                riwayat_hipertensi=riwayat_hipertensi,
                lama_hipertensi=lama_hipertensi,
                gigi_hilang=gigi_hilang,
                skrining_payudara=skrining_payudara,
                hb_catin=hb_catin,
                kolesterol_total=kolesterol_total,
                hdl=hdl,
                ldl=ldl,
                trigliserida=trigliserida,
                hasil_ekg=hasil_ekg,
                healed_notes=healed_notes,
                validation_warning=", ".join(warning_parts),
            )
        else:
            nama_sekolah = _clean_cell(padded[5])
            nama_sekolah_bersih = bersihkan_nama_sekolah(nama_sekolah)
            sekolah_candidates = build_school_candidates(nama_sekolah)
            if nama_sekolah_bersih != nama_sekolah:
                quality.healed_school_count += 1
                healed_notes.append(f"Sekolah -> '{nama_sekolah_bersih}'")

            kelas_mentah = _clean_cell(padded[6], strip_decimal_zero=True)
            kelas, kelas_angka = normalize_kelas(kelas_mentah)

            berat, b_healed = _clean_numeric_str(padded[16], allow_decimal=True)
            tinggi, t_healed = _clean_numeric_str(padded[17], allow_decimal=True)
            gds, g_healed = _clean_numeric_str(padded[20], allow_decimal=False)
            sistolik, s_healed = _clean_numeric_str(padded[21], allow_decimal=False)
            diastolik, d_healed = _clean_numeric_str(padded[22], allow_decimal=False)
            if any((b_healed, t_healed, g_healed, s_healed, d_healed)):
                quality.healed_numeric_count += 1

            rec = StudentRecord(
                row_index=len(records),
                nik=nik,
                nama=nama,
                tgl_lahir_mentah=tgl_mentah,
                target_tahun=t_tahun,
                target_bulan_teks=t_bln_teks,
                target_bulan_idx=t_bln_idx,
                target_tanggal=t_tgl,
                tgl_iso=tgl_iso,
                umur=umur,
                jk_mentah=jk_mentah,
                jk_pasien=jk_pasien,
                wa_mentah=wa_mentah,
                wa_pasien=wa_pasien,
                nama_sekolah=nama_sekolah,
                nama_sekolah_bersih=nama_sekolah_bersih,
                sekolah_candidates=sekolah_candidates,
                kelas_mentah=kelas_mentah,
                kelas=kelas,
                kelas_angka=kelas_angka,
                provinsi=_clean_cell(padded[7]),
                kabkota=_clean_cell(padded[8]),
                kecamatan=_clean_cell(padded[9]),
                desa=_clean_cell(padded[10]),
                detail_alamat=_clean_cell(padded[11]),
                batuk_tb=_clean_cell(padded[12]).lower() or "tidak",
                keputihan_putri=_clean_cell(padded[13]).lower() or "tidak",
                perilaku_merokok=_clean_cell(padded[14]).lower() or "tidak",
                aktivitas_fisik=_clean_cell(padded[15]).lower() or "tidak",
                berat=berat,
                tinggi=tinggi,
                riwayat_dm=_clean_cell(padded[18]).lower() or "tidak",
                lama_dm=_clean_cell(padded[19], strip_decimal_zero=True),
                gds=gds,
                sistolik=sistolik,
                diastolik=diastolik,
                curiga_katarak=_clean_cell(padded[23]).lower() or "normal",
                visus_mentah=_clean_cell(padded[24]).lower() or "normal",
                kacamata_mentah=_clean_cell(padded[25]).lower() or "tidak",
                serumen_mentah=_clean_cell(padded[26]).lower() or "normal",
                gigi_karies=_clean_cell(padded[27], strip_decimal_zero=True) or "Tidak",
                kadar_co_mentah=_clean_cell(padded[28], strip_decimal_zero=True),
                malaria_mentah=_clean_cell(padded[29]),
                hepb_mentah=_clean_cell(padded[30]),
                hepc_mentah=_clean_cell(padded[31]),
                hb_anemia_mentah=_clean_cell(padded[32], strip_decimal_zero=True),
                service_type="sekolah",
                healed_notes=healed_notes,
                validation_warning=", ".join(warning_parts),
            )

        # If loaded from an existing Report file, also preserve previous output columns if present
        if col_offset == 4:
            raw_tata = _clean_cell(raw_row[0]) or "-"
            if "perlu tindak lanjut" in raw_tata.lower():
                rec.tatalaksana = "Harus tatalaksana"
            elif "normal / aman" in raw_tata.lower():
                rec.tatalaksana = "Aman (Tidak Ada Tindakan)"
            else:
                rec.tatalaksana = raw_tata
            rec.status_rapor = _clean_cell(raw_row[1]) or "-"
            rec.no_tiket = _clean_cell(raw_row[2]) or "-"
            rec.status_sistem = _clean_cell(raw_row[3]) or "-"

        records.append(rec)

    wb.close()
    quality.total_rows = len(records)
    quality.valid_rows = sum(1 for r in records if not r.validation_warning)
    label_peserta = "peserta" if service_type == "umum" else "siswa"
    if quality.healed_wa_count > 0:
        quality.warnings.append(
            f"Auto-Heal: {quality.healed_wa_count} Nomor WhatsApp tanpa angka '0' di depan otomatis diperbaiki ke format '08...'."
        )
    if quality.invalid_nik_count > 0:
        quality.warnings.append(
            f"Perhatian: {quality.invalid_nik_count} {label_peserta} memiliki panjang NIK tidak tepat 16 digit."
        )
    if quality.missing_dob_count > 0:
        quality.warnings.append(
            f"Perhatian: {quality.missing_dob_count} {label_peserta} memiliki format Tanggal Lahir tidak dikenali."
        )

    return (records, quality)


def load_students_from_excel(excel_path: str | Path) -> List[StudentRecord]:
    """Backward-compatible helper returning only the student list."""
    records, _ = load_students_with_quality(excel_path)
    return records


def humanize_status_pelayanan(raw_status: str) -> str:
    """
    Convert internal/legacy status codes (e.g. 'SUKSES PARIPURNA (Mode C)') into
    self-explanatory, executive-grade Indonesian clinical service descriptions.
    """
    s = (raw_status or "").strip()
    if not s or s == "-":
        return "Belum Diproses"
    su = s.upper()
    if "DRAFT" in su:
        return "Tersimpan Draft (Menunggu Klik Selesaikan Layanan)"
    if "SKRINING MANDIRI DILENGKAPI" in su:
        return "Selesai Lengkap (Skrining Mandiri & Pemeriksaan Nakes)"
    if (
        "MODE C" in su
        or "SUDAH SELESAI & LENGKAP" in su
        or "SUKSES (LENGKAP)" in su
        or "SUDAH SELESAI DI SERVER" in su
        or "SELESAI LENGKAP" in su
    ):
        return "Selesai Lengkap (Pendaftaran, Skrining Mandiri & Pemeriksaan Nakes)"
    if "MODE A" in su or "PENDAFTARAN & HADIR" in su or "TERDAFTAR & MULAI LAYANAN" in su:
        return "Selesai Tahap 1 (Pendaftaran & Konfirmasi Kehadiran)"
    if "MODE B" in su or "SKRINING MANDIRI" in su and ("SUKSES" in su or "SELESAI" in su):
        return "Selesai Tahap 2 (Kuesioner Skrining Mandiri)"
    if "MODE D" in su or "PEMERIKSAAN FISIK" in su:
        return "Selesai Tahap 3 (Pemeriksaan Fisik & Klinis Nakes)"
    if "SUKSES PARIPURNA" in su:
        return "Selesai Lengkap (Pendaftaran, Skrining Mandiri & Pemeriksaan Nakes)"
    if "SUKSES BOOKING" in su:
        return "Terdaftar Booking (Belum Konfirmasi Kehadiran)"
    if s.lower().startswith("skipped:"):
        return f"Dilewati: {s[8:].strip()}"
    if s.lower().startswith("sudah dilayani"):
        return re.sub(r"(?i)^sudah dilayani", "Sudah Dilayani Sebelumnya", s, count=1)
    return s


def humanize_tatalaksana(raw_tata: str, raw_status: str = "") -> str:
    """Format clinical follow-up conclusion into clear Indonesian medical terminology."""
    t = (raw_tata or "").strip()
    tl = t.lower()
    if tl == "harus tatalaksana" or "perlu tindak lanjut" in tl:
        return "Perlu Tindak Lanjut Medis"
    if "aman" in tl or tl == "normal":
        return "Normal / Aman (Tidak Ada Tindakan)"
    if (not t or t == "-") and "sudah dilayani" in (raw_status or "").lower():
        return "Sudah Dilayani Sebelumnya"
    return t or "-"


def humanize_status_rapor(raw_rapor: str) -> str:
    """Format WhatsApp health report delivery status cleanly."""
    r = (raw_rapor or "").strip()
    if not r or r == "-":
        return "-"
    rl = r.lower()
    if "sukses" in rl or "terkirim" in rl:
        return "Terkirim (WhatsApp)"
    return r


def _pretty_flag(val: Any, default: str = "") -> str:
    """Normalize Yes/No/Normal/Non-Reaktif clinical values to consistent Title Case."""
    s = _clean_cell(val)
    if not s:
        return default
    sl = s.lower()
    if sl == "tidak":
        return "Tidak"
    if sl == "ya":
        return "Ya"
    if sl == "normal":
        return "Normal"
    if sl in ("non reaktif", "non-reaktif"):
        return "Non-Reaktif"
    return s


def _pretty_wilayah(val: Any, strip_prefix: bool = False) -> str:
    """Normalize region/village names to clean uppercase without typos like 'SAADAI' or 'Desa/Kel.'."""
    s = _clean_cell(val)
    if not s:
        return ""
    if strip_prefix:
        s = re.sub(r"(?i)^(?:desa/kel\.?|kelurahan|desa|kel\.?)\s*", "", s).strip()
    su = re.sub(r"\s+", " ", s).upper()
    if su == "SAADAI":
        return "SADAI"
    return su


def _suppress_excel_text_number_warnings(xlsx_path: Path) -> None:
    """
    Inject OOXML <ignoredErrors><ignoredError sqref="A1:AZ5000" numberStoredAsText="1"/></ignoredErrors>
    into worksheet XMLs so Microsoft Excel never displays green corner triangles on NIK or WhatsApp numbers.
    """
    import zipfile

    try:
        with zipfile.ZipFile(xlsx_path, "r") as zin:
            entries = {name: zin.read(name) for name in zin.namelist()}

        modified = False
        ignored_tag = '<ignoredErrors><ignoredError sqref="A1:AZ5000" numberStoredAsText="1"/></ignoredErrors>'
        for name, raw_bytes in list(entries.items()):
            if name.startswith("xl/worksheets/sheet") and name.endswith(".xml"):
                xml_str = raw_bytes.decode("utf-8")
                if "<ignoredErrors" not in xml_str:
                    # Insert in valid ECMA-376 CT_Worksheet order (before drawing/legacyDrawing/tableParts or </worksheet>)
                    inserted = False
                    for anchor in ("<drawing", "<legacyDrawing", "<tableParts", "</worksheet>"):
                        if anchor in xml_str:
                            xml_str = xml_str.replace(anchor, ignored_tag + anchor, 1)
                            inserted = True
                            break
                    if inserted:
                        entries[name] = xml_str.encode("utf-8")
                        modified = True

        if modified:
            with zipfile.ZipFile(xlsx_path, "w", zipfile.ZIP_DEFLATED) as zout:
                for name, data in entries.items():
                    zout.writestr(name, data)
    except Exception:
        pass


def _build_executive_summary_sheet(
    wb: openpyxl.Workbook,
    students: List[StudentRecord],
    is_umum: bool,
) -> None:
    """Create a polished 'Ringkasan Eksekutif' worksheet as the second tab of the report workbook."""
    ws_sum = wb.create_sheet(title="Ringkasan Eksekutif")
    ws_sum.views.sheetView[0].showGridLines = True

    total = len(students)
    selesai_cnt = 0
    sudah_dilayani_cnt = 0
    gagal_cnt = 0
    belum_cnt = 0
    normal_cnt = 0
    tindak_lanjut_cnt = 0
    rapor_terkirim_cnt = 0

    karies_cnt = 0
    visus_cnt = 0
    kacamata_cnt = 0
    serumen_cnt = 0
    katarak_cnt = 0
    rokok_tb_cnt = 0

    for s in students:
        st_human = humanize_status_pelayanan(s.status_sistem)
        st_up = st_human.upper()
        if st_up.startswith("SELESAI") or "SUKSES" in (s.status_sistem or "").upper():
            selesai_cnt += 1
        elif "SUDAH DILAYANI" in st_up or s.state == "skipped":
            sudah_dilayani_cnt += 1
        elif "GAGAL" in st_up or "ERROR" in st_up or s.state == "failed":
            gagal_cnt += 1
        else:
            belum_cnt += 1

        tata_h = humanize_tatalaksana(s.tatalaksana, s.status_sistem)
        if tata_h == "Perlu Tindak Lanjut Medis":
            tindak_lanjut_cnt += 1
        elif tata_h.startswith("Normal / Aman"):
            normal_cnt += 1

        if humanize_status_rapor(s.status_rapor) == "Terkirim (WhatsApp)":
            rapor_terkirim_cnt += 1

        if _pretty_flag(s.gigi_karies, "Tidak") not in ("Tidak", "-", ""):
            karies_cnt += 1
        if _pretty_flag(s.visus_mentah, "Normal") not in ("Normal", "-", ""):
            visus_cnt += 1
        if _pretty_flag(s.kacamata_mentah, "Tidak") == "Ya":
            kacamata_cnt += 1
        if _pretty_flag(s.serumen_mentah, "Normal") not in ("Normal", "-", ""):
            serumen_cnt += 1
        if _pretty_flag(s.curiga_katarak, "Normal") not in ("Normal", "-", ""):
            katarak_cnt += 1
        if _pretty_flag(s.perilaku_merokok, "Tidak") == "Ya" or _pretty_flag(s.batuk_tb, "Tidak") != "Tidak":
            rokok_tb_cnt += 1

    tuntas_total = selesai_cnt + sudah_dilayani_cnt
    pct_tuntas = f"{(tuntas_total / total * 100.0):.1f}%" if total > 0 else "0.0%"

    lokasi_utama = (
        (students[0].nama_sekolah_bersih or students[0].nama_sekolah)
        if students
        else ("Wilayah CKG Umum" if is_umum else "Satuan Pendidikan")
    )
    kelas_set = sorted({(s.kelas or "").strip() for s in students if (s.kelas or "").strip()})
    kelas_label = ", ".join(kelas_set) if kelas_set else "-"
    waktu_cetak = dt.datetime.now().strftime("%d %B %Y • %H:%M WIB")

    fill_navy = PatternFill(start_color="0F172A", end_color="0F172A", fill_type="solid")
    fill_sub = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
    fill_sec = PatternFill(start_color="F1F5F9", end_color="F1F5F9", fill_type="solid")
    fill_ok = PatternFill(start_color="DCFCE7", end_color="DCFCE7", fill_type="solid")
    fill_warn = PatternFill(start_color="FEF3C7", end_color="FEF3C7", fill_type="solid")
    fill_rose = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")

    font_title = Font(name="Calibri", size=13, bold=True, color="FFFFFF")
    font_sub = Font(name="Calibri", size=10, bold=True, color="E2E8F0")
    font_sec = Font(name="Calibri", size=10, bold=True, color="0F172A")
    font_lbl = Font(name="Calibri", size=10, bold=False, color="1E293B")
    font_val = Font(name="Calibri", size=10, bold=True, color="0F172A")
    font_ok = Font(name="Calibri", size=10, bold=True, color="166534")
    font_warn = Font(name="Calibri", size=10, bold=True, color="92400E")
    font_rose = Font(name="Calibri", size=10, bold=True, color="991B1B")

    thin_bdr = Border(
        left=Side(style="thin", color="CBD5E1"),
        right=Side(style="thin", color="CBD5E1"),
        top=Side(style="thin", color="CBD5E1"),
        bottom=Side(style="thin", color="CBD5E1"),
    )

    ws_sum.merge_cells("A1:D1")
    ws_sum["A1"] = (
        "RINGKASAN EKSEKUTIF PELAYANAN CEK KESEHATAN GRATIS (CKG UMUM)"
        if is_umum
        else "RINGKASAN EKSEKUTIF PELAYANAN CEK KESEHATAN GRATIS (CKG SEKOLAH)"
    )
    ws_sum["A1"].fill = fill_navy
    ws_sum["A1"].font = font_title
    ws_sum["A1"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws_sum.row_dimensions[1].height = 32

    ws_sum.merge_cells("A2:D2")
    ws_sum["A2"] = f"Lokasi / Satuan Pendidikan: {lokasi_utama}   |   Kelas / Sasaran: {kelas_label}   |   Dicetak: {waktu_cetak}"
    ws_sum["A2"].fill = fill_sub
    ws_sum["A2"].font = font_sub
    ws_sum["A2"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws_sum.row_dimensions[2].height = 22

    summary_rows = [
        ("SECTION", "I. REKAPITULASI CAPAIAN PELAYANAN CKG", "JUMLAH", "PERSENTASE", "KETERANGAN"),
        ("ROW", "Total Sasaran Peserta Didik / Peserta", total, "100.0%", "Seluruh data peserta di dalam berkas Excel"),
        ("OK", "Selesai Pemeriksaan Lengkap (Pendaftaran, Skrining & Nakes)", selesai_cnt, f"{(selesai_cnt / total * 100.0):.1f}%" if total else "0.0%", "Seluruh tahapan pemeriksaan & kunci layanan tuntas"),
        ("WARN", "Sudah Dilayani Sebelumnya (Lintas Tanggal / Puskesmas)", sudah_dilayani_cnt, f"{(sudah_dilayani_cnt / total * 100.0):.1f}%" if total else "0.0%", "Peserta tercatat sudah selesai diperiksa sebelumnya"),
        ("OK", "Total Tuntas Terlayani (Selesai + Sudah Dilayani)", tuntas_total, pct_tuntas, "Tingkat ketuntasan akhir pelayanan CKG"),
        ("ROSE" if gagal_cnt > 0 else "ROW", "Terkendala / Perlu Tindak Lanjut Data (NIK/Dukcapil)", gagal_cnt, f"{(gagal_cnt / total * 100.0):.1f}%" if total else "0.0%", "Data ditolak Dukcapil atau belum selesai"),
        ("SPACER", "", "", "", ""),
        ("SECTION", "II. REKAPITULASI KESIMPULAN MEDIS & RAPOR KESEHATAN", "JUMLAH", "PERSENTASE", "KETERANGAN"),
        ("OK", "Normal / Aman (Tidak Ada Tindakan Medis)", normal_cnt, f"{(normal_cnt / max(1, selesai_cnt) * 100.0):.1f}%", "Hasil pemeriksaan fisik & skrining dalam batas normal"),
        ("ROSE", "Perlu Tindak Lanjut Medis (Ada Temuan Klinis)", tindak_lanjut_cnt, f"{(tindak_lanjut_cnt / max(1, selesai_cnt) * 100.0):.1f}%", "Ditemukan indikasi medis (Gigi/Mata/Telinga/Gizi/Tensi)"),
        ("OK", "Rapor Kesehatan Terkirim via WhatsApp", rapor_terkirim_cnt, f"{(rapor_terkirim_cnt / max(1, selesai_cnt) * 100.0):.1f}%", "Notifikasi rapor kesehatan terkirim ke nomor WA Ortu/Peserta"),
        ("SPACER", "", "", "", ""),
        ("SECTION", "III. RINCIAN INDIKATOR TEMUAN KLINIS PESERTA", "JUMLAH", "PERSENTASE", "RINCIAN TINDAK LANJUT UKS / PUSKESMAS"),
        ("WARN" if karies_cnt > 0 else "ROW", "Indikasi Karies Gigi (Gigi Karies ≥ 1)", karies_cnt, f"{(karies_cnt / max(1, total) * 100.0):.1f}%", "Edukasi kesehatan gigi & mulut / rujukan poli gigi Puskesmas"),
        ("WARN" if visus_cnt > 0 else "ROW", "Gangguan Tajam Penglihatan / Visus Mata", visus_cnt, f"{(visus_cnt / max(1, total) * 100.0):.1f}%", "Pemeriksaan refraksi lanjutan di Puskesmas"),
        ("ROW", "Menggunakan Kacamata", kacamata_cnt, f"{(kacamata_cnt / max(1, total) * 100.0):.1f}%", "Pemantauan berkala koreksi visus kacamata"),
        ("WARN" if serumen_cnt > 0 else "ROW", "Temuan Serumen / Gangguan Pendengaran", serumen_cnt, f"{(serumen_cnt / max(1, total) * 100.0):.1f}%", "Pemeriksaan liang telinga / ekstraksi serumen"),
        ("WARN" if katarak_cnt > 0 else "ROW", "Curiga Katarak / Kelainan Mata Lainnya", katarak_cnt, f"{(katarak_cnt / max(1, total) * 100.0):.1f}%", "Evaluasi medis mata oleh dokter Puskesmas"),
        ("WARN" if rokok_tb_cnt > 0 else "ROW", "Indikasi Perilaku Merokok / Gejala Batuk TB", rokok_tb_cnt, f"{(rokok_tb_cnt / max(1, total) * 100.0):.1f}%", "Konseling berhenti merokok / skrining TB lanjutan"),
    ]

    cur_row = 4
    for kind, col_a, col_b, col_c, col_d in summary_rows:
        if kind == "SPACER":
            ws_sum.row_dimensions[cur_row].height = 12
            cur_row += 1
            continue
        ws_sum.cell(row=cur_row, column=1, value=col_a)
        ws_sum.cell(row=cur_row, column=2, value=col_b)
        ws_sum.cell(row=cur_row, column=3, value=col_c)
        ws_sum.cell(row=cur_row, column=4, value=col_d)
        ws_sum.row_dimensions[cur_row].height = 24 if kind == "SECTION" else 21

        for c_i in range(1, 5):
            cell = ws_sum.cell(row=cur_row, column=c_i)
            cell.border = thin_bdr
            if kind == "SECTION":
                cell.fill = fill_sec
                cell.font = font_sec
                cell.alignment = Alignment(
                    horizontal="center" if c_i in (2, 3) else "left",
                    vertical="center",
                    indent=0 if c_i in (2, 3) else 1,
                )
            else:
                cell.alignment = Alignment(
                    horizontal="center" if c_i in (2, 3) else "left",
                    vertical="center",
                    indent=0 if c_i in (2, 3) else 1,
                )
                if kind == "OK" and c_i in (2, 3):
                    cell.fill = fill_ok
                    cell.font = font_ok
                elif kind == "WARN" and c_i in (2, 3):
                    cell.fill = fill_warn
                    cell.font = font_warn
                elif kind == "ROSE" and c_i in (2, 3):
                    cell.fill = fill_rose
                    cell.font = font_rose
                else:
                    cell.font = font_val if c_i in (2, 3) else font_lbl
        cur_row += 1

    ws_sum.column_dimensions["A"].width = 56
    ws_sum.column_dimensions["B"].width = 16
    ws_sum.column_dimensions["C"].width = 16
    ws_sum.column_dimensions["D"].width = 54


def export_report_excel(
    source_excel_path: Optional[str | Path],
    students: List[StudentRecord],
    output_path: str | Path,
) -> Path:
    """
    Generate the World-Class Clinical Excel Report:
    - Sheet 1 ('Laporan CKG Sekolah' / 'Laporan CKG Umum'):
      Prepends ['Tatalaksana Medis', 'Status Rapor WA', 'Nomor Tiket', 'Status Pelayanan CKG'] at columns A..D
      followed by all 33 standard columns (CKG Sekolah) or all 37 standard columns (CKG Umum).
      Uses clear, self-explanatory Indonesian clinical descriptions (no internal 'Mode C' or 'Robot' jargon),
      refined medical badge colors, zebra row striping, auto-filter, freeze panes, and suppresses Excel's
      green 'Number Stored as Text' triangles.
    - Sheet 2 ('Ringkasan Eksekutif'):
      Executive summary table of completion statistics, medical follow-up distribution, and clinical findings.
    """
    out_path = Path(output_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    is_umum = any(getattr(s, "service_type", "sekolah") == "umum" for s in students)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Laporan CKG Umum" if is_umum else "Laporan CKG Sekolah"
    ws.views.sheetView[0].showGridLines = True

    base_columns = TEMPLATE_UMUM_COLUMNS if is_umum else TEMPLATE_COLUMNS
    headers = ["Tatalaksana Medis", "Status Rapor WA", "Nomor Tiket", "Status Pelayanan CKG"] + base_columns
    ws.append(headers)

    # Color-coded header groups by clinical section
    hdr_fill_status = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
    hdr_fill_identitas = PatternFill(start_color="0F172A", end_color="0F172A", fill_type="solid")
    hdr_fill_domisili = PatternFill(start_color="1E40AF", end_color="1E40AF", fill_type="solid")
    hdr_fill_skrining = PatternFill(start_color="065F46", end_color="065F46", fill_type="solid")
    hdr_fill_klinis = PatternFill(start_color="3B0764", end_color="3B0764", fill_type="solid")
    header_font = Font(name="Calibri", color="FFFFFF", bold=True, size=10)
    hdr_border = Border(
        left=Side(style="thin", color="334155"),
        right=Side(style="thin", color="334155"),
        top=Side(style="thin", color="0F172A"),
        bottom=Side(style="medium", color="0F172A"),
    )

    for col_idx in range(1, len(headers) + 1):
        cell = ws.cell(row=1, column=col_idx)
        if col_idx <= 4:
            cell.fill = hdr_fill_status
        elif col_idx <= 9:
            cell.fill = hdr_fill_identitas
        elif col_idx <= (17 if is_umum else 16):
            cell.fill = hdr_fill_domisili
        elif col_idx <= 20:
            cell.fill = hdr_fill_skrining
        else:
            cell.fill = hdr_fill_klinis
        cell.font = header_font
        cell.border = hdr_border
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    ws.row_dimensions[1].height = 30

    # Refined Clinical Badge Palettes (Readable, Executive, Eye-Friendly)
    fill_tata_merah = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")
    font_tata_merah = Font(name="Calibri", size=10, bold=True, color="991B1B")

    fill_tata_hijau = PatternFill(start_color="D1FAE5", end_color="D1FAE5", fill_type="solid")
    font_tata_hijau = Font(name="Calibri", size=10, bold=True, color="065F46")

    fill_tata_abu = PatternFill(start_color="F1F5F9", end_color="F1F5F9", fill_type="solid")
    font_tata_abu = Font(name="Calibri", size=10, bold=True, color="475569")

    fill_rapor_ok = PatternFill(start_color="E0F2FE", end_color="E0F2FE", fill_type="solid")
    font_rapor_ok = Font(name="Calibri", size=10, bold=True, color="0369A1")

    fill_tiket = PatternFill(start_color="EEF2FF", end_color="EEF2FF", fill_type="solid")
    font_tiket = Font(name="Calibri", size=10, bold=True, color="1E40AF")

    fill_st_hijau = PatternFill(start_color="DCFCE7", end_color="DCFCE7", fill_type="solid")
    font_st_hijau = Font(name="Calibri", size=10, bold=True, color="166534")

    fill_st_kuning = PatternFill(start_color="FEF3C7", end_color="FEF3C7", fill_type="solid")
    font_st_kuning = Font(name="Calibri", size=10, bold=True, color="92400E")

    fill_st_merah = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")
    font_st_merah = Font(name="Calibri", size=10, bold=True, color="991B1B")

    fill_zebra_even = PatternFill(start_color="FFFFFF", end_color="FFFFFF", fill_type="solid")
    fill_zebra_odd = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid")

    font_data = Font(name="Calibri", size=10, bold=False, color="0F172A")
    font_nama = Font(name="Calibri", size=10, bold=True, color="0F172A")

    cell_border = Border(
        left=Side(style="thin", color="E2E8F0"),
        right=Side(style="thin", color="E2E8F0"),
        top=Side(style="thin", color="E2E8F0"),
        bottom=Side(style="thin", color="E2E8F0"),
    )
    align_left = Alignment(horizontal="left", vertical="center")
    align_center = Alignment(horizontal="center", vertical="center")

    center_cols_sekolah = {2, 3, 5, 7, 8, 9, 11} | set(range(17, 38))
    center_cols_umum = {2, 3, 5, 7, 8, 9, 10, 11} | set(range(18, 42))
    center_cols = center_cols_umum if is_umum else center_cols_sekolah

    for r_idx, s in enumerate(students, start=2):
        tata_display = humanize_tatalaksana(s.tatalaksana, s.status_sistem)
        rapor_display = humanize_status_rapor(s.status_rapor)
        tiket_display = (s.no_tiket or "-").strip() or "-"
        status_display = humanize_status_pelayanan(s.status_sistem)

        if is_umum:
            row_values = [
                tata_display,
                rapor_display,
                tiket_display,
                status_display,
                s.nik,
                s.nama,
                s.tgl_iso or s.tgl_lahir_mentah,
                s.jk_pasien,
                s.wa_pasien,
                s.tgl_pemeriksaan,
                s.status_pernikahan,
                s.pekerjaan,
                _pretty_wilayah(s.provinsi),
                _pretty_wilayah(s.kabkota),
                _pretty_wilayah(s.kecamatan),
                _pretty_wilayah(s.desa, strip_prefix=True),
                s.detail_alamat,
                _pretty_flag(s.riwayat_hubungan_intim, "Tidak"),
                _pretty_flag(s.perilaku_merokok, "Tidak"),
                _pretty_flag(s.aktivitas_fisik, "Ya"),
                s.berat,
                s.tinggi,
                s.lingkar_perut,
                _pretty_flag(s.riwayat_dm, "Tidak"),
                s.lama_dm,
                s.gds,
                _pretty_flag(s.riwayat_hipertensi, "Tidak"),
                s.lama_hipertensi,
                s.sistolik,
                s.diastolik,
                _pretty_flag(s.curiga_katarak, "Normal"),
                _pretty_flag(s.gigi_karies, "Tidak"),
                _pretty_flag(s.gigi_hilang, "Tidak"),
                s.skrining_payudara,
                s.kadar_co_mentah,
                s.hb_catin,
                s.kolesterol_total,
                s.hdl,
                s.ldl,
                s.trigliserida,
                s.hasil_ekg,
            ]
        else:
            row_values = [
                tata_display,
                rapor_display,
                tiket_display,
                status_display,
                s.nik,
                s.nama,
                s.tgl_iso or s.tgl_lahir_mentah,
                s.jk_pasien,
                s.wa_pasien,
                s.nama_sekolah_bersih or s.nama_sekolah,
                s.kelas or s.kelas_mentah or s.kelas_angka,
                _pretty_wilayah(s.provinsi),
                _pretty_wilayah(s.kabkota),
                _pretty_wilayah(s.kecamatan),
                _pretty_wilayah(s.desa, strip_prefix=True),
                s.detail_alamat,
                _pretty_flag(s.batuk_tb, "Tidak"),
                _pretty_flag(s.keputihan_putri, "Tidak"),
                _pretty_flag(s.perilaku_merokok, "Tidak"),
                _pretty_flag(s.aktivitas_fisik, "Ya"),
                s.berat,
                s.tinggi,
                _pretty_flag(s.riwayat_dm, "Tidak"),
                s.lama_dm,
                s.gds,
                s.sistolik,
                s.diastolik,
                _pretty_flag(s.curiga_katarak, "Normal"),
                _pretty_flag(s.visus_mentah, "Normal"),
                _pretty_flag(s.kacamata_mentah, "Tidak"),
                _pretty_flag(s.serumen_mentah, "Normal"),
                _pretty_flag(s.gigi_karies, "Tidak"),
                s.kadar_co_mentah,
                _pretty_flag(s.malaria_mentah, "Non-Reaktif"),
                _pretty_flag(s.hepb_mentah, "Non-Reaktif"),
                _pretty_flag(s.hepc_mentah, "Non-Reaktif"),
                s.hb_anemia_mentah,
            ]
        ws.append(row_values)
        ws.row_dimensions[r_idx].height = 22

        row_fill = fill_zebra_even if r_idx % 2 == 0 else fill_zebra_odd
        for c_i in range(1, len(headers) + 1):
            c_cell = ws.cell(row=r_idx, column=c_i)
            c_cell.fill = row_fill
            c_cell.font = font_nama if c_i == 6 else font_data
            c_cell.border = cell_border
            c_cell.alignment = align_center if c_i in center_cols else align_left

        # Ensure NIK, DOB, and WA stay formatted as text
        ws.cell(row=r_idx, column=5).number_format = "@"
        ws.cell(row=r_idx, column=7).number_format = "@"
        ws.cell(row=r_idx, column=9).number_format = "@"

        # Column A: Tatalaksana Medis badge styling
        tata_cell = ws.cell(row=r_idx, column=1)
        if tata_display == "Perlu Tindak Lanjut Medis":
            tata_cell.fill = fill_tata_merah
            tata_cell.font = font_tata_merah
        elif tata_display.startswith("Normal / Aman"):
            tata_cell.fill = fill_tata_hijau
            tata_cell.font = font_tata_hijau
        elif tata_display != "-":
            tata_cell.fill = fill_tata_abu
            tata_cell.font = font_tata_abu

        # Column B: Status Rapor WA badge styling
        rapor_cell = ws.cell(row=r_idx, column=2)
        if rapor_display == "Terkirim (WhatsApp)":
            rapor_cell.fill = fill_rapor_ok
            rapor_cell.font = font_rapor_ok

        # Column C: Nomor Tiket badge styling
        tiket_cell = ws.cell(row=r_idx, column=3)
        if tiket_display != "-":
            tiket_cell.fill = fill_tiket
            tiket_cell.font = font_tiket

        # Column D: Status Pelayanan CKG badge styling
        status_cell = ws.cell(row=r_idx, column=4)
        st_upper = status_display.upper()
        if st_upper.startswith("SELESAI") or "SUKSES" in st_upper:
            status_cell.fill = fill_st_hijau
            status_cell.font = font_st_hijau
        elif "GAGAL" in st_upper or "ERROR" in st_upper or "BELUM SELESAI" in st_upper:
            status_cell.fill = fill_st_merah
            status_cell.font = font_st_merah
        elif status_display not in ("-", "Belum Diproses"):
            status_cell.fill = fill_st_kuning
            status_cell.font = font_st_kuning

        # Highlight positive clinical findings (Gigi Karies / Mata / Telinga) so follow-up cause is immediately visible
        if not is_umum:
            for clin_col, normal_val in ((28, "Normal"), (29, "Normal"), (30, "Tidak"), (31, "Normal"), (32, "Tidak")):
                c_val = str(ws.cell(row=r_idx, column=clin_col).value or "").strip()
                if c_val and c_val not in (normal_val, "-"):
                    ws.cell(row=r_idx, column=clin_col).fill = fill_st_kuning
                    ws.cell(row=r_idx, column=clin_col).font = font_st_kuning

    ws.freeze_panes = "G2"
    last_col_letter = get_column_letter(len(headers))
    ws.auto_filter.ref = f"A1:{last_col_letter}{max(2, len(students) + 1)}"

    for col in ws.columns:
        col_letter = col[0].column_letter
        col_idx = col[0].column
        max_len = max((len(str(cell.value or "")) for cell in col), default=10)
        if col_idx == 4:
            ws.column_dimensions[col_letter].width = min(max(max_len + 4, 28), 58)
        elif col_idx in (1, 6, 10, 16):
            ws.column_dimensions[col_letter].width = min(max(max_len + 4, 18), 38)
        else:
            ws.column_dimensions[col_letter].width = min(max(max_len + 4, 13), 30)

    # Sheet 2: Ringkasan Eksekutif
    _build_executive_summary_sheet(wb, students, is_umum=is_umum)

    wb.save(out_path)
    wb.close()
    _suppress_excel_text_number_warnings(out_path)
    return out_path


def generate_smart_pro_template(
    output_path: str | Path,
    existing_students: Optional[List[StudentRecord]] = None,
    service_type: str = "sekolah",
) -> Path:
    """
    Create the robust 'CKG Smart Pro V3 (.xlsx)' template (or convert existing students into it)
    for either CKG Sekolah (33 columns) or CKG Umum (37 columns / Data_Siap_CKG).
    """
    if existing_students and any(getattr(s, "service_type", "sekolah") == "umum" for s in existing_students):
        service_type = "umum"

    out_path = Path(output_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    wb = openpyxl.Workbook()
    ws = wb.active

    fill_identitas = PatternFill(start_color="0F172A", end_color="0F172A", fill_type="solid")
    fill_sekolah = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
    fill_skrining = PatternFill(start_color="065F46", end_color="065F46", fill_type="solid")
    fill_nakes = PatternFill(start_color="4C1D95", end_color="4C1D95", fill_type="solid")
    font_hdr = Font(color="FFFFFF", bold=True, size=10)
    thin_border = Border(
        left=Side(style="thin", color="CBD5E1"),
        right=Side(style="thin", color="CBD5E1"),
        top=Side(style="thin", color="CBD5E1"),
        bottom=Side(style="thin", color="CBD5E1"),
    )

    if service_type == "umum":
        ws.title = "Data_Siap_CKG"
        ws.append(TEMPLATE_UMUM_COLUMNS)
        for col_idx in range(1, len(TEMPLATE_UMUM_COLUMNS) + 1):
            cell = ws.cell(row=1, column=col_idx)
            if col_idx <= 6:
                cell.fill = fill_identitas
            elif col_idx <= 13:
                cell.fill = fill_sekolah
            elif col_idx <= 16:
                cell.fill = fill_skrining
            else:
                cell.fill = fill_nakes
            cell.font = font_hdr
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.row_dimensions[1].height = 28

        if existing_students:
            for s in existing_students:
                ws.append(
                    [
                        s.nik,
                        s.nama,
                        s.tgl_iso or s.tgl_lahir_mentah,
                        s.jk_pasien,
                        s.wa_pasien,
                        s.tgl_pemeriksaan or dt.date.today().strftime("%Y-%m-%d"),
                        s.status_pernikahan or "Menikah",
                        s.pekerjaan or "Lainnya",
                        s.provinsi,
                        s.kabkota,
                        s.kecamatan,
                        s.desa,
                        s.detail_alamat,
                        s.riwayat_hubungan_intim or "Ya",
                        s.perilaku_merokok.capitalize() if s.perilaku_merokok else "Tidak",
                        s.aktivitas_fisik.capitalize() if s.aktivitas_fisik else "Ya",
                        s.berat,
                        s.tinggi,
                        s.lingkar_perut,
                        s.riwayat_dm.capitalize() if s.riwayat_dm else "Tidak",
                        s.lama_dm,
                        s.gds,
                        s.riwayat_hipertensi.capitalize() if s.riwayat_hipertensi else "Tidak",
                        s.lama_hipertensi,
                        s.sistolik,
                        s.diastolik,
                        "Curiga Katarak" if "katarak" in (s.curiga_katarak or "").lower() else "Normal",
                        s.gigi_karies or "Tidak",
                        s.gigi_hilang or "Tidak",
                        s.skrining_payudara if s.jk_pasien == "Perempuan" else "",
                        s.kadar_co_mentah,
                        s.hb_catin,
                        s.kolesterol_total,
                        s.hdl,
                        s.ldl,
                        s.trigliserida,
                        s.hasil_ekg,
                    ]
                )
        else:
            sample_row_umum = [
                "2171092404720003",
                "SUGITO",
                "1972-04-24",
                "Laki-laki",
                "089623131731",
                dt.date.today().strftime("%Y-%m-%d"),
                "Menikah",
                "Pegawai Swasta",
                "KEPULAUAN RIAU",
                "KOTA BATAM",
                "BENGKONG",
                "BENGKONG INDAH",
                "RT 003 RW 010 BENGKONG INDAH",
                "Ya",
                "Tidak",
                "Ya",
                "68",
                "166",
                "84",
                "Tidak",
                "",
                "104",
                "Tidak",
                "",
                "122",
                "80",
                "Normal",
                "Tidak",
                "Tidak",
                "",
                "",
                "",
                "188",
                "",
                "",
                "",
                "",
            ]
            ws.append(sample_row_umum)

        max_data_row = max(ws.max_row + 50, 200)
        for r in range(2, max_data_row + 1):
            ws.cell(row=r, column=1).number_format = "@"  # NIK
            ws.cell(row=r, column=3).number_format = "@"  # Tgl Lahir
            ws.cell(row=r, column=5).number_format = "@"  # WA
            ws.cell(row=r, column=6).number_format = "@"  # Tgl Pemeriksaan
            if r <= ws.max_row:
                for c in range(1, 38):
                    ws.cell(row=r, column=c).border = thin_border

        validations_umum = [
            ("D", '"Laki-laki,Perempuan"'),
            ("G", '"Belum Menikah,Menikah,Cerai Hidup,Cerai Mati"'),
            ("H", '"Lainnya,Belum/Tidak Bekerja,ASN (Kantor Pemerintah),Ibu Rumah Tangga,Pegawai Swasta,Petani / Pekebun"'),
            ("N", '"Ya,Tidak"'),
            ("O", '"Tidak,Ya"'),
            ("P", '"Ya,Tidak"'),
            ("T", '"Tidak,Ya"'),
            ("W", '"Tidak,Ya"'),
            ("AA", '"Normal,Curiga Katarak"'),
            ("AB", '"Tidak,Ya"'),
            ("AC", '"Tidak,Ya"'),
            ("AD", '"Sadanis,USG Payudara"'),
        ]
        for col_letter, formula in validations_umum:
            dv = DataValidation(type="list", formula1=formula, allow_blank=True)
            ws.add_data_validation(dv)
            dv.add(f"{col_letter}2:{col_letter}{max_data_row}")

        ws.freeze_panes = "C2"
        for col_idx in range(1, len(TEMPLATE_UMUM_COLUMNS) + 1):
            col_letter = get_column_letter(col_idx)
            hdr_len = len(TEMPLATE_UMUM_COLUMNS[col_idx - 1])
            ws.column_dimensions[col_letter].width = max(hdr_len + 5, 15)

        ws_guide = wb.create_sheet(title="Panduan CKG Umum")
        guide_rows = [
            ["PANDUAN FORMAT EXCEL CKG UMUM (37 KOLOM • DEWASA & LANSIA)"],
            [""],
            ["Kolom", "Nama Field", "Aturan & Auto-Healer Mesin V3.5", "Contoh Valid"],
            ["A (1)", "NIK", "Wajib 16 digit angka sesuai KTP/KK.", "2171092404720003"],
            ["B (2)", "Nama", "Nama lengkap peserta.", "SUGITO"],
            ["C (3)", "Tanggal Lahir", "Format YYYY-MM-DD (misal 1972-04-24).", "1972-04-24"],
            ["D (4)", "Jenis Kelamin", "Laki-laki / Perempuan (atau L / P).", "Laki-laki"],
            ["E (5)", "WhatsApp", "Nomor WA aktif (otomatis dilengkapi angka 0 di depan jika terpotong Excel).", "089623131731"],
            ["F (6)", "Tanggal Pemeriksaan", "Format YYYY-MM-DD tanggal pelayanan CKG Umum.", "2026-10-12"],
            ["G-H (7-8)", "Status & Pekerjaan", "Status Pernikahan (Belum Menikah/Menikah/Cerai Hidup/Cerai Mati) & Pekerjaan.", "Menikah | Lainnya"],
            ["I-M (9-13)", "Domisili", "Provinsi, Kab/Kota, Kecamatan, Desa/Kelurahan, Detail Alamat.", "KEPULAUAN RIAU | KOTA BATAM"],
            ["Q-S (17-19)", "Antropometri", "Berat Badan (kg), Tinggi Badan (cm), Lingkar Perut (cm).", "68 | 166 | 84"],
            ["T-Z (20-26)", "Gula Darah & Tensi", "Riwayat DM, Lama DM (bln), GDS, Riwayat HT, Lama HT (bln), Sistolik, Diastolik.", "Tidak | 104 | 122/80"],
            ["AA-AD (27-30)", "Mata, Gigi, Payudara", "Curiga Katarak, Gigi Karies, Gigi Hilang, Skrining Payudara (Sadanis khusus Perempuan).", "Normal | Tidak | Sadanis"],
            ["AG (33)", "Kolesterol Total", "Nilai POCT Kolesterol Total (mg/dL) bila diperiksa.", "188"],
        ]
        for r in guide_rows:
            ws_guide.append(r)
        ws_guide.column_dimensions["A"].width = 16
        ws_guide.column_dimensions["B"].width = 24
        ws_guide.column_dimensions["C"].width = 74
        ws_guide.column_dimensions["D"].width = 28

        wb.save(out_path)
        wb.close()
        return out_path

    ws.title = "Data Siswa CKG"
    ws.append(TEMPLATE_COLUMNS)
    for col_idx in range(1, len(TEMPLATE_COLUMNS) + 1):
        cell = ws.cell(row=1, column=col_idx)
        if col_idx <= 5:
            cell.fill = fill_identitas
        elif col_idx <= 12:
            cell.fill = fill_sekolah
        elif col_idx <= 16:
            cell.fill = fill_skrining
        else:
            cell.fill = fill_nakes
        cell.font = font_hdr
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    ws.row_dimensions[1].height = 28

    if existing_students:
        for s in existing_students:
            ws.append(
                [
                    s.nik,
                    s.nama,
                    s.tgl_iso or s.tgl_lahir_mentah,
                    s.jk_pasien,
                    s.wa_pasien,
                    s.nama_sekolah_bersih or s.nama_sekolah,
                    s.kelas_angka or s.kelas_mentah,
                    s.provinsi,
                    s.kabkota,
                    s.kecamatan,
                    s.desa,
                    s.detail_alamat,
                    s.batuk_tb.capitalize() if s.batuk_tb else "Tidak",
                    s.keputihan_putri.capitalize() if s.keputihan_putri else "Tidak",
                    s.perilaku_merokok.capitalize() if s.perilaku_merokok else "Tidak",
                    s.aktivitas_fisik.capitalize() if s.aktivitas_fisik else "Ya",
                    s.berat,
                    s.tinggi,
                    s.riwayat_dm.capitalize() if s.riwayat_dm else "Tidak",
                    s.lama_dm,
                    s.gds,
                    s.sistolik,
                    s.diastolik,
                    s.curiga_katarak.capitalize() if s.curiga_katarak else "Normal",
                    s.visus_mentah.capitalize() if s.visus_mentah else "Normal",
                    s.kacamata_mentah.capitalize() if s.kacamata_mentah else "Tidak",
                    s.serumen_mentah.capitalize() if s.serumen_mentah else "Normal",
                    s.gigi_karies or "Tidak",
                    s.kadar_co_mentah,
                    s.malaria_mentah or "Non-Reaktif",
                    s.hepb_mentah or "Non Reaktif",
                    s.hepc_mentah or "Non Reaktif",
                    s.hb_anemia_mentah,
                ]
            )
    else:
        sample_row = [
            "2171096011150012",
            "AINAYA FATHIYYATU RAHMA",
            "2015-11-20",
            "Perempuan",
            "085117622524",
            "SD NEGERI 005 BENGKONG",
            "4",
            "KEPULAUAN RIAU",
            "KOTA BATAM",
            "BENGKONG",
            "TANJUNG BUNTUNG",
            "BENGKONG INDAH",
            "Tidak",
            "Tidak",
            "Tidak",
            "Ya",
            "26.1",
            "132",
            "Tidak",
            "",
            "90",
            "90",
            "60",
            "Normal",
            "Normal",
            "Tidak",
            "Normal",
            "Tidak",
            "",
            "Non-Reaktif",
            "Non Reaktif",
            "Non Reaktif",
            "12.5",
        ]
        ws.append(sample_row)

    max_data_row = max(ws.max_row + 50, 200)
    for r in range(2, max_data_row + 1):
        ws.cell(row=r, column=1).number_format = "@"  # NIK as Text
        ws.cell(row=r, column=3).number_format = "@"  # Tanggal Lahir as Text
        ws.cell(row=r, column=5).number_format = "@"  # WhatsApp as Text
        if r <= ws.max_row:
            for c in range(1, 34):
                ws.cell(row=r, column=c).border = thin_border

    # Add Excel Dropdown Validations so users never mistype clinical codes
    validations = [
        ("D", '"Laki-laki,Perempuan"'),
        ("G", '"1,2,3,4,5,6,7,8,9,10,11,12"'),
        ("M", '"Tidak,Kurang dari 2 minggu,Lebih dari 2 minggu"'),
        ("N", '"Tidak,Ya"'),
        ("O", '"Tidak,Ya"'),
        ("P", '"Ya,Tidak"'),
        ("S", '"Tidak,Ya"'),
        ("X", '"Normal,Kanan,Kiri,Kanan & Kiri"'),
        ("Y", '"Normal,Kanan,Kiri,Kanan & Kiri"'),
        ("Z", '"Tidak,Ya"'),
        ("AA", '"Normal,Kanan,Kiri,Kanan & Kiri"'),
        ("AB", '"Tidak,1,2,3,>3"'),
    ]
    for col_letter, formula in validations:
        dv = DataValidation(type="list", formula1=formula, allow_blank=True)
        ws.add_data_validation(dv)
        dv.add(f"{col_letter}2:{col_letter}{max_data_row}")

    ws.freeze_panes = "C2"
    for col_idx in range(1, len(TEMPLATE_COLUMNS) + 1):
        col_letter = get_column_letter(col_idx)
        hdr_len = len(TEMPLATE_COLUMNS[col_idx - 1])
        ws.column_dimensions[col_letter].width = max(hdr_len + 5, 15)

    # Sheet 2: Panduan & Standar Data
    ws_guide = wb.create_sheet(title="Panduan & Standar Data")
    guide_rows = [
        ["PANDUAN FORMAT EXCEL CKG SMART PRO V3.0 (HIGH SUCCESS RATE)"],
        [""],
        ["Kolom", "Nama Field", "Aturan & Auto-Healer Mesin V3.0", "Contoh Valid"],
        ["A (1)", "NIK", "Wajib 16 digit angka. Mesin otomatis membersihkan spasi/kutip.", "2171096011150012"],
        ["B (2)", "Nama Lengkap", "Nama siswa sesuai KK / Dukcapil.", "AINAYA FATHIYYATU RAHMA"],
        ["C (3)", "Tanggal Lahir", "Format YYYY-MM-DD atau DD/MM/YYYY. Jika ditolak Dukcapil, Smart Sensor otomatis menukar DD/MM.", "2015-11-20"],
        ["D (4)", "Jenis Kelamin", "Laki-laki / Perempuan (atau L / P).", "Perempuan"],
        ["E (5)", "No WhatsApp", "Wajib diawali 08 (10-13 digit). Jika angka 0 hilang karena Excel (851...), mesin otomatis menyembuhkan jadi 0851...", "085117622524"],
        ["F (6)", "Nama Sekolah", "Nama sekolah sesuai aplikasi Kemenkes (SD NEGERI ... atau SDN ...). Mesin otomatis mencoba kedua variasi.", "SD NEGERI 005 BENGKONG"],
        ["G (7)", "Kelas", "Angka kelas 1 s/d 12 (atau 'Kelas 4'). Mesin otomatis menormalisasi menjadi 'Kelas X'.", "4"],
        ["H-L (8-12)", "Domisili", "Provinsi, Kab/Kota, Kecamatan, Desa/Kelurahan, Detail Alamat.", "KEPULAUAN RIAU | KOTA BATAM"],
        ["M-P (13-16)", "Skrining Mandiri", "Batuk TB, Keputihan, Merokok, Aktivitas Fisik (Ya/Tidak).", "Tidak"],
        ["Q-R (17-18)", "BB & TB", "Berat Badan (kg) & Tinggi Badan (cm). Koma otomatis diubah ke titik.", "26.1 | 132"],
        ["U-W (21-23)", "GDS & Tensi", "GDS (mg/dL), Sistolik (mmHg), Diastolik (mmHg) dalam angka bulat.", "90 | 90 | 60"],
        ["X-AB (24-28)", "Mata, Telinga, Gigi", "Katarak/Visus/Serumen: Normal/Kanan/Kiri. Gigi Karies: Tidak / 1 / 2 / 3 / >3.", "Normal | Tidak"],
    ]
    for r in guide_rows:
        ws_guide.append(r)
    ws_guide.column_dimensions["A"].width = 16
    ws_guide.column_dimensions["B"].width = 22
    ws_guide.column_dimensions["C"].width = 72
    ws_guide.column_dimensions["D"].width = 28

    wb.save(out_path)
    wb.close()
    return out_path


def generate_sample_template(output_path: str | Path, service_type: str = "sekolah") -> Path:
    """Generate the Smart Pro V3 sample template for CKG Sekolah (33-col) or CKG Umum (37-col)."""
    return generate_smart_pro_template(output_path, service_type=service_type)
