let currentMode = "C";
let currentServiceType = "sekolah";
let lastLogId = 0;
let cachedStudents = [];
let cachedSlots = [];
let peekOpen = false;
let initialConfigLoaded = false;
let verifyingSlotId = 0;

function applyProgramUI(serviceType) {
  const isUmum = serviceType === "umum";
  currentServiceType = isUmum ? "umum" : "sekolah";

  const btnSek = document.getElementById("progBtnSekolah");
  const btnUmum = document.getElementById("progBtnUmum");
  if (btnSek) btnSek.classList.toggle("active", !isUmum);
  if (btnUmum) btnUmum.classList.toggle("active", isUmum);

  const badgeEl = document.getElementById("activeProgramBadge");
  if (badgeEl) {
    badgeEl.textContent = isUmum ? "CKG UMUM • 37 KOLOM" : "CKG SEKOLAH • 33 KOLOM";
  }

  const statTotalLbl = document.getElementById("statTotalLabel");
  if (statTotalLbl) {
    statTotalLbl.textContent = isUmum ? "TOTAL PESERTA CKG" : "TOTAL PESERTA DIDIK";
  }

  const statHealedDesc = document.getElementById("statHealedDesc");
  if (statHealedDesc) {
    statHealedDesc.textContent = isUmum
      ? "Format No. WA, Tgl Lahir & Validasi Klinis"
      : "Format No. WA Ortu, Tgl Lahir & Nama Sekolah";
  }

  const statWarnFoot = document.getElementById("statWarningFoot");
  if (statWarnFoot) {
    statWarnFoot.textContent = isUmum
      ? "Pemeriksaan tuntas • Ada temuan medis (Tensi/GDS/Kolesterol)"
      : "Pemeriksaan tuntas • Ada temuan medis (Gigi/Mata/Gizi)";
  }

  const modeASub = document.getElementById("modeASub");
  if (modeASub) {
    modeASub.textContent = isUmum
      ? "Hanya mendaftarkan peserta & klik konfirmasi hadir"
      : "Hanya mendaftarkan siswa baru & klik konfirmasi hadir";
  }

  const modeBSub = document.getElementById("modeBSub");
  if (modeBSub) {
    modeBSub.textContent = isUmum
      ? "Hanya mengisi kuesioner skrining mandiri peserta"
      : "Hanya mengisi kuesioner skrining mandiri siswa";
  }

  const rowAlamatSekolah = document.getElementById("rowAlamatSekolah");
  if (rowAlamatSekolah) {
    rowAlamatSekolah.classList.toggle("hidden", isUmum);
  }

  const lblCariByTiket = document.getElementById("lblCariByTiket");
  if (lblCariByTiket) {
    lblCariByTiket.innerHTML = isUmum
      ? "Cari peserta menggunakan <b>Nomor Tiket</b> (jika NIK ganda)"
      : "Cari siswa menggunakan <b>Nomor Tiket</b> (jika NIK ganda)";
  }

  const lblUpdateDataLama = document.getElementById("lblUpdateDataLama");
  if (lblUpdateDataLama) {
    lblUpdateDataLama.textContent = isUmum
      ? "Perbarui ulang data peserta yang sudah pernah diperiksa"
      : "Perbarui ulang data siswa yang sudah pernah diperiksa";
  }

  const lblAttendanceSection = document.getElementById("lblAttendanceSection");
  if (lblAttendanceSection) {
    lblAttendanceSection.textContent = isUmum
      ? "4. OPSI KHUSUS KEHADIRAN PESERTA"
      : "4. OPSI KHUSUS KEHADIRAN SISWA";
  }

  const lblModeBypass = document.getElementById("lblModeBypass");
  if (lblModeBypass) {
    lblModeBypass.innerHTML = isUmum
      ? "<b>Peserta Sudah Hadir</b> (Langsung buka menu Pelayanan)"
      : "<b>Siswa Sudah Hadir</b> (Langsung buka menu Pelayanan)";
  }

  const lblModeProsesBooking = document.getElementById("lblModeProsesBooking");
  if (lblModeProsesBooking) {
    lblModeProsesBooking.innerHTML = isUmum
      ? "<b>Konfirmasi Booking</b> (Hanya hadirkan peserta terdaftar)"
      : "<b>Konfirmasi Booking</b> (Hanya hadirkan siswa terdaftar)";
  }

  const btnRetry = document.getElementById("btnRetry");
  if (btnRetry) {
    btnRetry.textContent = isUmum ? "🔄 Ulangi Peserta Terkendala" : "🔄 Ulangi Siswa Terkendala";
  }

  const gridSek = document.getElementById("sniperGridSekolah");
  const gridUmum = document.getElementById("sniperGridUmum");
  if (gridSek) gridSek.classList.toggle("hidden", isUmum);
  if (gridUmum) gridUmum.classList.toggle("hidden", !isUmum);

  const nakesLbl = document.getElementById("nakesSectionLabel");
  if (nakesLbl) {
    nakesLbl.textContent = isUmum
      ? "3. FORM NAKES (DEWASA & LANSIA)"
      : "3. FORM PEMERIKSAAN NAKES";
  }

  const tblTitle = document.getElementById("tablePanelTitle");
  if (tblTitle) {
    tblTitle.textContent = isUmum
      ? "📋 Daftar Peserta & Hasil Pelayanan CKG Umum"
      : "📋 Daftar Peserta Didik & Hasil Pelayanan CKG Sekolah";
  }

  const thId = document.getElementById("thIdentityLabel");
  if (thId) thId.textContent = isUmum ? "Identitas Peserta CKG" : "Identitas Peserta Didik";

  const thWa = document.getElementById("thWaLabel");
  if (thWa) thWa.textContent = isUmum ? "No. WhatsApp" : "No. WhatsApp Ortu";

  const thSch = document.getElementById("thSchoolLabel");
  if (thSch) thSch.textContent = isUmum ? "Domisili & Usia" : "Sekolah & Kelas";

  const btnPick = document.getElementById("btnPickExcel");
  if (btnPick) {
    btnPick.textContent = isUmum ? "📂 Pilih Excel CKG Umum" : "📂 Pilih Excel CKG Sekolah";
  }

  const btnTpl = document.getElementById("btnDownloadTemplate");
  if (btnTpl) {
    btnTpl.textContent = isUmum ? "📥 Contoh Format Umum (37 Kol)" : "📥 Contoh Format Sekolah (33 Kol)";
  }
}

function toggleAllNakesForms(checked) {
  const containerId = currentServiceType === "umum" ? "sniperGridUmum" : "sniperGridSekolah";
  const container = document.getElementById(containerId);
  if (!container) return;
  container.querySelectorAll('input[type="checkbox"]').forEach((cb) => {
    cb.checked = Boolean(checked);
  });
  if (currentServiceType === "umum") {
    const g = document.getElementById("cfg_is_gigi");
    const m = document.getElementById("cfg_is_telinga_mata");
    if (g) g.checked = Boolean(checked);
    if (m) m.checked = Boolean(checked);
  }
  syncConfig();
}

async function switchProgram(targetType) {
  applyProgramUI(targetType);
  lastKelasSignature = "";
  lastRenderedTableHtml = "";
  try {
    await fetch("/api/switch-program", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ service_type: targetType }),
    });
  } catch (e) {
    console.warn("switchProgram error:", e);
  }
  await fetchState();
}

// World-Class Data Table State (Pagination, Multi-Column Filter & Sort)
let currentPage = 1;
let pageSize = 5;
let sortColumn = "row_index";
let sortDir = "asc";
let followActiveStudent = true;
let lastFollowedRowIndex = -1;
let lastKelasSignature = "";
let lastRenderedTableHtml = "";
let lastRenderedPagHtml = "";

// Initialize Theme (Default: SATUSEHAT Indonesiaku Light Clinical Theme)
function initTheme() {
  const saved = localStorage.getItem("ckg_satusehat_theme") || "light";
  applyTheme(saved);
}

function applyTheme(theme) {
  const cleanTheme = theme === "dark" ? "dark" : "light";
  document.documentElement.setAttribute("data-theme", cleanTheme);
  localStorage.setItem("ckg_satusehat_theme", cleanTheme);
  const iconEl = document.getElementById("themeIcon");
  const labelEl = document.getElementById("themeLabel");
  if (iconEl && labelEl) {
    if (cleanTheme === "dark") {
      iconEl.textContent = "☀️";
      labelEl.textContent = "Terang";
    } else {
      iconEl.textContent = "🌙";
      labelEl.textContent = "Malam";
    }
  }
}

function toggleTheme() {
  const current = document.documentElement.getAttribute("data-theme") || "light";
  applyTheme(current === "dark" ? "light" : "dark");
}

initTheme();

async function fetchState() {
  try {
    const res = await fetch(`/api/state?since_log_id=${lastLogId}`);
    if (!res.ok) return;
    const data = await res.json();
    updateDashboardUI(data);
  } catch (err) {
    console.warn("Polling error:", err);
  }
}

function formatFriendlySystemStatus(rawStatus, state) {
  const txt = String(rawStatus || "").trim();
  if (!txt) return "-";
  if (txt.toUpperCase().includes("SUKSES PARIPURNA")) {
    return "Layanan Tuntas • Pemeriksaan & Rapor Selesai";
  }
  if (txt.toUpperCase().includes("SUKSES (DRAFT")) {
    return "Data Tersimpan (Belum Klik Selesaikan Layanan)";
  }
  return txt
    .replace(/^Skipped:\s*/i, "")
    .replace(/Sudah Dilayani/i, "Sudah Selesai Diperiksa Sebelumnya");
}

function formatFriendlyLogMessage(msg) {
  return String(msg || "")
    .replace(/\[W(\d+)\]/g, "[Petugas #$1]")
    .replace(/Worker #(\d+)/g, "Petugas #$1")
    .replace(/Headless Background/gi, "Mode Otomatis di Balik Layar")
    .replace(/SUKSES PARIPURNA \(Mode C\)/gi, "SELESAI PEMERIKSAAN LENGKAP");
}

function updateDashboardUI(data) {
  // 1. Friendly Status Tag & Active Puskesmas
  const pTag = document.getElementById("platformTag");
  if (pTag) {
    pTag.textContent = data.is_running ? "Sedang Melayani..." : "Siap Melayani";
  }
  const faskesText = data.faskes_region
    ? `${data.active_faskes || "Puskesmas Aktif"} (${data.faskes_region})`
    : data.active_faskes || "Puskesmas Aktif";
  document.getElementById("faskesLabel").textContent = faskesText;

  // 2. Session Pill, Expired Banner & Multi-Account Officer Manager
  const dot = document.getElementById("sessionDot");
  const sText = document.getElementById("sessionText");
  const banner = document.getElementById("sessionBanner");
  const slots = data.session_slots || [];
  cachedSlots = slots;

  const healthySlots = slots.filter(
    (s) => s.has_file && (s.status === "active" || s.status === "expiring_soon")
  );
  const slotBadge = document.getElementById("slotCountBadge");
  if (slotBadge) {
    slotBadge.textContent = `${healthySlots.length}/4`;
  }

  if (data.session_expired) {
    dot.className = "status-dot err";
    sText.textContent = "Sesi Berakhir (Klik Login Ulang)";
    banner.classList.remove("hidden");
  } else if (data.has_session) {
    dot.className = "status-dot ok";
    const s1 = healthySlots[0];
    const expHint =
      s1 && typeof s1.jwt_remaining_minutes === "number" && s1.jwt_remaining_minutes > 0
        ? ` • ${Math.floor(s1.jwt_remaining_minutes / 60)}j ${s1.jwt_remaining_minutes % 60}m`
        : "";
    sText.textContent =
      healthySlots.length > 1
        ? `${healthySlots.length} Akun Petugas Aktif${expHint}`
        : `Akun Kemenkes Terhubung${expHint}`;
    banner.classList.add("hidden");
  } else {
    dot.className = "status-dot";
    sText.textContent = "Belum Login Akun Kemenkes";
    banner.classList.add("hidden");
  }

  renderSessionSlots(slots);
  if (data.saas) {
    updateSaasStudioUI(data.saas, data.active_faskes);
  }

  // 3. Sync UI controls & active program on poll
  const dq = data.data_quality || {};
  const detectedProg = dq.service_type || (data.config && data.config.service_type) || "sekolah";
  applyProgramUI(detectedProg);

  if (!initialConfigLoaded && data.config) {
    applyConfigToInputs(data.config);
    initialConfigLoaded = true;
  }

  // 4. Stats Cards & Progress Bar
  const st = data.stats || {};
  const isUmum = currentServiceType === "umum";
  const unitLabel = isUmum ? "Peserta Umum" : "Peserta Didik";
  const normalDone = st.success || 0;
  const tataDone = st.warning || 0;
  const totalCompletedExam = normalDone + tataDone;

  document.getElementById("statTotal").textContent = st.total || 0;
  document.getElementById("statSuccess").textContent = totalCompletedExam;
  document.getElementById("statWarning").textContent = tataDone;
  document.getElementById("statFailed").textContent = st.failed || 0;
  document.getElementById("statSkippedChip").textContent = `${st.skipped || 0} Dilewati`;
  document.getElementById("statProgressLabel").textContent =
    totalCompletedExam > 0
      ? `${normalDone} Normal • ${tataDone} Tindak Lanjut (${st.progress_pct || 0}%)`
      : `Cakupan Pelayanan: ${st.progress_pct || 0}% (${st.done || 0}/${st.total || 0})`;
  document.getElementById("statRunningLabel").textContent =
    `Dilewati (Sudah Dilayani): ${st.skipped || 0} • Sedang Diperiksa: ${st.running || 0}`;
  document.getElementById("statSuccessRate").textContent = `${st.success_rate_pct ?? 100}% Tuntas`;
  document.getElementById("progressBar").style.width = `${st.progress_pct || 0}%`;

  const totalHealed =
    (dq.healed_wa_count || 0) +
    (dq.healed_date_count || 0) +
    (dq.healed_school_count || 0) +
    (dq.healed_numeric_count || 0);
  document.getElementById("statHealed").textContent = totalHealed;
  document.getElementById("chipFormat").textContent = isUmum
    ? "CKG Umum • 37 Kol"
    : "CKG Sekolah • 33 Kol";

  if (data.file_name) {
    document.getElementById("statFileLabel").textContent = data.file_name;
    document.getElementById("uploadTitle").textContent = `✅ ${data.file_name} (${st.total || 0} ${unitLabel} Dimuat)`;
  }

  // 5. Data Quality Banner
  const healerBanner = document.getElementById("healerBanner");
  if (st.total > 0) {
    healerBanner.classList.remove("hidden");
    const parts = [];
    if (dq.healed_wa_count > 0) parts.push(`${dq.healed_wa_count} No. WA otomatis dilengkapi angka '08...'`);
    if (dq.healed_date_count > 0) parts.push(`${dq.healed_date_count} Tanggal Lahir disesuaikan`);
    if (dq.healed_school_count > 0) parts.push(`${dq.healed_school_count} Nama Sekolah dirapikan`);
    if (dq.invalid_nik_count > 0) parts.push(`⚠️ ${dq.invalid_nik_count} NIK belum 16 digit`);

    document.getElementById("healerTitle").textContent = `ℹ️ Pemeriksaan Format Data ${unitLabel} (${dq.format_detected || (isUmum ? "Format Standar CKG Umum 37 Kolom" : "Format Standar CKG Sekolah 33 Kolom")})`;
    document.getElementById("healerDetails").textContent =
      parts.length > 0
        ? parts.join(" • ")
        : `Seluruh data ${unitLabel.toLowerCase()} sudah rapi dan siap dicatat ke aplikasi Sehat Indonesiaku.`;
  } else {
    healerBanner.classList.add("hidden");
  }

  // 6. Control Buttons State
  const btnStart = document.getElementById("btnStart");
  const btnRetry = document.getElementById("btnRetry");
  const btnPause = document.getElementById("btnPause");
  const btnStop = document.getElementById("btnStop");

  btnStart.disabled = data.is_running;
  btnRetry.disabled = data.is_running;
  btnPause.disabled = !data.is_running;
  btnStop.disabled = !data.is_running;
  btnPause.innerHTML = data.is_paused ? "▶️ Lanjutkan Pelayanan" : "⏸️ Jeda Sementara";

  // 7. Active Officer Pills
  const strip = document.getElementById("workerStrip");
  const workers = data.workers || {};
  const wKeys = Object.keys(workers);
  if (wKeys.length === 0) {
    strip.innerHTML = "";
  } else {
    strip.innerHTML = wKeys
      .map(
        (k) =>
          `<div class="worker-pill"><b>👩‍⚕️ Petugas #${k}</b> <span>${escapeHtml(workers[k])}</span></div>`
      )
      .join("");
  }

  // 8. Students Table
  cachedStudents = data.students || [];
  renderStudentTable();

  // 9. Append New Logs
  if (data.logs && data.logs.length > 0) {
    const consoleEl = document.getElementById("logConsole");
    for (const lg of data.logs) {
      const div = document.createElement("div");
      div.className = `log-line log-${lg.level || "info"}`;
      div.innerHTML = `<span class="log-time">[${lg.time}]</span>${escapeHtml(formatFriendlyLogMessage(lg.message))}`;
      consoleEl.appendChild(div);
      lastLogId = Math.max(lastLogId, lg.id);
    }
    consoleEl.scrollTop = consoleEl.scrollHeight;
  }

  // 10. Refresh Peek if open
  if (peekOpen && data.available_peeks && data.available_peeks.length > 0) {
    renderPeekImages(data.available_peeks, workers);
  }

  // 11. Align Right Workspace Column (Table + Activity Log) flush with Left Config Panel
  syncWorkspaceHeight();
}

function updateQuickFilterCounts(students) {
  const counts = {
    all: students.length,
    completed_all: 0,
    success: 0,
    warning: 0,
    running: 0,
    pending: 0,
    failed: 0,
    skipped: 0,
  };
  for (const s of students) {
    const st = s.state || "pending";
    if (st === "success") {
      counts.success++;
      counts.completed_all++;
    } else if (st === "warning") {
      counts.warning++;
      counts.completed_all++;
    } else if (counts[st] !== undefined) {
      counts[st]++;
    } else {
      counts.pending++;
    }
  }
  for (const [k, v] of Object.entries(counts)) {
    const el = document.getElementById(`qCount_${k}`);
    if (el && el.textContent !== String(v)) {
      el.textContent = String(v);
    }
  }
}

function updateKelasFilterOptions(students) {
  const sel = document.getElementById("colFilterKelas");
  if (!sel) return;
  const isUmum = currentServiceType === "umum";
  const classCounts = new Map();
  for (const s of students) {
    let k = String(s.kelas || "").trim();
    if (isUmum && !k) {
      const u = Number(s.usia_tahun || 0);
      k = u >= 60 ? "Lansia (≥60 th)" : u >= 18 ? "Dewasa (18–59 th)" : u >= 10 ? "Remaja (10–17 th)" : "Anak (<10 th)";
    }
    if (!k) continue;
    classCounts.set(k, (classCounts.get(k) || 0) + 1);
  }
  const sortedClasses = Array.from(classCounts.keys()).sort((a, b) =>
    a.localeCompare(b, "id", { numeric: true })
  );
  const sig = `${currentServiceType}::` + sortedClasses.map((k) => `${k}:${classCounts.get(k)}`).join("|");
  if (sig === lastKelasSignature) return;
  lastKelasSignature = sig;

  const currentVal = sel.value || "all";
  let html = `<option value="all">${isUmum ? "Semua Usia" : "Semua Kelas"}</option>`;
  for (const k of sortedClasses) {
    const cnt = classCounts.get(k);
    html += `<option value="${escapeHtml(k)}">${escapeHtml(k)} (${cnt})</option>`;
  }
  sel.innerHTML = html;
  if (sortedClasses.includes(currentVal)) {
    sel.value = currentVal;
  } else {
    sel.value = "all";
  }
}

function selectQuickStatus(stateVal) {
  const sel = document.getElementById("filterState");
  if (sel) sel.value = stateVal;
  syncQuickChipsHighlight(stateVal);
  currentPage = 1;
  renderStudentTable();
}

function onStatusSelectChange() {
  const sel = document.getElementById("filterState");
  const stateVal = sel ? sel.value : "all";
  syncQuickChipsHighlight(stateVal);
  currentPage = 1;
  renderStudentTable();
}

function syncQuickChipsHighlight(stateVal) {
  document.querySelectorAll("#quickStatusChips .q-chip").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.state === stateVal);
  });
}

function onFilterChange() {
  currentPage = 1;
  renderStudentTable();
}

function clearGlobalSearch() {
  const inp = document.getElementById("searchStudent");
  if (inp) inp.value = "";
  currentPage = 1;
  renderStudentTable();
}

function resetTableFilters() {
  const idsToReset = [
    ["searchStudent", ""],
    ["colFilterGender", "all"],
    ["colFilterIdentity", ""],
    ["colFilterWa", "all"],
    ["colFilterKelas", "all"],
    ["colFilterKlinis", "all"],
    ["colFilterTiket", ""],
    ["filterState", "all"],
    ["colFilterRapor", "all"],
    ["colFilterTata", "all"],
    ["colFilterStep", ""],
  ];
  for (const [id, defVal] of idsToReset) {
    const el = document.getElementById(id);
    if (el) el.value = defVal;
  }
  sortColumn = "row_index";
  sortDir = "asc";
  updateSortIndicators();
  syncQuickChipsHighlight("all");
  currentPage = 1;
  renderStudentTable();
}

function toggleFollowActive() {
  followActiveStudent = !followActiveStudent;
  const btn = document.getElementById("btnFollowActive");
  if (btn) {
    btn.classList.toggle("active-follow", followActiveStudent);
  }
  if (followActiveStudent) {
    lastFollowedRowIndex = -1;
    renderStudentTable();
  }
}

function toggleSort(col) {
  if (sortColumn === col) {
    sortDir = sortDir === "asc" ? "desc" : "asc";
  } else {
    sortColumn = col;
    sortDir = "asc";
  }
  updateSortIndicators();
  renderStudentTable();
}

function updateSortIndicators() {
  const cols = [
    "row_index",
    "nama",
    "wa",
    "kelas",
    "berat",
    "no_tiket",
    "state",
    "status_rapor",
    "tatalaksana",
    "last_step",
  ];
  for (const c of cols) {
    const el = document.getElementById(`sort_${c}`);
    if (!el) continue;
    if (c === sortColumn) {
      el.textContent = sortDir === "asc" ? "▲" : "▼";
      el.classList.add("active");
    } else {
      el.textContent = "↕";
      el.classList.remove("active");
    }
  }
}

function onPageSizeChange() {
  const sel = document.getElementById("pageSizeSelect");
  pageSize = parseInt(sel?.value || "5", 10) || 5;
  currentPage = 1;
  renderStudentTable();
  syncWorkspaceHeight();
}

function goToPage(p, manualClick = false) {
  if (manualClick && followActiveStudent) {
    // Pause auto-follow when user explicitly navigates to another page while a student is running
    const hasRunning = cachedStudents.some((s) => s.state === "running");
    if (hasRunning) {
      followActiveStudent = false;
      const btn = document.getElementById("btnFollowActive");
      if (btn) btn.classList.remove("active-follow");
    }
  }
  currentPage = Math.max(1, p);
  renderStudentTable();
}

function renderStudentTable() {
  const tbody = document.getElementById("studentTableBody");
  if (!tbody) return;

  updateQuickFilterCounts(cachedStudents);
  updateKelasFilterOptions(cachedStudents);

  const q = (document.getElementById("searchStudent")?.value || "").toLowerCase().trim();
  const clearBtn = document.getElementById("btnClearSearch");
  if (clearBtn) clearBtn.classList.toggle("hidden", !q);

  const fGender = document.getElementById("colFilterGender")?.value || "all";
  const fIdentity = (document.getElementById("colFilterIdentity")?.value || "").toLowerCase().trim();
  const fWa = document.getElementById("colFilterWa")?.value || "all";
  const fKelas = document.getElementById("colFilterKelas")?.value || "all";
  const fKlinis = document.getElementById("colFilterKlinis")?.value || "all";
  const fTiket = (document.getElementById("colFilterTiket")?.value || "").toLowerCase().trim();
  const fState = document.getElementById("filterState")?.value || "all";
  const fRapor = document.getElementById("colFilterRapor")?.value || "all";
  const fTata = document.getElementById("colFilterTata")?.value || "all";
  const fStep = (document.getElementById("colFilterStep")?.value || "").toLowerCase().trim();

  // Highlight active column filter controls
  const filterControls = [
    ["colFilterGender", fGender !== "all"],
    ["colFilterIdentity", fIdentity !== ""],
    ["colFilterWa", fWa !== "all"],
    ["colFilterKelas", fKelas !== "all"],
    ["colFilterKlinis", fKlinis !== "all"],
    ["colFilterTiket", fTiket !== ""],
    ["filterState", fState !== "all"],
    ["colFilterRapor", fRapor !== "all"],
    ["colFilterTata", fTata !== "all"],
    ["colFilterStep", fStep !== ""],
  ];
  let anyFilterActive = Boolean(q) || sortColumn !== "row_index" || sortDir !== "asc";
  for (const [id, isActive] of filterControls) {
    if (isActive) anyFilterActive = true;
    const el = document.getElementById(id);
    if (el) el.classList.toggle("has-val", isActive);
  }
  const btnReset = document.getElementById("btnResetFilters");
  if (btnReset) btnReset.classList.toggle("hidden", !anyFilterActive);

  // Filter rows
  const filtered = cachedStudents.filter((s) => {
    const st = s.state || "pending";
    if (fState === "completed_all") {
      if (st !== "success" && st !== "warning") return false;
    } else if (fState !== "all" && st !== fState) {
      return false;
    }

    if (fGender !== "all") {
      const jkUpper = String(s.jk || "").toUpperCase();
      if (fGender === "L" && !jkUpper.startsWith("L")) return false;
      if (fGender === "P" && !jkUpper.startsWith("P")) return false;
    }

    if (fIdentity) {
      const matchId =
        (s.nama && s.nama.toLowerCase().includes(fIdentity)) ||
        (s.nik && s.nik.toLowerCase().includes(fIdentity));
      if (!matchId) return false;
    }

    if (fWa === "healed") {
      if (!s.healed_notes || s.healed_notes.length === 0) return false;
    } else if (fWa === "valid") {
      if (!s.wa || s.wa === "-") return false;
    }

    if (fKelas !== "all") {
      let rowK = String(s.kelas || "").trim();
      if (currentServiceType === "umum" && !rowK) {
        const u = Number(s.usia_tahun || 0);
        rowK = u >= 60 ? "Lansia (≥60 th)" : u >= 18 ? "Dewasa (18–59 th)" : u >= 10 ? "Remaja (10–17 th)" : "Anak (<10 th)";
      }
      if (rowK !== fKelas) return false;
    }

    if (fKlinis === "complete") {
      if (!s.berat || s.berat === "-" || !s.tinggi || s.tinggi === "-") return false;
    } else if (fKlinis === "warn") {
      if (!s.validation_warning && s.berat && s.berat !== "-" && s.tinggi && s.tinggi !== "-") {
        return false;
      }
    }

    if (fTiket) {
      if (!String(s.no_tiket || "").toLowerCase().includes(fTiket)) return false;
    }

    if (fRapor === "sent") {
      const rp = String(s.status_rapor || "").toLowerCase();
      if (!rp || rp === "-" || (!rp.includes("sukses") && !rp.includes("terkirim") && !rp.includes("3/3"))) {
        return false;
      }
    } else if (fRapor === "unsent") {
      const rp = String(s.status_rapor || "").toLowerCase();
      if (rp.includes("sukses") || rp.includes("terkirim") || rp.includes("3/3")) return false;
    }

    if (fTata === "tatalaksana") {
      if (s.tatalaksana !== "Harus tatalaksana") return false;
    } else if (fTata === "aman") {
      if (!String(s.tatalaksana || "").toLowerCase().includes("aman")) return false;
    } else if (fTata === "none") {
      if (s.tatalaksana && s.tatalaksana !== "-") return false;
    }

    if (fStep) {
      const stepMatch =
        String(s.last_step || "").toLowerCase().includes(fStep) ||
        String(s.status_sistem || "").toLowerCase().includes(fStep);
      if (!stepMatch) return false;
    }

    if (q) {
      const globalMatch =
        (s.nik && s.nik.toLowerCase().includes(q)) ||
        (s.nama && s.nama.toLowerCase().includes(q)) ||
        (s.sekolah && s.sekolah.toLowerCase().includes(q)) ||
        (s.kelas && s.kelas.toLowerCase().includes(q)) ||
        (s.no_tiket && s.no_tiket.toLowerCase().includes(q)) ||
        (s.wa && s.wa.toLowerCase().includes(q));
      if (!globalMatch) return false;
    }

    return true;
  });

  // Sort rows
  const sorted = [...filtered].sort((a, b) => {
    let va = a[sortColumn];
    let vb = b[sortColumn];
    if (sortColumn === "row_index") {
      va = Number(a.row_index ?? 0);
      vb = Number(b.row_index ?? 0);
    } else if (sortColumn === "berat") {
      va = parseFloat(a.berat) || 0;
      vb = parseFloat(b.berat) || 0;
    } else {
      va = String(va ?? "").toLowerCase();
      vb = String(vb ?? "").toLowerCase();
    }
    if (va < vb) return sortDir === "asc" ? -1 : 1;
    if (va > vb) return sortDir === "asc" ? 1 : -1;
    return (a.row_index ?? 0) - (b.row_index ?? 0);
  });

  const totalFiltered = sorted.length;
  const totalPages = Math.max(1, Math.ceil(totalFiltered / pageSize));

  // Auto-follow active running student if enabled
  if (followActiveStudent) {
    const runningIdx = sorted.findIndex((s) => s.state === "running");
    if (runningIdx !== -1) {
      const targetRowIdx = sorted[runningIdx].row_index;
      const targetPage = Math.floor(runningIdx / pageSize) + 1;
      if (targetRowIdx !== lastFollowedRowIndex || currentPage !== targetPage) {
        currentPage = targetPage;
        lastFollowedRowIndex = targetRowIdx;
      }
    }
  }

  if (currentPage > totalPages) currentPage = totalPages;
  if (currentPage < 1) currentPage = 1;

  const startIndex = (currentPage - 1) * pageSize;
  const pageItems = sorted.slice(startIndex, startIndex + pageSize);

  // Update Pagination Summary & Controls
  renderPaginationBar(totalFiltered, cachedStudents.length, startIndex, pageItems.length, totalPages);

  if (totalFiltered === 0) {
    const emptyMsg =
      cachedStudents.length === 0
        ? "Silakan pilih file Excel CKG Sekolah untuk memulai pelayanan."
        : "Tidak ada peserta didik yang sesuai dengan filter kolom / pencarian saat ini.";
    const emptyHtml = `<tr><td colspan="10" class="empty-cell">${emptyMsg}</td></tr>`;
    if (lastRenderedTableHtml !== emptyHtml) {
      tbody.innerHTML = emptyHtml;
      lastRenderedTableHtml = emptyHtml;
    }
    return;
  }

  const rowsHtml = pageItems
    .map((s) => {
      const st = s.state || "pending";
      const isFinishedExam = st === "success" || st === "warning";
      const rowCls = st === "running" ? ` class="row-running"` : "";
      const rawSys = String(s.status_sistem || "").toLowerCase();
      const rawStep = String(s.last_step || "").toLowerCase();
      const isMandiriIncomplete =
        (rawSys.includes("mandiri") && (rawSys.includes("belum lengkap") || rawSys.includes("menunggu"))) ||
        rawStep.includes("mandiri belum lengkap");

      let statusBadgeHtml = "";
      if (isMandiriIncomplete && st !== "running") {
        statusBadgeHtml = `<span class="badge badge-failed" title="Di portal SATUSEHAT, status Pemeriksaan Mandiri siswa ini masih Belum Lengkap">⚠️ Mandiri Belum Lengkap</span>`;
      } else if (isFinishedExam) {
        statusBadgeHtml = `<span class="badge badge-success">✓ Selesai Pemeriksaan</span>`;
      } else if (st === "skipped") {
        statusBadgeHtml = `<span class="badge badge-skipped">⏭ Sudah Dilayani</span>`;
      } else if (st === "running") {
        statusBadgeHtml = `<span class="badge badge-running">⏳ Sedang Diperiksa...</span>`;
      } else if (st === "failed") {
        statusBadgeHtml = `<span class="badge badge-failed">⚠ Terkendala</span>`;
      } else {
        statusBadgeHtml = `<span class="badge badge-pending">🕒 Menunggu Giliran</span>`;
      }

      let tataHtml = `<span class="student-sub-meta">-</span>`;
      if (s.tatalaksana === "Harus tatalaksana") {
        tataHtml = `
          <span class="badge badge-warning" title="Pemeriksaan CKG sudah selesai 100%. Kemenkes menandai adanya temuan klinis (Gigi/Mata/Gizi/TD) untuk tindak lanjut.">⚕ Perlu Tindak Lanjut</span>
          <div class="student-sub-meta">Ada temuan klinis</div>
        `;
      } else if (s.tatalaksana && s.tatalaksana.toLowerCase().includes("aman")) {
        tataHtml = `
          <span class="badge badge-success">✓ Normal / Aman</span>
          <div class="student-sub-meta">Tidak ada tindakan</div>
        `;
      } else if (s.tatalaksana && s.tatalaksana !== "-") {
        tataHtml = escapeHtml(s.tatalaksana);
      }

      const healedBadge =
        s.healed_notes && s.healed_notes.length > 0
          ? `<div class="badge-healed" title="${escapeHtml(s.healed_notes.join(" | "))}">✨ Dirapikan Otomatis</div>`
          : "";

      const warnBadge = s.validation_warning
        ? `<div class="badge-warn-inline">⚠️ ${escapeHtml(s.validation_warning)}</div>`
        : "";

      const friendlySubStatus = formatFriendlySystemStatus(s.status_sistem, st);
      const raporText =
        s.status_rapor && s.status_rapor !== "-"
          ? `<span class="badge badge-success">${escapeHtml(s.status_rapor.replace("Sukses", "Terkirim"))}</span>`
          : `<span class="student-sub-meta">-</span>`;

      const isRowUmum = s.service_type === "umum" || currentServiceType === "umum";
      const identityMeta = isRowUmum
        ? `${escapeHtml(s.nik)} • ${escapeHtml(s.jk)} (${escapeHtml(s.tgl_lahir)}, ${s.umur || "-"} th • ${escapeHtml(s.status_pernikahan || "Menikah")})`
        : `${escapeHtml(s.nik)} • ${escapeHtml(s.jk)} (${escapeHtml(s.tgl_lahir)}, ${s.umur || "-"} th)`;

      const kelasMeta = isRowUmum
        ? `${escapeHtml(s.kelas)}${s.tgl_pemeriksaan ? ` • Tgl: ${escapeHtml(s.tgl_pemeriksaan)}` : ""}`
        : escapeHtml(s.kelas);

      const anthropoLine = isRowUmum
        ? `<strong>${escapeHtml(s.berat || "-")} kg</strong> / <strong>${escapeHtml(s.tinggi || "-")} cm</strong>${s.lingkar_perut && s.lingkar_perut !== "-" ? ` • LP: <b>${escapeHtml(s.lingkar_perut)} cm</b>` : ""}`
        : `<strong>${escapeHtml(s.berat || "-")} kg</strong> / <strong>${escapeHtml(s.tinggi || "-")} cm</strong>`;

      const labLine = isRowUmum
        ? `TD: ${escapeHtml(s.tensi)} • GDS: ${escapeHtml(s.gds || "-")}${s.kolesterol_total && s.kolesterol_total !== "-" ? ` • Kol: <b>${escapeHtml(s.kolesterol_total)}</b>` : ""}`
        : `TD: ${escapeHtml(s.tensi)} • GDS: ${escapeHtml(s.gds || "-")}`;

      return `
        <tr${rowCls}>
          <td><strong>${s.row_index + 1}</strong></td>
          <td>
            <strong>${escapeHtml(s.nama)}</strong>
            <div class="student-sub-meta">${identityMeta}</div>
            ${warnBadge}
          </td>
          <td>
            <code style="font-size:11.5px">${escapeHtml(s.wa || "-")}</code>
            ${healedBadge}
          </td>
          <td>
            <div>${escapeHtml(s.sekolah)}</div>
            <div class="student-school-kelas">${kelasMeta}</div>
          </td>
          <td>
            <div>${anthropoLine}</div>
            <div class="student-sub-meta">${labLine}</div>
          </td>
          <td><span class="ticket-pill">${escapeHtml(s.no_tiket || "-")}</span></td>
          <td>
            ${statusBadgeHtml}
            <div class="student-sub-meta">${escapeHtml(friendlySubStatus)}</div>
          </td>
          <td>${raporText}</td>
          <td>${tataHtml}</td>
          <td class="student-sub-meta">${escapeHtml(s.last_step || "-")}</td>
        </tr>
      `;
    })
    .join("");

  if (lastRenderedTableHtml !== rowsHtml) {
    tbody.innerHTML = rowsHtml;
    lastRenderedTableHtml = rowsHtml;
  }
}

function renderPaginationBar(totalFiltered, totalAll, startIndex, countOnPage, totalPages) {
  const sumEl = document.getElementById("paginationSummary");
  if (sumEl) {
    if (totalFiltered === 0) {
      sumEl.innerHTML =
        totalAll > 0
          ? `Menampilkan <b>0</b> dari <b>0</b> hasil filter (total <b>${totalAll}</b> peserta didik)`
          : `Menampilkan <b>0</b> peserta didik`;
    } else {
      const fromNum = startIndex + 1;
      const toNum = startIndex + countOnPage;
      const filterSuffix =
        totalFiltered < totalAll ? ` hasil filter (total <b>${totalAll}</b>)` : ` peserta didik`;
      sumEl.innerHTML = `Menampilkan <b>${fromNum}–${toNum}</b> dari <b>${totalFiltered}</b>${filterSuffix}`;
    }
  }

  const ctrlEl = document.getElementById("paginationControls");
  if (!ctrlEl) return;

  const pages = [];
  if (totalPages <= 7) {
    for (let i = 1; i <= totalPages; i++) pages.push(i);
  } else {
    pages.push(1);
    if (currentPage > 3) pages.push("...");
    const startP = Math.max(2, currentPage - 1);
    const endP = Math.min(totalPages - 1, currentPage + 1);
    for (let i = startP; i <= endP; i++) pages.push(i);
    if (currentPage < totalPages - 2) pages.push("...");
    pages.push(totalPages);
  }

  let btnsHtml = `
    <button type="button" class="page-btn" onclick="goToPage(1, true)" ${currentPage <= 1 ? "disabled" : ""} title="Halaman Pertama">«</button>
    <button type="button" class="page-btn" onclick="goToPage(${currentPage - 1}, true)" ${currentPage <= 1 ? "disabled" : ""} title="Halaman Sebelumnya">‹ Prev</button>
  `;

  for (const p of pages) {
    if (p === "...") {
      btnsHtml += `<span class="page-ellipsis">…</span>`;
    } else {
      const activeCls = p === currentPage ? " active" : "";
      btnsHtml += `<button type="button" class="page-btn${activeCls}" onclick="goToPage(${p}, true)">${p}</button>`;
    }
  }

  btnsHtml += `
    <button type="button" class="page-btn" onclick="goToPage(${currentPage + 1}, true)" ${currentPage >= totalPages ? "disabled" : ""} title="Halaman Berikutnya">Next ›</button>
    <button type="button" class="page-btn" onclick="goToPage(${totalPages}, true)" ${currentPage >= totalPages ? "disabled" : ""} title="Halaman Terakhir">»</button>
  `;

  if (lastRenderedPagHtml !== btnsHtml) {
    ctrlEl.innerHTML = btnsHtml;
    lastRenderedPagHtml = btnsHtml;
  }
}

function syncWorkspaceHeight() {
  const configPanel = document.querySelector(".config-panel");
  const workspaceCol = document.querySelector(".workspace-col");
  const actionPanel = document.querySelector(".action-panel");
  const tablePanel = document.getElementById("tablePanel");
  const tableScroll = document.getElementById("tableScrollBox");
  const peekPanel = document.getElementById("peekPanel");

  if (!configPanel || !workspaceCol || !actionPanel || !tablePanel || !tableScroll) return;

  if (window.innerWidth <= 1180) {
    workspaceCol.style.height = "auto";
    configPanel.style.height = "auto";
    tableScroll.style.maxHeight = "380px";
    return;
  }

  // Measure natural height of left sidebar
  configPanel.style.height = "auto";
  const leftNaturalH = configPanel.offsetHeight;

  const isPeekVisible = peekPanel && !peekPanel.classList.contains("hidden");
  if (isPeekVisible) {
    workspaceCol.style.height = "auto";
    configPanel.style.height = "100%";
    return;
  }

  // Calculate available height so table + activity log fit cleanly and bottom aligns 100% with left panel
  const actionH = actionPanel.offsetHeight;
  const tableChromeH = tablePanel.offsetHeight - tableScroll.offsetHeight;
  const minLogPanelH = 215; // Comfortable height for Riwayat Aktivitas Pelayanan Langsung
  const gapsH = 28; // 2 x 14px flex gap in workspace-col

  const idealTableScrollMax = Math.max(
    245,
    leftNaturalH - actionH - tableChromeH - minLogPanelH - gapsH
  );
  tableScroll.style.maxHeight = `${idealTableScrollMax}px`;

  // Lock both columns to the same height so .log-panel (flex: 1 1 0) ends pixel-flush with .config-panel
  workspaceCol.style.height = `${leftNaturalH}px`;
  configPanel.style.height = `${leftNaturalH}px`;
}

window.addEventListener("resize", syncWorkspaceHeight);

function selectMode(mode) {
  currentMode = mode;
  document.querySelectorAll(".mode-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.mode === mode);
  });
  syncConfig();
}

function updateWorkerLabel() {
  const el = document.getElementById("workerCountLabel");
  if (el) {
    el.textContent = "1 Petugas Turbo Stabil";
  }
}

function handleSubMode(which) {
  const byp = document.getElementById("cfg_mode_bypass");
  const bkg = document.getElementById("cfg_mode_booking");
  const prb = document.getElementById("cfg_mode_proses_booking");
  if (which === "bypass" && byp.checked) {
    bkg.checked = false;
    prb.checked = false;
  } else if (which === "booking" && bkg.checked) {
    byp.checked = false;
    prb.checked = false;
  } else if (which === "proses_booking" && prb.checked) {
    byp.checked = false;
    bkg.checked = false;
  }
  syncConfig();
}

function gatherConfigFromInputs() {
  return {
    mode: currentMode,
    service_type: currentServiceType,
    headless: document.getElementById("cfg_headless").checked,
    workers: parseInt(document.getElementById("cfg_workers").value, 10) || 1,
    block_media: document.getElementById("cfg_block_media").checked,
    alamat_sekolah: document.getElementById("cfg_alamat_sekolah").checked,
    cari_by_tiket: document.getElementById("cfg_cari_by_tiket").checked,
    update_data_lama: document.getElementById("cfg_update_data_lama").checked,
    lewati_skrining: document.getElementById("cfg_lewati_skrining").checked,
    kirim_rapor: document.getElementById("cfg_kirim_rapor").checked,
    auto_selesai: document.getElementById("cfg_auto_selesai").checked,
    mode_bypass: document.getElementById("cfg_mode_bypass").checked,
    mode_booking: document.getElementById("cfg_mode_booking").checked,
    mode_proses_booking: document.getElementById("cfg_mode_proses_booking").checked,
    is_telinga_mata: document.getElementById("cfg_is_telinga_mata").checked,
    is_gigi: document.getElementById("cfg_is_gigi").checked,
    is_tb: document.getElementById("cfg_is_tb").checked,
    is_kulit: document.getElementById("cfg_is_kulit").checked,
    is_ppok: document.getElementById("cfg_is_ppok").checked,
    is_kebugaran: document.getElementById("cfg_is_kebugaran").checked,
    is_co: document.getElementById("cfg_is_co").checked,
    is_malaria: document.getElementById("cfg_is_malaria").checked,
    is_hepatitis: document.getElementById("cfg_is_hepatitis").checked,
    is_anemia: document.getElementById("cfg_is_anemia").checked,
    is_gizi_umum: document.getElementById("cfg_is_gizi_umum")
      ? document.getElementById("cfg_is_gizi_umum").checked
      : true,
    is_tensi_umum: document.getElementById("cfg_is_tensi_umum")
      ? document.getElementById("cfg_is_tensi_umum").checked
      : true,
    is_gds_umum: document.getElementById("cfg_is_gds_umum")
      ? document.getElementById("cfg_is_gds_umum").checked
      : true,
    is_lipid_umum: document.getElementById("cfg_is_lipid_umum")
      ? document.getElementById("cfg_is_lipid_umum").checked
      : true,
    is_payudara_umum: document.getElementById("cfg_is_payudara_umum")
      ? document.getElementById("cfg_is_payudara_umum").checked
      : true,
    is_ekg_umum: document.getElementById("cfg_is_ekg_umum")
      ? document.getElementById("cfg_is_ekg_umum").checked
      : true,
  };
}

function applyConfigToInputs(cfg) {
  currentMode = cfg.mode || "C";
  if (cfg.service_type) {
    applyProgramUI(cfg.service_type);
  }
  document.querySelectorAll(".mode-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.mode === currentMode);
  });
  const setCheck = (id, val) => {
    const el = document.getElementById(id);
    if (el && typeof val === "boolean") el.checked = val;
  };
  setCheck("cfg_headless", cfg.headless);
  if (cfg.workers) {
    document.getElementById("cfg_workers").value = cfg.workers;
    updateWorkerLabel();
  }
  setCheck("cfg_block_media", cfg.block_media);
  setCheck("cfg_alamat_sekolah", cfg.alamat_sekolah);
  setCheck("cfg_cari_by_tiket", cfg.cari_by_tiket);
  setCheck("cfg_update_data_lama", cfg.update_data_lama);
  setCheck("cfg_lewati_skrining", cfg.lewati_skrining);
  setCheck("cfg_kirim_rapor", cfg.kirim_rapor);
  setCheck("cfg_auto_selesai", cfg.auto_selesai);
  setCheck("cfg_mode_bypass", cfg.mode_bypass);
  setCheck("cfg_mode_booking", cfg.mode_booking);
  setCheck("cfg_mode_proses_booking", cfg.mode_proses_booking);
  setCheck("cfg_is_telinga_mata", cfg.is_telinga_mata);
  setCheck("cfg_is_gigi", cfg.is_gigi);
  setCheck("cfg_is_tb", cfg.is_tb);
  setCheck("cfg_is_kulit", cfg.is_kulit);
  setCheck("cfg_is_ppok", cfg.is_ppok);
  setCheck("cfg_is_kebugaran", cfg.is_kebugaran);
  setCheck("cfg_is_co", cfg.is_co);
  setCheck("cfg_is_malaria", cfg.is_malaria);
  setCheck("cfg_is_hepatitis", cfg.is_hepatitis);
  setCheck("cfg_is_anemia", cfg.is_anemia);
  setCheck("cfg_is_gizi_umum", cfg.is_gizi_umum);
  setCheck("cfg_is_tensi_umum", cfg.is_tensi_umum);
  setCheck("cfg_is_gds_umum", cfg.is_gds_umum);
  setCheck("cfg_is_lipid_umum", cfg.is_lipid_umum);
  setCheck("cfg_is_payudara_umum", cfg.is_payudara_umum);
  setCheck("cfg_is_ekg_umum", cfg.is_ekg_umum);
  setCheck("cfg_is_gigi_umum", cfg.is_gigi);
  setCheck("cfg_is_mata_umum", cfg.is_telinga_mata);
}

async function syncConfig() {
  const cfg = gatherConfigFromInputs();
  await fetch("/api/config", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(cfg),
  });
}

async function handleExcelSelect(event) {
  const file = event.target.files[0];
  if (!file) return;
  await uploadExcelFile(file);
}

async function uploadExcelFile(file) {
  const buf = await file.arrayBuffer();
  const res = await fetch("/api/upload-excel", {
    method: "POST",
    headers: {
      "Content-Type": "application/octet-stream",
      "X-Filename": encodeURIComponent(file.name),
    },
    body: buf,
  });
  const data = await res.json();
  if (!data.ok) {
    alert(data.message || "Gagal memuat file Excel.");
  }
  await fetchState();
}

async function triggerLogin(slotId = 1, freshLogin = false) {
  const res = await fetch("/api/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ slot_id: slotId, fresh_login: freshLogin }),
  });
  const data = await res.json();
  if (!data.ok && data.message) {
    alert(data.message);
  }
  await fetchState();
}

function openSessionModal() {
  document.getElementById("sessionModal").classList.remove("hidden");
  renderSessionSlots(cachedSlots);
}

function closeSessionModal() {
  document.getElementById("sessionModal").classList.add("hidden");
}

function renderSessionSlots(slots) {
  const grid = document.getElementById("sessionSlotsGrid");
  if (!grid || !Array.isArray(slots)) return;

  grid.innerHTML = slots
    .map((s) => {
      const isHealthy = s.has_file && (s.status === "active" || s.status === "expiring_soon");
      const isExpired = s.has_file && s.status === "expired";
      const cardCls = isHealthy
        ? "slot-card slot-healthy"
        : isExpired
        ? "slot-card slot-expired"
        : "slot-card";

      const badgeHtml = isHealthy
        ? `<span class="badge badge-success">● ${escapeHtml(s.status_label || "Aktif & Terhubung")}</span>`
        : isExpired
        ? `<span class="badge badge-failed">● ${escapeHtml(s.status_label || "Sesi Berakhir")}</span>`
        : `<span class="badge badge-pending">○ Belum Terhubung</span>`;

      const metaHtml = s.has_file
        ? `
          <div class="slot-meta">
            <strong>🏥 ${escapeHtml(s.faskes_name || "Puskesmas Aktif")}</strong>
            <span>👩‍⚕️ Nama Petugas: ${escapeHtml(s.officer_name || "Tenaga Kesehatan")} ${s.email ? `(${escapeHtml(s.email)})` : ""}</span>
            <span>📍 Wilayah: ${escapeHtml(s.region || "-")} • Login: ${escapeHtml(s.saved_at || "-")}</span>
            ${s.verified_at ? `<span style="color:var(--accent-tosca-dark)">✓ Pemeriksaan Koneksi Terakhir: ${escapeHtml(s.verified_at)}</span>` : ""}
          </div>
        `
        : `
          <div class="slot-meta">
            <strong>Slot Akun Petugas #${s.slot_id} Belum Diisi</strong>
            <span>Hubungkan akun petugas ke-${s.slot_id} jika ingin menjalankan ${s.slot_id} jalur input secara bersamaan.</span>
          </div>
        `;

      const isVerifying = verifyingSlotId === s.slot_id;
      return `
        <div class="${cardCls}">
          <div>
            <div class="slot-top">
              <span class="slot-title">👩‍⚕️ Akun Petugas #${s.slot_id} ${s.slot_id === 1 ? "(Utama)" : `(Jalur #${s.slot_id})`}</span>
              ${badgeHtml}
            </div>
            <div style="margin-top:8px">${metaHtml}</div>
          </div>
          <div class="slot-actions">
            <button class="btn btn-start btn-sm" onclick="triggerLogin(${s.slot_id}, false)">
              🔑 ${s.has_file ? "Login Ulang / Perbarui" : "Hubungkan Akun"}
            </button>
            ${
              s.has_file
                ? `
              <button class="btn btn-auth btn-sm" onclick="verifySessionSlot(${s.slot_id})" ${isVerifying ? "disabled" : ""}>
                ${isVerifying ? "⏳ Mengecek..." : "🩺 Cek Koneksi Akun"}
              </button>
              <button class="btn btn-ghost btn-sm" onclick="triggerLogin(${s.slot_id}, true)" title="Buka jendela login baru untuk mengganti akun petugas">
                🔄 Ganti Akun Lain
              </button>
              <button class="btn btn-ghost btn-sm" onclick="deleteSessionSlot(${s.slot_id})" title="Hapus akun dari slot ini">
                🗑️
              </button>
            `
                : ""
            }
          </div>
        </div>
      `;
    })
    .join("");
}

async function verifySessionSlot(slotId) {
  verifyingSlotId = slotId;
  renderSessionSlots(cachedSlots);
  try {
    const res = await fetch("/api/session/verify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ slot_id: slotId }),
    });
    const data = await res.json();
    if (data.message) {
      alert(data.message);
    }
  } finally {
    verifyingSlotId = 0;
    await fetchState();
  }
}

async function deleteSessionSlot(slotId) {
  if (!confirm(`Hapus simpanan login Akun Petugas #${slotId}?`)) return;
  await fetch("/api/session/delete", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ slot_id: slotId }),
  });
  await fetchState();
}

function openSaasModal() {
  document.getElementById("saasModal").classList.remove("hidden");
}

function closeSaasModal() {
  document.getElementById("saasModal").classList.add("hidden");
}

let cachedIssuedLicenses = [];

function cleanFaskesForLock(raw) {
  let s = String(raw || "").trim();
  if (s.includes("•")) {
    s = s.split("•")[0].trim();
  }
  return s.toUpperCase() || "*";
}

function onGenClientNameInput() {
  const clientVal = document.getElementById("genClientName")?.value || "";
  const planVal = document.getElementById("genPlan")?.value || "PRO_PUSKESMAS";
  const lockInput = document.getElementById("genFaskesLock");
  if (!lockInput) return;
  if (planVal === "ENTERPRISE_DINKES") {
    lockInput.value = "*";
  } else {
    lockInput.value = cleanFaskesForLock(clientVal);
  }
}

function updateSaasStudioUI(saas, activeFaskes) {
  const saasBadgeBtn = document.getElementById("topPlanBadge") || document.getElementById("saasBadgeBtn");
  if (saasBadgeBtn) {
    if (!saas.is_valid) {
      saasBadgeBtn.textContent = "🛡️ Lisensi LOCKED";
    } else if (saas.plan_code === "TRIAL") {
      saasBadgeBtn.textContent = "🛡️ Lisensi TRIAL";
    } else {
      saasBadgeBtn.textContent = "🛡️ Lisensi PRO";
    }
  }

  const statusPill = document.getElementById("saasStatusPill");
  if (statusPill) {
    if (!saas.is_valid) {
      statusPill.className = "badge badge-failed";
      statusPill.textContent = "● Tidak Aktif";
    } else if (saas.plan_code === "TRIAL") {
      statusPill.className = "badge badge-warning";
      statusPill.textContent = "● Mode Uji Coba (Trial)";
    } else {
      statusPill.className = "badge badge-success";
      statusPill.textContent = saas.is_owner_mode ? "● Aktif • Owner Studio" : "● Aktif & Terverifikasi";
    }
  }

  const clientCard = document.getElementById("saasClientUpgradeCard");
  const ownerCard = document.getElementById("saasOwnerGeneratorCard");
  const regCard = document.getElementById("saasOwnerRegistryCard");
  if (clientCard && ownerCard) {
    if (saas.is_owner_mode) {
      clientCard.classList.add("hidden");
      ownerCard.classList.remove("hidden");
      if (regCard) regCard.classList.remove("hidden");
    } else {
      clientCard.classList.remove("hidden");
      ownerCard.classList.add("hidden");
      if (regCard) regCard.classList.add("hidden");
    }
  }

  const lockLabel = document.getElementById("tenantLockLabel");
  if (lockLabel) {
    lockLabel.textContent =
      saas.faskes_lock && saas.faskes_lock !== "*"
        ? `🔒 INSTANSI TERDAFTAR`
        : "🏥 PUSKESMAS / INSTANSI AKTIF";
  }

  const elPlan = document.getElementById("saasPlanName");
  if (elPlan) elPlan.textContent = saas.plan_name || "-";
  const elClient = document.getElementById("saasClientName");
  if (elClient) elClient.textContent = saas.client_name || "-";
  const elLock = document.getElementById("saasFaskesLock");
  if (elLock) {
    elLock.textContent =
      saas.faskes_lock === "*" ? "* (Semua Puskesmas Diizinkan)" : saas.faskes_lock;
  }
  const elMachine = document.getElementById("saasMachineId");
  if (elMachine) elMachine.textContent = saas.machine_id || "-";

  const used = Number(saas.quota_used || 0);
  const limit = Math.max(1, Number(saas.quota_limit || 1));
  const elQuota = document.getElementById("saasQuotaInfo");
  if (elQuota) {
    elQuota.textContent = `${used.toLocaleString("id-ID")} / ${Number(saas.quota_limit || 0).toLocaleString("id-ID")} Peserta`;
  }
  const quotaBar = document.getElementById("saasQuotaBar");
  if (quotaBar) {
    const pct = Math.min(100, Math.max(2, (used / limit) * 100));
    quotaBar.style.width = `${pct.toFixed(1)}%`;
  }

  const elExp = document.getElementById("saasExpiryInfo");
  if (elExp) {
    elExp.textContent = !saas.is_valid
      ? `Tidak Aktif (${saas.message || "-"})`
      : `${saas.days_left} Hari Tersisa (s/d ${saas.expires_at})`;
  }

  const genFaskes = document.getElementById("genFaskesLock");
  if (genFaskes && activeFaskes) {
    const cleaned = cleanFaskesForLock(activeFaskes);
    if (
      genFaskes.value === "PUSKESMAS SEI PANAS" ||
      genFaskes.value.includes("•")
    ) {
      genFaskes.value = cleaned.startsWith("PUSKESMAS") ? cleaned : `PUSKESMAS ${cleaned}`;
    }
  }

  if (Array.isArray(saas.issued_licenses)) {
    cachedIssuedLicenses = saas.issued_licenses;
    renderIssuedLicensesTable();
  }
}

function renderIssuedLicensesTable() {
  const tbody = document.getElementById("issuedLicensesTbody");
  if (!tbody) return;

  const q = (document.getElementById("regSearchInput")?.value || "").toLowerCase().trim();
  const activeCount = cachedIssuedLicenses.filter((x) => x.status === "active").length;
  const expCount = cachedIssuedLicenses.filter((x) => x.status !== "active").length;

  const elAct = document.getElementById("regCountActive");
  if (elAct) elAct.textContent = `${activeCount} Aktif`;
  const elExp = document.getElementById("regCountExpiring");
  if (elExp) elExp.textContent = `${expCount} Perlu Perhatian`;

  const filtered = cachedIssuedLicenses.filter((item) => {
    if (!q) return true;
    const hay = `${item.client_name} ${item.faskes_lock} ${item.machine_lock} ${item.plan_name} ${item.notes || ""}`.toLowerCase();
    return hay.includes(q);
  });

  if (filtered.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" class="empty-cell">
          ${
            cachedIssuedLicenses.length === 0
              ? "Belum ada kode lisensi klien yang diterbitkan. Gunakan formulir di atas untuk menerbitkan lisensi Puskesmas pertama Anda."
              : "Tidak ada data klien yang cocok dengan pencarian."
          }
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = filtered
    .map((item, idx) => {
      const badgeCls =
        item.status === "active"
          ? "badge-success"
          : item.status === "expiring_soon"
          ? "badge-warning"
          : "badge-failed";
      const quotaFmt = Number(item.quota_limit || 0).toLocaleString("id-ID");
      return `
        <tr>
          <td>
            <strong>${escapeHtml(item.client_name || "-")}</strong>
            ${item.notes ? `<div class="student-sub-meta">📝 ${escapeHtml(item.notes)}</div>` : `<div class="student-sub-meta">Terbit: ${escapeHtml(item.created_at || "-")}</div>`}
          </td>
          <td><span class="badge badge-running">${escapeHtml(item.plan_badge || item.plan)}</span></td>
          <td><strong>${escapeHtml(item.faskes_lock || "*")}</strong></td>
          <td><code class="ticket-pill">${escapeHtml(item.machine_lock || "*")}</code></td>
          <td><strong>${quotaFmt}</strong></td>
          <td>
            <span class="badge ${badgeCls}">${escapeHtml(item.status_label || "-")}</span>
            <div class="student-sub-meta">s/d ${escapeHtml(item.expires_at || "-")}</div>
          </td>
          <td style="text-align:right;white-space:nowrap;">
            <button class="btn btn-emerald btn-xs" onclick="copyIssuedLicenseItem('${escapeHtml(item.id)}', 'key')" title="Salin Kode Lisensi CKG-V3">🔑 Kode</button>
            <button class="btn btn-primary btn-xs" onclick="copyIssuedLicenseItem('${escapeHtml(item.id)}', 'wa')" title="Salin Pesan WhatsApp Siap Kirim">📲 WA</button>
            <button class="btn btn-saas btn-xs" onclick="printClientInvoice('${escapeHtml(item.id)}')" title="Cetak Invoice / Kwitansi Resmi Puskesmas (PDF)">🧾 Invoice</button>
            <button class="btn btn-auth btn-xs" onclick="renewIssuedLicense('${escapeHtml(item.id)}')" title="Muat ke Form & Perpanjang Lisensi Klien Ini">🔄 Perpanjang</button>
            <button class="btn btn-ghost btn-xs" onclick="deleteIssuedLicense('${escapeHtml(item.id)}')" title="Hapus dari Daftar">🗑️</button>
          </td>
        </tr>
      `;
    })
    .join("");
}

function copyIssuedLicenseItem(recId, which) {
  const found = cachedIssuedLicenses.find((x) => x.id === recId);
  if (!found) return;
  const val = which === "wa" ? found.wa_template : found.license_key;
  navigator.clipboard?.writeText(val || "");
  const fb = document.getElementById("genCopyFeedback");
  if (fb) {
    fb.textContent =
      which === "wa"
        ? `✅ Pesan WA untuk ${found.client_name} disalin!`
        : `✅ Kode Lisensi ${found.client_name} disalin!`;
  }
}

async function renewIssuedLicense(recId) {
  const found = cachedIssuedLicenses.find((x) => x.id === recId);
  if (!found) return;
  document.getElementById("genClientName").value = found.client_name || "";
  document.getElementById("genPlan").value = found.plan || "PRO_PUSKESMAS";
  document.getElementById("genFaskesLock").value = found.faskes_lock || "*";
  document.getElementById("genDays").value = found.days_valid || 365;
  document.getElementById("genQuota").value = found.quota_limit || 50000;
  document.getElementById("genHwLock").value = found.machine_lock || "*";
  const notesEl = document.getElementById("genNotes");
  if (notesEl) notesEl.value = found.notes || "Perpanjangan Lisensi";
  await generateClientLicense();
}

async function deleteIssuedLicense(recId) {
  if (!confirm("Hapus catatan lisensi klien ini dari daftar riwayat?")) return;
  const res = await fetch("/api/saas/delete-license", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id: recId }),
  });
  const data = await res.json();
  if (data.ok && Array.isArray(data.issued_licenses)) {
    cachedIssuedLicenses = data.issued_licenses;
    renderIssuedLicensesTable();
  }
}

function onGenPlanChange() {
  const plan = document.getElementById("genPlan").value;
  if (plan === "TRIAL") {
    document.getElementById("genDays").value = 14;
    document.getElementById("genQuota").value = 30;
  } else if (plan === "PAKET_BULANAN") {
    document.getElementById("genDays").value = 30;
    document.getElementById("genQuota").value = 300;
  } else if (plan === "PRO_SEKOLAH" || plan === "PRO_UMUM") {
    document.getElementById("genDays").value = 180;
    document.getElementById("genQuota").value = 3000;
  } else if (plan === "PRO_PUSKESMAS") {
    document.getElementById("genDays").value = 365;
    document.getElementById("genQuota").value = 50000;
  } else if (plan === "ENTERPRISE_DINKES") {
    document.getElementById("genDays").value = 365;
    document.getElementById("genQuota").value = 500000;
    document.getElementById("genFaskesLock").value = "*";
  }
}

function printClientInvoice(recId) {
  const found = cachedIssuedLicenses.find((x) => x.id === recId);
  if (!found) return;
  const priceMap = {
    TRIAL: "Rp 0 (Uji Coba Gratis)",
    PAKET_BULANAN: "Rp 99.000",
    PRO_SEKOLAH: "Rp 249.000",
    PRO_UMUM: "Rp 249.000",
    PRO_PUSKESMAS: "Rp 499.000",
    ENTERPRISE_DINKES: "Rp 5.000.000",
  };
  const defaultNominal = priceMap[found.plan] || "Rp 249.000";
  const nominal = prompt(
    `Masukkan nominal pembayaran lisensi untuk ${found.client_name}:`,
    defaultNominal
  );
  if (nominal === null) return;

  const invNo = `NOTA/CKG/${(found.created_at || "2026").replace(/-/g, "")}/${found.id.slice(-4)}`;
  const win = window.open("", "_blank", "width=840,height=720");
  if (!win) return;
  win.document.write(`<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <title>Nota_Lisensi_${escapeHtml(found.client_name)}_${escapeHtml(invNo)}</title>
  <style>
    body { font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif; color: #0f172a; margin: 36px; line-height: 1.5; }
    .inv-box { border: 1.5px solid #cbd5e1; border-radius: 12px; padding: 28px 32px; max-width: 740px; margin: 0 auto; }
    .inv-head { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #047857; padding-bottom: 16px; margin-bottom: 20px; }
    .inv-title { font-size: 20px; font-weight: 800; color: #047857; margin: 0; }
    .inv-sub { font-size: 12px; color: #475569; margin-top: 4px; }
    .badge-paid { display: inline-block; background: #d1fae5; color: #047857; font-weight: 800; font-size: 12px; padding: 4px 12px; border-radius: 999px; border: 1px solid #6ee7b7; }
    table { width: 100%; border-collapse: collapse; margin: 18px 0; font-size: 13px; }
    th { background: #f1f5f9; text-align: left; padding: 10px 12px; border-bottom: 1.5px solid #cbd5e1; }
    td { padding: 12px; border-bottom: 1px solid #e2e8f0; }
    .total-row td { font-weight: 800; font-size: 15px; background: #f8fafc; color: #047857; }
    .foot-grid { display: flex; justify-content: space-between; margin-top: 28px; font-size: 12px; color: #475569; }
    .no-print { text-align: center; margin-bottom: 16px; }
    .btn-print { background: #047857; color: #fff; border: none; padding: 9px 18px; border-radius: 8px; font-weight: 700; cursor: pointer; }
    @media print { .no-print { display: none; } body { margin: 0; } }
  </style>
</head>
<body>
  <div class="no-print">
    <button class="btn-print" onclick="window.print()">🖨️ Cetak / Simpan sebagai PDF</button>
  </div>
  <div class="inv-box">
    <div class="inv-head">
      <div>
        <h1 class="inv-title">CKG TERPADU V3.5 — ASISTEN DIGITAL NAKES</h1>
        <div class="inv-sub">Aplikasi Otomasi Pencatatan CKG Sekolah &amp; CKG Umum<br>Layanan Aktivasi &amp; Dukungan Teknis (WA): 0811-1017-195</div>
      </div>
      <div style="text-align:right;">
        <div style="font-weight:800;font-size:15px;">BUKTI PEMBAYARAN &amp; AKTIVASI LISENSI</div>
        <div class="inv-sub">No: <b>${escapeHtml(invNo)}</b><br>Tanggal: ${escapeHtml(found.created_at || "-")}</div>
        <div style="margin-top:6px;"><span class="badge-paid">AKTIF &amp; TERVERIFIKASI</span></div>
      </div>
    </div>

    <div style="font-size:13px;margin-bottom:14px;">
      <strong>Pengguna / Tim Pelayanan Kesehatan:</strong><br>
      <span style="font-size:15px;font-weight:800;">${escapeHtml(found.client_name)}</span><br>
      Kunci Fasilitas Kesehatan: <b>${escapeHtml(found.faskes_lock)}</b> • ID Perangkat: <code>${escapeHtml(found.machine_lock)}</code>
      ${found.notes ? `<br>Catatan: ${escapeHtml(found.notes)}` : ""}
    </div>

    <table>
      <thead>
        <tr>
          <th>Deskripsi Paket Lisensi</th>
          <th>Masa Aktif</th>
          <th>Kuota Pelayanan</th>
          <th style="text-align:right;">Nominal</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <strong>${escapeHtml(found.plan_name)} (${escapeHtml(found.plan)})</strong><br>
            <small style="color:#64748b;">Lisensi Penggunaan Aplikasi CKG Terpadu V3.5 (Sekolah &amp; Umum) + Pembaruan Sistem</small>
          </td>
          <td>${escapeHtml(String(found.days_valid))} Hari<br><small style="color:#64748b;">s/d ${escapeHtml(found.expires_at)}</small></td>
          <td>${Number(found.quota_limit || 0).toLocaleString("id-ID")} Peserta</td>
          <td style="text-align:right;font-weight:700;">${escapeHtml(nominal)}</td>
        </tr>
        <tr class="total-row">
          <td colspan="3" style="text-align:right;">TOTAL PEMBAYARAN (QRIS / TRANSFER BANK)</td>
          <td style="text-align:right;">${escapeHtml(nominal)}</td>
        </tr>
      </tbody>
    </table>

    <div class="foot-grid">
      <div>
        <strong>Metode Pembayaran:</strong><br>
        QRIS / Transfer Bank<br>
        WhatsApp Layanan Teknis: <b>0811-1017-195</b>
      </div>
      <div style="text-align:center;min-width:180px;">
        <div>Pengembang CKG Terpadu,</div>
        <div style="height:48px;"></div>
        <div style="font-weight:800;border-top:1px solid #94a3b8;padding-top:4px;">Admin CKG Terpadu</div>
      </div>
    </div>
  </div>
</body>
</html>`);
  win.document.close();
}

function copyClientOrderWhatsApp() {
  const faskes = document.getElementById("faskesLabel")?.textContent || "Puskesmas";
  const hwId = document.getElementById("saasMachineId")?.textContent || "-";
  const text =
    `Halo Admin *CKG Terpadu V3.5*,\n\n` +
    `Saya ingin mengaktifkan Lisensi Aplikasi CKG Terpadu:\n` +
    `• Instansi / Tim Nakes: *${faskes}*\n` +
    `• Kode Perangkat: \`${hwId}\`\n` +
    `• Pilihan Paket: *Paket Hemat Bulanan / Paket Semester / Clinical Pro*\n\n` +
    `Mohon kirimkan kode QRIS atau nomor rekening transfer untuk aktivasi lisensinya. Terima kasih.`;
  navigator.clipboard?.writeText(text);
  const waUrl = `https://wa.me/628111017195?text=${encodeURIComponent(text)}`;
  window.open(waUrl, "_blank", "noopener,noreferrer");
  const msgEl = document.getElementById("clientOrderCopyMsg");
  if (msgEl) {
    msgEl.style.color = "#059669";
    msgEl.textContent = "✅ Membuka WhatsApp Admin (0811-1017-195) & menyalin format pesan...";
  }
}

async function unlockOwnerStudio() {
  const pin = (document.getElementById("inputOwnerPin")?.value || "").trim();
  const msgEl = document.getElementById("ownerUnlockMsg");
  if (!pin) {
    if (msgEl) {
      msgEl.style.color = "#e11d48";
      msgEl.textContent = "Masukkan PIN Pengelola terlebih dahulu.";
    }
    return;
  }
  const res = await fetch("/api/saas/unlock-owner", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ owner_pin: pin }),
  });
  const data = await res.json();
  if (msgEl) {
    msgEl.style.color = data.ok ? "#059669" : "#e11d48";
    msgEl.textContent = data.message || "";
  }
  await fetchState();
}

async function activateSaasLicense() {
  const key = (document.getElementById("inputLicenseKey").value || "").trim();
  const msgEl = document.getElementById("saasActivateMsg");
  if (!key) {
    msgEl.style.color = "#e11d48";
    msgEl.textContent = "Masukkan kode lisensi CKG-V3 terlebih dahulu.";
    return;
  }
  const res = await fetch("/api/saas/activate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ license_key: key }),
  });
  const data = await res.json();
  msgEl.style.color = data.ok ? "#059669" : "#e11d48";
  msgEl.textContent = data.message || "";
  await fetchState();
}

async function generateClientLicense() {
  const payload = {
    client_name: document.getElementById("genClientName").value,
    plan: document.getElementById("genPlan").value,
    faskes_lock: cleanFaskesForLock(document.getElementById("genFaskesLock").value),
    days_valid: parseInt(document.getElementById("genDays").value, 10) || 365,
    quota_limit: parseInt(document.getElementById("genQuota").value, 10) || 50000,
    machine_lock: document.getElementById("genHwLock").value || "*",
    notes: document.getElementById("genNotes")?.value || "",
  };
  const res = await fetch("/api/saas/generate-key", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (data.ok) {
    document.getElementById("genResultBox").classList.remove("hidden");
    document.getElementById("genOutputKey").value = data.license_key;
    document.getElementById("genOutputWa").value = data.wa_template;
    if (Array.isArray(data.issued_licenses)) {
      cachedIssuedLicenses = data.issued_licenses;
      renderIssuedLicensesTable();
    }
    const fb = document.getElementById("genCopyFeedback");
    if (fb) {
      fb.textContent = "✅ Tersimpan di Daftar Klien!";
    }
  } else if (data.message) {
    alert(data.message);
  }
}

async function testGeneratedKeyNow() {
  const key = document.getElementById("genOutputKey").value;
  if (!key) return;
  document.getElementById("inputLicenseKey").value = key;
  await activateSaasLicense();
}

function copyTextById(id) {
  const txt = document.getElementById(id)?.textContent || "";
  navigator.clipboard?.writeText(txt);
}

function copyInputVal(id, feedbackMsg = "") {
  const val = document.getElementById(id)?.value || "";
  navigator.clipboard?.writeText(val);
  const fb = document.getElementById("genCopyFeedback");
  if (fb && feedbackMsg) {
    fb.textContent = `✅ ${feedbackMsg}`;
  }
}

async function startBatch(retryFailedOnly) {
  const cfg = gatherConfigFromInputs();
  const res = await fetch("/api/start", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ config: cfg, retry_failed_only: retryFailedOnly }),
  });
  const data = await res.json();
  if (!data.ok && data.message) {
    alert(data.message);
  }
  await fetchState();
}

async function togglePause() {
  await fetch("/api/pause", { method: "POST" });
  await fetchState();
}

async function stopBatch() {
  await fetch("/api/stop", { method: "POST" });
  await fetchState();
}

async function resetCheckpoints() {
  if (!confirm("Atur ulang seluruh status siswa di file ini kembali ke Menunggu Giliran?")) return;
  await fetch("/api/reset-checkpoints", { method: "POST" });
  await fetchState();
}

function downloadTemplate() {
  window.location.href = `/api/template-excel?type=${encodeURIComponent(currentServiceType)}`;
}

function convertCurrentToSmartExcel() {
  window.location.href = "/api/convert-smart-excel";
}

function downloadReport() {
  window.location.href = "/api/download-report";
}

function togglePeekDrawer() {
  peekOpen = !peekOpen;
  document.getElementById("peekPanel").classList.toggle("hidden", !peekOpen);
  syncWorkspaceHeight();
  if (peekOpen) refreshPeeks();
}

function refreshPeeks() {
  fetchState();
}

function renderPeekImages(workerIds, workersMap) {
  const grid = document.getElementById("peekGrid");
  const ts = Date.now();
  grid.innerHTML = workerIds
    .map(
      (id) => `
      <div class="peek-card">
        <header>
          <span>👩‍⚕️ Petugas #${id}</span>
          <span>${escapeHtml(workersMap[id] || "Aktif Melayani")}</span>
        </header>
        <img src="/api/worker-peek?worker=${id}&t=${ts}" alt="Layar Pemeriksaan Petugas ${id}" />
      </div>
    `
    )
    .join("");
}

function clearLocalLogs() {
  document.getElementById("logConsole").innerHTML = "";
}

function escapeHtml(str) {
  return String(str ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// Drag & Drop support on Upload Zone
const dropZone = document.getElementById("dropZone");
if (dropZone) {
  dropZone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropZone.style.borderColor = "#16b3ac";
  });
  dropZone.addEventListener("dragleave", () => {
    dropZone.style.borderColor = "";
  });
  dropZone.addEventListener("drop", async (e) => {
    e.preventDefault();
    dropZone.style.borderColor = "";
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      await uploadExcelFile(e.dataTransfer.files[0]);
    }
  });
}

setInterval(fetchState, 1000);
fetchState();
