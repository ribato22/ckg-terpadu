from __future__ import annotations

import asyncio
import base64
import datetime as dt
import hashlib
import importlib
import json
import mimetypes
import platform
import re
import urllib.parse
import urllib.request
import webbrowser
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from . import engine as _engine_mod
from . import excel_io as _excel_io_mod
from . import models as _models_mod
from . import saas as _saas_mod
from . import selectors as _selectors_mod
from .engine import CKGTurboEngine
from .excel_io import (
    export_report_excel,
    generate_smart_pro_template,
    load_students_with_quality,
)
from .models import JobConfig
from .saas import LicenseManager, SessionVault
from .state_db import StateDB


class DashboardApp:
    """
    Application state & controller for CKG Sekolah V3.2 Pro (SaaS Edition) Web Dashboard.
    Works both with FastAPI/Uvicorn and the built-in zero-dependency asyncio HTTP server.
    """

    def __init__(self, base_dir: Optional[str | Path] = None) -> None:
        self.base_dir = Path(base_dir) if base_dir else Path(__file__).resolve().parent.parent
        self.static_dir = Path(__file__).resolve().parent / "static"
        self.data_dir = self.base_dir / "data"
        self.uploads_dir = self.data_dir / "uploads"
        self.uploads_dir.mkdir(parents=True, exist_ok=True)

        self.state_db = StateDB(self.data_dir / "ckg_state.db")
        self.logs: List[Dict[str, Any]] = []
        self._log_seq = 0

        saved_cfg = self.state_db.get_setting("job_config")
        self.config = JobConfig.from_dict(saved_cfg) if isinstance(saved_cfg, dict) else JobConfig()

        self.engine = CKGTurboEngine(
            data_dir=self.data_dir,
            state_db=self.state_db,
            log_callback=self.append_log,
        )
        self._batch_task: Optional[asyncio.Task[Any]] = None
        self._login_task: Optional[asyncio.Task[Any]] = None
        self._code_mtime: float = self._get_code_mtime()

        self.append_log(
            f"⚡ CKG Sekolah V3.2 Pro (High-Reliability Engine) siap di {platform.system()} ({platform.machine()}) — "
            f"Faskes Aktif: {self.engine.active_faskes}",
            "info",
        )
        self._autoload_last_excel()

    def _autoload_last_excel(self) -> None:
        """Auto-load the most recent Excel file in data/uploads if available."""
        try:
            xlsx_files = sorted(
                self.uploads_dir.glob("*.xlsx"),
                key=lambda p: p.stat().st_mtime,
                reverse=True,
            )
            if xlsx_files:
                latest = xlsx_files[0]
                self.load_excel_bytes(latest.name, latest.read_bytes(), log_quiet=False)
        except Exception:
            pass

    def append_log(self, message: str, level: str = "info", worker_id: Optional[int] = None) -> None:
        self._log_seq += 1
        entry = {
            "id": self._log_seq,
            "time": dt.datetime.now().strftime("%H:%M:%S"),
            "level": level,
            "worker_id": worker_id,
            "message": message,
        }
        self.logs.append(entry)
        if len(self.logs) > 600:
            self.logs = self.logs[-600:]

    def check_playwright_installed(self) -> bool:
        try:
            import playwright  # noqa: F401
            return True
        except ImportError:
            return False

    def _get_code_mtime(self) -> float:
        try:
            pkg_dir = Path(__file__).resolve().parent
            return max(
                (pkg_dir / "models.py").stat().st_mtime,
                (pkg_dir / "excel_io.py").stat().st_mtime,
                (pkg_dir / "state_db.py").stat().st_mtime,
                (pkg_dir / "engine.py").stat().st_mtime,
                (pkg_dir / "selectors.py").stat().st_mtime,
                (pkg_dir / "saas.py").stat().st_mtime,
            )
        except Exception:
            return 0.0

    def _hot_reload_engine_code(self, force: bool = False) -> None:
        """Hot-reload models.py, excel_io.py, selectors.py, saas.py, and engine.py methods onto the live engine instance."""
        try:
            cur_mtime = self._get_code_mtime()
            if not force and cur_mtime <= self._code_mtime:
                return
            self._code_mtime = cur_mtime
            importlib.reload(_models_mod)
            global JobConfig, export_report_excel, generate_smart_pro_template, load_students_with_quality
            JobConfig = _models_mod.JobConfig
            importlib.reload(_excel_io_mod)
            export_report_excel = _excel_io_mod.export_report_excel
            generate_smart_pro_template = _excel_io_mod.generate_smart_pro_template
            load_students_with_quality = _excel_io_mod.load_students_with_quality
            importlib.reload(_selectors_mod)
            importlib.reload(_saas_mod)
            importlib.reload(_engine_mod)
            self.engine.__class__ = _engine_mod.CKGTurboEngine
            if not hasattr(self.engine, "license_mgr"):
                self.engine.license_mgr = _saas_mod.LicenseManager(self.state_db)
            else:
                self.engine.license_mgr.__class__ = _saas_mod.LicenseManager
            if not hasattr(self.engine, "session_vault"):
                self.engine.session_vault = _saas_mod.SessionVault(self.data_dir, self.state_db)
            else:
                self.engine.session_vault.__class__ = _saas_mod.SessionVault
            if not self.engine.is_running and self.engine.current_file_key and self.engine.students:
                self.state_db.restore_checkpoints(self.engine.current_file_key, self.engine.students)
            self.append_log("⚡ Kode mesin CKG Terpadu V3.5 berhasil diperbarui otomatis.", "info")
        except Exception:
            pass

    def get_dashboard_state(self, since_log_id: int = 0) -> Dict[str, Any]:
        self._hot_reload_engine_code(force=False)
        if self.engine.is_running and self._batch_task is not None and self._batch_task.done():
            self.engine.is_running = False
        if not hasattr(self.engine, "license_mgr"):
            self.engine.license_mgr = LicenseManager(self.state_db)
        if not hasattr(self.engine, "session_vault"):
            self.engine.session_vault = SessionVault(self.data_dir, self.state_db)

        students = self.engine.students
        total = len(students)
        counts = {
            "pending": 0,
            "running": 0,
            "success": 0,
            "warning": 0,
            "failed": 0,
            "skipped": 0,
        }
        for s in students:
            counts[s.state] = counts.get(s.state, 0) + 1

        done_count = counts["success"] + counts["warning"] + counts["failed"] + counts["skipped"]
        progress_pct = round((done_count / total) * 100, 1) if total > 0 else 0.0
        success_total = counts["success"] + counts["warning"] + counts["skipped"]
        success_rate_pct = round((success_total / done_count) * 100, 1) if done_count > 0 else 100.0

        new_logs = [lg for lg in self.logs if lg["id"] > since_log_id]
        session_slots = self.engine.session_vault.get_all_slots()
        healthy_slots = [s for s in session_slots if s["status"] in ("active", "expiring_soon") and s["has_file"]]

        return {
            "is_running": self.engine.is_running,
            "is_paused": self.engine.is_paused,
            "session_expired": self.engine.session_expired,
            "has_session": self.engine.has_saved_session(),
            "active_faskes": self.engine.active_faskes,
            "officer_name": self.engine.officer_name,
            "faskes_region": self.engine.faskes_region,
            "session_slots": session_slots,
            "healthy_slots_count": len(healthy_slots),
            "saas": self.engine.license_mgr.get_status(),
            "playwright_ready": self.check_playwright_installed(),
            "platform": f"{platform.system()} {platform.release()} ({platform.machine()})",
            "config": self.config.to_dict(),
            "file_name": self.engine.current_excel_path.name if self.engine.current_excel_path else None,
            "data_quality": self.engine.data_quality.to_dict(),
            "stats": {
                "total": total,
                "done": done_count,
                "progress_pct": progress_pct,
                "success_rate_pct": success_rate_pct,
                **counts,
            },
            "workers": {
                str(k): v for k, v in self.engine.worker_status.items()
            },
            "available_peeks": sorted(list(self.engine.worker_screenshots.keys())),
            "students": [s.to_summary_dict() for s in students],
            "logs": new_logs,
            "last_log_id": self._log_seq,
        }

    def load_excel_bytes(
        self,
        filename: str,
        raw_bytes: bytes,
        log_quiet: bool = False,
        sheet_filter: Optional[str] = None,
    ) -> Dict[str, Any]:
        safe_name = Path(filename).name or "Data_Siswa_CKG.xlsx"
        target_path = self.uploads_dir / safe_name
        target_path.write_bytes(raw_bytes)

        students, quality = load_students_with_quality(
            target_path, sheet_filter=sheet_filter
        )

        # If a specific sheet/class was filtered (or downloaded from Google Sheets),
        # give it a descriptive filename (e.g. SDN_004_Bengkong_Kelas_2.xlsx) and persist the filtered rows
        if students and (sheet_filter or safe_name.startswith("GoogleSheet_")):
            sch_slug = re.sub(r"[^A-Za-z0-9]+", "_", students[0].nama_sekolah).strip("_") or "Sekolah"
            if sheet_filter and sheet_filter.strip().lower() not in ("all", "semua"):
                kls_slug = re.sub(r"[^A-Za-z0-9]+", "_", students[0].kelas).strip("_") or "Kelas"
                safe_name = f"{sch_slug}_{kls_slug}.xlsx"
                target_path = self.uploads_dir / safe_name
                generate_smart_pro_template(target_path, existing_students=students)
            elif safe_name.startswith("GoogleSheet_"):
                safe_name = f"{sch_slug}_Semua_Kelas.xlsx"
                target_path = self.uploads_dir / safe_name
                target_path.write_bytes(raw_bytes)

        digest = hashlib.sha256(target_path.read_bytes()).hexdigest()[:16]
        file_key = f"{safe_name}_{digest}"

        restored = self.state_db.restore_checkpoints(file_key, students)

        self.engine.current_excel_path = target_path
        self.engine.current_file_key = file_key
        self.engine.students = students
        self.engine.data_quality = quality
        self.engine.latest_report_path = None

        if quality.service_type in ("sekolah", "umum"):
            self.config.service_type = quality.service_type
            self.engine.config = self.config
            self.state_db.save_setting("job_config", self.config.to_dict())
            self.state_db.save_setting(f"last_excel_{quality.service_type}", str(target_path))

        if not log_quiet:
            healed_msg = ""
            if quality.healed_wa_count > 0:
                healed_msg = f" • Auto-Healed {quality.healed_wa_count} No. WA"
            unit_lbl = "peserta CKG Umum" if quality.service_type == "umum" else "siswa CKG Sekolah"
            self.append_log(
                f"📂 Berhasil memuat '{safe_name}': {len(students)} {unit_lbl} valid "
                f"({restored} checkpoint dipulihkan{healed_msg}).",
                "success",
            )
        return {
            "ok": True,
            "file_name": safe_name,
            "service_type": quality.service_type,
            "total_students": len(students),
            "restored_checkpoints": restored,
            "data_quality": quality.to_dict(),
        }

    def update_config(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        merged = {**self.config.to_dict(), **payload}
        self.config = JobConfig.from_dict(merged)
        self.engine.config = self.config
        self.state_db.save_setting("job_config", self.config.to_dict())
        return {"ok": True, "config": self.config.to_dict()}

    @staticmethod
    def _is_trusted_local_origin(headers: Dict[str, str]) -> bool:
        """Prevent Cross-Site Request Forgery (CSRF) from external web pages against local 127.0.0.1 API."""
        norm_hdrs = {str(k).lower(): str(v).strip() for k, v in (headers or {}).items()}
        sec_site = norm_hdrs.get("sec-fetch-site", "").lower()
        if sec_site == "cross-site":
            return False
        for hdr_name in ("origin", "referer"):
            val = norm_hdrs.get(hdr_name, "")
            if not val:
                continue
            parsed = urllib.parse.urlsplit(val)
            host = (parsed.hostname or "").lower()
            if host not in ("127.0.0.1", "localhost", "::1"):
                return False
        return True

    async def handle_api_request(
        self,
        method: str,
        path: str,
        query: Dict[str, List[str]],
        headers: Dict[str, str],
        body: bytes,
    ) -> Tuple[int, Dict[str, str], bytes]:
        """Unified router for API & static files."""
        sec_headers = {
            "Cache-Control": "no-store",
            "X-Frame-Options": "SAMEORIGIN",
            "X-Content-Type-Options": "nosniff",
            "Referrer-Policy": "no-referrer",
        }
        if method == "GET" and path in ("/", "/index.html"):
            content = (self.static_dir / "index.html").read_bytes()
            return 200, {"Content-Type": "text/html; charset=utf-8", **sec_headers}, content

        if method == "GET" and path.startswith("/static/"):
            rel = path[len("/static/"):]
            fpath = (self.static_dir / rel).resolve()
            if str(fpath).startswith(str(self.static_dir.resolve())) and fpath.is_file():
                ctype, _ = mimetypes.guess_type(str(fpath))
                return (
                    200,
                    {"Content-Type": ctype or "application/octet-stream", **sec_headers},
                    fpath.read_bytes(),
                )
            return 404, {"Content-Type": "text/plain", **sec_headers}, b"Not Found"

        if method == "POST" and not self._is_trusted_local_origin(headers):
            return self._json_response(
                403,
                {
                    "ok": False,
                    "message": "Akses Ditolak (CSRF Protection): Permintaan lintas-domain (Cross-Origin) diblokir.",
                },
            )

        try:
            if method == "GET" and path == "/api/state":
                since_id = int(query.get("since_log_id", ["0"])[0])
                data = self.get_dashboard_state(since_log_id=since_id)
                return self._json_response(200, data)

            if method == "GET" and path == "/api/template-excel":
                req_type = query.get("type", [self.config.service_type])[0]
                is_umum_tpl = req_type == "umum"
                fname_tpl = (
                    "Template_CKG_Umum_37Kolom.xlsx"
                    if is_umum_tpl
                    else "Template_CKG_Sekolah_33Kolom.xlsx"
                )
                tpl_path = self.data_dir / fname_tpl
                generate_smart_pro_template(
                    tpl_path, service_type="umum" if is_umum_tpl else "sekolah"
                )
                return (
                    200,
                    {
                        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "Content-Disposition": f'attachment; filename="{fname_tpl}"',
                    },
                    tpl_path.read_bytes(),
                )

            if method == "POST" and path == "/api/switch-program":
                payload = json.loads(body.decode("utf-8") or "{}") if body else {}
                target_type = payload.get("service_type", "sekolah")
                if target_type not in ("sekolah", "umum"):
                    target_type = "sekolah"
                self.update_config({"service_type": target_type})

                # Check if current loaded students already match target_type
                cur_type = getattr(self.engine.data_quality, "service_type", "sekolah")
                if cur_type != target_type or not self.engine.students:
                    candidate_path: Optional[Path] = None
                    saved_last = self.state_db.get_setting(f"last_excel_{target_type}")
                    if saved_last and Path(saved_last).is_file():
                        candidate_path = Path(saved_last)
                    else:
                        # Scan uploads_dir for matching program file
                        for p in sorted(
                            self.uploads_dir.glob("*.xlsx"),
                            key=lambda x: x.stat().st_mtime,
                            reverse=True,
                        ):
                            try:
                                _, q_test = load_students_with_quality(p)
                                if q_test.service_type == target_type:
                                    candidate_path = p
                                    break
                            except Exception:
                                pass
                        # If switching to 'umum' for the first time, check user's Downloads sample
                        if candidate_path is None and target_type == "umum":
                            dl_sample = Path.home() / "Downloads" / "Format CKG Umum Versi Terbaru_ckg rt 003 rw 010 BI.xlsx"
                            if dl_sample.is_file():
                                candidate_path = dl_sample

                    if candidate_path and candidate_path.is_file():
                        self.load_excel_bytes(
                            candidate_path.name, candidate_path.read_bytes(), log_quiet=False
                        )
                    else:
                        self.engine.data_quality.service_type = target_type

                prog_label = "CKG Umum (Dewasa & Lansia • 37 Kolom)" if target_type == "umum" else "CKG Sekolah (Anak & Remaja • 33 Kolom)"
                self.append_log(f"🔀 Mode Program beralih ke: {prog_label}", "info")
                return self._json_response(
                    200,
                    {
                        "ok": True,
                        "service_type": target_type,
                        "file_name": self.engine.current_excel_path.name if self.engine.current_excel_path else None,
                        "total_students": len(self.engine.students),
                    },
                )

            if method == "GET" and path == "/api/convert-smart-excel":
                if not self.engine.students:
                    return self._json_response(400, {"ok": False, "message": "Belum ada data siswa."})
                base_name = (
                    self.engine.current_excel_path.stem
                    if self.engine.current_excel_path
                    else "Data_Siswa"
                )
                conv_path = self.data_dir / f"SmartPro_{base_name}.xlsx"
                generate_smart_pro_template(conv_path, existing_students=self.engine.students)
                return (
                    200,
                    {
                        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "Content-Disposition": f'attachment; filename="{conv_path.name}"',
                    },
                    conv_path.read_bytes(),
                )

            if method == "GET" and path == "/api/download-report":
                self._hot_reload_engine_code()
                if not self.engine.students:
                    return self._json_response(400, {"ok": False, "message": "Belum ada data siswa."})
                out_path = await self.engine._save_report_snapshot()
                if not out_path or not out_path.exists():
                    return self._json_response(404, {"ok": False, "message": "File laporan belum tersedia."})
                return (
                    200,
                    {
                        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "Content-Disposition": f'attachment; filename="{out_path.name}"',
                    },
                    out_path.read_bytes(),
                )

            if method == "GET" and path == "/api/worker-peek":
                w_id = int(query.get("worker", ["1"])[0])
                jpg = self.engine.worker_screenshots.get(w_id)
                if not jpg:
                    return 204, {}, b""
                return 200, {"Content-Type": "image/jpeg", "Cache-Control": "no-store"}, jpg

            if method == "POST" and path == "/api/upload-excel":
                filename = urllib.parse.unquote(headers.get("x-filename", "Data_Siswa_CKG.xlsx"))
                sheet_filter = urllib.parse.unquote(headers.get("x-sheet-filter", "")).strip() or None
                if headers.get("content-type", "").startswith("application/json"):
                    payload = json.loads(body.decode("utf-8"))
                    filename = payload.get("filename", filename)
                    sheet_filter = payload.get("sheet_filter", sheet_filter)
                    raw_bytes = base64.b64decode(payload["data_base64"])
                else:
                    raw_bytes = body
                res = self.load_excel_bytes(filename, raw_bytes, sheet_filter=sheet_filter)
                return self._json_response(200, res)

            if method == "POST" and path == "/api/load-gsheet":
                self._hot_reload_engine_code()
                payload = json.loads(body.decode("utf-8") or "{}") if body else {}
                raw_url = str(payload.get("url", "")).strip()
                sheet_filter = str(payload.get("sheet_filter", "")).strip() or None
                if not raw_url:
                    return self._json_response(
                        400,
                        {"ok": False, "message": "Masukkan link Google Spreadsheet terlebih dahulu."},
                    )
                m_id = re.search(r"/d/([a-zA-Z0-9_-]{15,})", raw_url)
                file_id = m_id.group(1) if m_id else (raw_url if re.fullmatch(r"[a-zA-Z0-9_-]{15,}", raw_url) else "")
                if not file_id:
                    return self._json_response(
                        400,
                        {"ok": False, "message": "Format link Google Spreadsheet tidak dikenali."},
                    )

                export_url = f"https://docs.google.com/spreadsheets/d/{file_id}/export?format=xlsx"
                req = urllib.request.Request(
                    export_url,
                    headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)"},
                )
                try:
                    raw_bytes = await asyncio.to_thread(
                        lambda: urllib.request.urlopen(req, timeout=25).read()
                    )
                except Exception as exc:
                    return self._json_response(
                        400,
                        {
                            "ok": False,
                            "message": f"Gagal mengunduh Google Spreadsheet (pastikan akses link 'Siapa saja yang memiliki link'): {exc}",
                        },
                    )
                if not raw_bytes or not raw_bytes.startswith(b"PK"):
                    return self._json_response(
                        400,
                        {
                            "ok": False,
                            "message": "Link Google Spreadsheet memerlukan izin akses (set ke 'Anyone with the link / Siapa saja yang memiliki link').",
                        },
                    )
                res = self.load_excel_bytes(
                    f"GoogleSheet_{file_id[:8]}.xlsx",
                    raw_bytes,
                    sheet_filter=sheet_filter,
                )
                return self._json_response(200, res)

            if method == "POST" and path == "/api/config":
                payload = json.loads(body.decode("utf-8") or "{}")
                res = self.update_config(payload)
                return self._json_response(200, res)

            if method == "POST" and path == "/api/login":
                self._hot_reload_engine_code()
                if not self.check_playwright_installed():
                    return self._json_response(
                        400,
                        {
                            "ok": False,
                            "message": "Playwright belum terinstal. Jalankan ./run.sh atau pip install playwright && playwright install chromium",
                        },
                    )
                payload = json.loads(body.decode("utf-8") or "{}") if body else {}
                slot_id = int(payload.get("slot_id", 1))
                fresh_login = bool(payload.get("fresh_login", False))
                if self._login_task and not self._login_task.done():
                    return self._json_response(
                        200, {"ok": True, "message": "Jendela login sudah terbuka."}
                    )
                self._login_task = asyncio.create_task(
                    self.engine.login_and_save_session(slot_id=slot_id, fresh_login=fresh_login)
                )
                return self._json_response(
                    200,
                    {
                        "ok": True,
                        "slot_id": slot_id,
                        "message": f"Membuka jendela browser untuk Login Akun Nakes #{slot_id}...",
                    },
                )

            if method == "POST" and path == "/api/session/verify":
                self._hot_reload_engine_code()
                payload = json.loads(body.decode("utf-8") or "{}") if body else {}
                slot_id = int(payload.get("slot_id", 1))
                res = await self.engine.verify_session_slot(slot_id=slot_id)
                return self._json_response(200, res)

            if method == "POST" and path == "/api/session/delete":
                self._hot_reload_engine_code()
                payload = json.loads(body.decode("utf-8") or "{}") if body else {}
                slot_id = int(payload.get("slot_id", 1))
                self.engine.session_vault.delete_slot(slot_id)
                self.engine._load_session_metadata()
                self.append_log(f"🗑️ Sesi Akun Nakes #{slot_id} telah dihapus dari Brankas Sesi.", "warning")
                return self._json_response(
                    200,
                    {
                        "ok": True,
                        "slot_id": slot_id,
                        "session_slots": self.engine.session_vault.get_all_slots(),
                    },
                )

            if method == "POST" and path == "/api/saas/activate":
                self._hot_reload_engine_code()
                payload = json.loads(body.decode("utf-8") or "{}") if body else {}
                key_str = payload.get("license_key", "")
                res = self.engine.license_mgr.activate_license(key_str)
                if res.get("ok"):
                    self.append_log(f"🛡️ {res.get('message')}", "success")
                return self._json_response(200 if res.get("ok") else 400, res)

            if method == "POST" and path == "/api/saas/unlock-owner":
                self._hot_reload_engine_code()
                payload = json.loads(body.decode("utf-8") or "{}") if body else {}
                pin = payload.get("owner_pin", "")
                ok, msg = self.engine.license_mgr.unlock_owner_studio(pin)
                return self._json_response(
                    200 if ok else 403,
                    {"ok": ok, "message": msg, "status": self.engine.license_mgr.get_status()},
                )

            if method == "POST" and path == "/api/saas/generate-key":
                self._hot_reload_engine_code()
                payload = json.loads(body.decode("utf-8") or "{}") if body else {}
                owner_pin = payload.get("owner_pin", "")
                if not self.engine.license_mgr.verify_owner_pin(owner_pin):
                    return self._json_response(
                        403,
                        {
                            "ok": False,
                            "message": "Akses Ditolak: Masukkan PIN Pengelola (Owner) yang sah untuk membuat kode lisensi.",
                        },
                    )
                client_name = (payload.get("client_name", "Puskesmas Mitra") or "Puskesmas Mitra").strip()
                plan = payload.get("plan", "PRO_PUSKESMAS")
                raw_faskes_lock = payload.get("faskes_lock", "*")
                faskes_lock = self.engine.license_mgr.clean_faskes_lock(raw_faskes_lock)
                days_valid = int(payload.get("days_valid", 365))
                quota_limit = max(1, int(payload.get("quota_limit", 50000)))
                raw_machine_lock = (payload.get("machine_lock", "*") or "*").strip().upper()
                notes = (payload.get("notes", "") or "").strip()

                hw_tokens = [
                    tok.strip().upper()
                    for tok in re.split(r"[,;\s]+", raw_machine_lock)
                    if tok.strip()
                ]
                hw_list = list(dict.fromkeys(hw_tokens))[:10] or ["*"]
                n_dev = len(hw_list)

                base_quota = max(1, quota_limit // n_dev)
                rem_quota = quota_limit % n_dev if quota_limit >= n_dev else 0

                generated_items: List[Dict[str, Any]] = []
                issued: List[Dict[str, Any]] = []

                for idx, hw_id in enumerate(hw_list):
                    dev_quota = base_quota + (1 if idx < rem_quota else 0)
                    dev_client_name = (
                        f"{client_name} (Laptop #{idx + 1}/{n_dev})"
                        if n_dev > 1
                        else client_name
                    )
                    dev_key = self.engine.license_mgr.generate_license_key(
                        client_name=dev_client_name,
                        plan=plan,
                        faskes_lock=faskes_lock,
                        days_valid=days_valid,
                        quota_limit=dev_quota,
                        machine_lock=hw_id,
                        owner_pin=owner_pin,
                    )
                    dev_wa = (
                        f"Halo *{dev_client_name}*,\n\n"
                        f"Berikut Kode Lisensi Resmi *CKG Terpadu V3.5 Clinical Pro (Sekolah & Umum)* Anda:\n"
                        f"• Paket: *{plan}*\n"
                        f"• Kunci Faskes: *{faskes_lock}*\n"
                        f"• Kunci Perangkat: *{hw_id}*\n"
                        f"• Masa Aktif: *{days_valid} Hari*\n"
                        f"• Kuota Peserta: *{dev_quota:,} Peserta*\n\n"
                        f"🔑 *KODE LISENSI:*\n`{dev_key}`\n\n"
                        f"Cara Aktivasi: Klik tombol *🛡️ Lisensi* di kanan atas aplikasi, tempel kode di atas pada kolom Aktivasi, lalu klik *Aktifkan*.\n"
                        f"Bantuan Teknis & Perpanjangan (WA Admin): https://wa.me/628111017195"
                    )
                    dev_notes = (
                        f"Patungan Laptop #{idx + 1}/{n_dev} ({dev_quota:,}/{quota_limit:,})"
                        + (f" • {notes}" if notes else "")
                        if n_dev > 1
                        else notes
                    )
                    issued = self.engine.license_mgr.record_issued_license(
                        client_name=dev_client_name,
                        plan=plan,
                        faskes_lock=faskes_lock,
                        days_valid=days_valid,
                        quota_limit=dev_quota,
                        machine_lock=hw_id,
                        license_key=dev_key,
                        wa_template=dev_wa,
                        notes=dev_notes,
                    )
                    generated_items.append(
                        {
                            "device_index": idx + 1,
                            "client_name": dev_client_name,
                            "machine_lock": hw_id,
                            "quota_limit": dev_quota,
                            "license_key": dev_key,
                            "wa_template": dev_wa,
                        }
                    )

                if n_dev == 1:
                    primary_key = generated_items[0]["license_key"]
                    wa_template = generated_items[0]["wa_template"]
                else:
                    primary_key = " | ".join(it["license_key"] for it in generated_items)
                    wa_lines = [
                        f"Halo *{client_name}*,\n",
                        f"Berikut *{n_dev} Kode Lisensi Resmi CKG Terpadu V3.5 Clinical Pro (Mode Patungan {n_dev} Laptop)* Anda:",
                        f"• Paket: *{plan}*",
                        f"• Kunci Faskes: *{faskes_lock}*",
                        f"• Masa Aktif: *{days_valid} Hari*",
                        f"• Total Kuota Tim: *{quota_limit:,} Peserta* (Dibagi rata ke {n_dev} Laptop)\n",
                    ]
                    for it in generated_items:
                        wa_lines.append(
                            f"💻 *LAPTOP #{it['device_index']}* (ID Perangkat: `{it['machine_lock']}` • Kuota: *{it['quota_limit']:,} Peserta*):\n`{it['license_key']}`\n"
                        )
                    wa_lines.append(
                        "Cara Aktivasi: Di masing-masing laptop, klik tombol *🛡️ Lisensi* di kanan atas aplikasi, tempel kode sesuai ID Perangkat laptop tersebut, lalu klik *Aktifkan*.\n"
                        "Bantuan Teknis & Perpanjangan (WA Admin): https://wa.me/628111017195"
                    )
                    wa_template = "\n".join(wa_lines)

                return self._json_response(
                    200,
                    {
                        "ok": True,
                        "device_count": n_dev,
                        "license_key": primary_key,
                        "generated_keys": generated_items,
                        "wa_template": wa_template,
                        "issued_licenses": issued,
                    },
                )

            if method == "POST" and path == "/api/saas/delete-license":
                self._hot_reload_engine_code()
                payload = json.loads(body.decode("utf-8") or "{}") if body else {}
                owner_pin = payload.get("owner_pin", "")
                if not self.engine.license_mgr.verify_owner_pin(owner_pin):
                    return self._json_response(
                        403,
                        {"ok": False, "message": "Akses Ditolak: Khusus Pengelola (Owner)."},
                    )
                rec_id = str(payload.get("id", ""))
                issued = self.engine.license_mgr.delete_issued_license(rec_id)
                return self._json_response(200, {"ok": True, "issued_licenses": issued})

            if method == "POST" and path == "/api/start":
                self._hot_reload_engine_code()
                if not self.check_playwright_installed():
                    return self._json_response(
                        400,
                        {
                            "ok": False,
                            "message": "Playwright belum terinstal. Jalankan ./run.sh untuk menginstal dependensi otomatis.",
                        },
                    )
                payload = json.loads(body.decode("utf-8") or "{}")
                if "config" in payload and isinstance(payload["config"], dict):
                    self.update_config(payload["config"])
                retry_failed = bool(payload.get("retry_failed_only", False))

                if self.engine.is_running and self._batch_task is not None and self._batch_task.done():
                    self.engine.is_running = False

                if self.engine.is_running:
                    return self._json_response(
                        400, {"ok": False, "message": "Mesin robot sudah berjalan."}
                    )
                self._batch_task = asyncio.create_task(
                    self.engine.run_batch(self.config, retry_failed_only=retry_failed)
                )
                return self._json_response(200, {"ok": True, "message": "Mesin CKG Turbo dimulai!"})

            if method == "POST" and path == "/api/pause":
                if self.engine.is_paused:
                    # Resuming: clear session_expired and hot-reload latest storage_state.json into workers
                    self.engine.trigger_session_hot_reload(auto_resume=True)
                    self.engine.is_paused = False
                    st = "DILANJUTKAN (Sesi Diperbarui)"
                else:
                    self.engine.is_paused = True
                    st = "DIPAUSE"
                self.append_log(f"⏸️ Status eksekusi: {st}", "warning")
                return self._json_response(
                    200,
                    {
                        "ok": True,
                        "is_paused": self.engine.is_paused,
                        "session_expired": self.engine.session_expired,
                    },
                )

            if method == "POST" and path == "/api/stop":
                self.engine.stop_requested = True
                self.engine.is_paused = False
                self.append_log("🛑 Permintaan STOP diterima. Menghentikan worker dengan aman...", "warning")
                return self._json_response(200, {"ok": True})

            if method == "POST" and path == "/api/reset-checkpoints":
                if self.engine.current_file_key:
                    self.state_db.clear_checkpoints(self.engine.current_file_key, preserve_tickets=True)
                for s in self.engine.students:
                    s.state = "pending"
                    s.status_sistem = (
                        f"Siap Diselesaikan (Fast-Track Tiket {s.no_tiket})"
                        if (s.no_tiket and s.no_tiket != "-")
                        else "-"
                    )
                    s.status_rapor = "-"
                    s.tatalaksana = "-"
                    s.last_step = (
                        "Fast-Track langsung ke Menu Pelayanan"
                        if (s.no_tiket and s.no_tiket != "-")
                        else ""
                    )
                self.append_log(
                    "🔄 Status antrean siswa di-reset ke Menunggu (Nomor Tiket tetap disimpan untuk Fast-Track).",
                    "info",
                )
                return self._json_response(200, {"ok": True})

            return self._json_response(404, {"ok": False, "message": f"Endpoint {path} tidak ditemukan"})
        except Exception as exc:
            self.append_log(f"❌ API Error ({path}): {exc}", "error")
            return self._json_response(500, {"ok": False, "message": str(exc)})

    @staticmethod
    def _json_response(status: int, data: Any) -> Tuple[int, Dict[str, str], bytes]:
        raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
        return (
            status,
            {
                "Content-Type": "application/json; charset=utf-8",
                "Cache-Control": "no-store",
                "X-Frame-Options": "DENY",
                "X-Content-Type-Options": "nosniff",
                "Referrer-Policy": "no-referrer",
            },
            raw,
        )


async def _handle_client(
    app: DashboardApp, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
) -> None:
    """Built-in lightweight async HTTP/1.1 handler so the dashboard runs even without uvicorn."""
    try:
        req_line = await asyncio.wait_for(reader.readline(), timeout=15.0)
        if not req_line:
            writer.close()
            return
        parts = req_line.decode("latin-1").strip().split(" ")
        if len(parts) < 2:
            writer.close()
            return
        method, raw_target = parts[0].upper(), parts[1]
        parsed_url = urllib.parse.urlsplit(raw_target)
        path = parsed_url.path or "/"
        query = urllib.parse.parse_qs(parsed_url.query)

        headers: Dict[str, str] = {}
        while True:
            hline = await asyncio.wait_for(reader.readline(), timeout=10.0)
            if not hline or hline in (b"\r\n", b"\n"):
                break
            decoded = hline.decode("latin-1").strip()
            if ":" in decoded:
                k, v = decoded.split(":", 1)
                headers[k.strip().lower()] = v.strip()

        content_length = int(headers.get("content-length", "0"))
        body = b""
        if content_length > 0:
            body = await asyncio.wait_for(reader.readexactly(content_length), timeout=60.0)

        status, resp_headers, resp_body = await app.handle_api_request(
            method, path, query, headers, body
        )

        status_text = {
            200: "OK",
            204: "No Content",
            400: "Bad Request",
            403: "Forbidden",
            404: "Not Found",
            500: "Internal Server Error",
        }.get(status, "OK")

        resp_headers["Content-Length"] = str(len(resp_body))
        resp_headers["Connection"] = "close"

        header_lines = [f"HTTP/1.1 {status} {status_text}\r\n"]
        for hk, hv in resp_headers.items():
            header_lines.append(f"{hk}: {hv}\r\n")
        header_lines.append("\r\n")

        writer.write("".join(header_lines).encode("latin-1") + resp_body)
        await writer.drain()
    except Exception:
        pass
    finally:
        try:
            writer.close()
            await writer.wait_closed()
        except Exception:
            pass


async def run_server(
    host: str = "127.0.0.1",
    port: int = 8765,
    open_browser: bool = True,
    base_dir: Optional[str | Path] = None,
) -> None:
    app = DashboardApp(base_dir=base_dir)
    server = await asyncio.start_server(
        lambda r, w: _handle_client(app, r, w),
        host=host,
        port=port,
        reuse_address=True,
    )
    url = f"http://{host}:{port}"
    print(f"\n=======================================================")
    print(f"🚀 CKG SEKOLAH V3.2 PRO (SAAS EDITION) — DASHBOARD AKTIF")
    print(f"🌐 URL Dashboard : {url}")
    print(f"🏥 Faskes Aktif  : {app.engine.active_faskes}")
    print(f"💻 Platform      : {platform.system()} {platform.release()} ({platform.machine()})")
    print(f"=======================================================\n")

    if open_browser:
        try:
            webbrowser.open(url)
        except Exception:
            pass

    async with server:
        await server.serve_forever()
