from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class JobConfig:
    """Configuration for a CKG Sekolah / CKG Umum automation batch run."""

    # Service Program Type:
    # "sekolah" = CKG Anak Sekolah (33 Kolom)
    # "umum"    = CKG Umum Dewasa & Lansia (37 Kolom)
    service_type: str = "sekolah"

    # Workflow mode:
    # "C" = Full Paripurna (Pendaftaran + Konfirmasi Hadir + Skrining Mandiri + Pelayanan Nakes)
    # "A" = Pendaftaran & Konfirmasi Hadir saja
    # "B" = Skrining Mandiri saja
    # "D" = Sniper Mode (Pelayanan Nakes & Form Incaran)
    mode: str = "C"

    # Execution & Background settings
    headless: bool = True
    workers: int = 1  # Default 1 isolated context worker for maximum Kemenkes stability (configurable 1..4)
    block_media: bool = True

    # Core workflow toggles (matching V2.6 capabilities)
    auto_selesai: bool = True
    kirim_rapor: bool = True
    auto_retry_failed: bool = True
    update_data_lama: bool = False
    lewati_skrining: bool = False
    alamat_sekolah: bool = True
    cari_by_tiket: bool = False

    # Registration sub-modes
    mode_bypass: bool = False          # Lewati daftar baru, langsung ke pelayanan/konfirmasi
    mode_booking: bool = False         # Hanya daftar baru (booking), belum konfirmasi hadir
    mode_proses_booking: bool = False  # Hanya konfirmasi hadir untuk siswa yang sudah booking

    # Sniper / Nakes specific form toggles
    is_telinga_mata: bool = True
    is_gigi: bool = True
    is_kulit: bool = True
    is_tb: bool = True
    is_ppok: bool = False
    is_kebugaran: bool = False
    is_co: bool = False
    is_malaria: bool = False
    is_hepatitis: bool = False
    is_anemia: bool = False

    # CKG Umum specific clinical toggles
    is_gizi_umum: bool = True
    is_tensi_umum: bool = True
    is_gds_umum: bool = True
    is_lipid_umum: bool = True
    is_payudara_umum: bool = True
    is_leher_rahim_umum: bool = True
    is_ekg_umum: bool = False

    @property
    def skip_mandiri(self) -> bool:
        return self.lewati_skrining

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "JobConfig":
        valid_keys = {f.name for f in cls.__dataclass_fields__.values()}
        filtered = {k: v for k, v in data.items() if k in valid_keys}
        if "workers" in filtered:
            filtered["workers"] = max(1, min(4, int(filtered["workers"])))
        return cls(**filtered)


@dataclass
class DataQualitySummary:
    """Pre-flight validation & auto-healing report for uploaded Excel files."""

    service_type: str = "sekolah"
    format_detected: str = "V2.6 Legacy (33 Kolom)"
    total_rows: int = 0
    valid_rows: int = 0
    healed_wa_count: int = 0
    healed_date_count: int = 0
    healed_school_count: int = 0
    healed_numeric_count: int = 0
    invalid_nik_count: int = 0
    missing_dob_count: int = 0
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class StudentRecord:
    """Normalized representation of a CKG Sekolah student row (supports V2.6 33-col & Smart Pro V3)."""

    row_index: int
    nik: str = ""
    nama: str = ""
    tgl_lahir_mentah: str = ""
    target_tahun: str = ""
    target_bulan_teks: str = ""
    target_bulan_idx: int = 0
    target_tanggal: str = ""
    tgl_iso: str = ""
    umur: int = 10
    jk_mentah: str = ""
    jk_pasien: str = "Laki-laki"
    wa_mentah: str = ""
    wa_pasien: str = ""
    nama_sekolah: str = ""
    nama_sekolah_bersih: str = ""
    sekolah_candidates: List[str] = field(default_factory=list)
    kelas_mentah: str = ""
    kelas: str = ""
    kelas_angka: str = ""
    provinsi: str = ""
    kabkota: str = ""
    kecamatan: str = ""
    desa: str = ""
    detail_alamat: str = ""

    # Screening & clinical columns (iloc 12..32)
    batuk_tb: str = "tidak"
    keputihan_putri: str = "tidak"
    perilaku_merokok: str = "tidak"
    aktivitas_fisik: str = "tidak"
    berat: str = ""
    tinggi: str = ""
    riwayat_dm: str = "tidak"
    lama_dm: str = ""
    gds: str = ""
    sistolik: str = ""
    diastolik: str = ""
    curiga_katarak: str = "normal"
    visus_mentah: str = "normal"
    kacamata_mentah: str = "tidak"
    serumen_mentah: str = "normal"
    gigi_karies: str = "Tidak"
    kadar_co_mentah: str = ""
    malaria_mentah: str = ""
    hepb_mentah: str = ""
    hepc_mentah: str = ""
    hb_anemia_mentah: str = ""

    # CKG Umum (37-Column Data_Siap_CKG) specific fields
    service_type: str = "sekolah"
    tgl_pemeriksaan: str = ""
    status_pernikahan: str = "Menikah"
    pekerjaan: str = "Lainnya"
    riwayat_hubungan_intim: str = "Ya"
    lingkar_perut: str = ""
    riwayat_hipertensi: str = "Tidak"
    lama_hipertensi: str = ""
    gigi_hilang: str = "Tidak"
    skrining_payudara: str = ""
    hb_catin: str = ""
    kolesterol_total: str = ""
    hdl: str = ""
    ldl: str = ""
    trigliserida: str = ""
    hasil_ekg: str = ""

    # Pre-flight validation notes for this student
    healed_notes: List[str] = field(default_factory=list)
    validation_warning: str = ""

    # Output tracking fields
    status_sistem: str = "-"
    status_rapor: str = "-"
    tatalaksana: str = "-"
    no_tiket: str = "-"
    state: str = "pending"  # pending | running | success | warning | failed | skipped
    worker_id: Optional[int] = None
    last_step: str = ""
    updated_at: str = ""

    def to_summary_dict(self) -> Dict[str, Any]:
        return {
            "row_index": self.row_index,
            "service_type": self.service_type,
            "nik": self.nik,
            "nama": self.nama,
            "tgl_lahir": self.tgl_iso or self.tgl_lahir_mentah,
            "umur": self.umur,
            "jk": self.jk_pasien,
            "wa": self.wa_pasien,
            "sekolah": self.nama_sekolah_bersih or self.nama_sekolah,
            "kelas": self.kelas,
            "tgl_pemeriksaan": self.tgl_pemeriksaan,
            "status_pernikahan": self.status_pernikahan,
            "pekerjaan": self.pekerjaan,
            "desa": self.desa,
            "detail_alamat": self.detail_alamat,
            "berat": self.berat,
            "tinggi": self.tinggi,
            "lingkar_perut": self.lingkar_perut,
            "gds": self.gds,
            "kolesterol_total": self.kolesterol_total,
            "tensi": f"{self.sistolik}/{self.diastolik}" if self.sistolik and self.diastolik else "-",
            "riwayat_hipertensi": self.riwayat_hipertensi,
            "riwayat_dm": self.riwayat_dm,
            "gigi_karies": self.gigi_karies,
            "gigi_hilang": self.gigi_hilang,
            "skrining_payudara": self.skrining_payudara,
            "healed_notes": self.healed_notes,
            "validation_warning": self.validation_warning,
            "status_sistem": self.status_sistem,
            "status_rapor": self.status_rapor,
            "tatalaksana": self.tatalaksana,
            "no_tiket": self.no_tiket,
            "state": self.state,
            "worker_id": self.worker_id,
            "last_step": self.last_step,
            "updated_at": self.updated_at,
        }
