#!/usr/bin/env python3
"""
Entry point for CKG Sekolah V3.0 Turbo — Cross-Platform Background Engine.
Can be run directly on Windows, macOS, and Linux:
    python main.py [--host 127.0.0.1] [--port 8765] [--no-browser]
"""
from __future__ import annotations

import argparse
import asyncio
import ctypes
import os
import platform
import signal
import socket
import subprocess
import time
from pathlib import Path
from typing import Optional

from ckg_turbo.server import run_server


def _acquire_system_wake_lock() -> Optional[subprocess.Popen]:
    """
    Prevent macOS / Windows / Linux from entering System Idle Sleep while CKG Sekolah is running,
    even if the user turns off the monitor (Screen Off) or locks the screen (Lock Screen).
    """
    sys_name = platform.system()
    try:
        if sys_name == "Darwin":
            # caffeinate -ims -w <pid>: prevents idle/disk/system sleep and auto-exits with this PID
            return subprocess.Popen(
                ["caffeinate", "-ims", "-w", str(os.getpid())],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        if sys_name == "Windows":
            # ES_CONTINUOUS (0x80000000) | ES_SYSTEM_REQUIRED (0x00000001) | ES_AWAYMODE_REQUIRED (0x00000040)
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000041)
    except Exception:
        pass
    return None


def _free_port_if_occupied(host: str, port: int) -> None:
    """Ensure any previous server process holding the dashboard port is cleanly stopped."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.3)
        if s.connect_ex((host, port)) != 0:
            return
    try:
        out = subprocess.check_output(["lsof", "-ti", f"tcp:{port}"], text=True).strip()
        my_pid = os.getpid()
        for line in out.splitlines():
            pid = int(line.strip())
            if pid != my_pid:
                os.kill(pid, signal.SIGTERM)
        time.sleep(0.5)
    except Exception:
        pass


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="CKG Sekolah V3.0 Turbo — Multi-Tab Headless Background Automation"
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host address to bind (default: 127.0.0.1, use 0.0.0.0 for LAN access)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8765,
        help="Port number for the Web Dashboard (default: 8765)",
    )
    parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Do not automatically open the Web Dashboard in the default browser",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    base_dir = Path(__file__).resolve().parent
    try:
        if os.isatty(0):
            devnull_fd = os.open(os.devnull, os.O_RDONLY)
            os.dup2(devnull_fd, 0)
            os.close(devnull_fd)
    except Exception:
        pass
    _free_port_if_occupied(args.host, args.port)
    wake_proc = _acquire_system_wake_lock()
    try:
        asyncio.run(
            run_server(
                host=args.host,
                port=args.port,
                open_browser=not args.no_browser,
                base_dir=base_dir,
            )
        )
    except KeyboardInterrupt:
        print("\n👋 Server CKG Sekolah V3.0 Turbo dihentikan.")
    finally:
        if wake_proc is not None:
            try:
                wake_proc.terminate()
            except Exception:
                pass


if __name__ == "__main__":
    main()

