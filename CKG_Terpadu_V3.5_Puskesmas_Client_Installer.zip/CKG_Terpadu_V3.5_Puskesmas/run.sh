#!/usr/bin/env bash
set -e

cd "$(dirname "$0")"

# Prefer Python interpreter that already has openpyxl installed, or create .venv
PYTHON_BIN=""
for candidate in ".venv/bin/python" "/opt/homebrew/bin/python3.14" "/opt/homebrew/bin/python3.12" "/opt/homebrew/bin/python3" "python3"; do
  if command -v "$candidate" >/dev/null 2>&1; then
    PYTHON_BIN="$candidate"
    break
  fi
done

if [ -z "$PYTHON_BIN" ]; then
  echo "❌ Python 3 tidak ditemukan. Silakan instal Python 3.10+ terlebih dahulu."
  exit 1
fi

# Create virtualenv if openpyxl or playwright is missing
if ! "$PYTHON_BIN" -c "import openpyxl, playwright" >/dev/null 2>&1; then
  echo "📦 Menyiapkan virtual environment (.venv) dan menginstal dependensi..."
  if [ ! -d ".venv" ]; then
    "$PYTHON_BIN" -m venv .venv
  fi
  PYTHON_BIN=".venv/bin/python"
  "$PYTHON_BIN" -m pip install --upgrade pip
  "$PYTHON_BIN" -m pip install -r requirements.txt
  "$PYTHON_BIN" -m playwright install chromium
fi

exec "$PYTHON_BIN" main.py "$@"

