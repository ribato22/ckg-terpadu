@echo off
title CKG Terpadu V3.5 Clinical Pro - Instalasi & Jalankan Otomatis
cd /d "%~dp0"

echo ============================================================================
echo   CKG TERPADU V3.5 CLINICAL PRO (SEKOLAH ^& UMUM) - PUSKESMAS EDITION
echo ============================================================================
echo.

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [!] Python 3 belum terinstal di komputer Windows ini.
    echo [*] Membuka halaman unduhan Python 3.12 resmi...
    echo [*] PENTING: Saat instal Python, wajib centang "Add Python to PATH" di bagian bawah!
    start https://www.python.org/downloads/windows/
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo [*] Menyiapkan mesin CKG Terpadu untuk pertama kali (1-3 menit)...
    python -m venv .venv
    .venv\Scripts\python.exe -m pip install --upgrade pip
    .venv\Scripts\python.exe -m pip install -r requirements.txt
    echo [*] Mengunduh browser otomatis Chromium untuk SatuSehat...
    .venv\Scripts\python.exe -m playwright install chromium
)

echo [*] Membuka Dashboard CKG Terpadu V3.5 di Browser...
.venv\Scripts\python.exe main.py
pause
