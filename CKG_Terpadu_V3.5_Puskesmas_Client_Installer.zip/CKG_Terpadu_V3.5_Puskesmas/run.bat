@echo off
title CKG Sekolah V3.0 Turbo - Sehat Indonesiaku Background Engine
cd /d "%~dp0"

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [!] Python 3 belum terinstal di Windows ini. Silakan instal Python 3.10+ dari python.org
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo [*] Menyiapkan environment Python (.venv) untuk pertama kali...
    python -m venv .venv
    .venv\Scripts\python.exe -m pip install --upgrade pip
    .venv\Scripts\python.exe -m pip install -r requirements.txt
    .venv\Scripts\python.exe -m playwright install chromium
)

echo [*] Menjalankan CKG Sekolah V3.0 Turbo Web Dashboard...
.venv\Scripts\python.exe main.py
pause

