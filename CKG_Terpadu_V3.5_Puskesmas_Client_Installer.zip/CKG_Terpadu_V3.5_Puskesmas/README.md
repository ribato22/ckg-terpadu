# ⚡ CKG Sekolah V3.0 Turbo — Cross-Platform Background Engine

Versi modern, jauh lebih cepat, teliti, dan berjalan **100% di latar belakang (Headless Background)** dari **Robot Input CKG Sekolah V2.6**, dirancang untuk berjalan di **macOS (MacBook Intel & Apple Silicon), Windows, dan Linux**.

---

## 🔍 Hasil Analisis Reverse Engineering (`Robot Input CKG Sekolah V2.6.exe`)

| Aspek | Versi Lama (`V2.6.exe`) | Versi Baru (`V3.0 Turbo`) |
| :--- | :--- | :--- |
| **Platform** | Hanya Windows (`PE32+ x86_64`, PyInstaller 119,6 MB) | **Cross-Platform** (Windows, macOS, Linux, LAN/Docker) |
| **Mode Jalan** | Memaksa `headless=False` & `--start-maximized` (mengganggu layar utama) | **100% Headless Background** + fitur **Live Background Peek** di Dashboard |
| **Sesi Login** | Harus login ulang setiap kali aplikasi dibuka | **Persistent Session (`storage_state.json`)** — Login sekali, jalan terus di background |
| **Kecepatan** | 1 Tab sekuensial + **206 `wait_for_timeout` statis** (total definisi delay 161,2 detik) | **Multi-Tab Paralel (1–4 Worker)** + **0 Sleep Statis** (Event-Driven DOM & Atomic JS) |
| **Ketelitian Form** | Klik radio/dropdown satu per satu via IPC Playwright | **Evaluasi DOM Atomik (`page.evaluate`)** + **Smart Sensor Tukar Tanggal/Bulan Dukcapil** |
| **Keamanan Data** | Hanya simpan Excel di akhir (rawan hilang bila mati lampu/hang) | **SQLite Auto-Checkpoint per Siswa** + **Live Report Excel Export** kapan saja |
| **Penguncian Faskes** | Terkunci pada 1 nama Puskesmas/Faskes | **Bebas Faskes (Universal)** — Bisa digunakan di akun Kemenkes mana saja |

---

## 🚀 Cara Menjalankan Aplikasi

### 1. Di macOS (MacBook) / Linux
Klik dua kali file **`Jalankan_CKG_Turbo.command`** di Finder, atau jalankan dari Terminal:
```bash
chmod +x run.sh Jalankan_CKG_Turbo.command
./run.sh
```
Untuk menjalankan langsung dengan Python yang sudah terinstal (tanpa instalasi ulang bila `openpyxl` sudah tersedia):
```bash
/opt/homebrew/bin/python3.14 main.py
```

### 2. Di Windows
Klik dua kali file **`run.bat`**, atau jalankan dari Command Prompt / PowerShell:
```bat
run.bat
```

Dashboard akan otomatis terbuka di browser pada alamat:
👉 **`http://127.0.0.1:8765`**

---

## 📋 Format 33 Kolom Excel (100% Kompatibel dengan V2.6)

Aplikasi ini membaca persis urutan **33 kolom (`iloc[0..32]`)** dari file Excel CKG Sekolah V2.6 (Anda juga dapat mengunduh template resminya langsung lewat tombol **📥 Template 33 Kolom** di Dashboard):

1. `NIK` *(Kolom A)*
2. `Nama Lengkap` *(Kolom B)*
3. `Tanggal Lahir` *(Kolom C — mendukung berbagai format tanggal & nama bulan Indonesia, dilengkapi Smart Sensor penukar tanggal/bulan bila ditolak Dukcapil)*
4. `Jenis Kelamin` *(Kolom D — L/P, Laki-laki/Perempuan)*
5. `No WhatsApp` *(Kolom E)*
6. `Nama Sekolah` *(Kolom F — otomatis menormalisasi singkatan `SDN` -> `SD NEGERI`, `SMPN` -> `SMP NEGERI`, dst.)*
7. `Kelas` *(Kolom G — angka/teks otomatis menjadi `Kelas X`)*
8. `Provinsi` *(Kolom H)*
9. `Kab/Kota` *(Kolom I)*
10. `Kecamatan` *(Kolom J)*
11. `Desa/Kelurahan` *(Kolom K)*
12. `Detail Alamat` *(Kolom L)*
13. `Batuk TB` *(Kolom M)*
14. `Keputihan (Putri)` *(Kolom N)*
15. `Perilaku Merokok` *(Kolom O)*
16. `Aktivitas Fisik` *(Kolom P)*
17. `Berat Badan (kg)` *(Kolom Q)*
18. `Tinggi Badan (cm)` *(Kolom R)*
19. `Riwayat DM` *(Kolom S)*
20. `Lama DM (Bulan)` *(Kolom T)*
21. `GDS (mg/dL)` *(Kolom U)*
22. `Sistolik (mmHg)` *(Kolom V)*
23. `Diastolik (mmHg)` *(Kolom W)*
24. `Curiga Katarak/Kelainan Mata` *(Kolom X)*
25. `Visus Mata` *(Kolom Y)*
26. `Kacamata` *(Kolom Z)*
27. `Serumen/Pendengaran` *(Kolom AA)*
28. `Gigi Karies` *(Kolom AB)*
29. `Kadar CO` *(Kolom AC)*
30. `Malaria` *(Kolom AD)*
31. `Hepatitis B` *(Kolom AE)*
32. `Hepatitis C` *(Kolom AF)*
33. `Hb / Anemia` *(Kolom AG)*

Kolom hasil yang otomatis disisipkan pada laporan akhir (`Report_CKG_<Sekolah>_<Waktu>.xlsx`):
- **`Status Sistem`** (Hijau `#059669` untuk Sukses Paripurna, Merah `#FF0000` untuk Gagal)
- **`Status Rapor`** (`Sukses 3/3`)
- **`Tatalaksana`** (`Aman (Tidak Ada Tindakan)` atau merah menyala `Harus tatalaksana`)
- **`No Tiket`** (Hasil tangkapan Jaring 1 pop-up pendaftaran & Jaring 2 halaman rekam medis)

